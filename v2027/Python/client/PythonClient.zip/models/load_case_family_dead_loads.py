from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case_family import LoadCaseFamily
    from .load_case_family_dead_loads_coefficients import LoadCaseFamilyDeadLoadsCoefficients

from .load_case_family import LoadCaseFamily

@dataclass
class LoadCaseFamily_DeadLoads(LoadCaseFamily, AdditionalDataHolder, Parsable):
    """
    Dead loads case family (self weight), load case parent
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Specific dead load (self weight) favourable / unfavorable partial safety factors stored on the gravity actor.All coefficients are dimensionless (unit: -).Default values (Eurocode persistent/transient design):GammaFavEQU = 0.9 (stabilizing permanent action EQU)GammaDefavEQU = 1.1 (destabilizing permanent action EQU)GammaFavSTRGEO = 1.0 (favourable permanent action STR/GEO)GammaDefavSTRGEO = 1.35 (unfavourable permanent action STR/GEO)GammaFavGEO = 1.0 (favourable permanent action GEO)GammaDefavGEO = 1.35 (unfavourable permanent action GEO)Set to null to allow engine defaults per national annex / standard.
    dead_loads_coefficients: Optional[LoadCaseFamilyDeadLoadsCoefficients] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily_DeadLoads:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily_DeadLoads
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseFamily_DeadLoads()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case_family import LoadCaseFamily
        from .load_case_family_dead_loads_coefficients import LoadCaseFamilyDeadLoadsCoefficients

        from .load_case_family import LoadCaseFamily
        from .load_case_family_dead_loads_coefficients import LoadCaseFamilyDeadLoadsCoefficients

        fields: dict[str, Callable[[Any], None]] = {
            "deadLoadsCoefficients": lambda n : setattr(self, 'dead_loads_coefficients', n.get_object_value(LoadCaseFamilyDeadLoadsCoefficients)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("deadLoadsCoefficients", self.dead_loads_coefficients)
        writer.write_additional_data_value(self.additional_data)
    

