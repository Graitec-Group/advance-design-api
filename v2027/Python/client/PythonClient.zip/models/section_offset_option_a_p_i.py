from enum import Enum

class SectionOffsetOption_API(str, Enum):
    Topleft = "topleft",
    Gauche_centre = "gauche_centre",
    Gauche_bas = "gauche_bas",
    Centre_haut = "centre_haut",
    Center_alignment = "center_alignment",
    Centre_bas = "centre_bas",
    Droite_haut = "droite_haut",
    Droite_centre = "droite_centre",
    Droite_bas = "droite_bas",
    Autre = "autre",

