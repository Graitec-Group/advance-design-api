from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_base import ElementBase
    from .e_i_d import EID
    from .planar_element_mesh_properties import PlanarElementMeshProperties
    from .planar_element_type import PlanarElementType
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class ElementPlanar(ElementBase, AdditionalDataHolder, Parsable):
    """
    The planar element class (i.e. slab , shell, etc.)
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .planar_element_type import PlanarElementType

    # element typeDefault value : PlanarElementType.shell
    element_type: Optional[PlanarElementType] = PlanarElementType("shell")
    # eccentricity of element;Unit: mDefault value : 0.0
    eccentricity: Optional[float] = None
    # Decide whether or not the offset is taken into account in the FEM calculation.Default value : false
    eccentricity_c_onsidered_also_for_f_e_m: Optional[bool] = None
    # geometry defined by 3D point list defined in global axis system, can't be empty, the object will not be created
    geom_pts_list: Optional[list[Pt3D]] = None
    # EID of the material already created, if it is 0 the object is not created
    material: Optional[EID] = None
    # Mesh propertiesDefault value : optional nullable object
    mesh_properties: Optional[PlanarElementMeshProperties] = None
    # Definition of variable thickness by slope (tangent of the angle of inclination) in local x axis directionUnit: no unitDefault value : 0.0
    slope_x: Optional[float] = None
    # Definition of variable thickness by slope (tangent of the angle of inclination) in local y axis directionUnit: no unitDefault value : 0.0
    slope_y: Optional[float] = None
    # Act as Supporting element for load areasDefault value : true
    supporting_element: Optional[bool] = None
    # Thickness in 1st vertex;Unit: mDefault value : 0.2
    thickness_in1st_vertex: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementPlanar:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementPlanar
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementPlanar()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_base import ElementBase
        from .e_i_d import EID
        from .planar_element_mesh_properties import PlanarElementMeshProperties
        from .planar_element_type import PlanarElementType
        from .pt3_d import Pt3D

        from .element_base import ElementBase
        from .e_i_d import EID
        from .planar_element_mesh_properties import PlanarElementMeshProperties
        from .planar_element_type import PlanarElementType
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "eccentricity": lambda n : setattr(self, 'eccentricity', n.get_float_value()),
            "eccentricityCOnsideredAlsoForFEM": lambda n : setattr(self, 'eccentricity_c_onsidered_also_for_f_e_m', n.get_bool_value()),
            "elementType": lambda n : setattr(self, 'element_type', n.get_enum_value(PlanarElementType)),
            "geomPtsList": lambda n : setattr(self, 'geom_pts_list', n.get_collection_of_object_values(Pt3D)),
            "material": lambda n : setattr(self, 'material', n.get_object_value(EID)),
            "meshProperties": lambda n : setattr(self, 'mesh_properties', n.get_object_value(PlanarElementMeshProperties)),
            "slopeX": lambda n : setattr(self, 'slope_x', n.get_float_value()),
            "slopeY": lambda n : setattr(self, 'slope_y', n.get_float_value()),
            "supportingElement": lambda n : setattr(self, 'supporting_element', n.get_bool_value()),
            "thicknessIn1stVertex": lambda n : setattr(self, 'thickness_in1st_vertex', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("eccentricity", self.eccentricity)
        writer.write_bool_value("eccentricityCOnsideredAlsoForFEM", self.eccentricity_c_onsidered_also_for_f_e_m)
        writer.write_enum_value("elementType", self.element_type)
        writer.write_collection_of_object_values("geomPtsList", self.geom_pts_list)
        writer.write_object_value("material", self.material)
        writer.write_object_value("meshProperties", self.mesh_properties)
        writer.write_float_value("slopeX", self.slope_x)
        writer.write_float_value("slopeY", self.slope_y)
        writer.write_bool_value("supportingElement", self.supporting_element)
        writer.write_float_value("thicknessIn1stVertex", self.thickness_in1st_vertex)
        writer.write_additional_data_value(self.additional_data)
    

