from enum import Enum

class LogVerboseLevel(str, Enum):
    Errors = "Errors",
    ErrorsAndWarnings = "ErrorsAndWarnings",
    AllDetails = "AllDetails",

