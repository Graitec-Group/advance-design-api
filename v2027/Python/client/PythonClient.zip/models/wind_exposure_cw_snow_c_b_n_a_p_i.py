from enum import Enum

class WindExposureCw_SnowCBN_API(str, Enum):
    SNOWCBNSn2010_CW_1 = "SNOWCBNSn2010_CW_1",
    SNOWCBNSn2010_CW_075 = "SNOWCBNSn2010_CW_075",
    SNOWCBNSn2010_CW_05 = "SNOWCBNSn2010_CW_05",

