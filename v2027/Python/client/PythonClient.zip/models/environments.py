from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .language_code import Language_Code
    from .localization_code import Localization_Code
    from .log_verbose_level import LogVerboseLevel

@dataclass
class Environments(Parsable):
    """
    Environment settings
    """
    # Language used in environment
    language: Optional[Language_Code] = None
    # Localization setting for norms and regulations
    localization: Optional[Localization_Code] = None
    # Verbosity level for engine log output in API responses.Level 1: Errors only. Level 2: Errors and Warnings. Level 3: All details.Default is ErrorsAndWarnings (2).<p>Possible values:</p><ul><li><b>1 - Errors</b>: Level 1: Only errors are included in the API response diagnostics.</li><li><b>2 - ErrorsAndWarnings</b>: Level 2: Errors and warnings are included in the API response diagnostics.</li><li><b>3 - AllDetails</b>: Level 3: All details (errors, warnings, and informational messages) are included.</li></ul>
    log_verbosity: Optional[LogVerboseLevel] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Environments:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Environments
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Environments()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .language_code import Language_Code
        from .localization_code import Localization_Code
        from .log_verbose_level import LogVerboseLevel

        from .language_code import Language_Code
        from .localization_code import Localization_Code
        from .log_verbose_level import LogVerboseLevel

        fields: dict[str, Callable[[Any], None]] = {
            "language": lambda n : setattr(self, 'language', n.get_enum_value(Language_Code)),
            "localization": lambda n : setattr(self, 'localization', n.get_enum_value(Localization_Code)),
            "logVerbosity": lambda n : setattr(self, 'log_verbosity', n.get_enum_value(LogVerboseLevel)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("language", self.language)
        writer.write_enum_value("localization", self.localization)
        writer.write_enum_value("logVerbosity", self.log_verbosity)
    

