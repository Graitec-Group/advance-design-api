from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .detailed_mesh_on_segment import DetailedMeshOnSegment
    from .planar_mesh_density import PlanarMeshDensity
    from .planar_mesh_type import PlanarMeshType

@dataclass
class PlanarElementMeshProperties(Parsable):
    """
    Planar element mesh properies
    """
    from .planar_mesh_density import PlanarMeshDensity

    # Selecting a method for defining mesh density. The following options are available:- Global: the mesh element density is defined according to the global mesh settings- Simplified: define the number of meshes on x and y local axis directions- Detailed: define the meshing for each edge of the planar element- Element size: define the size of a mesh elementDefault value : PlanarMeshDensity.global
    mesh_density: Optional[PlanarMeshDensity] = PlanarMeshDensity("global")
    from .planar_mesh_type import PlanarMeshType

    # Meshing style of the element. Three options are available:- Complete: performs a complete meshing of the element by the global mesh algorithm, defined in the Mesh options dialog box- Triangulation: creates a triangular meshing with nodes on the sides of the planar element, using the global mesh algorithm- None: The element is not meshed, the nodes are created at each vertexDefault value : PlanarMeshType.complete
    mesh_type: Optional[PlanarMeshType] = PlanarMeshType("complete")
    # Enable automatic meshDefault value : true
    automatic_mesh: Optional[bool] = None
    # used if MeshDensity is detailed, consists of a list with the same size as the sides of the geometry polyDefault value : can be empty if MeshDensity is not detailed else it should have the same number of DetailedMeshOnSegment in the list as the number of points in the geometry list
    detailed_mesh_style_per_edge: Optional[list[DetailedMeshOnSegment]] = None
    # used if MeshDensity is element_size,Unit: mDefault value : 1.0
    mesh_element_size: Optional[float] = None
    # used if MeshDensity is simplified, number of meshes in the x direction of the local element systemDefault value : 0
    mesh_no_in_x_dir_in_local: Optional[int] = None
    # used if MeshDensity is simplified, number of meshes in the y direction of the local element systemDefault value : 0
    mesh_no_in_y_dir_in_local: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PlanarElementMeshProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PlanarElementMeshProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PlanarElementMeshProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .detailed_mesh_on_segment import DetailedMeshOnSegment
        from .planar_mesh_density import PlanarMeshDensity
        from .planar_mesh_type import PlanarMeshType

        from .detailed_mesh_on_segment import DetailedMeshOnSegment
        from .planar_mesh_density import PlanarMeshDensity
        from .planar_mesh_type import PlanarMeshType

        fields: dict[str, Callable[[Any], None]] = {
            "automaticMesh": lambda n : setattr(self, 'automatic_mesh', n.get_bool_value()),
            "detailedMeshStylePerEdge": lambda n : setattr(self, 'detailed_mesh_style_per_edge', n.get_collection_of_object_values(DetailedMeshOnSegment)),
            "meshDensity": lambda n : setattr(self, 'mesh_density', n.get_enum_value(PlanarMeshDensity)),
            "meshElementSize": lambda n : setattr(self, 'mesh_element_size', n.get_float_value()),
            "meshNoInXDirInLocal": lambda n : setattr(self, 'mesh_no_in_x_dir_in_local', n.get_int_value()),
            "meshNoInYDirInLocal": lambda n : setattr(self, 'mesh_no_in_y_dir_in_local', n.get_int_value()),
            "meshType": lambda n : setattr(self, 'mesh_type', n.get_enum_value(PlanarMeshType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("automaticMesh", self.automatic_mesh)
        writer.write_collection_of_object_values("detailedMeshStylePerEdge", self.detailed_mesh_style_per_edge)
        writer.write_enum_value("meshDensity", self.mesh_density)
        writer.write_float_value("meshElementSize", self.mesh_element_size)
        writer.write_int_value("meshNoInXDirInLocal", self.mesh_no_in_x_dir_in_local)
        writer.write_int_value("meshNoInYDirInLocal", self.mesh_no_in_y_dir_in_local)
        writer.write_enum_value("meshType", self.mesh_type)
    

