from enum import Enum

class GreenhouseClass_SnowNF_EC1_API(str, Enum):
    GREENHOUSE_CLASS_A = "GREENHOUSE_CLASS_A",
    GREENHOUSE_CLASS_B = "GREENHOUSE_CLASS_B",
    GREENHOUSE_CLASS_C = "GREENHOUSE_CLASS_C",

