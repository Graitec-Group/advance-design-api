from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class LoadCaseCombinationsCoefficients(Parsable):
    """
    Combinations coefficients for load case (Effect)
    """
    # Action lifetime (Immediate/Short-Term/Medium-Term/Long-Term/Permanent) Unit : - Default value : 0
    action_life_time: Optional[int] = None
    # Gamma coefficient for combinations EQU Unit : - Default value : 1.0
    gamma_coefficient: Optional[float] = None
    # Gamma coefficient for combinations GEO, only for Italy national annex Unit : - Default value : 1.0
    gamma_coefficient_g_e_o: Optional[float] = None
    # Gamma coefficient for combinations STR or STR/GEO Unit : - Default value : 1.0 
    gamma_coefficient_str: Optional[float] = None
    # /// Load case action type (Base,leading(0)/Accompanying(1)/Base,leading or Accompanying(2)) or (Favorable(0)/Unfavorable(1)/Favorable or Unfavorable(2) ) Unit : - Default value : eADActionTypeBaseAndAcco (2)
    load_case_action_type: Optional[int] = None
    # Psi0 coefficient for combinations Unit : - Default value : 1.0
    psi0_coefficient: Optional[float] = None
    # Psi1 coefficient for combinations Unit : - Default value : 1.0
    psi1_coefficient: Optional[float] = None
    # Psi2 coefficient for combinations Unit : - Default value : 1.0
    psi2_coefficient: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseCombinationsCoefficients:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseCombinationsCoefficients
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseCombinationsCoefficients()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "actionLifeTime": lambda n : setattr(self, 'action_life_time', n.get_int_value()),
            "gammaCoefficient": lambda n : setattr(self, 'gamma_coefficient', n.get_float_value()),
            "gammaCoefficientGEO": lambda n : setattr(self, 'gamma_coefficient_g_e_o', n.get_float_value()),
            "gammaCoefficientStr": lambda n : setattr(self, 'gamma_coefficient_str', n.get_float_value()),
            "loadCaseActionType": lambda n : setattr(self, 'load_case_action_type', n.get_int_value()),
            "psi0Coefficient": lambda n : setattr(self, 'psi0_coefficient', n.get_float_value()),
            "psi1Coefficient": lambda n : setattr(self, 'psi1_coefficient', n.get_float_value()),
            "psi2Coefficient": lambda n : setattr(self, 'psi2_coefficient', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("actionLifeTime", self.action_life_time)
        writer.write_float_value("gammaCoefficient", self.gamma_coefficient)
        writer.write_float_value("gammaCoefficientGEO", self.gamma_coefficient_g_e_o)
        writer.write_float_value("gammaCoefficientStr", self.gamma_coefficient_str)
        writer.write_int_value("loadCaseActionType", self.load_case_action_type)
        writer.write_float_value("psi0Coefficient", self.psi0_coefficient)
        writer.write_float_value("psi1Coefficient", self.psi1_coefficient)
        writer.write_float_value("psi2Coefficient", self.psi2_coefficient)
    

