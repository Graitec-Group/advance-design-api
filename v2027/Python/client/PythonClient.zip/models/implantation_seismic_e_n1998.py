from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .soil_class_e_n1998_a_p_i import SoilClassEN1998_API
    from .spectrum_type_a_p_i import SpectrumType_API
    from .topographic_category_n_t_c_a_p_i import TopographicCategoryNTC_API

@dataclass
class ImplantationSeismicEN1998(Parsable):
    """
    Implantation parameters for seismic EN 1998-1
    """
    from .soil_class_e_n1998_a_p_i import SoilClassEN1998_API

    # Soil class (ground type)Values: A, B, C, D, EDefault: depends on norm/annex
    soil_class: Optional[SoilClassEN1998_API] = SoilClassEN1998_API("C")
    from .spectrum_type_a_p_i import SpectrumType_API

    # Spectrum typeValues: 0=ELASTIC_1, 1=DESIGN_1, 2=ELASTIC_2, 3=DESIGN_2Default: DESIGN_1 (1)
    spectrum_type: Optional[SpectrumType_API] = SpectrumType_API("SPECTRE_DESIGN_1")
    from .topographic_category_n_t_c_a_p_i import TopographicCategoryNTC_API

    # Topographic category (NTC 2008/2018 only)Values: T1, T2, T3, T4Default: T1 (0)
    topographic_category: Optional[TopographicCategoryNTC_API] = TopographicCategoryNTC_API("T1")
    # Design ground acceleration (ag*gamma_I)Unit: dimensionless (g)Default: 0.08
    ag_rg: Optional[float] = None
    # Amplification factor F0 (NTC 2008/2018 only)Unit: dimensionlessDefault: 2.49
    amplification_factor_f0: Optional[float] = None
    # Contribution factor K (ES only)Unit: dimensionlessDefault: 1.0
    contribution_factor_k: Optional[float] = None
    # Latitude for site location (ES only)Unit: degreesDefault: 43.2
    latitude: Optional[float] = None
    # Longitude for site location (ES only)Unit: degreesDefault: -1.2
    longitude: Optional[float] = None
    # Modified construction indicator (FR only)Default: false
    modified_construction: Optional[bool] = None
    # Period Tc* (NTC 2008/2018 only)Unit: seconds (s)Default: 0.24
    period_tc_star: Optional[float] = None
    # Soil factor SUnit: dimensionlessDefault: calculated based on soil class
    s: Optional[float] = None
    # Topographic amplification coefficient ST (FR only)Unit: dimensionlessDefault: 1.0
    s_t_coef_amplif_topo: Optional[float] = None
    # Period Tb (lower limit of constant spectral acceleration branch)Unit: seconds (s)Default: calculated based on soil class
    tb_imposed_value: Optional[float] = None
    # Period Tc (upper limit of constant spectral acceleration branch)Unit: seconds (s)Default: calculated based on soil class
    tc_imposed_value: Optional[float] = None
    # Period Td (value defining beginning of constant displacement response range)Unit: seconds (s)Default: calculated based on soil class
    td_imposed_value: Optional[float] = None
    # Average shear wave velocity vs30 (ES only)Unit: m/sDefault: 0.138
    vs30: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ImplantationSeismicEN1998:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ImplantationSeismicEN1998
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ImplantationSeismicEN1998()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .soil_class_e_n1998_a_p_i import SoilClassEN1998_API
        from .spectrum_type_a_p_i import SpectrumType_API
        from .topographic_category_n_t_c_a_p_i import TopographicCategoryNTC_API

        from .soil_class_e_n1998_a_p_i import SoilClassEN1998_API
        from .spectrum_type_a_p_i import SpectrumType_API
        from .topographic_category_n_t_c_a_p_i import TopographicCategoryNTC_API

        fields: dict[str, Callable[[Any], None]] = {
            "agRg": lambda n : setattr(self, 'ag_rg', n.get_float_value()),
            "amplificationFactorF0": lambda n : setattr(self, 'amplification_factor_f0', n.get_float_value()),
            "contribution_factor_K": lambda n : setattr(self, 'contribution_factor_k', n.get_float_value()),
            "latitude": lambda n : setattr(self, 'latitude', n.get_float_value()),
            "longitude": lambda n : setattr(self, 'longitude', n.get_float_value()),
            "modifiedConstruction": lambda n : setattr(self, 'modified_construction', n.get_bool_value()),
            "periodTcStar": lambda n : setattr(self, 'period_tc_star', n.get_float_value()),
            "s": lambda n : setattr(self, 's', n.get_float_value()),
            "sT_CoefAmplifTopo": lambda n : setattr(self, 's_t_coef_amplif_topo', n.get_float_value()),
            "soilClass": lambda n : setattr(self, 'soil_class', n.get_enum_value(SoilClassEN1998_API)),
            "spectrumType": lambda n : setattr(self, 'spectrum_type', n.get_enum_value(SpectrumType_API)),
            "tbImposedValue": lambda n : setattr(self, 'tb_imposed_value', n.get_float_value()),
            "tcImposedValue": lambda n : setattr(self, 'tc_imposed_value', n.get_float_value()),
            "tdImposedValue": lambda n : setattr(self, 'td_imposed_value', n.get_float_value()),
            "topographicCategory": lambda n : setattr(self, 'topographic_category', n.get_enum_value(TopographicCategoryNTC_API)),
            "vs30": lambda n : setattr(self, 'vs30', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("agRg", self.ag_rg)
        writer.write_float_value("amplificationFactorF0", self.amplification_factor_f0)
        writer.write_float_value("contribution_factor_K", self.contribution_factor_k)
        writer.write_float_value("latitude", self.latitude)
        writer.write_float_value("longitude", self.longitude)
        writer.write_bool_value("modifiedConstruction", self.modified_construction)
        writer.write_float_value("periodTcStar", self.period_tc_star)
        writer.write_float_value("s", self.s)
        writer.write_float_value("sT_CoefAmplifTopo", self.s_t_coef_amplif_topo)
        writer.write_enum_value("soilClass", self.soil_class)
        writer.write_enum_value("spectrumType", self.spectrum_type)
        writer.write_float_value("tbImposedValue", self.tb_imposed_value)
        writer.write_float_value("tcImposedValue", self.tc_imposed_value)
        writer.write_float_value("tdImposedValue", self.td_imposed_value)
        writer.write_enum_value("topographicCategory", self.topographic_category)
        writer.write_float_value("vs30", self.vs30)
    

