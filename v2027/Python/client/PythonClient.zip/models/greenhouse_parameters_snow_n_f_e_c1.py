from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .greenhouse_class_snow_n_f_e_c1_a_p_i import GreenhouseClass_SnowNF_EC1_API
    from .surface_material_cm_snow_n_f_e_c1_a_p_i import SurfaceMaterialCm_SnowNF_EC1_API

@dataclass
class GreenhouseParametersSnowNF_EC1(Parsable):
    """
    Greenhouse parameters for Snow NF EC1 (EN 1991-1-3)
    """
    from .greenhouse_class_snow_n_f_e_c1_a_p_i import GreenhouseClass_SnowNF_EC1_API

    # Greenhouse classUnit: -Default: GREENHOUSE_CLASS_B
    greenhouse_class: Optional[GreenhouseClass_SnowNF_EC1_API] = GreenhouseClass_SnowNF_EC1_API("GREENHOUSE_CLASS_B")
    from .surface_material_cm_snow_n_f_e_c1_a_p_i import SurfaceMaterialCm_SnowNF_EC1_API

    # Surface material CmUnit: -Default: GREENHOUSE_MATERIAL_CM_1_2_PLUS
    surface_material_cm: Optional[SurfaceMaterialCm_SnowNF_EC1_API] = SurfaceMaterialCm_SnowNF_EC1_API("GREENHOUSE_MATERIAL_CM_1_2_PLUS")
    # Exposure coefficient CeUnit: -Default: 1.0
    exp_coeff_ce: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> GreenhouseParametersSnowNF_EC1:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: GreenhouseParametersSnowNF_EC1
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return GreenhouseParametersSnowNF_EC1()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .greenhouse_class_snow_n_f_e_c1_a_p_i import GreenhouseClass_SnowNF_EC1_API
        from .surface_material_cm_snow_n_f_e_c1_a_p_i import SurfaceMaterialCm_SnowNF_EC1_API

        from .greenhouse_class_snow_n_f_e_c1_a_p_i import GreenhouseClass_SnowNF_EC1_API
        from .surface_material_cm_snow_n_f_e_c1_a_p_i import SurfaceMaterialCm_SnowNF_EC1_API

        fields: dict[str, Callable[[Any], None]] = {
            "expCoeffCe": lambda n : setattr(self, 'exp_coeff_ce', n.get_float_value()),
            "greenhouseClass": lambda n : setattr(self, 'greenhouse_class', n.get_enum_value(GreenhouseClass_SnowNF_EC1_API)),
            "surfaceMaterialCm": lambda n : setattr(self, 'surface_material_cm', n.get_enum_value(SurfaceMaterialCm_SnowNF_EC1_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("expCoeffCe", self.exp_coeff_ce)
        writer.write_enum_value("greenhouseClass", self.greenhouse_class)
        writer.write_enum_value("surfaceMaterialCm", self.surface_material_cm)
    

