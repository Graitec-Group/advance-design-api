from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .connection_style import ConnectionStyle

@dataclass
class ConnectionTotale(Parsable):
    """
    Connection totale properties
    """
    # End boundary connectionDefault value: optional nullable object
    end_boundary_connection: Optional[ConnectionStyle] = None
    # Start boundary connectionDefault value: optional nullable object
    start_boundary_connection: Optional[ConnectionStyle] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConnectionTotale:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConnectionTotale
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConnectionTotale()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .connection_style import ConnectionStyle

        from .connection_style import ConnectionStyle

        fields: dict[str, Callable[[Any], None]] = {
            "endBoundaryConnection": lambda n : setattr(self, 'end_boundary_connection', n.get_object_value(ConnectionStyle)),
            "startBoundaryConnection": lambda n : setattr(self, 'start_boundary_connection', n.get_object_value(ConnectionStyle)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("endBoundaryConnection", self.end_boundary_connection)
        writer.write_object_value("startBoundaryConnection", self.start_boundary_connection)
    

