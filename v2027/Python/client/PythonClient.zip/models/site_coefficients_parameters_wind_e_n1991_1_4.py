from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .iso_loaded_areas_wind_e_n1991_1_4_a_p_i import IsoLoadedAreas_Wind_EN1991_1_4_API
    from .phi_type_wind_e_n1991_1_4_a_p_i import PhiType_Wind_EN1991_1_4_API
    from .wind_effort_type_wind_e_n1991_1_4_a_p_i import WindEffortType_Wind_EN1991_1_4_API

@dataclass
class SiteCoefficientsParameters_Wind_EN1991_1_4(Parsable):
    """
    Site coefficients parameters for Wind EN 1991-1-4
    """
    from .iso_loaded_areas_wind_e_n1991_1_4_a_p_i import IsoLoadedAreas_Wind_EN1991_1_4_API

    # ISO loaded areasUnit: -Default: WINDEC1_ISOLA_EXPOSED_AREA
    iso_loaded_areas: Optional[IsoLoadedAreas_Wind_EN1991_1_4_API] = IsoLoadedAreas_Wind_EN1991_1_4_API("WINDEC1_ISOLA_EXPOSED_AREA")
    from .phi_type_wind_e_n1991_1_4_a_p_i import PhiType_Wind_EN1991_1_4_API

    # Phi typeUnit: -Default: PHI_TYPE_AUTO
    phi_type: Optional[PhiType_Wind_EN1991_1_4_API] = PhiType_Wind_EN1991_1_4_API("PHI_TYPE_AUTO")
    from .wind_effort_type_wind_e_n1991_1_4_a_p_i import WindEffortType_Wind_EN1991_1_4_API

    # Wind effort typeUnit: -Default: WINDEC1_EFF_TYPE_ISOL_BOTH
    wind_effort_type: Optional[WindEffortType_Wind_EN1991_1_4_API] = WindEffortType_Wind_EN1991_1_4_API("WINDEC1_EFF_TYPE_ISOL_BOTH")
    # Land factor (orography)Unit: -Default: 1.0
    land_factor: Optional[float] = None
    # Phi valueUnit: -Default: 1.0
    phi: Optional[float] = None
    # Sheltered minimum percentUnit: %Default: 0.0
    sheltered_min_percent: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SiteCoefficientsParameters_Wind_EN1991_1_4:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SiteCoefficientsParameters_Wind_EN1991_1_4
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SiteCoefficientsParameters_Wind_EN1991_1_4()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .iso_loaded_areas_wind_e_n1991_1_4_a_p_i import IsoLoadedAreas_Wind_EN1991_1_4_API
        from .phi_type_wind_e_n1991_1_4_a_p_i import PhiType_Wind_EN1991_1_4_API
        from .wind_effort_type_wind_e_n1991_1_4_a_p_i import WindEffortType_Wind_EN1991_1_4_API

        from .iso_loaded_areas_wind_e_n1991_1_4_a_p_i import IsoLoadedAreas_Wind_EN1991_1_4_API
        from .phi_type_wind_e_n1991_1_4_a_p_i import PhiType_Wind_EN1991_1_4_API
        from .wind_effort_type_wind_e_n1991_1_4_a_p_i import WindEffortType_Wind_EN1991_1_4_API

        fields: dict[str, Callable[[Any], None]] = {
            "isoLoadedAreas": lambda n : setattr(self, 'iso_loaded_areas', n.get_enum_value(IsoLoadedAreas_Wind_EN1991_1_4_API)),
            "landFactor": lambda n : setattr(self, 'land_factor', n.get_float_value()),
            "phi": lambda n : setattr(self, 'phi', n.get_float_value()),
            "phiType": lambda n : setattr(self, 'phi_type', n.get_enum_value(PhiType_Wind_EN1991_1_4_API)),
            "shelteredMinPercent": lambda n : setattr(self, 'sheltered_min_percent', n.get_float_value()),
            "windEffortType": lambda n : setattr(self, 'wind_effort_type', n.get_enum_value(WindEffortType_Wind_EN1991_1_4_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("isoLoadedAreas", self.iso_loaded_areas)
        writer.write_float_value("landFactor", self.land_factor)
        writer.write_float_value("phi", self.phi)
        writer.write_enum_value("phiType", self.phi_type)
        writer.write_float_value("shelteredMinPercent", self.sheltered_min_percent)
        writer.write_enum_value("windEffortType", self.wind_effort_type)
    

