from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class FunctionPoint(Parsable):
    """
    Function point x,f(x)
    """
    # FX value (ordinate)
    value_f_x: Optional[float] = None
    # X value (abscissa)
    value_x: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FunctionPoint:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FunctionPoint
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return FunctionPoint()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "valueFX": lambda n : setattr(self, 'value_f_x', n.get_float_value()),
            "valueX": lambda n : setattr(self, 'value_x', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("valueFX", self.value_f_x)
        writer.write_float_value("valueX", self.value_x)
    

