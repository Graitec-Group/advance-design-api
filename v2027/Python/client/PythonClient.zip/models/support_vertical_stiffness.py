from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .soil_layer import SoilLayer

@dataclass
class SupportVerticalStiffness(Parsable):
    """
    Support Vertical Stiffness   properties 
    """
    # Soil layers.Unit: no unit Default value: Empty list
    layers: Optional[list[SoilLayer]] = None
    # Type of calculation for vertical stiffness (0 = Auto, 1 = Manual).Unit: no unit Default value: 1
    vertical_stiffness_calcul: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SupportVerticalStiffness:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SupportVerticalStiffness
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SupportVerticalStiffness()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .soil_layer import SoilLayer

        from .soil_layer import SoilLayer

        fields: dict[str, Callable[[Any], None]] = {
            "layers": lambda n : setattr(self, 'layers', n.get_collection_of_object_values(SoilLayer)),
            "verticalStiffnessCalcul": lambda n : setattr(self, 'vertical_stiffness_calcul', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("layers", self.layers)
        writer.write_int_value("verticalStiffnessCalcul", self.vertical_stiffness_calcul)
    

