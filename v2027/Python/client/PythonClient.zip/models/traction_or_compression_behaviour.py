from enum import Enum

class TractionOrCompressionBehaviour(str, Enum):
    Compression = "compression",
    Traction = "traction",

