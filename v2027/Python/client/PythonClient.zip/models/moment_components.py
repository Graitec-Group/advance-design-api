from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class MomentComponents(Parsable):
    """
    Moment components
    """
    # Moment component MX (N·m), at least one of FX, FY, FZ, MX, MY or MZ must not be 0. Unit: N·m Default value : 0.0
    mx: Optional[float] = None
    # Moment component MY (N·m), at least one of FX, FY, FZ, MX, MY or MZ must not be 0. Unit: N·m Default value : 0.0
    my: Optional[float] = None
    # Moment component MZ (N·m), at least one of FX, FY, FZ, MX, MY or MZ must not be 0. Unit: N·m Default value : 0.0
    mz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> MomentComponents:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: MomentComponents
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return MomentComponents()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "mx": lambda n : setattr(self, 'mx', n.get_float_value()),
            "my": lambda n : setattr(self, 'my', n.get_float_value()),
            "mz": lambda n : setattr(self, 'mz', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("mx", self.mx)
        writer.write_float_value("my", self.my)
        writer.write_float_value("mz", self.mz)
    

