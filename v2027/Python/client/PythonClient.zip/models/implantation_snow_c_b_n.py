from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .importance_factor_i_e_snow_c_b_n_a_p_i import ImportanceFactorIE_SnowCBN_API
    from .wind_exposure_cw_snow_c_b_n_a_p_i import WindExposureCw_SnowCBN_API

@dataclass
class ImplantationSnowCBN(Parsable):
    """
    Implantation parameters for Snow CBN Sn 2010
    """
    from .wind_exposure_cw_snow_c_b_n_a_p_i import WindExposureCw_SnowCBN_API

    # Wind exposure coefficient (Cw)Unit: -Default: SNOWCBNSn2010_CW_1
    cw: Optional[WindExposureCw_SnowCBN_API] = WindExposureCw_SnowCBN_API("SNOWCBNSn2010_CW_1")
    from .importance_factor_i_e_snow_c_b_n_a_p_i import ImportanceFactorIE_SnowCBN_API

    # Importance factor (IE)Unit: -Default: SNOWCBNSn2010_IE_NORMAL
    importance_factor_i_e: Optional[ImportanceFactorIE_SnowCBN_API] = ImportanceFactorIE_SnowCBN_API("SNOWCBNSn2010_IE_NORMAL")
    # Zone hash identifierUnit: -Default: " "
    zone_hash: Optional[str] = " "
    # Associated 1-in-50 year rain load (Sr)Unit: Pa (Pascal)Default: 400.0
    sr50: Optional[float] = None
    # 1-in-50 year ground snow load (Ss)Unit: Pa (Pascal)Default: 2600.0
    ss50: Optional[float] = None
    # Zone identifierUnit: -Default: ""
    zone: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ImplantationSnowCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ImplantationSnowCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ImplantationSnowCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .importance_factor_i_e_snow_c_b_n_a_p_i import ImportanceFactorIE_SnowCBN_API
        from .wind_exposure_cw_snow_c_b_n_a_p_i import WindExposureCw_SnowCBN_API

        from .importance_factor_i_e_snow_c_b_n_a_p_i import ImportanceFactorIE_SnowCBN_API
        from .wind_exposure_cw_snow_c_b_n_a_p_i import WindExposureCw_SnowCBN_API

        fields: dict[str, Callable[[Any], None]] = {
            "cw": lambda n : setattr(self, 'cw', n.get_enum_value(WindExposureCw_SnowCBN_API)),
            "importanceFactorIE": lambda n : setattr(self, 'importance_factor_i_e', n.get_enum_value(ImportanceFactorIE_SnowCBN_API)),
            "sr50": lambda n : setattr(self, 'sr50', n.get_float_value()),
            "ss50": lambda n : setattr(self, 'ss50', n.get_float_value()),
            "zone": lambda n : setattr(self, 'zone', n.get_str_value()),
            "zoneHash": lambda n : setattr(self, 'zone_hash', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("cw", self.cw)
        writer.write_enum_value("importanceFactorIE", self.importance_factor_i_e)
        writer.write_float_value("sr50", self.sr50)
        writer.write_float_value("ss50", self.ss50)
        writer.write_str_value("zone", self.zone)
        writer.write_str_value("zoneHash", self.zone_hash)
    

