from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class TemperatureFieldDefinition(Parsable):
    """
    Temperature field definition (dilatation and gradients)
    """
    # Temperature dilatation along X axis.Unit: °C Default: 0.0
    dilatation_x: Optional[float] = None
    # Temperature gradient along Y axis.Unit: °C/m Default: 0.0
    gradient_y: Optional[float] = None
    # Temperature gradient along Z axis.Unit: °C/m Default: 0.0
    gradient_z: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TemperatureFieldDefinition:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TemperatureFieldDefinition
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TemperatureFieldDefinition()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "dilatationX": lambda n : setattr(self, 'dilatation_x', n.get_float_value()),
            "gradientY": lambda n : setattr(self, 'gradient_y', n.get_float_value()),
            "gradientZ": lambda n : setattr(self, 'gradient_z', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("dilatationX", self.dilatation_x)
        writer.write_float_value("gradientY", self.gradient_y)
        writer.write_float_value("gradientZ", self.gradient_z)
    

