from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .eurocode_general_parameters_snow_n_f_e_c1 import EurocodeGeneralParametersSnowNF_EC1
    from .greenhouse_parameters_snow_n_f_e_c1 import GreenhouseParametersSnowNF_EC1
    from .load_case_family_snow import LoadCaseFamily_Snow
    from .project_situation_snow_n_f_e_c1 import ProjectSituationSnowNF_EC1
    from .snow_load_category_a_p_i import SnowLoadCategory_API

from .load_case_family_snow import LoadCaseFamily_Snow

@dataclass
class LoadCaseFamily_Snow_1991_1_3(LoadCaseFamily_Snow, AdditionalDataHolder, Parsable):
    """
    Snow loads case family for EN 1991-1-3, load case parent
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .snow_load_category_a_p_i import SnowLoadCategory_API

    # Snow load categoryUnit: -Default: eSnowZoneUnder1000
    snow_load_category: Optional[SnowLoadCategory_API] = SnowLoadCategory_API("eSnowZoneUnder1000")
    # Eurocode general parameters (EN 1991-1-3)
    eurocode_parameters: Optional[EurocodeGeneralParametersSnowNF_EC1] = None
    # Greenhouse parameters (for greenhouses per EN 13031-1)
    greenhouse_parameters: Optional[GreenhouseParametersSnowNF_EC1] = None
    # Project situation parameters
    project_situation: Optional[ProjectSituationSnowNF_EC1] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily_Snow_1991_1_3:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily_Snow_1991_1_3
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseFamily_Snow_1991_1_3()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .eurocode_general_parameters_snow_n_f_e_c1 import EurocodeGeneralParametersSnowNF_EC1
        from .greenhouse_parameters_snow_n_f_e_c1 import GreenhouseParametersSnowNF_EC1
        from .load_case_family_snow import LoadCaseFamily_Snow
        from .project_situation_snow_n_f_e_c1 import ProjectSituationSnowNF_EC1
        from .snow_load_category_a_p_i import SnowLoadCategory_API

        from .eurocode_general_parameters_snow_n_f_e_c1 import EurocodeGeneralParametersSnowNF_EC1
        from .greenhouse_parameters_snow_n_f_e_c1 import GreenhouseParametersSnowNF_EC1
        from .load_case_family_snow import LoadCaseFamily_Snow
        from .project_situation_snow_n_f_e_c1 import ProjectSituationSnowNF_EC1
        from .snow_load_category_a_p_i import SnowLoadCategory_API

        fields: dict[str, Callable[[Any], None]] = {
            "eurocodeParameters": lambda n : setattr(self, 'eurocode_parameters', n.get_object_value(EurocodeGeneralParametersSnowNF_EC1)),
            "greenhouseParameters": lambda n : setattr(self, 'greenhouse_parameters', n.get_object_value(GreenhouseParametersSnowNF_EC1)),
            "projectSituation": lambda n : setattr(self, 'project_situation', n.get_object_value(ProjectSituationSnowNF_EC1)),
            "snowLoadCategory": lambda n : setattr(self, 'snow_load_category', n.get_enum_value(SnowLoadCategory_API)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("eurocodeParameters", self.eurocode_parameters)
        writer.write_object_value("greenhouseParameters", self.greenhouse_parameters)
        writer.write_object_value("projectSituation", self.project_situation)
        writer.write_enum_value("snowLoadCategory", self.snow_load_category)
        writer.write_additional_data_value(self.additional_data)
    

