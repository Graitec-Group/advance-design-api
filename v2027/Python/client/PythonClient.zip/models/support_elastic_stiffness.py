from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SupportElasticStiffness(Parsable):
    """
    Stiffness associated with degrees of freedom.Translational: [N/m], Rotational: [N·m/rad].
    """
    # Rotational stiffness about X [N·m/rad].Unit: N·m/rad Default value : 0.0
    krx: Optional[float] = None
    # Rotational stiffness about Y [N·m/rad].Unit: N·m/rad Default value : 0.0
    kry: Optional[float] = None
    # Rotational stiffness about Z [N·m/rad].Unit: N·m/rad Default value : 0.0
    krz: Optional[float] = None
    # Translational stiffness along X [N/m].Unit: N/m Default value : 0.0
    ktx: Optional[float] = None
    # Translational stiffness along Y [N/m].Unit: N/m Default value : 0.0
    kty: Optional[float] = None
    # Translational stiffness along Z [N/m].Unit: N/m Default value : 0.0
    ktz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SupportElasticStiffness:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SupportElasticStiffness
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SupportElasticStiffness()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "krx": lambda n : setattr(self, 'krx', n.get_float_value()),
            "kry": lambda n : setattr(self, 'kry', n.get_float_value()),
            "krz": lambda n : setattr(self, 'krz', n.get_float_value()),
            "ktx": lambda n : setattr(self, 'ktx', n.get_float_value()),
            "kty": lambda n : setattr(self, 'kty', n.get_float_value()),
            "ktz": lambda n : setattr(self, 'ktz', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("krx", self.krx)
        writer.write_float_value("kry", self.kry)
        writer.write_float_value("krz", self.krz)
        writer.write_float_value("ktx", self.ktx)
        writer.write_float_value("kty", self.kty)
        writer.write_float_value("ktz", self.ktz)
    

