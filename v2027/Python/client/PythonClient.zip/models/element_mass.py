from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_base import ElementBase
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class ElementMass(ElementBase, AdditionalDataHolder, Parsable):
    """
    Mass element
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # gemetry point 3D (global repere).Unit: m Default value : (0, 0, 0)
    geom_pt: Optional[Pt3D] = None
    # Mass inertia about the global X axis (Kg·m*m)Unit: Kg·m*m Default value : 0.0
    ix: Optional[float] = None
    # Mass inertia about the global Y axis (Kg·m*m)Unit: Kg·m*m Default value : 0.0
    iy: Optional[float] = None
    # Mass inertia about the global Z axis (Kg·m*m)Unit: Kg·m*m Default value : 0.0
    iz: Optional[float] = None
    # Mass component Mx (Kg) Unit: Kg Default value : 0.0
    mx: Optional[float] = None
    # Mass component My (Kg) Unit: Kg Default value : 0.0
    my: Optional[float] = None
    # Mass component MZ (Kg)Unit: Kg Default value : 0.0
    mz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementMass:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementMass
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementMass()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_base import ElementBase
        from .pt3_d import Pt3D

        from .element_base import ElementBase
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "geomPt": lambda n : setattr(self, 'geom_pt', n.get_object_value(Pt3D)),
            "ix": lambda n : setattr(self, 'ix', n.get_float_value()),
            "iy": lambda n : setattr(self, 'iy', n.get_float_value()),
            "iz": lambda n : setattr(self, 'iz', n.get_float_value()),
            "mx": lambda n : setattr(self, 'mx', n.get_float_value()),
            "my": lambda n : setattr(self, 'my', n.get_float_value()),
            "mz": lambda n : setattr(self, 'mz', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("geomPt", self.geom_pt)
        writer.write_float_value("ix", self.ix)
        writer.write_float_value("iy", self.iy)
        writer.write_float_value("iz", self.iz)
        writer.write_float_value("mx", self.mx)
        writer.write_float_value("my", self.my)
        writer.write_float_value("mz", self.mz)
        writer.write_additional_data_value(self.additional_data)
    

