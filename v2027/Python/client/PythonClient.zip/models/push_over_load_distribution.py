from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .push_over_directions import PushOverDirections

@dataclass
class PushOverLoadDistribution(Parsable):
    """
    Push over load distribution configuration
    """
    # Control parameterDefault: 0
    control: Optional[int] = None
    # Direction configuration for push over load
    directions: Optional[PushOverDirections] = None
    # Load distribution typeePushOverLoadConcentrated = 0, ePushOverLoadUniformDistributed = 1, ePushOverLoadTriangularDistributed = 2,  ePushOverLoadCodeDistributed = 3, ePushOverLoadModeShapeDistributed = 4Default: Concentrated (0)
    distribution: Optional[int] = None
    # Point of application typeePushOverPtAppCenterOfMass = 0, ePushOverPtAppSurfaceLoadDistributed = 1Default: Center of mass (0)
    point_of_application: Optional[int] = None
    # Enable state checkboxDefault: true
    state: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PushOverLoadDistribution:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PushOverLoadDistribution
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PushOverLoadDistribution()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .push_over_directions import PushOverDirections

        from .push_over_directions import PushOverDirections

        fields: dict[str, Callable[[Any], None]] = {
            "control": lambda n : setattr(self, 'control', n.get_int_value()),
            "directions": lambda n : setattr(self, 'directions', n.get_object_value(PushOverDirections)),
            "distribution": lambda n : setattr(self, 'distribution', n.get_int_value()),
            "pointOfApplication": lambda n : setattr(self, 'point_of_application', n.get_int_value()),
            "state": lambda n : setattr(self, 'state', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("control", self.control)
        writer.write_object_value("directions", self.directions)
        writer.write_int_value("distribution", self.distribution)
        writer.write_int_value("pointOfApplication", self.point_of_application)
        writer.write_bool_value("state", self.state)
    

