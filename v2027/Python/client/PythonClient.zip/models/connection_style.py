from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ConnectionStyle(Parsable):
    """
    Connection style properties
    """
    # Relaxation RxDefault value: false
    relaxation_rx: Optional[bool] = None
    # Relaxation RyDefault value: false
    relaxation_ry: Optional[bool] = None
    # Relaxation RzDefault value: false
    relaxation_rz: Optional[bool] = None
    # Relaxation TxDefault value: false
    relaxation_tx: Optional[bool] = None
    # Relaxation TyDefault value: false
    relaxation_ty: Optional[bool] = None
    # Relaxation TzDefault value: false
    relaxation_tz: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConnectionStyle:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConnectionStyle
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConnectionStyle()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "relaxationRx": lambda n : setattr(self, 'relaxation_rx', n.get_bool_value()),
            "relaxationRy": lambda n : setattr(self, 'relaxation_ry', n.get_bool_value()),
            "relaxationRz": lambda n : setattr(self, 'relaxation_rz', n.get_bool_value()),
            "relaxationTx": lambda n : setattr(self, 'relaxation_tx', n.get_bool_value()),
            "relaxationTy": lambda n : setattr(self, 'relaxation_ty', n.get_bool_value()),
            "relaxationTz": lambda n : setattr(self, 'relaxation_tz', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("relaxationRx", self.relaxation_rx)
        writer.write_bool_value("relaxationRy", self.relaxation_ry)
        writer.write_bool_value("relaxationRz", self.relaxation_rz)
        writer.write_bool_value("relaxationTx", self.relaxation_tx)
        writer.write_bool_value("relaxationTy", self.relaxation_ty)
        writer.write_bool_value("relaxationTz", self.relaxation_tz)
    

