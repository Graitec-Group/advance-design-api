from enum import Enum

class CalculMethod_API(str, Enum):
    SRSS = "SRSS",
    CQC = "CQC",
    ABS = "ABS",

