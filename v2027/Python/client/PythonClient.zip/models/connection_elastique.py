from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .connection_elastique_object import ConnectionElastiqueObject

@dataclass
class ConnectionElastique(Parsable):
    """
    Connection elastique properties
    """
    # End connection elastiqueDefault value: optional nullable object
    end_connection_elastique: Optional[ConnectionElastiqueObject] = None
    # Start connection elastiqueDefault value: optional nullable object
    start_connection_elastique: Optional[ConnectionElastiqueObject] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConnectionElastique:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConnectionElastique
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConnectionElastique()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .connection_elastique_object import ConnectionElastiqueObject

        from .connection_elastique_object import ConnectionElastiqueObject

        fields: dict[str, Callable[[Any], None]] = {
            "endConnectionElastique": lambda n : setattr(self, 'end_connection_elastique', n.get_object_value(ConnectionElastiqueObject)),
            "startConnectionElastique": lambda n : setattr(self, 'start_connection_elastique', n.get_object_value(ConnectionElastiqueObject)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("endConnectionElastique", self.end_connection_elastique)
        writer.write_object_value("startConnectionElastique", self.start_connection_elastique)
    

