from enum import Enum

class PlanarMeshDensity(str, Enum):
    Global_ = "global",
    Simplified = "simplified",
    Detailed = "detailed",
    Element_size = "element_size",

