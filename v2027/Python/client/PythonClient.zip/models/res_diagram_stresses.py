from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_abscissa_value import ResAbscissaValue

@dataclass
class ResDiagramStresses(Parsable):
    """
    stress diagram along an element, defined by a collection of AD.API.ResAbscissaValue instances representing the stresses at various positions along the element.
    """
    # Von Mises
    sv: Optional[list[ResAbscissaValue]] = None
    # Sxx max
    sxx_max: Optional[list[ResAbscissaValue]] = None
    # Sxx min
    sxx_min: Optional[list[ResAbscissaValue]] = None
    # Sxy max
    sxy_max: Optional[list[ResAbscissaValue]] = None
    # Sxy min
    sxy_min: Optional[list[ResAbscissaValue]] = None
    # Sxz max
    sxz_max: Optional[list[ResAbscissaValue]] = None
    # Sxz min
    sxz_min: Optional[list[ResAbscissaValue]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResDiagramStresses:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResDiagramStresses
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResDiagramStresses()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_abscissa_value import ResAbscissaValue

        from .res_abscissa_value import ResAbscissaValue

        fields: dict[str, Callable[[Any], None]] = {
            "sv": lambda n : setattr(self, 'sv', n.get_collection_of_object_values(ResAbscissaValue)),
            "sxxMax": lambda n : setattr(self, 'sxx_max', n.get_collection_of_object_values(ResAbscissaValue)),
            "sxxMin": lambda n : setattr(self, 'sxx_min', n.get_collection_of_object_values(ResAbscissaValue)),
            "sxyMax": lambda n : setattr(self, 'sxy_max', n.get_collection_of_object_values(ResAbscissaValue)),
            "sxyMin": lambda n : setattr(self, 'sxy_min', n.get_collection_of_object_values(ResAbscissaValue)),
            "sxzMax": lambda n : setattr(self, 'sxz_max', n.get_collection_of_object_values(ResAbscissaValue)),
            "sxzMin": lambda n : setattr(self, 'sxz_min', n.get_collection_of_object_values(ResAbscissaValue)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("sv", self.sv)
        writer.write_collection_of_object_values("sxxMax", self.sxx_max)
        writer.write_collection_of_object_values("sxxMin", self.sxx_min)
        writer.write_collection_of_object_values("sxyMax", self.sxy_max)
        writer.write_collection_of_object_values("sxyMin", self.sxy_min)
        writer.write_collection_of_object_values("sxzMax", self.sxz_max)
        writer.write_collection_of_object_values("sxzMin", self.sxz_min)
    

