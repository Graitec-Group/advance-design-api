from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .section_offset_option_a_p_i import SectionOffsetOption_API

@dataclass
class SectionOffsetStyle(Parsable):
    """
    Section offset style properties
    """
    from .section_offset_option_a_p_i import SectionOffsetOption_API

    # Offset option, Options available for defining the eccentricity of a cross-section in relation to its local axis.  With predefined eccentricity types, z and y denote an eccentricity of half the section size.Default value: SectionOffsetOption_API.center_alignment
    option: Optional[SectionOffsetOption_API] = SectionOffsetOption_API("center_alignment")
    # Considered in FEMDefault value: false
    considered_in_f_e_m: Optional[bool] = None
    # Delta Y at startUnit: mDefault value: 0.0
    delta_y1: Optional[float] = None
    # Delta Y at endUnit: mDefault value: 0.0
    delta_y2: Optional[float] = None
    # Delta Z at startUnit: mDefault value: 0.0
    delta_z1: Optional[float] = None
    # Delta Z at endUnit: mDefault value: 0.0
    delta_z2: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SectionOffsetStyle:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SectionOffsetStyle
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SectionOffsetStyle()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .section_offset_option_a_p_i import SectionOffsetOption_API

        from .section_offset_option_a_p_i import SectionOffsetOption_API

        fields: dict[str, Callable[[Any], None]] = {
            "consideredInFEM": lambda n : setattr(self, 'considered_in_f_e_m', n.get_bool_value()),
            "deltaY1": lambda n : setattr(self, 'delta_y1', n.get_float_value()),
            "deltaY2": lambda n : setattr(self, 'delta_y2', n.get_float_value()),
            "deltaZ1": lambda n : setattr(self, 'delta_z1', n.get_float_value()),
            "deltaZ2": lambda n : setattr(self, 'delta_z2', n.get_float_value()),
            "option": lambda n : setattr(self, 'option', n.get_enum_value(SectionOffsetOption_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("consideredInFEM", self.considered_in_f_e_m)
        writer.write_float_value("deltaY1", self.delta_y1)
        writer.write_float_value("deltaY2", self.delta_y2)
        writer.write_float_value("deltaZ1", self.delta_z1)
        writer.write_float_value("deltaZ2", self.delta_z2)
        writer.write_enum_value("option", self.option)
    

