from enum import Enum

class MaterialBehaviourType(str, Enum):
    Isotropic_behavior = "isotropic_behavior",
    Orthotropic_behavior = "orthotropic_behavior",

