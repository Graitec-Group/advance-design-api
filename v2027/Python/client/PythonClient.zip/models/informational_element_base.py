from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .combination import Combination
    from .load_case import LoadCase
    from .load_case_accidental import LoadCase_Accidental
    from .load_case_dead_loads import LoadCase_DeadLoads
    from .load_case_dynamic_temporal import LoadCase_DynamicTemporal
    from .load_case_family import LoadCaseFamily
    from .load_case_family_accidental import LoadCaseFamily_Accidental
    from .load_case_family_dead_loads import LoadCaseFamily_DeadLoads
    from .load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal
    from .load_case_family_live_loads import LoadCaseFamily_LiveLoads
    from .load_case_family_other import LoadCaseFamily_Other
    from .load_case_family_push_over import LoadCaseFamily_PushOver
    from .load_case_family_seismic import LoadCaseFamily_Seismic
    from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
    from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
    from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
    from .load_case_family_snow import LoadCaseFamily_Snow
    from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
    from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
    from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC
    from .load_case_family_thermic import LoadCaseFamily_Thermic
    from .load_case_family_wind import LoadCaseFamily_Wind
    from .load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4
    from .load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN
    from .load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC
    from .load_case_live_loads import LoadCase_LiveLoads
    from .load_case_other import LoadCase_Other
    from .load_case_push_over import LoadCase_PushOver
    from .load_case_seismic import LoadCase_Seismic
    from .load_case_seismic_c_b_n import LoadCase_SeismicCBN
    from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
    from .load_case_seismic_i_b_c import LoadCase_SeismicIBC
    from .load_case_snow import LoadCase_Snow
    from .load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3
    from .load_case_snow_c_b_n import LoadCase_SnowCBN
    from .load_case_snow_i_b_c import LoadCase_SnowIBC
    from .load_case_thermic import LoadCase_Thermic
    from .load_case_wind import LoadCase_Wind
    from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
    from .load_case_wind_c_b_n import LoadCase_WindCBN
    from .load_case_wind_i_b_c import LoadCase_WindIBC

@dataclass
class InformationalElementBase(Parsable):
    """
    Base class for informational objects : load cases, load cases families, etc. Requires the `type_class` discriminator when serialized for the API.
    """
    # The Type property
    type: Optional[str] = None
    # user ID of the element used for additional identification on the UI. It's different than the internal ID (EID) which is used for internal reference and is not exposed to the interface. The ID is intended to be used by the client application for display purposes.
    user_i_d: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> InformationalElementBase:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: InformationalElementBase
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "Combination".casefold():
            from .combination import Combination

            return Combination()
        if mapping_value and mapping_value.casefold() == "LoadCase".casefold():
            from .load_case import LoadCase

            return LoadCase()
        if mapping_value and mapping_value.casefold() == "LoadCase_Accidental".casefold():
            from .load_case_accidental import LoadCase_Accidental

            return LoadCase_Accidental()
        if mapping_value and mapping_value.casefold() == "LoadCase_DeadLoads".casefold():
            from .load_case_dead_loads import LoadCase_DeadLoads

            return LoadCase_DeadLoads()
        if mapping_value and mapping_value.casefold() == "LoadCase_DynamicTemporal".casefold():
            from .load_case_dynamic_temporal import LoadCase_DynamicTemporal

            return LoadCase_DynamicTemporal()
        if mapping_value and mapping_value.casefold() == "LoadCase_LiveLoads".casefold():
            from .load_case_live_loads import LoadCase_LiveLoads

            return LoadCase_LiveLoads()
        if mapping_value and mapping_value.casefold() == "LoadCase_Other".casefold():
            from .load_case_other import LoadCase_Other

            return LoadCase_Other()
        if mapping_value and mapping_value.casefold() == "LoadCase_PushOver".casefold():
            from .load_case_push_over import LoadCase_PushOver

            return LoadCase_PushOver()
        if mapping_value and mapping_value.casefold() == "LoadCase_Seismic".casefold():
            from .load_case_seismic import LoadCase_Seismic

            return LoadCase_Seismic()
        if mapping_value and mapping_value.casefold() == "LoadCase_SeismicCBN".casefold():
            from .load_case_seismic_c_b_n import LoadCase_SeismicCBN

            return LoadCase_SeismicCBN()
        if mapping_value and mapping_value.casefold() == "LoadCase_SeismicEN_1998_1".casefold():
            from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1

            return LoadCase_SeismicEN_1998_1()
        if mapping_value and mapping_value.casefold() == "LoadCase_SeismicIBC".casefold():
            from .load_case_seismic_i_b_c import LoadCase_SeismicIBC

            return LoadCase_SeismicIBC()
        if mapping_value and mapping_value.casefold() == "LoadCase_Snow".casefold():
            from .load_case_snow import LoadCase_Snow

            return LoadCase_Snow()
        if mapping_value and mapping_value.casefold() == "LoadCase_Snow_1991_1_3".casefold():
            from .load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3

            return LoadCase_Snow_1991_1_3()
        if mapping_value and mapping_value.casefold() == "LoadCase_SnowCBN".casefold():
            from .load_case_snow_c_b_n import LoadCase_SnowCBN

            return LoadCase_SnowCBN()
        if mapping_value and mapping_value.casefold() == "LoadCase_SnowIBC".casefold():
            from .load_case_snow_i_b_c import LoadCase_SnowIBC

            return LoadCase_SnowIBC()
        if mapping_value and mapping_value.casefold() == "LoadCase_Thermic".casefold():
            from .load_case_thermic import LoadCase_Thermic

            return LoadCase_Thermic()
        if mapping_value and mapping_value.casefold() == "LoadCase_Wind".casefold():
            from .load_case_wind import LoadCase_Wind

            return LoadCase_Wind()
        if mapping_value and mapping_value.casefold() == "LoadCase_Wind_1991_1_4".casefold():
            from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4

            return LoadCase_Wind_1991_1_4()
        if mapping_value and mapping_value.casefold() == "LoadCase_WindCBN".casefold():
            from .load_case_wind_c_b_n import LoadCase_WindCBN

            return LoadCase_WindCBN()
        if mapping_value and mapping_value.casefold() == "LoadCase_WindIBC".casefold():
            from .load_case_wind_i_b_c import LoadCase_WindIBC

            return LoadCase_WindIBC()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily".casefold():
            from .load_case_family import LoadCaseFamily

            return LoadCaseFamily()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Accidental".casefold():
            from .load_case_family_accidental import LoadCaseFamily_Accidental

            return LoadCaseFamily_Accidental()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_DeadLoads".casefold():
            from .load_case_family_dead_loads import LoadCaseFamily_DeadLoads

            return LoadCaseFamily_DeadLoads()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_DynamicTemporal".casefold():
            from .load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal

            return LoadCaseFamily_DynamicTemporal()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_LiveLoads".casefold():
            from .load_case_family_live_loads import LoadCaseFamily_LiveLoads

            return LoadCaseFamily_LiveLoads()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Other".casefold():
            from .load_case_family_other import LoadCaseFamily_Other

            return LoadCaseFamily_Other()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_PushOver".casefold():
            from .load_case_family_push_over import LoadCaseFamily_PushOver

            return LoadCaseFamily_PushOver()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Seismic".casefold():
            from .load_case_family_seismic import LoadCaseFamily_Seismic

            return LoadCaseFamily_Seismic()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicCBN".casefold():
            from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN

            return LoadCaseFamily_SeismicCBN()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicEN_1998_1".casefold():
            from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1

            return LoadCaseFamily_SeismicEN_1998_1()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicIBC".casefold():
            from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC

            return LoadCaseFamily_SeismicIBC()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Snow".casefold():
            from .load_case_family_snow import LoadCaseFamily_Snow

            return LoadCaseFamily_Snow()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Snow_1991_1_3".casefold():
            from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3

            return LoadCaseFamily_Snow_1991_1_3()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SnowCBN".casefold():
            from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN

            return LoadCaseFamily_SnowCBN()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SnowIBC".casefold():
            from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC

            return LoadCaseFamily_SnowIBC()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Thermic".casefold():
            from .load_case_family_thermic import LoadCaseFamily_Thermic

            return LoadCaseFamily_Thermic()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Wind".casefold():
            from .load_case_family_wind import LoadCaseFamily_Wind

            return LoadCaseFamily_Wind()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Wind_1991_1_4".casefold():
            from .load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4

            return LoadCaseFamily_Wind_1991_1_4()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_WindCBN".casefold():
            from .load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN

            return LoadCaseFamily_WindCBN()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_WindIBC".casefold():
            from .load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC

            return LoadCaseFamily_WindIBC()
        return InformationalElementBase()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .combination import Combination
        from .load_case import LoadCase
        from .load_case_accidental import LoadCase_Accidental
        from .load_case_dead_loads import LoadCase_DeadLoads
        from .load_case_dynamic_temporal import LoadCase_DynamicTemporal
        from .load_case_family import LoadCaseFamily
        from .load_case_family_accidental import LoadCaseFamily_Accidental
        from .load_case_family_dead_loads import LoadCaseFamily_DeadLoads
        from .load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal
        from .load_case_family_live_loads import LoadCaseFamily_LiveLoads
        from .load_case_family_other import LoadCaseFamily_Other
        from .load_case_family_push_over import LoadCaseFamily_PushOver
        from .load_case_family_seismic import LoadCaseFamily_Seismic
        from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
        from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
        from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
        from .load_case_family_snow import LoadCaseFamily_Snow
        from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
        from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
        from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC
        from .load_case_family_thermic import LoadCaseFamily_Thermic
        from .load_case_family_wind import LoadCaseFamily_Wind
        from .load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4
        from .load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN
        from .load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC
        from .load_case_live_loads import LoadCase_LiveLoads
        from .load_case_other import LoadCase_Other
        from .load_case_push_over import LoadCase_PushOver
        from .load_case_seismic import LoadCase_Seismic
        from .load_case_seismic_c_b_n import LoadCase_SeismicCBN
        from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
        from .load_case_seismic_i_b_c import LoadCase_SeismicIBC
        from .load_case_snow import LoadCase_Snow
        from .load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3
        from .load_case_snow_c_b_n import LoadCase_SnowCBN
        from .load_case_snow_i_b_c import LoadCase_SnowIBC
        from .load_case_thermic import LoadCase_Thermic
        from .load_case_wind import LoadCase_Wind
        from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
        from .load_case_wind_c_b_n import LoadCase_WindCBN
        from .load_case_wind_i_b_c import LoadCase_WindIBC

        from .combination import Combination
        from .load_case import LoadCase
        from .load_case_accidental import LoadCase_Accidental
        from .load_case_dead_loads import LoadCase_DeadLoads
        from .load_case_dynamic_temporal import LoadCase_DynamicTemporal
        from .load_case_family import LoadCaseFamily
        from .load_case_family_accidental import LoadCaseFamily_Accidental
        from .load_case_family_dead_loads import LoadCaseFamily_DeadLoads
        from .load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal
        from .load_case_family_live_loads import LoadCaseFamily_LiveLoads
        from .load_case_family_other import LoadCaseFamily_Other
        from .load_case_family_push_over import LoadCaseFamily_PushOver
        from .load_case_family_seismic import LoadCaseFamily_Seismic
        from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
        from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
        from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
        from .load_case_family_snow import LoadCaseFamily_Snow
        from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
        from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
        from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC
        from .load_case_family_thermic import LoadCaseFamily_Thermic
        from .load_case_family_wind import LoadCaseFamily_Wind
        from .load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4
        from .load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN
        from .load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC
        from .load_case_live_loads import LoadCase_LiveLoads
        from .load_case_other import LoadCase_Other
        from .load_case_push_over import LoadCase_PushOver
        from .load_case_seismic import LoadCase_Seismic
        from .load_case_seismic_c_b_n import LoadCase_SeismicCBN
        from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
        from .load_case_seismic_i_b_c import LoadCase_SeismicIBC
        from .load_case_snow import LoadCase_Snow
        from .load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3
        from .load_case_snow_c_b_n import LoadCase_SnowCBN
        from .load_case_snow_i_b_c import LoadCase_SnowIBC
        from .load_case_thermic import LoadCase_Thermic
        from .load_case_wind import LoadCase_Wind
        from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
        from .load_case_wind_c_b_n import LoadCase_WindCBN
        from .load_case_wind_i_b_c import LoadCase_WindIBC

        fields: dict[str, Callable[[Any], None]] = {
            "$type": lambda n : setattr(self, 'type', n.get_str_value()),
            "userID": lambda n : setattr(self, 'user_i_d', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("$type", self.type)
        writer.write_int_value("userID", self.user_i_d)
    

