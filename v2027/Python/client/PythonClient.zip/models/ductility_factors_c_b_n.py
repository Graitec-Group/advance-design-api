from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class DuctilityFactorsCBN(Parsable):
    """
    Ductility factors for Seismic CBN load case
    """
    # Calibration flagDefault: true
    calibration: Optional[bool] = None
    # L parameter - CBN 2015/2020 onlyUnit: dimensionlessDefault: 0.0
    l: Optional[float] = None
    # Ductility-related force modification factor RdUnit: dimensionlessDefault: 1.0
    rd: Optional[float] = None
    # Overstrength-related force modification factor RoUnit: dimensionlessDefault: 1.0
    ro: Optional[float] = None
    # Torsion consideration flagDefault: false
    torsion: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DuctilityFactorsCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DuctilityFactorsCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DuctilityFactorsCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "calibration": lambda n : setattr(self, 'calibration', n.get_bool_value()),
            "l": lambda n : setattr(self, 'l', n.get_float_value()),
            "rd": lambda n : setattr(self, 'rd', n.get_float_value()),
            "ro": lambda n : setattr(self, 'ro', n.get_float_value()),
            "torsion": lambda n : setattr(self, 'torsion', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("calibration", self.calibration)
        writer.write_float_value("l", self.l)
        writer.write_float_value("rd", self.rd)
        writer.write_float_value("ro", self.ro)
        writer.write_bool_value("torsion", self.torsion)
    

