from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID
    from .haunch_length_size_type_a_p_i import HaunchLengthSizeType_API
    from .haunch_position_a_p_i import HaunchPosition_API
    from .haunch_section_type_a_p_i import HaunchSectionType_API

@dataclass
class HaunchProperties(Parsable):
    """
    Haunch properties
    """
    from .haunch_position_a_p_i import HaunchPosition_API

    # Haunch positionDefault value: HaunchPosition_API.no_haunch
    haunch_position: Optional[HaunchPosition_API] = HaunchPosition_API("no_haunch")
    from .haunch_section_type_a_p_i import HaunchSectionType_API

    # Haunch section typeDefault value: HaunchSectionType_API.identical, if imposed then HaunchSection will be taken into account
    haunch_section_type: Optional[HaunchSectionType_API] = HaunchSectionType_API("identical")
    from .haunch_length_size_type_a_p_i import HaunchLengthSizeType_API

    # Height typeDefault value: HaunchLengthSizeType_API.ratio
    height_type: Optional[HaunchLengthSizeType_API] = HaunchLengthSizeType_API("ratio")
    from .haunch_length_size_type_a_p_i import HaunchLengthSizeType_API

    # Length typeDefault value: HaunchLengthSizeType_API.ratio
    length_type: Optional[HaunchLengthSizeType_API] = HaunchLengthSizeType_API("ratio")
    # Haunch section EID, used if HaunchSectionType is imposed HaunchSectionType_API.imposee Default value: 0
    haunch_section: Optional[EID] = None
    # Height ratioUnit: no unitDefault value: 1.0
    height_ratio: Optional[float] = None
    # Height valueUnit: mDefault value: 0.2
    height_value: Optional[float] = None
    # Length ratioUnit: no unitDefault value: 0.2
    length_ratio: Optional[float] = None
    # Length valueUnit: mDefault value: 0.5
    length_value: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> HaunchProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: HaunchProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return HaunchProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID
        from .haunch_length_size_type_a_p_i import HaunchLengthSizeType_API
        from .haunch_position_a_p_i import HaunchPosition_API
        from .haunch_section_type_a_p_i import HaunchSectionType_API

        from .e_i_d import EID
        from .haunch_length_size_type_a_p_i import HaunchLengthSizeType_API
        from .haunch_position_a_p_i import HaunchPosition_API
        from .haunch_section_type_a_p_i import HaunchSectionType_API

        fields: dict[str, Callable[[Any], None]] = {
            "haunchPosition": lambda n : setattr(self, 'haunch_position', n.get_enum_value(HaunchPosition_API)),
            "haunchSection": lambda n : setattr(self, 'haunch_section', n.get_object_value(EID)),
            "haunchSectionType": lambda n : setattr(self, 'haunch_section_type', n.get_enum_value(HaunchSectionType_API)),
            "heightRatio": lambda n : setattr(self, 'height_ratio', n.get_float_value()),
            "heightType": lambda n : setattr(self, 'height_type', n.get_enum_value(HaunchLengthSizeType_API)),
            "heightValue": lambda n : setattr(self, 'height_value', n.get_float_value()),
            "lengthRatio": lambda n : setattr(self, 'length_ratio', n.get_float_value()),
            "lengthType": lambda n : setattr(self, 'length_type', n.get_enum_value(HaunchLengthSizeType_API)),
            "lengthValue": lambda n : setattr(self, 'length_value', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("haunchPosition", self.haunch_position)
        writer.write_object_value("haunchSection", self.haunch_section)
        writer.write_enum_value("haunchSectionType", self.haunch_section_type)
        writer.write_float_value("heightRatio", self.height_ratio)
        writer.write_enum_value("heightType", self.height_type)
        writer.write_float_value("heightValue", self.height_value)
        writer.write_float_value("lengthRatio", self.length_ratio)
        writer.write_enum_value("lengthType", self.length_type)
        writer.write_float_value("lengthValue", self.length_value)
    

