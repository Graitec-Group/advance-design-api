from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID
    from .res_element_linear import ResElementLinear
    from .res_element_planar import ResElementPlanar
    from .res_linear_support import ResLinearSupport
    from .res_node import ResNode
    from .res_planar_node import ResPlanarNode
    from .res_planar_support import ResPlanarSupport
    from .res_punctual_support import ResPunctualSupport

@dataclass
class ResBase(Parsable):
    """
    base class for all analysis objects
    """
    # internal generated Id of element which is generated at creation
    id: Optional[EID] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResBase:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResBase
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "ResElementLinear".casefold():
            from .res_element_linear import ResElementLinear

            return ResElementLinear()
        if mapping_value and mapping_value.casefold() == "ResElementPlanar".casefold():
            from .res_element_planar import ResElementPlanar

            return ResElementPlanar()
        if mapping_value and mapping_value.casefold() == "ResLinearSupport".casefold():
            from .res_linear_support import ResLinearSupport

            return ResLinearSupport()
        if mapping_value and mapping_value.casefold() == "ResNode".casefold():
            from .res_node import ResNode

            return ResNode()
        if mapping_value and mapping_value.casefold() == "ResPlanarNode".casefold():
            from .res_planar_node import ResPlanarNode

            return ResPlanarNode()
        if mapping_value and mapping_value.casefold() == "ResPlanarSupport".casefold():
            from .res_planar_support import ResPlanarSupport

            return ResPlanarSupport()
        if mapping_value and mapping_value.casefold() == "ResPunctualSupport".casefold():
            from .res_punctual_support import ResPunctualSupport

            return ResPunctualSupport()
        return ResBase()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID
        from .res_element_linear import ResElementLinear
        from .res_element_planar import ResElementPlanar
        from .res_linear_support import ResLinearSupport
        from .res_node import ResNode
        from .res_planar_node import ResPlanarNode
        from .res_planar_support import ResPlanarSupport
        from .res_punctual_support import ResPunctualSupport

        from .e_i_d import EID
        from .res_element_linear import ResElementLinear
        from .res_element_planar import ResElementPlanar
        from .res_linear_support import ResLinearSupport
        from .res_node import ResNode
        from .res_planar_node import ResPlanarNode
        from .res_planar_support import ResPlanarSupport
        from .res_punctual_support import ResPunctualSupport

        fields: dict[str, Callable[[Any], None]] = {
            "id": lambda n : setattr(self, 'id', n.get_object_value(EID)),
            "$type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("id", self.id)
        writer.write_str_value("$type", self.type)
    

