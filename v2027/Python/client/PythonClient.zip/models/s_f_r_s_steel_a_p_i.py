from enum import Enum

class SFRSSteel_API(str, Enum):
    DuctileMomentResistingFrame = "DuctileMomentResistingFrame",
    DuctileBracedFrame = "DuctileBracedFrame",
    ModeratelyDuctileMomentResistingFrame = "ModeratelyDuctileMomentResistingFrame",
    ModeratelyDuctileBracedFrame = "ModeratelyDuctileBracedFrame",
    ConventionalConstruction = "ConventionalConstruction",

