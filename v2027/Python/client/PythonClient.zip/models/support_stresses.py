from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SupportStresses(Parsable):
    """
    Stresses container for supports.
    """
    # Von Mises or resultant (support)
    s: Optional[float] = None
    # Support stress X
    sx: Optional[float] = None
    # Support stress Y
    sy: Optional[float] = None
    # Support stress Z
    sz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SupportStresses:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SupportStresses
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SupportStresses()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "s": lambda n : setattr(self, 's', n.get_float_value()),
            "sx": lambda n : setattr(self, 'sx', n.get_float_value()),
            "sy": lambda n : setattr(self, 'sy', n.get_float_value()),
            "sz": lambda n : setattr(self, 'sz', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("s", self.s)
        writer.write_float_value("sx", self.sx)
        writer.write_float_value("sy", self.sy)
        writer.write_float_value("sz", self.sz)
    

