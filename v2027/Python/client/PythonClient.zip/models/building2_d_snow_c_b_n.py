from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class Building2DSnowCBN(Parsable):
    """
    2D Building parameters for Snow CBN Sn 2010
    """
    # Building lengthUnit: m (meters)Default: 30.0
    building_length: Optional[float] = None
    # Portal positionUnit: m (meters)Default: 5.0
    portal_position: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Building2DSnowCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Building2DSnowCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Building2DSnowCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "buildingLength": lambda n : setattr(self, 'building_length', n.get_float_value()),
            "portalPosition": lambda n : setattr(self, 'portal_position', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("buildingLength", self.building_length)
        writer.write_float_value("portalPosition", self.portal_position)
    

