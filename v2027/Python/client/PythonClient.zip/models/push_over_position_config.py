from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PushOverPositionConfig(Parsable):
    """
    Push over position configuration (eccentricity)
    """
    # Eccentricity on X directionePushOverEccentricityOnX_YPlus = 0, ePushOverEccentricityOnX_YMinus = 1Default: Y+ (0)
    eccentricity_on_x: Optional[int] = None
    # Eccentricity on Y directionePushOverEccentricityOnY_XPlus = 0, ePushOverEccentricityOnY_XMinus = 1Default: X+ (0)
    eccentricity_on_y: Optional[int] = None
    # Enable load eccentricityDefault: false
    load_eccentricity: Optional[bool] = None
    # Percentage value on XUnit: %Default: 5.0
    percentage_on_x: Optional[float] = None
    # Percentage value on YUnit: %Default: 5.0
    percentage_on_y: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PushOverPositionConfig:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PushOverPositionConfig
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PushOverPositionConfig()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "eccentricityOnX": lambda n : setattr(self, 'eccentricity_on_x', n.get_int_value()),
            "eccentricityOnY": lambda n : setattr(self, 'eccentricity_on_y', n.get_int_value()),
            "loadEccentricity": lambda n : setattr(self, 'load_eccentricity', n.get_bool_value()),
            "percentageOnX": lambda n : setattr(self, 'percentage_on_x', n.get_float_value()),
            "percentageOnY": lambda n : setattr(self, 'percentage_on_y', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("eccentricityOnX", self.eccentricity_on_x)
        writer.write_int_value("eccentricityOnY", self.eccentricity_on_y)
        writer.write_bool_value("loadEccentricity", self.load_eccentricity)
        writer.write_float_value("percentageOnX", self.percentage_on_x)
        writer.write_float_value("percentageOnY", self.percentage_on_y)
    

