from enum import Enum

class ClippingCalculationType_API(str, Enum):
    Clipping_auto = "clipping_auto",
    Clipping_imposed = "clipping_imposed",

