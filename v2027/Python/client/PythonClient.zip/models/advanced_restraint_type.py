from enum import Enum

class AdvancedRestraintType(str, Enum):
    EFree = "eFree",
    EFixed = "eFixed",
    EElastic = "eElastic",
    ENLActiveForCompression = "eNLActiveForCompression",
    ENLActiveForTension = "eNLActiveForTension",
    ENLGap = "eNLGap",
    ENLHardening = "eNLHardening",
    ENLDiagram = "eNLDiagram",

