from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .coordinate_system_for_linear_or_planar_geometry import CoordinateSystemForLinearOrPlanarGeometry
    from .element_base import ElementBase
    from .e_i_d import EID
    from .linear_variation import LinearVariation
    from .moment_components import MomentComponents
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class ElementLoadLinear(ElementBase, AdditionalDataHolder, Parsable):
    """
    Punctual load
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .coordinate_system_for_linear_or_planar_geometry import CoordinateSystemForLinearOrPlanarGeometry

    # Loads coordinate system type (raw enum value).Unit: no unit Default value : 0
    coordinate_system_type: Optional[CoordinateSystemForLinearOrPlanarGeometry] = CoordinateSystemForLinearOrPlanarGeometry("global_or_user")
    # Force component FX (N) (over length unit m - to be considered a load), at least one of FX, FY, FZ, MX, MY or MZ must not be 0. Unit: N Default value : 0.0
    fx: Optional[float] = None
    # Force component FY (N) (over length unit m - to be considered a load), at least one of FX, FY, FZ, MX, MY or MZ must not be 0. Unit: N Default value : 0.0
    fy: Optional[float] = None
    # Force component FZ (N) (over length unit m - to be considered a load), at least one of FX, FY, FZ, MX, MY or MZ must not be 0. Unit: N Default value : 0.0
    fz: Optional[float] = None
    # End point in 3D space expressed in global axes.Unit: m Default value : (0, 0, 0)
    geom_pt_end: Optional[Pt3D] = None
    # Start oint in 3D space expressed in global axes.Unit: m Default value : (0, 0, 0)
    geom_pt_start: Optional[Pt3D] = None
    # EID of the load case already created
    load_case: Optional[EID] = None
    # Moment components, optional if any of FX, FY or FZ is not 0 Default value : optional nullable object
    moment: Optional[MomentComponents] = None
    # User comment for the load element.Default value : null
    user_comment: Optional[str] = None
    # Load variation.Default value : optional nullable object
    variation: Optional[LinearVariation] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementLoadLinear:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementLoadLinear
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementLoadLinear()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .coordinate_system_for_linear_or_planar_geometry import CoordinateSystemForLinearOrPlanarGeometry
        from .element_base import ElementBase
        from .e_i_d import EID
        from .linear_variation import LinearVariation
        from .moment_components import MomentComponents
        from .pt3_d import Pt3D

        from .coordinate_system_for_linear_or_planar_geometry import CoordinateSystemForLinearOrPlanarGeometry
        from .element_base import ElementBase
        from .e_i_d import EID
        from .linear_variation import LinearVariation
        from .moment_components import MomentComponents
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "coordinateSystemType": lambda n : setattr(self, 'coordinate_system_type', n.get_enum_value(CoordinateSystemForLinearOrPlanarGeometry)),
            "fx": lambda n : setattr(self, 'fx', n.get_float_value()),
            "fy": lambda n : setattr(self, 'fy', n.get_float_value()),
            "fz": lambda n : setattr(self, 'fz', n.get_float_value()),
            "geomPtEnd": lambda n : setattr(self, 'geom_pt_end', n.get_object_value(Pt3D)),
            "geomPtStart": lambda n : setattr(self, 'geom_pt_start', n.get_object_value(Pt3D)),
            "loadCase": lambda n : setattr(self, 'load_case', n.get_object_value(EID)),
            "moment": lambda n : setattr(self, 'moment', n.get_object_value(MomentComponents)),
            "userComment": lambda n : setattr(self, 'user_comment', n.get_str_value()),
            "variation": lambda n : setattr(self, 'variation', n.get_object_value(LinearVariation)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("coordinateSystemType", self.coordinate_system_type)
        writer.write_float_value("fx", self.fx)
        writer.write_float_value("fy", self.fy)
        writer.write_float_value("fz", self.fz)
        writer.write_object_value("geomPtEnd", self.geom_pt_end)
        writer.write_object_value("geomPtStart", self.geom_pt_start)
        writer.write_object_value("loadCase", self.load_case)
        writer.write_object_value("moment", self.moment)
        writer.write_str_value("userComment", self.user_comment)
        writer.write_object_value("variation", self.variation)
        writer.write_additional_data_value(self.additional_data)
    

