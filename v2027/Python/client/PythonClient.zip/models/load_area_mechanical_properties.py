from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID

@dataclass
class LoadAreaMechanicalProperties(Parsable):
    """
    Load area mechanical properties
    """
    # EID of the material already created to be taken into account for SelfWeight and RigidDiafragmrequired for RigidDiafragm or SelfWeightAuto = true
    material: Optional[EID] = None
    # creates a RigidDiafragm planar element in analysis model based on Material and ThicknessDefault value : false
    rigid_diafragm: Optional[bool] = None
    # add Self Weight in analysis model based on Material and ThicknessDefault value : false
    self_weight_auto: Optional[bool] = None
    # Thickness of load area taken into account for SelfWeight and RigidDiafragm;Unit: mDefault value : 0.2
    thickness: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadAreaMechanicalProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadAreaMechanicalProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadAreaMechanicalProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID

        from .e_i_d import EID

        fields: dict[str, Callable[[Any], None]] = {
            "material": lambda n : setattr(self, 'material', n.get_object_value(EID)),
            "rigidDiafragm": lambda n : setattr(self, 'rigid_diafragm', n.get_bool_value()),
            "selfWeightAuto": lambda n : setattr(self, 'self_weight_auto', n.get_bool_value()),
            "thickness": lambda n : setattr(self, 'thickness', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("material", self.material)
        writer.write_bool_value("rigidDiafragm", self.rigid_diafragm)
        writer.write_bool_value("selfWeightAuto", self.self_weight_auto)
        writer.write_float_value("thickness", self.thickness)
    

