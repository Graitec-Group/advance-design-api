from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case_family import LoadCaseFamily
    from .push_over_load_distribution import PushOverLoadDistribution

from .load_case_family import LoadCaseFamily

@dataclass
class LoadCaseFamily_PushOver(LoadCaseFamily, AdditionalDataHolder, Parsable):
    """
    Push over loads case family, load case parent
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Load distribution configuration for load type 1
    load_type1: Optional[PushOverLoadDistribution] = None
    # Load distribution configuration for load type 2
    load_type2: Optional[PushOverLoadDistribution] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily_PushOver:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily_PushOver
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseFamily_PushOver()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case_family import LoadCaseFamily
        from .push_over_load_distribution import PushOverLoadDistribution

        from .load_case_family import LoadCaseFamily
        from .push_over_load_distribution import PushOverLoadDistribution

        fields: dict[str, Callable[[Any], None]] = {
            "loadType1": lambda n : setattr(self, 'load_type1', n.get_object_value(PushOverLoadDistribution)),
            "loadType2": lambda n : setattr(self, 'load_type2', n.get_object_value(PushOverLoadDistribution)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("loadType1", self.load_type1)
        writer.write_object_value("loadType2", self.load_type2)
        writer.write_additional_data_value(self.additional_data)
    

