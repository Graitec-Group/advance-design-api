from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .occupancy_category_i_b_c_a_p_i import OccupancyCategoryIBC_API
    from .site_class_i_b_c_a_p_i import SiteClassIBC_API

@dataclass
class ImplantationSeismicIBC(Parsable):
    """
    Implantation parameters for IBC seismic load case family
    """
    from .occupancy_category_i_b_c_a_p_i import OccupancyCategoryIBC_API

    # Occupancy Category (I, II, III, IV)Default: OccupancyCategoryIBC_API.II
    occupancy_category: Optional[OccupancyCategoryIBC_API] = OccupancyCategoryIBC_API("II")
    from .site_class_i_b_c_a_p_i import SiteClassIBC_API

    # Site class (A through F)Default: SiteClassIBC_API.D
    site_class: Optional[SiteClassIBC_API] = SiteClassIBC_API("D")
    # Site coefficient Fa (short period)Unit: adimensionalDefault: calculated based on site class and Ss
    fa: Optional[float] = None
    # Site coefficient Fv (1 second period)Unit: adimensionalDefault: calculated based on site class and S1
    fv: Optional[float] = None
    # Mapped spectral response acceleration parameter at 1 second periodUnit: adimensionalDefault: 0.0
    s1: Optional[float] = None
    # Spectral acceleration at TLUnit: adimensionalDefault: calculated
    sa_t_l: Optional[float] = None
    # Spectral acceleration at TsUnit: adimensionalDefault: calculated (0.666666666666 * Fa * Ss)
    sa_t_s: Optional[float] = None
    # Spectral acceleration at T0Unit: adimensionalDefault: calculated (0.666666666666 * Fa * Ss)
    sa_t0: Optional[float] = None
    # Mapped spectral response acceleration parameter at short periodsUnit: adimensionalDefault: 0.0
    ss: Optional[float] = None
    # Transition period (0.2 * Fv * S1 / (Fa * Ss))Unit: time (seconds)Default: calculated
    t0: Optional[float] = None
    # Long-period transition periodUnit: time (seconds)Default: 0.0
    tl: Optional[float] = None
    # Short period transition (Fv * S1 / (Fa * Ss))Unit: time (seconds)Default: calculated
    ts: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ImplantationSeismicIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ImplantationSeismicIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ImplantationSeismicIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .occupancy_category_i_b_c_a_p_i import OccupancyCategoryIBC_API
        from .site_class_i_b_c_a_p_i import SiteClassIBC_API

        from .occupancy_category_i_b_c_a_p_i import OccupancyCategoryIBC_API
        from .site_class_i_b_c_a_p_i import SiteClassIBC_API

        fields: dict[str, Callable[[Any], None]] = {
            "fa": lambda n : setattr(self, 'fa', n.get_float_value()),
            "fv": lambda n : setattr(self, 'fv', n.get_float_value()),
            "occupancyCategory": lambda n : setattr(self, 'occupancy_category', n.get_enum_value(OccupancyCategoryIBC_API)),
            "s1": lambda n : setattr(self, 's1', n.get_float_value()),
            "saTL": lambda n : setattr(self, 'sa_t_l', n.get_float_value()),
            "saTS": lambda n : setattr(self, 'sa_t_s', n.get_float_value()),
            "saT0": lambda n : setattr(self, 'sa_t0', n.get_float_value()),
            "siteClass": lambda n : setattr(self, 'site_class', n.get_enum_value(SiteClassIBC_API)),
            "ss": lambda n : setattr(self, 'ss', n.get_float_value()),
            "t0": lambda n : setattr(self, 't0', n.get_float_value()),
            "tl": lambda n : setattr(self, 'tl', n.get_float_value()),
            "ts": lambda n : setattr(self, 'ts', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("fa", self.fa)
        writer.write_float_value("fv", self.fv)
        writer.write_enum_value("occupancyCategory", self.occupancy_category)
        writer.write_float_value("s1", self.s1)
        writer.write_float_value("saTL", self.sa_t_l)
        writer.write_float_value("saTS", self.sa_t_s)
        writer.write_float_value("saT0", self.sa_t0)
        writer.write_enum_value("siteClass", self.site_class)
        writer.write_float_value("ss", self.ss)
        writer.write_float_value("t0", self.t0)
        writer.write_float_value("tl", self.tl)
        writer.write_float_value("ts", self.ts)
    

