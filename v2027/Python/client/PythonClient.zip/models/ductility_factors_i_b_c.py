from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class DuctilityFactorsIBC(Parsable):
    """
    Ductility factors for IBC seismic effect
    """
    # Calibration flagDefault: true
    calibration: Optional[bool] = None
    # Deflection amplification factorUnit: adimensionalDefault: calculated based on SFRS
    cd: Optional[float] = None
    # Response modification coefficientUnit: adimensionalDefault: calculated based on SFRS
    r: Optional[float] = None
    # Torsion consideration flagDefault: true
    torsion: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DuctilityFactorsIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DuctilityFactorsIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DuctilityFactorsIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "calibration": lambda n : setattr(self, 'calibration', n.get_bool_value()),
            "cd": lambda n : setattr(self, 'cd', n.get_float_value()),
            "r": lambda n : setattr(self, 'r', n.get_float_value()),
            "torsion": lambda n : setattr(self, 'torsion', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("calibration", self.calibration)
        writer.write_float_value("cd", self.cd)
        writer.write_float_value("r", self.r)
        writer.write_bool_value("torsion", self.torsion)
    

