from enum import Enum

class ImportanceFactorIE_API(str, Enum):
    IE_0_8 = "IE_0_8",
    IE_1_0 = "IE_1_0",
    IE_1_3 = "IE_1_3",
    IE_1_5 = "IE_1_5",

