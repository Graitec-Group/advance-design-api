from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .function_point import FunctionPoint

@dataclass
class ConnectionElastiqueObject(Parsable):
    """
    Connection elastique object properties
    """
    # Elastique relaxation Rx optionThis property holds the function definition.    Set to null to allow engine defaults
    elastique_relaxation_rx_values: Optional[list[FunctionPoint]] = None
    # Elastique relaxation Ry optionThis property holds the function definition.    Set to null to allow engine defaults
    elastique_relaxation_ry_values: Optional[list[FunctionPoint]] = None
    # Elastique relaxation Rz optionThis property holds the function definition.    Set to null to allow engine defaults
    elastique_relaxation_rz_values: Optional[list[FunctionPoint]] = None
    # Elastique relaxation Tx option    Set to null to allow engine defaults
    elastique_relaxation_tx_values: Optional[list[FunctionPoint]] = None
    # Elastique relaxation Ty optionThis property holds the function definition.Set to null to allow engine defaults
    elastique_relaxation_ty_values: Optional[list[FunctionPoint]] = None
    # Elastique relaxation Tz optionThis property holds the function definition.    Set to null to allow engine defaults
    elastique_relaxation_tz_values: Optional[list[FunctionPoint]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConnectionElastiqueObject:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConnectionElastiqueObject
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConnectionElastiqueObject()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .function_point import FunctionPoint

        from .function_point import FunctionPoint

        fields: dict[str, Callable[[Any], None]] = {
            "elastiqueRelaxationRxValues": lambda n : setattr(self, 'elastique_relaxation_rx_values', n.get_collection_of_object_values(FunctionPoint)),
            "elastiqueRelaxationRyValues": lambda n : setattr(self, 'elastique_relaxation_ry_values', n.get_collection_of_object_values(FunctionPoint)),
            "elastiqueRelaxationRzValues": lambda n : setattr(self, 'elastique_relaxation_rz_values', n.get_collection_of_object_values(FunctionPoint)),
            "elastiqueRelaxationTxValues": lambda n : setattr(self, 'elastique_relaxation_tx_values', n.get_collection_of_object_values(FunctionPoint)),
            "elastiqueRelaxationTyValues": lambda n : setattr(self, 'elastique_relaxation_ty_values', n.get_collection_of_object_values(FunctionPoint)),
            "elastiqueRelaxationTzValues": lambda n : setattr(self, 'elastique_relaxation_tz_values', n.get_collection_of_object_values(FunctionPoint)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("elastiqueRelaxationRxValues", self.elastique_relaxation_rx_values)
        writer.write_collection_of_object_values("elastiqueRelaxationRyValues", self.elastique_relaxation_ry_values)
        writer.write_collection_of_object_values("elastiqueRelaxationRzValues", self.elastique_relaxation_rz_values)
        writer.write_collection_of_object_values("elastiqueRelaxationTxValues", self.elastique_relaxation_tx_values)
        writer.write_collection_of_object_values("elastiqueRelaxationTyValues", self.elastique_relaxation_ty_values)
        writer.write_collection_of_object_values("elastiqueRelaxationTzValues", self.elastique_relaxation_tz_values)
    

