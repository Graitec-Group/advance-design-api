from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .no_auto_y_e_s_imposed_options import No_AutoYES_Imposed_Options

@dataclass
class FreeStandingWallShelterFactor(Parsable):
    """
    Free Standing Wall Shelter Factor calculation and value class
    """
    from .no_auto_y_e_s_imposed_options import No_AutoYES_Imposed_Options

    # free standing wall sheltering factor calculationDefault value : No_AutoYES_Imposed_Options.e_Option_Auto
    calculation_option: Optional[No_AutoYES_Imposed_Options] = No_AutoYES_Imposed_Options("e_Option_Auto")
    # free standing wall sheltering factor valueUnit : no unitDefault value : 1.0
    shelter_factor_value: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FreeStandingWallShelterFactor:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FreeStandingWallShelterFactor
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return FreeStandingWallShelterFactor()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .no_auto_y_e_s_imposed_options import No_AutoYES_Imposed_Options

        from .no_auto_y_e_s_imposed_options import No_AutoYES_Imposed_Options

        fields: dict[str, Callable[[Any], None]] = {
            "calculationOption": lambda n : setattr(self, 'calculation_option', n.get_enum_value(No_AutoYES_Imposed_Options)),
            "shelterFactorValue": lambda n : setattr(self, 'shelter_factor_value', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("calculationOption", self.calculation_option)
        writer.write_float_value("shelterFactorValue", self.shelter_factor_value)
    

