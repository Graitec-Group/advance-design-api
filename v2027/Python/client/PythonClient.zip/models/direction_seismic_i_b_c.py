from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .direction_choice_a_p_i import DirectionChoice_API
    from .sign_choice_a_p_i import SignChoice_API

@dataclass
class DirectionSeismicIBC(Parsable):
    """
    Direction configuration for IBC seismic effect
    """
    from .direction_choice_a_p_i import DirectionChoice_API

    # Direction choice (X, Y, Z, XY)Default: DirectionChoice_API.X
    direction_choice: Optional[DirectionChoice_API] = DirectionChoice_API("X")
    from .sign_choice_a_p_i import SignChoice_API

    # Sign choice for resultsDefault: SignChoice_API.UNSIGNED
    sign_choice: Optional[SignChoice_API] = SignChoice_API("UNSIGNED")
    # Mode number for signed resultsDefault: 1
    mode: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DirectionSeismicIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DirectionSeismicIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DirectionSeismicIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .direction_choice_a_p_i import DirectionChoice_API
        from .sign_choice_a_p_i import SignChoice_API

        from .direction_choice_a_p_i import DirectionChoice_API
        from .sign_choice_a_p_i import SignChoice_API

        fields: dict[str, Callable[[Any], None]] = {
            "directionChoice": lambda n : setattr(self, 'direction_choice', n.get_enum_value(DirectionChoice_API)),
            "mode": lambda n : setattr(self, 'mode', n.get_int_value()),
            "signChoice": lambda n : setattr(self, 'sign_choice', n.get_enum_value(SignChoice_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("directionChoice", self.direction_choice)
        writer.write_int_value("mode", self.mode)
        writer.write_enum_value("signChoice", self.sign_choice)
    

