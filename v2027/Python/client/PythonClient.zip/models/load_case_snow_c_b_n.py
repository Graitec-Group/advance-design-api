from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .effect_parameters_snow_c_b_n import EffectParametersSnowCBN
    from .load_case_snow import LoadCase_Snow
    from .snow_load_category_a_p_i import SnowLoadCategory_API

from .load_case_snow import LoadCase_Snow

@dataclass
class LoadCase_SnowCBN(LoadCase_Snow, AdditionalDataHolder, Parsable):
    """
    Snow load case for CBN Sn 2010
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .snow_load_category_a_p_i import SnowLoadCategory_API

    # Snow load categoryUnit: -Default: eSnowZoneUnder1000
    snow_load_category: Optional[SnowLoadCategory_API] = SnowLoadCategory_API("eSnowZoneUnder1000")
    # Effect-specific parameters (kind, type, automatic, updated)
    effect_parameters: Optional[EffectParametersSnowCBN] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_SnowCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_SnowCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_SnowCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .effect_parameters_snow_c_b_n import EffectParametersSnowCBN
        from .load_case_snow import LoadCase_Snow
        from .snow_load_category_a_p_i import SnowLoadCategory_API

        from .effect_parameters_snow_c_b_n import EffectParametersSnowCBN
        from .load_case_snow import LoadCase_Snow
        from .snow_load_category_a_p_i import SnowLoadCategory_API

        fields: dict[str, Callable[[Any], None]] = {
            "effectParameters": lambda n : setattr(self, 'effect_parameters', n.get_object_value(EffectParametersSnowCBN)),
            "snowLoadCategory": lambda n : setattr(self, 'snow_load_category', n.get_enum_value(SnowLoadCategory_API)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("effectParameters", self.effect_parameters)
        writer.write_enum_value("snowLoadCategory", self.snow_load_category)
        writer.write_additional_data_value(self.additional_data)
    

