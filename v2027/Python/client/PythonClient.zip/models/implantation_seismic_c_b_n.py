from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .importance_factor_i_e_a_p_i import ImportanceFactorIE_API
    from .seismic_category_a_p_i import SeismicCategory_API
    from .site_class_a_p_i import SiteClass_API

@dataclass
class ImplantationSeismicCBN(Parsable):
    """
    Implantation parameters for Seismic CBN load case family
    """
    from .importance_factor_i_e_a_p_i import ImportanceFactorIE_API

    # Importance factor IEDefault: ImportanceFactorIE_API.IE_1_0
    importance_factor_i_e: Optional[ImportanceFactorIE_API] = ImportanceFactorIE_API("IE_1_0")
    from .seismic_category_a_p_i import SeismicCategory_API

    # Seismic category - CBN 2020 onlyDefault: SeismicCategory_API.SC1
    seismic_category: Optional[SeismicCategory_API] = SeismicCategory_API("SC1")
    from .site_class_a_p_i import SiteClass_API

    # Site class for soil conditionsDefault: SiteClass_API.C
    site_class: Optional[SiteClass_API] = SiteClass_API("C")
    # Seismic zone hashDefault: " "
    zone_hash: Optional[str] = " "
    # Site coefficient Fa for short periodUnit: dimensionlessDefault: 0.0
    fa: Optional[float] = None
    # Site coefficient Fv for 1s periodUnit: dimensionlessDefault: 0.0
    fv: Optional[float] = None
    # IeFaSa02 or IeS02 depending on CBN versionCBN 2020: IeS02 = max(Sa02, Sa05) * IeCBN 2005/2015: IeFaSa02Unit: g (dimensionless)Default: 0.0
    ie_fa_sa02: Optional[float] = None
    # IeS10 = Sa10 * Ie - CBN 2020 onlyUnit: g (dimensionless)Default: 0.0
    ie_s10: Optional[float] = None
    # Peak Ground Acceleration (PGA) - CBN 2015/2020 onlyUnit: g (dimensionless)Default: 0.0
    pga: Optional[float] = None
    # Spectral acceleration Sa(0.2) - all site classesUnit: g (dimensionless)Default: 0.0
    sa02: Optional[float] = None
    # Spectral acceleration Sa(0.2) at X=450 - CBN 2020 onlyUnit: g (dimensionless)Default: 0.0
    sa02_x450: Optional[float] = None
    # Spectral acceleration Sa(0.5) - all site classesUnit: g (dimensionless)Default: 0.0
    sa05: Optional[float] = None
    # Spectral acceleration Sa(0.5) at X=450 - CBN 2020 onlyUnit: g (dimensionless)Default: 0.0
    sa05_x450: Optional[float] = None
    # Spectral acceleration Sa(1.0) - all site classesUnit: g (dimensionless)Default: 0.0
    sa10: Optional[float] = None
    # Spectral acceleration Sa(1.0) at X=450 - CBN 2020 onlyUnit: g (dimensionless)Default: 0.0
    sa10_x450: Optional[float] = None
    # Spectral acceleration Sa(10.0) - CBN 2015/2020 onlyUnit: g (dimensionless)Default: 0.0
    sa100: Optional[float] = None
    # Spectral acceleration Sa(2.0) - all site classesUnit: g (dimensionless)Default: 0.0
    sa20: Optional[float] = None
    # Spectral acceleration Sa(2.0) at X=450 - CBN 2020 onlyUnit: g (dimensionless)Default: 0.0
    sa20_x450: Optional[float] = None
    # Spectral acceleration Sa(5.0) - CBN 2015/2020 onlyUnit: g (dimensionless)Default: 0.0
    sa50: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ImplantationSeismicCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ImplantationSeismicCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ImplantationSeismicCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .importance_factor_i_e_a_p_i import ImportanceFactorIE_API
        from .seismic_category_a_p_i import SeismicCategory_API
        from .site_class_a_p_i import SiteClass_API

        from .importance_factor_i_e_a_p_i import ImportanceFactorIE_API
        from .seismic_category_a_p_i import SeismicCategory_API
        from .site_class_a_p_i import SiteClass_API

        fields: dict[str, Callable[[Any], None]] = {
            "fa": lambda n : setattr(self, 'fa', n.get_float_value()),
            "fv": lambda n : setattr(self, 'fv', n.get_float_value()),
            "ieFaSa02": lambda n : setattr(self, 'ie_fa_sa02', n.get_float_value()),
            "ieS10": lambda n : setattr(self, 'ie_s10', n.get_float_value()),
            "importanceFactorIE": lambda n : setattr(self, 'importance_factor_i_e', n.get_enum_value(ImportanceFactorIE_API)),
            "pga": lambda n : setattr(self, 'pga', n.get_float_value()),
            "sa02": lambda n : setattr(self, 'sa02', n.get_float_value()),
            "sa02_X450": lambda n : setattr(self, 'sa02_x450', n.get_float_value()),
            "sa05": lambda n : setattr(self, 'sa05', n.get_float_value()),
            "sa05_X450": lambda n : setattr(self, 'sa05_x450', n.get_float_value()),
            "sa10": lambda n : setattr(self, 'sa10', n.get_float_value()),
            "sa10_X450": lambda n : setattr(self, 'sa10_x450', n.get_float_value()),
            "sa100": lambda n : setattr(self, 'sa100', n.get_float_value()),
            "sa20": lambda n : setattr(self, 'sa20', n.get_float_value()),
            "sa20_X450": lambda n : setattr(self, 'sa20_x450', n.get_float_value()),
            "sa50": lambda n : setattr(self, 'sa50', n.get_float_value()),
            "seismicCategory": lambda n : setattr(self, 'seismic_category', n.get_enum_value(SeismicCategory_API)),
            "siteClass": lambda n : setattr(self, 'site_class', n.get_enum_value(SiteClass_API)),
            "zoneHash": lambda n : setattr(self, 'zone_hash', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("fa", self.fa)
        writer.write_float_value("fv", self.fv)
        writer.write_float_value("ieFaSa02", self.ie_fa_sa02)
        writer.write_float_value("ieS10", self.ie_s10)
        writer.write_enum_value("importanceFactorIE", self.importance_factor_i_e)
        writer.write_float_value("pga", self.pga)
        writer.write_float_value("sa02", self.sa02)
        writer.write_float_value("sa02_X450", self.sa02_x450)
        writer.write_float_value("sa05", self.sa05)
        writer.write_float_value("sa05_X450", self.sa05_x450)
        writer.write_float_value("sa10", self.sa10)
        writer.write_float_value("sa10_X450", self.sa10_x450)
        writer.write_float_value("sa100", self.sa100)
        writer.write_float_value("sa20", self.sa20)
        writer.write_float_value("sa20_X450", self.sa20_x450)
        writer.write_float_value("sa50", self.sa50)
        writer.write_enum_value("seismicCategory", self.seismic_category)
        writer.write_enum_value("siteClass", self.site_class)
        writer.write_str_value("zoneHash", self.zone_hash)
    

