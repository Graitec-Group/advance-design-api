from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .ductility_determination_e_n1998_a_p_i import DuctilityDeterminationEN1998_API

@dataclass
class DuctilityConfigEN1998(Parsable):
    """
    Ductility configuration for seismic EN 1998-1 effect
    """
    from .ductility_determination_e_n1998_a_p_i import DuctilityDeterminationEN1998_API

    # Method for determining ductility coefficientValues: 0=Q_CALCULATED, 1=Q_IMPOSEDefault: Q_IMPOSE (1)
    ductility_determination: Optional[DuctilityDeterminationEN1998_API] = DuctilityDeterminationEN1998_API("Q_IMPOSE")
    # Ductility coefficient value (q factor)Range: 1.0 to 10.0Unit: dimensionlessDefault: 1.0
    ductility_coefficient: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DuctilityConfigEN1998:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DuctilityConfigEN1998
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DuctilityConfigEN1998()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .ductility_determination_e_n1998_a_p_i import DuctilityDeterminationEN1998_API

        from .ductility_determination_e_n1998_a_p_i import DuctilityDeterminationEN1998_API

        fields: dict[str, Callable[[Any], None]] = {
            "ductilityCoefficient": lambda n : setattr(self, 'ductility_coefficient', n.get_float_value()),
            "ductilityDetermination": lambda n : setattr(self, 'ductility_determination', n.get_enum_value(DuctilityDeterminationEN1998_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("ductilityCoefficient", self.ductility_coefficient)
        writer.write_enum_value("ductilityDetermination", self.ductility_determination)
    

