from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .diagnostic_entry import DiagnosticEntry

@dataclass
class ApiResponseDetails(Parsable):
    """
    response details for API operations, including the actual result data and structured diagnostics.
    """
    # Diagnostics for this operation, filtered by the requested verbosity level.
    diagnostics: Optional[list[DiagnosticEntry]] = None
    # `true` when this operation produced at least one error or critical diagnostic.
    has_errors: Optional[bool] = None
    # `true` when this operation produced at least one warning.
    has_warnings: Optional[bool] = None
    # `true` when the operation completed without error-level diagnostics.
    success: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ApiResponseDetails:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ApiResponseDetails
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ApiResponseDetails()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .diagnostic_entry import DiagnosticEntry

        from .diagnostic_entry import DiagnosticEntry

        fields: dict[str, Callable[[Any], None]] = {
            "diagnostics": lambda n : setattr(self, 'diagnostics', n.get_collection_of_object_values(DiagnosticEntry)),
            "hasErrors": lambda n : setattr(self, 'has_errors', n.get_bool_value()),
            "hasWarnings": lambda n : setattr(self, 'has_warnings', n.get_bool_value()),
            "success": lambda n : setattr(self, 'success', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("diagnostics", self.diagnostics)
        writer.write_bool_value("hasErrors", self.has_errors)
        writer.write_bool_value("hasWarnings", self.has_warnings)
        writer.write_bool_value("success", self.success)
    

