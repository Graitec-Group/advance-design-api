from enum import Enum

class SFRSConcrete_API(str, Enum):
    DuctileMomentResistingFrame = "DuctileMomentResistingFrame",
    DuctileWallSystem = "DuctileWallSystem",
    ModeratelyDuctileMomentResistingFrame = "ModeratelyDuctileMomentResistingFrame",
    ModeratelyDuctileShearWall = "ModeratelyDuctileShearWall",
    ConventionalConstruction = "ConventionalConstruction",

