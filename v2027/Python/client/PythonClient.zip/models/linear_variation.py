from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class LinearVariation(Parsable):
    """
    Load linear variation properties
    """
    # Coefficient at extremity 1(1st point) of the action Unit: no unit Default value : 1.0
    coefficient1: Optional[float] = None
    # Coefficient at extremity 2(2nd point) of the action Unit: no unit Default value : 1.0
    coefficient2: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LinearVariation:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LinearVariation
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LinearVariation()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "coefficient1": lambda n : setattr(self, 'coefficient1', n.get_float_value()),
            "coefficient2": lambda n : setattr(self, 'coefficient2', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("coefficient1", self.coefficient1)
        writer.write_float_value("coefficient2", self.coefficient2)
    

