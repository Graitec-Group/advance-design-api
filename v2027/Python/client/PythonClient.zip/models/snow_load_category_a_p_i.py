from enum import Enum

class SnowLoadCategory_API(str, Enum):
    ESnowZoneUnder1000 = "eSnowZoneUnder1000",
    ESnowZoneOver1000 = "eSnowZoneOver1000",

