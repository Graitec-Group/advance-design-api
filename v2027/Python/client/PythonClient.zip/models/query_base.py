from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .query_elements_loads import QueryElementsLoads
    from .query_elements_model import QueryElementsModel
    from .query_info_load_case import QueryInfoLoadCase
    from .query_info_model import QueryInfoModel

@dataclass
class QueryBase(Parsable):
    """
    Base type for query models.
    """
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> QueryBase:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: QueryBase
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "QueryElementsLoads".casefold():
            from .query_elements_loads import QueryElementsLoads

            return QueryElementsLoads()
        if mapping_value and mapping_value.casefold() == "QueryElementsModel".casefold():
            from .query_elements_model import QueryElementsModel

            return QueryElementsModel()
        if mapping_value and mapping_value.casefold() == "QueryInfoLoadCase".casefold():
            from .query_info_load_case import QueryInfoLoadCase

            return QueryInfoLoadCase()
        if mapping_value and mapping_value.casefold() == "QueryInfoModel".casefold():
            from .query_info_model import QueryInfoModel

            return QueryInfoModel()
        return QueryBase()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .query_elements_loads import QueryElementsLoads
        from .query_elements_model import QueryElementsModel
        from .query_info_load_case import QueryInfoLoadCase
        from .query_info_model import QueryInfoModel

        from .query_elements_loads import QueryElementsLoads
        from .query_elements_model import QueryElementsModel
        from .query_info_load_case import QueryInfoLoadCase
        from .query_info_model import QueryInfoModel

        fields: dict[str, Callable[[Any], None]] = {
            "$type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("$type", self.type)
    

