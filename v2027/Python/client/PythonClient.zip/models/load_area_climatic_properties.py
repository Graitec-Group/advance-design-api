from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .free_standing_wall_shelter_factor import FreeStandingWallShelterFactor
    from .gutter_type import Gutter_type
    from .load_area_opening_type import LoadArea_Opening_type
    from .load_area_positioning import LoadArea_positioning
    from .load_area_type import Load_Area_Type

@dataclass
class LoadAreaClimaticProperties(Parsable):
    """
    Load area Climatic(wind and snow) properties
    """
    from .load_area_type import Load_Area_Type

    # Climatic Type - what type of structure is considered to simulate in the climatic engineDefault value : Load_Area_Type.CG_LOADAREA_BUILDING
    climatic_type: Optional[Load_Area_Type] = Load_Area_Type("CG_LOADAREA_BUILDING")
    from .gutter_type import Gutter_type

    # Selection of whether to include the gutter effect. Gutter effect creates additional load accumulation when automatic generating snow loads, due to snow melting. The behavior is described in the art. 5.2(6) of NF EN 1991-1-3/NADefault value : Gutter_type.CG_GUTTER_EFFECT_NONE
    gutter: Optional[Gutter_type] = Gutter_type("CG_GUTTER_EFFECT_NONE")
    from .load_area_opening_type import LoadArea_Opening_type

    # Load area opening typeDefault value : LoadArea_Opening_type.CG_WINDWALL_OPENING_TYPE_CLOSED_NO_OPENINGS
    opening_type: Optional[LoadArea_Opening_type] = LoadArea_Opening_type("CG_WINDWALL_OPENING_TYPE_CLOSED_NO_OPENINGS")
    # available for the automatic snow calculation in the climatic engineDefault value : true
    available_for_snow: Optional[bool] = None
    # available for the automatic wind calculation in the climatic engineDefault value : true
    available_for_wind: Optional[bool] = None
    # empty or with Wind_Directions_type::GRCG_WIND_DIRECTIONS_NO(=4) elements for each wind direction X+(position 0), X-(position 1), Y+(position 2) and Y-(position 3)Default value : LoadArea_positioning.GRCG_WIND_EXPOSURE_WINDWARD for each entry in list
    exposure_per_direction: Optional[list[LoadArea_positioning]] = None
    # Load area opening valueUnit: meters*meters if OpeningType = CG_WINDWALL_OPENING_TYPE_AREA or in percent (0 to 100) for OpeningType = CG_WINDWALL_OPENING_TYPE_AREA_PERCENTAGEDefault value : 0.0
    opening_value: Optional[float] = None
    # This is used for snow accumulation reduction against this parapet by subtracting it from the parapet height (EN 1991-1-3: 6.2 and B.4). This is active and taken into account if this load area is set to parapet type.Unit: mDefault value : 0.0
    parapet_reduction_height_by_purlins_and_roof_cover: Optional[float] = None
    # Free standing wall options per wind direction(X+, X-, Y+ and Y-) : empty or with Wind_Directions_type::GRCG_WIND_DIRECTIONS_NO(=4) elements for each wind direction X+(position 0), X-(position 1), Y+(position 2) and Y-(position 3)
    shelter_options_per_direction: Optional[list[FreeStandingWallShelterFactor]] = None
    # Use this option when snow fences or other obstructions exist on this load area or where the lower edge of the roof(load area) is terminated with a parapet. The snow load shape coefficient is then not reduced below 0,8 for monopitch and pitched roofs (5.3.2 (2), 5.3.3(2), EN 1991-1-3)Default value : false
    snow_guards_presence: Optional[bool] = None
    # Free standing wall solidity ratioUnit: no unitDefault value : 1.0
    solidity_ratio: Optional[float] = None
    # Canada : unobstructed slippery roofs where snow and ice can slide completely off the roofUS : The ability to shed snow load by sliding (roof’s surface slipperiness).A roof shall be considered unobstructed if no objects exist on it that prevent snow on it from sliding.Slippery surfaces shall include metal, slate, glass, and bituminous, rubber, and plastic membranes with a smooth surface.Default value : false
    unobstructed_slippery: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadAreaClimaticProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadAreaClimaticProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadAreaClimaticProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .free_standing_wall_shelter_factor import FreeStandingWallShelterFactor
        from .gutter_type import Gutter_type
        from .load_area_opening_type import LoadArea_Opening_type
        from .load_area_positioning import LoadArea_positioning
        from .load_area_type import Load_Area_Type

        from .free_standing_wall_shelter_factor import FreeStandingWallShelterFactor
        from .gutter_type import Gutter_type
        from .load_area_opening_type import LoadArea_Opening_type
        from .load_area_positioning import LoadArea_positioning
        from .load_area_type import Load_Area_Type

        fields: dict[str, Callable[[Any], None]] = {
            "availableForSnow": lambda n : setattr(self, 'available_for_snow', n.get_bool_value()),
            "availableForWind": lambda n : setattr(self, 'available_for_wind', n.get_bool_value()),
            "climaticType": lambda n : setattr(self, 'climatic_type', n.get_enum_value(Load_Area_Type)),
            "exposurePerDirection": lambda n : setattr(self, 'exposure_per_direction', n.get_collection_of_enum_values(LoadArea_positioning)),
            "gutter": lambda n : setattr(self, 'gutter', n.get_enum_value(Gutter_type)),
            "openingType": lambda n : setattr(self, 'opening_type', n.get_enum_value(LoadArea_Opening_type)),
            "openingValue": lambda n : setattr(self, 'opening_value', n.get_float_value()),
            "parapetReductionHeightByPurlinsAndRoofCover": lambda n : setattr(self, 'parapet_reduction_height_by_purlins_and_roof_cover', n.get_float_value()),
            "shelterOptionsPerDirection": lambda n : setattr(self, 'shelter_options_per_direction', n.get_collection_of_object_values(FreeStandingWallShelterFactor)),
            "snowGuardsPresence": lambda n : setattr(self, 'snow_guards_presence', n.get_bool_value()),
            "solidityRatio": lambda n : setattr(self, 'solidity_ratio', n.get_float_value()),
            "unobstructedSlippery": lambda n : setattr(self, 'unobstructed_slippery', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("availableForSnow", self.available_for_snow)
        writer.write_bool_value("availableForWind", self.available_for_wind)
        writer.write_enum_value("climaticType", self.climatic_type)
        writer.write_collection_of_enum_values("exposurePerDirection", self.exposure_per_direction)
        writer.write_enum_value("gutter", self.gutter)
        writer.write_enum_value("openingType", self.opening_type)
        writer.write_float_value("openingValue", self.opening_value)
        writer.write_float_value("parapetReductionHeightByPurlinsAndRoofCover", self.parapet_reduction_height_by_purlins_and_roof_cover)
        writer.write_collection_of_object_values("shelterOptionsPerDirection", self.shelter_options_per_direction)
        writer.write_bool_value("snowGuardsPresence", self.snow_guards_presence)
        writer.write_float_value("solidityRatio", self.solidity_ratio)
        writer.write_bool_value("unobstructedSlippery", self.unobstructed_slippery)
    

