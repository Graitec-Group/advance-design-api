from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_abscissa_value import ResAbscissaValue

@dataclass
class ResDiagramDisplacements(Parsable):
    """
    displacement diagram along an element, defined by a collection of AD.API.ResAbscissaValue instances representing the displacements at various positions along the element.
    """
    # Resultant displacement
    d: Optional[list[ResAbscissaValue]] = None
    # Displacement in X axis
    dx: Optional[list[ResAbscissaValue]] = None
    # Displacement in Y axis
    dy: Optional[list[ResAbscissaValue]] = None
    # Displacement in Z axis
    dz: Optional[list[ResAbscissaValue]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResDiagramDisplacements:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResDiagramDisplacements
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResDiagramDisplacements()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_abscissa_value import ResAbscissaValue

        from .res_abscissa_value import ResAbscissaValue

        fields: dict[str, Callable[[Any], None]] = {
            "d": lambda n : setattr(self, 'd', n.get_collection_of_object_values(ResAbscissaValue)),
            "dx": lambda n : setattr(self, 'dx', n.get_collection_of_object_values(ResAbscissaValue)),
            "dy": lambda n : setattr(self, 'dy', n.get_collection_of_object_values(ResAbscissaValue)),
            "dz": lambda n : setattr(self, 'dz', n.get_collection_of_object_values(ResAbscissaValue)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("d", self.d)
        writer.write_collection_of_object_values("dx", self.dx)
        writer.write_collection_of_object_values("dy", self.dy)
        writer.write_collection_of_object_values("dz", self.dz)
    

