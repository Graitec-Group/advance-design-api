from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID
    from .informational_element_base import InformationalElementBase
    from .load_case_accidental import LoadCase_Accidental
    from .load_case_combinations_coefficients import LoadCaseCombinationsCoefficients
    from .load_case_dead_loads import LoadCase_DeadLoads
    from .load_case_dynamic_temporal import LoadCase_DynamicTemporal
    from .load_case_live_loads import LoadCase_LiveLoads
    from .load_case_other import LoadCase_Other
    from .load_case_push_over import LoadCase_PushOver
    from .load_case_seismic import LoadCase_Seismic
    from .load_case_seismic_c_b_n import LoadCase_SeismicCBN
    from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
    from .load_case_seismic_i_b_c import LoadCase_SeismicIBC
    from .load_case_snow import LoadCase_Snow
    from .load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3
    from .load_case_snow_c_b_n import LoadCase_SnowCBN
    from .load_case_snow_i_b_c import LoadCase_SnowIBC
    from .load_case_thermic import LoadCase_Thermic
    from .load_case_wind import LoadCase_Wind
    from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
    from .load_case_wind_c_b_n import LoadCase_WindCBN
    from .load_case_wind_i_b_c import LoadCase_WindIBC

from .informational_element_base import InformationalElementBase

@dataclass
class LoadCase(InformationalElementBase, AdditionalDataHolder, Parsable):
    """
    Load case (parents of loads), child of LoadCaseFamily
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Combinations coefficients for this load case Default value : null (initialized with default values)
    combinations_coefficients: Optional[LoadCaseCombinationsCoefficients] = None
    # EID of the parent loads case family already created
    load_case_family_i_d: Optional[EID] = None
    # user name for the load case
    name: Optional[str] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "LoadCase_Accidental".casefold():
            from .load_case_accidental import LoadCase_Accidental

            return LoadCase_Accidental()
        if mapping_value and mapping_value.casefold() == "LoadCase_DeadLoads".casefold():
            from .load_case_dead_loads import LoadCase_DeadLoads

            return LoadCase_DeadLoads()
        if mapping_value and mapping_value.casefold() == "LoadCase_DynamicTemporal".casefold():
            from .load_case_dynamic_temporal import LoadCase_DynamicTemporal

            return LoadCase_DynamicTemporal()
        if mapping_value and mapping_value.casefold() == "LoadCase_LiveLoads".casefold():
            from .load_case_live_loads import LoadCase_LiveLoads

            return LoadCase_LiveLoads()
        if mapping_value and mapping_value.casefold() == "LoadCase_Other".casefold():
            from .load_case_other import LoadCase_Other

            return LoadCase_Other()
        if mapping_value and mapping_value.casefold() == "LoadCase_PushOver".casefold():
            from .load_case_push_over import LoadCase_PushOver

            return LoadCase_PushOver()
        if mapping_value and mapping_value.casefold() == "LoadCase_Seismic".casefold():
            from .load_case_seismic import LoadCase_Seismic

            return LoadCase_Seismic()
        if mapping_value and mapping_value.casefold() == "LoadCase_SeismicCBN".casefold():
            from .load_case_seismic_c_b_n import LoadCase_SeismicCBN

            return LoadCase_SeismicCBN()
        if mapping_value and mapping_value.casefold() == "LoadCase_SeismicEN_1998_1".casefold():
            from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1

            return LoadCase_SeismicEN_1998_1()
        if mapping_value and mapping_value.casefold() == "LoadCase_SeismicIBC".casefold():
            from .load_case_seismic_i_b_c import LoadCase_SeismicIBC

            return LoadCase_SeismicIBC()
        if mapping_value and mapping_value.casefold() == "LoadCase_Snow".casefold():
            from .load_case_snow import LoadCase_Snow

            return LoadCase_Snow()
        if mapping_value and mapping_value.casefold() == "LoadCase_Snow_1991_1_3".casefold():
            from .load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3

            return LoadCase_Snow_1991_1_3()
        if mapping_value and mapping_value.casefold() == "LoadCase_SnowCBN".casefold():
            from .load_case_snow_c_b_n import LoadCase_SnowCBN

            return LoadCase_SnowCBN()
        if mapping_value and mapping_value.casefold() == "LoadCase_SnowIBC".casefold():
            from .load_case_snow_i_b_c import LoadCase_SnowIBC

            return LoadCase_SnowIBC()
        if mapping_value and mapping_value.casefold() == "LoadCase_Thermic".casefold():
            from .load_case_thermic import LoadCase_Thermic

            return LoadCase_Thermic()
        if mapping_value and mapping_value.casefold() == "LoadCase_Wind".casefold():
            from .load_case_wind import LoadCase_Wind

            return LoadCase_Wind()
        if mapping_value and mapping_value.casefold() == "LoadCase_Wind_1991_1_4".casefold():
            from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4

            return LoadCase_Wind_1991_1_4()
        if mapping_value and mapping_value.casefold() == "LoadCase_WindCBN".casefold():
            from .load_case_wind_c_b_n import LoadCase_WindCBN

            return LoadCase_WindCBN()
        if mapping_value and mapping_value.casefold() == "LoadCase_WindIBC".casefold():
            from .load_case_wind_i_b_c import LoadCase_WindIBC

            return LoadCase_WindIBC()
        return LoadCase()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID
        from .informational_element_base import InformationalElementBase
        from .load_case_accidental import LoadCase_Accidental
        from .load_case_combinations_coefficients import LoadCaseCombinationsCoefficients
        from .load_case_dead_loads import LoadCase_DeadLoads
        from .load_case_dynamic_temporal import LoadCase_DynamicTemporal
        from .load_case_live_loads import LoadCase_LiveLoads
        from .load_case_other import LoadCase_Other
        from .load_case_push_over import LoadCase_PushOver
        from .load_case_seismic import LoadCase_Seismic
        from .load_case_seismic_c_b_n import LoadCase_SeismicCBN
        from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
        from .load_case_seismic_i_b_c import LoadCase_SeismicIBC
        from .load_case_snow import LoadCase_Snow
        from .load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3
        from .load_case_snow_c_b_n import LoadCase_SnowCBN
        from .load_case_snow_i_b_c import LoadCase_SnowIBC
        from .load_case_thermic import LoadCase_Thermic
        from .load_case_wind import LoadCase_Wind
        from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
        from .load_case_wind_c_b_n import LoadCase_WindCBN
        from .load_case_wind_i_b_c import LoadCase_WindIBC

        from .e_i_d import EID
        from .informational_element_base import InformationalElementBase
        from .load_case_accidental import LoadCase_Accidental
        from .load_case_combinations_coefficients import LoadCaseCombinationsCoefficients
        from .load_case_dead_loads import LoadCase_DeadLoads
        from .load_case_dynamic_temporal import LoadCase_DynamicTemporal
        from .load_case_live_loads import LoadCase_LiveLoads
        from .load_case_other import LoadCase_Other
        from .load_case_push_over import LoadCase_PushOver
        from .load_case_seismic import LoadCase_Seismic
        from .load_case_seismic_c_b_n import LoadCase_SeismicCBN
        from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
        from .load_case_seismic_i_b_c import LoadCase_SeismicIBC
        from .load_case_snow import LoadCase_Snow
        from .load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3
        from .load_case_snow_c_b_n import LoadCase_SnowCBN
        from .load_case_snow_i_b_c import LoadCase_SnowIBC
        from .load_case_thermic import LoadCase_Thermic
        from .load_case_wind import LoadCase_Wind
        from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
        from .load_case_wind_c_b_n import LoadCase_WindCBN
        from .load_case_wind_i_b_c import LoadCase_WindIBC

        fields: dict[str, Callable[[Any], None]] = {
            "combinationsCoefficients": lambda n : setattr(self, 'combinations_coefficients', n.get_object_value(LoadCaseCombinationsCoefficients)),
            "loadCaseFamilyID": lambda n : setattr(self, 'load_case_family_i_d', n.get_object_value(EID)),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("combinationsCoefficients", self.combinations_coefficients)
        writer.write_object_value("loadCaseFamilyID", self.load_case_family_i_d)
        writer.write_str_value("name", self.name)
        writer.write_additional_data_value(self.additional_data)
    

