from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_abscissa_value import ResAbscissaValue

@dataclass
class ResDiagramForces(Parsable):
    """
    linear diagram of forces along an element, defined by a collection of AD.API.ResAbscissaValue instances representing the forces at various positions along the element.
    """
    # Force in X axis
    fx: Optional[list[ResAbscissaValue]] = None
    # Force in Y axis
    fy: Optional[list[ResAbscissaValue]] = None
    # Force in Z axis
    fz: Optional[list[ResAbscissaValue]] = None
    # Moment in X axis
    mx: Optional[list[ResAbscissaValue]] = None
    # Moment in Y axis
    my: Optional[list[ResAbscissaValue]] = None
    # Moment in Z axis
    mz: Optional[list[ResAbscissaValue]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResDiagramForces:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResDiagramForces
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResDiagramForces()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_abscissa_value import ResAbscissaValue

        from .res_abscissa_value import ResAbscissaValue

        fields: dict[str, Callable[[Any], None]] = {
            "fx": lambda n : setattr(self, 'fx', n.get_collection_of_object_values(ResAbscissaValue)),
            "fy": lambda n : setattr(self, 'fy', n.get_collection_of_object_values(ResAbscissaValue)),
            "fz": lambda n : setattr(self, 'fz', n.get_collection_of_object_values(ResAbscissaValue)),
            "mx": lambda n : setattr(self, 'mx', n.get_collection_of_object_values(ResAbscissaValue)),
            "my": lambda n : setattr(self, 'my', n.get_collection_of_object_values(ResAbscissaValue)),
            "mz": lambda n : setattr(self, 'mz', n.get_collection_of_object_values(ResAbscissaValue)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("fx", self.fx)
        writer.write_collection_of_object_values("fy", self.fy)
        writer.write_collection_of_object_values("fz", self.fz)
        writer.write_collection_of_object_values("mx", self.mx)
        writer.write_collection_of_object_values("my", self.my)
        writer.write_collection_of_object_values("mz", self.mz)
    

