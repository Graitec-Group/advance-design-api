from enum import Enum

class PunchingPosition(str, Enum):
    Auto = "Auto",
    Edge = "Edge",
    Angle = "Angle",
    Inside = "Inside",
    Imposed = "Imposed",
    None_ = "None",

