from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID
    from .query_elements_model import QueryElementsModel

from .query_elements_model import QueryElementsModel

@dataclass
class QueryElementsLoads(QueryElementsModel, AdditionalDataHolder, Parsable):
    """
    Query definition for element load retrieval with an optional load case.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Optional load case ID for the requested loads.
    load_case_id: Optional[EID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> QueryElementsLoads:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: QueryElementsLoads
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return QueryElementsLoads()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID
        from .query_elements_model import QueryElementsModel

        from .e_i_d import EID
        from .query_elements_model import QueryElementsModel

        fields: dict[str, Callable[[Any], None]] = {
            "loadCaseId": lambda n : setattr(self, 'load_case_id', n.get_object_value(EID)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("loadCaseId", self.load_case_id)
        writer.write_additional_data_value(self.additional_data)
    

