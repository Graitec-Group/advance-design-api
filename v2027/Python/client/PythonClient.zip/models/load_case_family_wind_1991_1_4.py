from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .auto_generation_parameters_wind_e_n1991_1_4 import AutoGenerationParameters_Wind_EN1991_1_4
    from .base_pressure_parameters_wind_e_n1991_1_4 import BasePressureParameters_Wind_EN1991_1_4
    from .building2_d_parameters_wind_e_n1991_1_4 import Building2DParameters_Wind_EN1991_1_4
    from .greenhouse_parameters_wind_e_n1991_1_4 import GreenhouseParameters_Wind_EN1991_1_4
    from .load_case_family_wind import LoadCaseFamily_Wind
    from .response_coefficients_parameters_wind_e_n1991_1_4 import ResponseCoefficientsParameters_Wind_EN1991_1_4
    from .site_coefficients_parameters_wind_e_n1991_1_4 import SiteCoefficientsParameters_Wind_EN1991_1_4

from .load_case_family_wind import LoadCaseFamily_Wind

@dataclass
class LoadCaseFamily_Wind_1991_1_4(LoadCaseFamily_Wind, AdditionalDataHolder, Parsable):
    """
    Wind loads case family for EN 1991-1-4, load case parent
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Auto generation parameters
    auto_generation: Optional[AutoGenerationParameters_Wind_EN1991_1_4] = None
    # Base pressure parameters
    base_pressure: Optional[BasePressureParameters_Wind_EN1991_1_4] = None
    # 2D Building parameters
    building2_d: Optional[Building2DParameters_Wind_EN1991_1_4] = None
    # Greenhouse parameters (for greenhouses per EN 13031-1)
    greenhouse_parameters: Optional[GreenhouseParameters_Wind_EN1991_1_4] = None
    # Response coefficients parameters
    response_coefficients: Optional[ResponseCoefficientsParameters_Wind_EN1991_1_4] = None
    # Site coefficients parameters
    site_coefficients: Optional[SiteCoefficientsParameters_Wind_EN1991_1_4] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily_Wind_1991_1_4:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily_Wind_1991_1_4
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseFamily_Wind_1991_1_4()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .auto_generation_parameters_wind_e_n1991_1_4 import AutoGenerationParameters_Wind_EN1991_1_4
        from .base_pressure_parameters_wind_e_n1991_1_4 import BasePressureParameters_Wind_EN1991_1_4
        from .building2_d_parameters_wind_e_n1991_1_4 import Building2DParameters_Wind_EN1991_1_4
        from .greenhouse_parameters_wind_e_n1991_1_4 import GreenhouseParameters_Wind_EN1991_1_4
        from .load_case_family_wind import LoadCaseFamily_Wind
        from .response_coefficients_parameters_wind_e_n1991_1_4 import ResponseCoefficientsParameters_Wind_EN1991_1_4
        from .site_coefficients_parameters_wind_e_n1991_1_4 import SiteCoefficientsParameters_Wind_EN1991_1_4

        from .auto_generation_parameters_wind_e_n1991_1_4 import AutoGenerationParameters_Wind_EN1991_1_4
        from .base_pressure_parameters_wind_e_n1991_1_4 import BasePressureParameters_Wind_EN1991_1_4
        from .building2_d_parameters_wind_e_n1991_1_4 import Building2DParameters_Wind_EN1991_1_4
        from .greenhouse_parameters_wind_e_n1991_1_4 import GreenhouseParameters_Wind_EN1991_1_4
        from .load_case_family_wind import LoadCaseFamily_Wind
        from .response_coefficients_parameters_wind_e_n1991_1_4 import ResponseCoefficientsParameters_Wind_EN1991_1_4
        from .site_coefficients_parameters_wind_e_n1991_1_4 import SiteCoefficientsParameters_Wind_EN1991_1_4

        fields: dict[str, Callable[[Any], None]] = {
            "autoGeneration": lambda n : setattr(self, 'auto_generation', n.get_object_value(AutoGenerationParameters_Wind_EN1991_1_4)),
            "basePressure": lambda n : setattr(self, 'base_pressure', n.get_object_value(BasePressureParameters_Wind_EN1991_1_4)),
            "building2D": lambda n : setattr(self, 'building2_d', n.get_object_value(Building2DParameters_Wind_EN1991_1_4)),
            "greenhouseParameters": lambda n : setattr(self, 'greenhouse_parameters', n.get_object_value(GreenhouseParameters_Wind_EN1991_1_4)),
            "responseCoefficients": lambda n : setattr(self, 'response_coefficients', n.get_object_value(ResponseCoefficientsParameters_Wind_EN1991_1_4)),
            "siteCoefficients": lambda n : setattr(self, 'site_coefficients', n.get_object_value(SiteCoefficientsParameters_Wind_EN1991_1_4)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("autoGeneration", self.auto_generation)
        writer.write_object_value("basePressure", self.base_pressure)
        writer.write_object_value("building2D", self.building2_d)
        writer.write_object_value("greenhouseParameters", self.greenhouse_parameters)
        writer.write_object_value("responseCoefficients", self.response_coefficients)
        writer.write_object_value("siteCoefficients", self.site_coefficients)
        writer.write_additional_data_value(self.additional_data)
    

