from enum import Enum

class ComputingProbabilityCoeff_Wind_EN1991_1_4_API(str, Enum):
    EWindComputingProbabilityCoeffByKParameter = "eWindComputingProbabilityCoeffByKParameter",
    EWindComputingProbabilityCoeffByAdjustmentFactor = "eWindComputingProbabilityCoeffByAdjustmentFactor",
    EWindComputingProbabilityCoeffImposed = "eWindComputingProbabilityCoeffImposed",

