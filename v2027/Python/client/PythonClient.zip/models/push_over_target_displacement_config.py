from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PushOverTargetDisplacementConfig(Parsable):
    """
    Push over target displacement configuration
    """
    # Displacement directionePushOverDisplacementDirectionX = 0 ePushOverDisplacementDirectionY = 1Default: X (0)
    displacement_direction: Optional[int] = None
    # Maximum displacement valueUnit: mDefault: 0.0
    max_displacement: Optional[float] = None
    # Node identifier for master node controlDefault: 0
    node_id: Optional[int] = None
    # Target displacement control typeePushOverTargetDisplacementControlMaxDisplacement 0, ePushOverTargetDisplacementControlMasterNode 1Default: Max displacement (0)
    target_displacement_control: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PushOverTargetDisplacementConfig:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PushOverTargetDisplacementConfig
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PushOverTargetDisplacementConfig()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "displacementDirection": lambda n : setattr(self, 'displacement_direction', n.get_int_value()),
            "maxDisplacement": lambda n : setattr(self, 'max_displacement', n.get_float_value()),
            "nodeId": lambda n : setattr(self, 'node_id', n.get_int_value()),
            "targetDisplacementControl": lambda n : setattr(self, 'target_displacement_control', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("displacementDirection", self.displacement_direction)
        writer.write_float_value("maxDisplacement", self.max_displacement)
        writer.write_int_value("nodeId", self.node_id)
        writer.write_int_value("targetDisplacementControl", self.target_displacement_control)
    

