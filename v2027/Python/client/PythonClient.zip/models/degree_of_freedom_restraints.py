from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class DegreeOfFreedomRestraints(Parsable):
    """
    Boolean degree-of-freedom constraints for a punctual support (true = locked, false = free).
    """
    # Rotation about global X is locked when true.Unit: no unit Default value : false
    rx: Optional[bool] = None
    # Rotation about global Y is locked when true.Unit: no unit Default value : false
    ry: Optional[bool] = None
    # Rotation about global Z is locked when true.Unit: no unit Default value : false
    rz: Optional[bool] = None
    # Translation along global X is locked when true.Unit: no unit Default value : false
    tx: Optional[bool] = None
    # Translation along global Y is locked when true.Unit: no unit Default value : false
    ty: Optional[bool] = None
    # Translation along global Z is locked when true.Unit: no unit Default value : false
    tz: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DegreeOfFreedomRestraints:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DegreeOfFreedomRestraints
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DegreeOfFreedomRestraints()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "rx": lambda n : setattr(self, 'rx', n.get_bool_value()),
            "ry": lambda n : setattr(self, 'ry', n.get_bool_value()),
            "rz": lambda n : setattr(self, 'rz', n.get_bool_value()),
            "tx": lambda n : setattr(self, 'tx', n.get_bool_value()),
            "ty": lambda n : setattr(self, 'ty', n.get_bool_value()),
            "tz": lambda n : setattr(self, 'tz', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("rx", self.rx)
        writer.write_bool_value("ry", self.ry)
        writer.write_bool_value("rz", self.rz)
        writer.write_bool_value("tx", self.tx)
        writer.write_bool_value("ty", self.ty)
        writer.write_bool_value("tz", self.tz)
    

