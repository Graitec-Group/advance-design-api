from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class Int32Matrix(Parsable):
    """
    Generic matrix (column-major) similar to the native C++ CMat.Compatible with ASP.NET usage (POCO, no unsafe code).
    """
    # Number of columns.
    cols: Optional[int] = None
    # Gets or sets the array of data items.
    data: Optional[list[int]] = None
    # Number of rows.
    rows: Optional[int] = None
    # Total element count.
    size: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Int32Matrix:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Int32Matrix
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Int32Matrix()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "cols": lambda n : setattr(self, 'cols', n.get_int_value()),
            "_data": lambda n : setattr(self, 'data', n.get_collection_of_primitive_values(int)),
            "rows": lambda n : setattr(self, 'rows', n.get_int_value()),
            "size": lambda n : setattr(self, 'size', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("_data", self.data)
    

