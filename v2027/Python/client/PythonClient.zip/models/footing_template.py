from enum import Enum

class FootingTemplate(str, Enum):
    TypeAuto = "TypeAuto",
    Rectangular_pedestal = "Rectangular_pedestal",
    Rectangular_column = "Rectangular_column",
    Rectangular_column_with_expansion_joint = "Rectangular_column_with_expansion_joint",
    Circular_pedestal = "Circular_pedestal",
    Circular_column = "Circular_column",
    Circular_column_with_expansion_joint = "Circular_column_with_expansion_joint",
    Pocket_on_footing = "Pocket_on_footing",
    Pocket_on_pedestal = "Pocket_on_pedestal",
    Hinged_pocket_on_pedestal = "Hinged_pocket_on_pedestal",
    Hinged_pocket_on_footing = "Hinged_pocket_on_footing",
    Pocket_fixed_on_footing = "Pocket_fixed_on_footing",

