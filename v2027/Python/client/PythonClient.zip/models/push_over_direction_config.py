from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PushOverDirectionConfig(Parsable):
    """
    Push over direction configuration
    """
    # Load directionePushOverDirectionXPlus = 0, ePushOverDirectionYPlus = 1, ePushOverDirectionXMinus = 2, ePushOverDirectionYMinus = 3Default: X+ (0)
    direction: Optional[int] = None
    # Point of application typeePushOverPtAppCenterOfMass = 0, ePushOverPtAppSurfaceLoadDistributed = 1Default: Center of mass (0)
    point_of_application: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PushOverDirectionConfig:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PushOverDirectionConfig
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PushOverDirectionConfig()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "direction": lambda n : setattr(self, 'direction', n.get_int_value()),
            "pointOfApplication": lambda n : setattr(self, 'point_of_application', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("direction", self.direction)
        writer.write_int_value("pointOfApplication", self.point_of_application)
    

