from enum import Enum

class LoadingsCaseType_Snow(str, Enum):
    NORMAL_SNOW = "NORMAL_SNOW",
    DRIFTED_SNOW = "DRIFTED_SNOW",
    ACCIDENTAL_SNOW = "ACCIDENTAL_SNOW",

