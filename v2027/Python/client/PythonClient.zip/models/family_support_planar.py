from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_advanced_planar_support import ElementAdvancedPlanarSupport
    from .element_base import ElementBase
    from .element_elastic_planar_support import ElementElasticPlanarSupport
    from .element_rigid_planar_support import ElementRigidPlanarSupport
    from .element_t_c_planar_support import ElementTCPlanarSupport
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class FamilySupportPlanar(ElementBase, AdditionalDataHolder, Parsable):
    """
    Planar support
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Indicates whether the element is active in the analysis.Unit: no unit Default value : true
    element_active: Optional[bool] = None
    # geometry as list of 3D points in global axis Unit: m Default value : null
    geom_pts_list: Optional[list[Pt3D]] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FamilySupportPlanar:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FamilySupportPlanar
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "ElementAdvancedPlanarSupport".casefold():
            from .element_advanced_planar_support import ElementAdvancedPlanarSupport

            return ElementAdvancedPlanarSupport()
        if mapping_value and mapping_value.casefold() == "ElementElasticPlanarSupport".casefold():
            from .element_elastic_planar_support import ElementElasticPlanarSupport

            return ElementElasticPlanarSupport()
        if mapping_value and mapping_value.casefold() == "ElementRigidPlanarSupport".casefold():
            from .element_rigid_planar_support import ElementRigidPlanarSupport

            return ElementRigidPlanarSupport()
        if mapping_value and mapping_value.casefold() == "ElementTCPlanarSupport".casefold():
            from .element_t_c_planar_support import ElementTCPlanarSupport

            return ElementTCPlanarSupport()
        return FamilySupportPlanar()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_advanced_planar_support import ElementAdvancedPlanarSupport
        from .element_base import ElementBase
        from .element_elastic_planar_support import ElementElasticPlanarSupport
        from .element_rigid_planar_support import ElementRigidPlanarSupport
        from .element_t_c_planar_support import ElementTCPlanarSupport
        from .pt3_d import Pt3D

        from .element_advanced_planar_support import ElementAdvancedPlanarSupport
        from .element_base import ElementBase
        from .element_elastic_planar_support import ElementElasticPlanarSupport
        from .element_rigid_planar_support import ElementRigidPlanarSupport
        from .element_t_c_planar_support import ElementTCPlanarSupport
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "elementActive": lambda n : setattr(self, 'element_active', n.get_bool_value()),
            "geomPtsList": lambda n : setattr(self, 'geom_pts_list', n.get_collection_of_object_values(Pt3D)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_bool_value("elementActive", self.element_active)
        writer.write_collection_of_object_values("geomPtsList", self.geom_pts_list)
        writer.write_additional_data_value(self.additional_data)
    

