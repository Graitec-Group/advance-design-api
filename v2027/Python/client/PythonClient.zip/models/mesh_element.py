from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID
    from .int32_matrix import Int32Matrix

@dataclass
class MeshElement(Parsable):
    """
    associated mesh element data.
    """
    # Connectivity matrix (rows = nodes per element, cols = elements).
    connectivity: Optional[Int32Matrix] = None
    # Element identifier.
    id: Optional[EID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> MeshElement:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: MeshElement
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return MeshElement()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID
        from .int32_matrix import Int32Matrix

        from .e_i_d import EID
        from .int32_matrix import Int32Matrix

        fields: dict[str, Callable[[Any], None]] = {
            "connectivity": lambda n : setattr(self, 'connectivity', n.get_object_value(Int32Matrix)),
            "id": lambda n : setattr(self, 'id', n.get_object_value(EID)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("connectivity", self.connectivity)
        writer.write_object_value("id", self.id)
    

