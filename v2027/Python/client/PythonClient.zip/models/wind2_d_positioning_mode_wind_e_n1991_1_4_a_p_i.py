from enum import Enum

class Wind2DPositioningMode_Wind_EN1991_1_4_API(str, Enum):
    EWind2DPositioningModeValue = "eWind2DPositioningModeValue",
    EWind2DPositioningModeZone = "eWind2DPositioningModeZone",

