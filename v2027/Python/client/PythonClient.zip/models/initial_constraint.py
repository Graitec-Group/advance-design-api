from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID

@dataclass
class InitialConstraint(Parsable):
    """
    Linear element initial constraint properties
    """
    # Initial constraint Sxy valueUnit: MPaDefault value: 0.0
    constraint_sxy: Optional[float] = None
    # Initial constraint Sxz valueUnit: MPaDefault value: 0.0
    constraint_sxz: Optional[float] = None
    # Initial constraint load case ID (0 means NONE)Default value: 0
    initial_constraint_load_case: Optional[EID] = None
    # Initial constraint Sxx valueUnit: MPaDefault value: 0.0
    initial_constraint_sxx: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> InitialConstraint:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: InitialConstraint
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return InitialConstraint()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID

        from .e_i_d import EID

        fields: dict[str, Callable[[Any], None]] = {
            "constraintSxy": lambda n : setattr(self, 'constraint_sxy', n.get_float_value()),
            "constraintSxz": lambda n : setattr(self, 'constraint_sxz', n.get_float_value()),
            "initialConstraintLoadCase": lambda n : setattr(self, 'initial_constraint_load_case', n.get_object_value(EID)),
            "initialConstraintSxx": lambda n : setattr(self, 'initial_constraint_sxx', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("constraintSxy", self.constraint_sxy)
        writer.write_float_value("constraintSxz", self.constraint_sxz)
        writer.write_object_value("initialConstraintLoadCase", self.initial_constraint_load_case)
        writer.write_float_value("initialConstraintSxx", self.initial_constraint_sxx)
    

