from enum import Enum

class DuctilityClassEN1998_API(str, Enum):
    LOW = "LOW",
    MEDIUM = "MEDIUM",
    HIGH = "HIGH",

