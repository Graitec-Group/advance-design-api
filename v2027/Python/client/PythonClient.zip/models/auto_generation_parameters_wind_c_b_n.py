from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class AutoGenerationParametersWindCBN(Parsable):
    """
    Auto generation parameters for Wind CBN
    """
    # Load generationUnit: -Default: TRUE
    load_generation: Optional[bool] = None
    # Pressure coefficientUnit: -Default: TRUE
    pressure_coeff: Optional[bool] = None
    # Split wind wallsUnit: -Default: FALSE
    split_wind_walls: Optional[bool] = None
    # Wind wall statusUnit: -Default: TRUE
    wind_wall_status: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AutoGenerationParametersWindCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AutoGenerationParametersWindCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AutoGenerationParametersWindCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "loadGeneration": lambda n : setattr(self, 'load_generation', n.get_bool_value()),
            "pressureCoeff": lambda n : setattr(self, 'pressure_coeff', n.get_bool_value()),
            "splitWindWalls": lambda n : setattr(self, 'split_wind_walls', n.get_bool_value()),
            "windWallStatus": lambda n : setattr(self, 'wind_wall_status', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("loadGeneration", self.load_generation)
        writer.write_bool_value("pressureCoeff", self.pressure_coeff)
        writer.write_bool_value("splitWindWalls", self.split_wind_walls)
        writer.write_bool_value("windWallStatus", self.wind_wall_status)
    

