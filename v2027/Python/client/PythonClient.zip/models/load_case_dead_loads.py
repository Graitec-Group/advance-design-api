from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .gravity_field_definition import GravityFieldDefinition
    from .load_case import LoadCase
    from .load_case_dead_loads_coefficients import LoadCaseDeadLoadsCoefficients

from .load_case import LoadCase

@dataclass
class LoadCase_DeadLoads(LoadCase, AdditionalDataHolder, Parsable):
    """
    Dead load (self weight) load case
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Set to null to allow engine defaults per national annex / standard.
    dead_loads_coefficients: Optional[LoadCaseDeadLoadsCoefficients] = None
    # Gravity field definition (coefficients on direction)Default value : (0 , 0 , -1)
    field: Optional[GravityFieldDefinition] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_DeadLoads:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_DeadLoads
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_DeadLoads()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .gravity_field_definition import GravityFieldDefinition
        from .load_case import LoadCase
        from .load_case_dead_loads_coefficients import LoadCaseDeadLoadsCoefficients

        from .gravity_field_definition import GravityFieldDefinition
        from .load_case import LoadCase
        from .load_case_dead_loads_coefficients import LoadCaseDeadLoadsCoefficients

        fields: dict[str, Callable[[Any], None]] = {
            "deadLoadsCoefficients": lambda n : setattr(self, 'dead_loads_coefficients', n.get_object_value(LoadCaseDeadLoadsCoefficients)),
            "field": lambda n : setattr(self, 'field', n.get_object_value(GravityFieldDefinition)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("deadLoadsCoefficients", self.dead_loads_coefficients)
        writer.write_object_value("field", self.field)
        writer.write_additional_data_value(self.additional_data)
    

