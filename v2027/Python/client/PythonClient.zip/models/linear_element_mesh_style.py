from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class LinearElementMeshStyle(Parsable):
    """
    Linear element mesh style properties
    """
    # Number of elementsDefault value: 0
    number_of_elements: Optional[int] = None
    # Size of elementsUnit: mDefault value: 0.0
    size_of_elements: Optional[float] = None
    # Spacing factorUnit: no unitDefault value: 0.0
    spacing_factor: Optional[float] = None
    # Spacing optionDefault value: 0
    spacing_option: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LinearElementMeshStyle:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LinearElementMeshStyle
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LinearElementMeshStyle()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "numberOfElements": lambda n : setattr(self, 'number_of_elements', n.get_int_value()),
            "sizeOfElements": lambda n : setattr(self, 'size_of_elements', n.get_float_value()),
            "spacingFactor": lambda n : setattr(self, 'spacing_factor', n.get_float_value()),
            "spacingOption": lambda n : setattr(self, 'spacing_option', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("numberOfElements", self.number_of_elements)
        writer.write_float_value("sizeOfElements", self.size_of_elements)
        writer.write_float_value("spacingFactor", self.spacing_factor)
        writer.write_int_value("spacingOption", self.spacing_option)
    

