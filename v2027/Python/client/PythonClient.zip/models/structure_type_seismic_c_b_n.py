from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .material_s_r_f_s_a_p_i import MaterialSRFS_API
    from .s_f_r_s_concrete_a_p_i import SFRSConcrete_API
    from .s_f_r_s_masonry_a_p_i import SFRSMasonry_API
    from .s_f_r_s_steel_a_p_i import SFRSSteel_API
    from .s_f_r_s_timber_a_p_i import SFRSTimber_API
    from .type_structure_a_p_i import TypeStructure_API

@dataclass
class StructureTypeSeismicCBN(Parsable):
    """
    Structure type and SFRS parameters for Seismic CBN load case
    """
    from .s_f_r_s_concrete_a_p_i import SFRSConcrete_API

    # Concrete SFRS typeDefault: SFRSConcrete_API.DuctileMomentResistingFrame
    sfrs_concrete: Optional[SFRSConcrete_API] = SFRSConcrete_API("DuctileMomentResistingFrame")
    from .s_f_r_s_masonry_a_p_i import SFRSMasonry_API

    # Masonry SFRS typeDefault: SFRSMasonry_API.DuctileShearWall
    sfrs_masonry: Optional[SFRSMasonry_API] = SFRSMasonry_API("DuctileShearWall")
    from .s_f_r_s_steel_a_p_i import SFRSSteel_API

    # Steel SFRS typeDefault: SFRSSteel_API.DuctileMomentResistingFrame
    sfrs_steel: Optional[SFRSSteel_API] = SFRSSteel_API("DuctileMomentResistingFrame")
    from .s_f_r_s_timber_a_p_i import SFRSTimber_API

    # Timber SFRS typeDefault: SFRSTimber_API.DuctileShearWall
    sfrs_timber: Optional[SFRSTimber_API] = SFRSTimber_API("DuctileShearWall")
    from .material_s_r_f_s_a_p_i import MaterialSRFS_API

    # SFRS material typeDefault: MaterialSRFS_API.Concrete
    type_s_r_f_s: Optional[MaterialSRFS_API] = MaterialSRFS_API("Concrete")
    from .type_structure_a_p_i import TypeStructure_API

    # Type of structure (moment frame, shear wall, etc.)Default: TypeStructure_API.StructureResistMomentFrame
    type_structure: Optional[TypeStructure_API] = TypeStructure_API("StructureResistMomentFrame")
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> StructureTypeSeismicCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: StructureTypeSeismicCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return StructureTypeSeismicCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .material_s_r_f_s_a_p_i import MaterialSRFS_API
        from .s_f_r_s_concrete_a_p_i import SFRSConcrete_API
        from .s_f_r_s_masonry_a_p_i import SFRSMasonry_API
        from .s_f_r_s_steel_a_p_i import SFRSSteel_API
        from .s_f_r_s_timber_a_p_i import SFRSTimber_API
        from .type_structure_a_p_i import TypeStructure_API

        from .material_s_r_f_s_a_p_i import MaterialSRFS_API
        from .s_f_r_s_concrete_a_p_i import SFRSConcrete_API
        from .s_f_r_s_masonry_a_p_i import SFRSMasonry_API
        from .s_f_r_s_steel_a_p_i import SFRSSteel_API
        from .s_f_r_s_timber_a_p_i import SFRSTimber_API
        from .type_structure_a_p_i import TypeStructure_API

        fields: dict[str, Callable[[Any], None]] = {
            "sfrsConcrete": lambda n : setattr(self, 'sfrs_concrete', n.get_enum_value(SFRSConcrete_API)),
            "sfrsMasonry": lambda n : setattr(self, 'sfrs_masonry', n.get_enum_value(SFRSMasonry_API)),
            "sfrsSteel": lambda n : setattr(self, 'sfrs_steel', n.get_enum_value(SFRSSteel_API)),
            "sfrsTimber": lambda n : setattr(self, 'sfrs_timber', n.get_enum_value(SFRSTimber_API)),
            "typeSRFS": lambda n : setattr(self, 'type_s_r_f_s', n.get_enum_value(MaterialSRFS_API)),
            "typeStructure": lambda n : setattr(self, 'type_structure', n.get_enum_value(TypeStructure_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("sfrsConcrete", self.sfrs_concrete)
        writer.write_enum_value("sfrsMasonry", self.sfrs_masonry)
        writer.write_enum_value("sfrsSteel", self.sfrs_steel)
        writer.write_enum_value("sfrsTimber", self.sfrs_timber)
        writer.write_enum_value("typeSRFS", self.type_s_r_f_s)
        writer.write_enum_value("typeStructure", self.type_structure)
    

