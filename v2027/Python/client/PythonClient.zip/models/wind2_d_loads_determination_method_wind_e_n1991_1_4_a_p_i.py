from enum import Enum

class Wind2DLoadsDeterminationMethod_Wind_EN1991_1_4_API(str, Enum):
    EWind2DRealLoadsInSpan = "eWind2DRealLoadsInSpan",
    EWind2DLoadsInSectionInPortalPosition = "eWind2DLoadsInSectionInPortalPosition",

