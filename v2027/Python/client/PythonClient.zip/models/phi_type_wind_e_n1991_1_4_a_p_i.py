from enum import Enum

class PhiType_Wind_EN1991_1_4_API(str, Enum):
    PHI_TYPE_AUTO = "PHI_TYPE_AUTO",
    PHI_TYPE_IMPOSED = "PHI_TYPE_IMPOSED",

