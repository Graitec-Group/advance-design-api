from enum import Enum

class Wind2DPositioningZone_Wind_EN1991_1_4_API(str, Enum):
    EWind2DPositioningZoneEC1_A_F_G = "eWind2DPositioningZoneEC1_A_F_G",
    EWind2DPositioningZoneEC1_A_H = "eWind2DPositioningZoneEC1_A_H",
    EWind2DPositioningZoneEC1_B_H = "eWind2DPositioningZoneEC1_B_H",
    EWind2DPositioningZoneEC1_B_I = "eWind2DPositioningZoneEC1_B_I",
    EWind2DPositioningZoneEC1_C_I = "eWind2DPositioningZoneEC1_C_I",

