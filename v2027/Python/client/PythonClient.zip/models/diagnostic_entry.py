from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .diagnostic_severity import DiagnosticSeverity

@dataclass
class DiagnosticEntry(Parsable):
    """
    A single diagnostic message emitted during an API operation.Designed for both human and AI consumption: the AD.API.Srv.Models.DiagnosticEntry.Code fieldprovides a stable, machine-readable identifier while AD.API.Srv.Models.DiagnosticEntry.Messagecarries a human-readable explanation.
    """
    # A stable, machine-readable code that identifies the diagnostic category.Examples: "ANALYSIS_CONVERGED", "MATERIAL_NOT_FOUND", "MESH_QUALITY_LOW".An AI agent can use this code to decide on corrective actions.
    code: Optional[str] = None
    # Human-readable description of the diagnostic.
    message: Optional[str] = None
    # Severity of this diagnostic.<p>Possible values:</p><ul><li><b>0 - Information</b>: Purely informational – the operation progressed normally.</li><li><b>1 - Warning</b>: The operation completed but with a potential issue that deserves attention.</li><li><b>2 - Error</b>: A recoverable error occurred; the operation may have partially succeeded.</li><li><b>3 - Critical</b>: An unrecoverable error; the operation failed entirely.</li></ul>
    severity: Optional[DiagnosticSeverity] = None
    # Optional – the API operation or domain area that produced this entry(e.g. "Analysis", "Materials", "Sections", "Combinations").
    source: Optional[str] = None
    # UTC timestamp when the diagnostic was recorded.
    timestamp: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DiagnosticEntry:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DiagnosticEntry
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DiagnosticEntry()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .diagnostic_severity import DiagnosticSeverity

        from .diagnostic_severity import DiagnosticSeverity

        fields: dict[str, Callable[[Any], None]] = {
            "code": lambda n : setattr(self, 'code', n.get_str_value()),
            "message": lambda n : setattr(self, 'message', n.get_str_value()),
            "severity": lambda n : setattr(self, 'severity', n.get_enum_value(DiagnosticSeverity)),
            "source": lambda n : setattr(self, 'source', n.get_str_value()),
            "timestamp": lambda n : setattr(self, 'timestamp', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("code", self.code)
        writer.write_str_value("message", self.message)
        writer.write_enum_value("severity", self.severity)
        writer.write_str_value("source", self.source)
        writer.write_datetime_value("timestamp", self.timestamp)
    

