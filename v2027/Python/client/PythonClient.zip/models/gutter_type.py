from enum import Enum

class Gutter_type(str, Enum):
    CG_GUTTER_EFFECT_NONE = "CG_GUTTER_EFFECT_NONE",
    CG_GUTTER_EFFECT_STRONG = "CG_GUTTER_EFFECT_STRONG",

