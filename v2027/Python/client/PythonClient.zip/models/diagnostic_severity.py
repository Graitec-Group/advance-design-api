from enum import Enum

class DiagnosticSeverity(str, Enum):
    Information = "Information",
    Warning = "Warning",
    Error = "Error",
    Critical = "Critical",

