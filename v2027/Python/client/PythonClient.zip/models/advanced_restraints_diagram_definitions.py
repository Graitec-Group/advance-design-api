from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .diagram_point import DiagramPoint

@dataclass
class AdvancedRestraintsDiagramDefinitions(Parsable):
    """
    Advanced restraints diagram definitions
    """
    # Optional piecewise stiffness diagram for rotation about X, taken into account if RestraintsOptions is defined tooUnit: no unit Default value : optional nullable object
    lock_description_r_x: Optional[list[DiagramPoint]] = None
    # Optional piecewise stiffness diagram for rotation about Y, taken into account if RestraintsOptions is defined tooUnit: no unit Default value : optional nullable object
    lock_description_r_y: Optional[list[DiagramPoint]] = None
    # Optional piecewise stiffness diagram for rotation about Z, taken into account if RestraintsOptions is defined tooUnit: no unit Default value : optional nullable object
    lock_description_r_z: Optional[list[DiagramPoint]] = None
    # Optional piecewise stiffness diagram for translation along X, taken into account if RestraintsOptions is defined tooUnit: no unit Default value : optional nullable object
    lock_description_t_x: Optional[list[DiagramPoint]] = None
    # Optional piecewise stiffness diagram for translation along Y, taken into account if RestraintsOptions is defined tooUnit: no unit Default value : optional nullable object
    lock_description_t_y: Optional[list[DiagramPoint]] = None
    # Optional piecewise stiffness diagram for translation along Z, taken into account if RestraintsOptions is defined tooUnit: no unit Default value : optional nullable object
    lock_description_t_z: Optional[list[DiagramPoint]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AdvancedRestraintsDiagramDefinitions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AdvancedRestraintsDiagramDefinitions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AdvancedRestraintsDiagramDefinitions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .diagram_point import DiagramPoint

        from .diagram_point import DiagramPoint

        fields: dict[str, Callable[[Any], None]] = {
            "lockDescriptionRX": lambda n : setattr(self, 'lock_description_r_x', n.get_collection_of_object_values(DiagramPoint)),
            "lockDescriptionRY": lambda n : setattr(self, 'lock_description_r_y', n.get_collection_of_object_values(DiagramPoint)),
            "lockDescriptionRZ": lambda n : setattr(self, 'lock_description_r_z', n.get_collection_of_object_values(DiagramPoint)),
            "lockDescriptionTX": lambda n : setattr(self, 'lock_description_t_x', n.get_collection_of_object_values(DiagramPoint)),
            "lockDescriptionTY": lambda n : setattr(self, 'lock_description_t_y', n.get_collection_of_object_values(DiagramPoint)),
            "lockDescriptionTZ": lambda n : setattr(self, 'lock_description_t_z', n.get_collection_of_object_values(DiagramPoint)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("lockDescriptionRX", self.lock_description_r_x)
        writer.write_collection_of_object_values("lockDescriptionRY", self.lock_description_r_y)
        writer.write_collection_of_object_values("lockDescriptionRZ", self.lock_description_r_z)
        writer.write_collection_of_object_values("lockDescriptionTX", self.lock_description_t_x)
        writer.write_collection_of_object_values("lockDescriptionTY", self.lock_description_t_y)
        writer.write_collection_of_object_values("lockDescriptionTZ", self.lock_description_t_z)
    

