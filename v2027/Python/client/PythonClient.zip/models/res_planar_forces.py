from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResPlanarForces(Parsable):
    """
    PlanarForces result container
    """
    # alphaF
    alpha_f: Optional[float] = None
    # alphaM
    alpha_m: Optional[float] = None
    # Force F1
    f1: Optional[float] = None
    # Force F2
    f2: Optional[float] = None
    # Force in XX axis
    fxx: Optional[float] = None
    # Force in XY axis
    fxy: Optional[float] = None
    # Force in XZ axis
    fxz: Optional[float] = None
    # Force in YY axis
    fyy: Optional[float] = None
    # Force in YZ axis
    fyz: Optional[float] = None
    # Force in ZZ axis
    fzz: Optional[float] = None
    # Moment M1
    m1: Optional[float] = None
    # Moment M2
    m2: Optional[float] = None
    # Moment in ZZ axis
    mxx: Optional[float] = None
    # Moment in XY axis
    mxy: Optional[float] = None
    # Moment in XZ axis
    mxz: Optional[float] = None
    # Moment in YY axis
    myy: Optional[float] = None
    # Moment in YZ axis
    myz: Optional[float] = None
    # Moment in ZZ axis
    mzz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResPlanarForces:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResPlanarForces
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResPlanarForces()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "alphaF": lambda n : setattr(self, 'alpha_f', n.get_float_value()),
            "alphaM": lambda n : setattr(self, 'alpha_m', n.get_float_value()),
            "f1": lambda n : setattr(self, 'f1', n.get_float_value()),
            "f2": lambda n : setattr(self, 'f2', n.get_float_value()),
            "fxx": lambda n : setattr(self, 'fxx', n.get_float_value()),
            "fxy": lambda n : setattr(self, 'fxy', n.get_float_value()),
            "fxz": lambda n : setattr(self, 'fxz', n.get_float_value()),
            "fyy": lambda n : setattr(self, 'fyy', n.get_float_value()),
            "fyz": lambda n : setattr(self, 'fyz', n.get_float_value()),
            "fzz": lambda n : setattr(self, 'fzz', n.get_float_value()),
            "m1": lambda n : setattr(self, 'm1', n.get_float_value()),
            "m2": lambda n : setattr(self, 'm2', n.get_float_value()),
            "mxx": lambda n : setattr(self, 'mxx', n.get_float_value()),
            "mxy": lambda n : setattr(self, 'mxy', n.get_float_value()),
            "mxz": lambda n : setattr(self, 'mxz', n.get_float_value()),
            "myy": lambda n : setattr(self, 'myy', n.get_float_value()),
            "myz": lambda n : setattr(self, 'myz', n.get_float_value()),
            "mzz": lambda n : setattr(self, 'mzz', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("alphaF", self.alpha_f)
        writer.write_float_value("alphaM", self.alpha_m)
        writer.write_float_value("f1", self.f1)
        writer.write_float_value("f2", self.f2)
        writer.write_float_value("fxx", self.fxx)
        writer.write_float_value("fxy", self.fxy)
        writer.write_float_value("fxz", self.fxz)
        writer.write_float_value("fyy", self.fyy)
        writer.write_float_value("fyz", self.fyz)
        writer.write_float_value("fzz", self.fzz)
        writer.write_float_value("m1", self.m1)
        writer.write_float_value("m2", self.m2)
        writer.write_float_value("mxx", self.mxx)
        writer.write_float_value("mxy", self.mxy)
        writer.write_float_value("mxz", self.mxz)
        writer.write_float_value("myy", self.myy)
        writer.write_float_value("myz", self.myz)
        writer.write_float_value("mzz", self.mzz)
    

