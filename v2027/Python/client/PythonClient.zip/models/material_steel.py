from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .material import Material
    from .material_behaviour_type import MaterialBehaviourType

from .material import Material

@dataclass
class MaterialSteel(Material, AdditionalDataHolder, Parsable):
    """
    Steel material properties
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .material_behaviour_type import MaterialBehaviourType

    # Material behavior type Default value: MaterialBehaviourType.isotropic_behavior
    behavior_type: Optional[MaterialBehaviourType] = MaterialBehaviourType("isotropic_behavior")
    # Thermal dilatation (α)Unit: 1/°CDefault value: 0.000012 (12E-6)
    alpha: Optional[float] = None
    # Color (angle in degrees)Unit: degreesDefault value: 1.2566370614359172 (72 degrees in radians)
    color: Optional[float] = None
    # Damping coefficient (% of critical damping)Unit: no unitDefault value: 0.05 (5%)
    damping: Optional[float] = None
    # Diffusion angleUnit: radiansDefault value: 1.2566370614359172 (72 degrees)
    diffusion: Optional[float] = None
    # Longitudinal rigidity (E)Unit: PaDefault value: 210000000000.0 (210 GPa for steel)
    e: Optional[float] = None
    # Transverse rigidity (G)Unit: PaDefault value: 0.0 (calculated from E and Nu if 0)
    g: Optional[float] = None
    # Poisson's ratio (ν)Unit: no unitDefault value: 0.3
    nu: Optional[float] = None
    # Density (ρ)Unit: kg/m³Default value: 7850.0
    ro: Optional[float] = None
    # Elastic limit stress (σe)Unit: PaDefault value: 235000000.0 (235 MPa)
    sigma_e: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> MaterialSteel:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: MaterialSteel
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return MaterialSteel()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .material import Material
        from .material_behaviour_type import MaterialBehaviourType

        from .material import Material
        from .material_behaviour_type import MaterialBehaviourType

        fields: dict[str, Callable[[Any], None]] = {
            "alpha": lambda n : setattr(self, 'alpha', n.get_float_value()),
            "behaviorType": lambda n : setattr(self, 'behavior_type', n.get_enum_value(MaterialBehaviourType)),
            "color": lambda n : setattr(self, 'color', n.get_float_value()),
            "damping": lambda n : setattr(self, 'damping', n.get_float_value()),
            "diffusion": lambda n : setattr(self, 'diffusion', n.get_float_value()),
            "e": lambda n : setattr(self, 'e', n.get_float_value()),
            "g": lambda n : setattr(self, 'g', n.get_float_value()),
            "nu": lambda n : setattr(self, 'nu', n.get_float_value()),
            "ro": lambda n : setattr(self, 'ro', n.get_float_value()),
            "sigmaE": lambda n : setattr(self, 'sigma_e', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("alpha", self.alpha)
        writer.write_enum_value("behaviorType", self.behavior_type)
        writer.write_float_value("color", self.color)
        writer.write_float_value("damping", self.damping)
        writer.write_float_value("diffusion", self.diffusion)
        writer.write_float_value("e", self.e)
        writer.write_float_value("g", self.g)
        writer.write_float_value("nu", self.nu)
        writer.write_float_value("ro", self.ro)
        writer.write_float_value("sigmaE", self.sigma_e)
        writer.write_additional_data_value(self.additional_data)
    

