from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResDisplacements(Parsable):
    """
    Displacements result container
    """
    # Total displacement
    d: Optional[float] = None
    # Displacement in X axis
    dx: Optional[float] = None
    # Displacement in Y axis
    dy: Optional[float] = None
    # Displacement in Z axis
    dz: Optional[float] = None
    # Total rotation
    r: Optional[float] = None
    # Rotation in X axis
    rx: Optional[float] = None
    # Rotation in Y axis
    ry: Optional[float] = None
    # Rotation in Z axis
    rz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResDisplacements:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResDisplacements
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResDisplacements()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "d": lambda n : setattr(self, 'd', n.get_float_value()),
            "dx": lambda n : setattr(self, 'dx', n.get_float_value()),
            "dy": lambda n : setattr(self, 'dy', n.get_float_value()),
            "dz": lambda n : setattr(self, 'dz', n.get_float_value()),
            "r": lambda n : setattr(self, 'r', n.get_float_value()),
            "rx": lambda n : setattr(self, 'rx', n.get_float_value()),
            "ry": lambda n : setattr(self, 'ry', n.get_float_value()),
            "rz": lambda n : setattr(self, 'rz', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("d", self.d)
        writer.write_float_value("dx", self.dx)
        writer.write_float_value("dy", self.dy)
        writer.write_float_value("dz", self.dz)
        writer.write_float_value("r", self.r)
        writer.write_float_value("rx", self.rx)
        writer.write_float_value("ry", self.ry)
        writer.write_float_value("rz", self.rz)
    

