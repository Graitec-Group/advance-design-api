from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .clipping_extremity import ClippingExtremity

@dataclass
class ClippingProperties(Parsable):
    """
    Clipping properties
    """
    # Clipping stateDefault value: false
    clipping_state: Optional[bool] = None
    # End clippingDefault value: optional nullable object
    end_clipping: Optional[ClippingExtremity] = None
    # Start clippingDefault value: optional nullable object
    start_clipping: Optional[ClippingExtremity] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ClippingProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ClippingProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ClippingProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .clipping_extremity import ClippingExtremity

        from .clipping_extremity import ClippingExtremity

        fields: dict[str, Callable[[Any], None]] = {
            "clippingState": lambda n : setattr(self, 'clipping_state', n.get_bool_value()),
            "endClipping": lambda n : setattr(self, 'end_clipping', n.get_object_value(ClippingExtremity)),
            "startClipping": lambda n : setattr(self, 'start_clipping', n.get_object_value(ClippingExtremity)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("clippingState", self.clipping_state)
        writer.write_object_value("endClipping", self.end_clipping)
        writer.write_object_value("startClipping", self.start_clipping)
    

