from enum import Enum

class LoadAreaSpanDirection(str, Enum):
    EFloorDeckLoadSpanDirectionX = "eFloorDeckLoadSpanDirectionX",
    EFloorDeckLoadSpanDirectionY = "eFloorDeckLoadSpanDirectionY",
    EFloorDeckLoadSpanDirectionXY = "eFloorDeckLoadSpanDirectionXY",

