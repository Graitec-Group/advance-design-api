from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_combination_type import ECombinationType
    from .e_i_d_double_pair import EIDDoublePair
    from .informational_element_base import InformationalElementBase

from .informational_element_base import InformationalElementBase

@dataclass
class Combination(InformationalElementBase, AdditionalDataHolder, Parsable):
    """
    Combination object definition
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # type of combination
    e_combination_type: Optional[ECombinationType] = None
    # ID of the combination - is not an input data, is managed in AD, use it only for get
    id_comb: Optional[int] = None
    # Gets the collection of case coefficients associated with their corresponding AD.API.EID values.
    list_cases_coeffs: Optional[list[EIDDoublePair]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Combination:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Combination
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Combination()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_combination_type import ECombinationType
        from .e_i_d_double_pair import EIDDoublePair
        from .informational_element_base import InformationalElementBase

        from .e_combination_type import ECombinationType
        from .e_i_d_double_pair import EIDDoublePair
        from .informational_element_base import InformationalElementBase

        fields: dict[str, Callable[[Any], None]] = {
            "eCombinationType": lambda n : setattr(self, 'e_combination_type', n.get_enum_value(ECombinationType)),
            "idComb": lambda n : setattr(self, 'id_comb', n.get_int_value()),
            "listCasesCoeffs": lambda n : setattr(self, 'list_cases_coeffs', n.get_collection_of_object_values(EIDDoublePair)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("eCombinationType", self.e_combination_type)
        writer.write_collection_of_object_values("listCasesCoeffs", self.list_cases_coeffs)
        writer.write_additional_data_value(self.additional_data)
    

