from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .....models.query_base import QueryBase
    from .....models.query_elements_loads import QueryElementsLoads
    from .....models.query_elements_model import QueryElementsModel
    from .....models.query_info_load_case import QueryInfoLoadCase
    from .....models.query_info_model import QueryInfoModel

@dataclass
class GetElementsID(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes QueryBase, QueryElementsLoads, QueryElementsModel, QueryInfoLoadCase, QueryInfoModel
    """
    # Composed type representation for type QueryBase
    query_base: Optional[QueryBase] = None
    # Composed type representation for type QueryElementsLoads
    query_elements_loads: Optional[QueryElementsLoads] = None
    # Composed type representation for type QueryElementsModel
    query_elements_model: Optional[QueryElementsModel] = None
    # Composed type representation for type QueryInfoLoadCase
    query_info_load_case: Optional[QueryInfoLoadCase] = None
    # Composed type representation for type QueryInfoModel
    query_info_model: Optional[QueryInfoModel] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> GetElementsID:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: GetElementsID
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = GetElementsID()
        if mapping_value and mapping_value.casefold() == "QueryBase".casefold():
            from .....models.query_base import QueryBase

            result.query_base = QueryBase()
        elif mapping_value and mapping_value.casefold() == "QueryElementsLoads".casefold():
            from .....models.query_elements_loads import QueryElementsLoads

            result.query_elements_loads = QueryElementsLoads()
        elif mapping_value and mapping_value.casefold() == "QueryElementsModel".casefold():
            from .....models.query_elements_model import QueryElementsModel

            result.query_elements_model = QueryElementsModel()
        elif mapping_value and mapping_value.casefold() == "QueryInfoLoadCase".casefold():
            from .....models.query_info_load_case import QueryInfoLoadCase

            result.query_info_load_case = QueryInfoLoadCase()
        elif mapping_value and mapping_value.casefold() == "QueryInfoModel".casefold():
            from .....models.query_info_model import QueryInfoModel

            result.query_info_model = QueryInfoModel()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .....models.query_base import QueryBase
        from .....models.query_elements_loads import QueryElementsLoads
        from .....models.query_elements_model import QueryElementsModel
        from .....models.query_info_load_case import QueryInfoLoadCase
        from .....models.query_info_model import QueryInfoModel

        if self.query_base:
            return self.query_base.get_field_deserializers()
        if self.query_elements_loads:
            return self.query_elements_loads.get_field_deserializers()
        if self.query_elements_model:
            return self.query_elements_model.get_field_deserializers()
        if self.query_info_load_case:
            return self.query_info_load_case.get_field_deserializers()
        if self.query_info_model:
            return self.query_info_model.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.query_base:
            writer.write_object_value(None, self.query_base)
        elif self.query_elements_loads:
            writer.write_object_value(None, self.query_elements_loads)
        elif self.query_elements_model:
            writer.write_object_value(None, self.query_elements_model)
        elif self.query_info_load_case:
            writer.write_object_value(None, self.query_info_load_case)
        elif self.query_info_model:
            writer.write_object_value(None, self.query_info_model)
    

