from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .....models.combination import Combination
    from .....models.informational_element_base import InformationalElementBase
    from .....models.load_case import LoadCase
    from .....models.load_case_accidental import LoadCase_Accidental
    from .....models.load_case_dead_loads import LoadCase_DeadLoads
    from .....models.load_case_dynamic_temporal import LoadCase_DynamicTemporal
    from .....models.load_case_family import LoadCaseFamily
    from .....models.load_case_family_accidental import LoadCaseFamily_Accidental
    from .....models.load_case_family_dead_loads import LoadCaseFamily_DeadLoads
    from .....models.load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal
    from .....models.load_case_family_live_loads import LoadCaseFamily_LiveLoads
    from .....models.load_case_family_other import LoadCaseFamily_Other
    from .....models.load_case_family_push_over import LoadCaseFamily_PushOver
    from .....models.load_case_family_seismic import LoadCaseFamily_Seismic
    from .....models.load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
    from .....models.load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
    from .....models.load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
    from .....models.load_case_family_snow import LoadCaseFamily_Snow
    from .....models.load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
    from .....models.load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
    from .....models.load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC
    from .....models.load_case_family_thermic import LoadCaseFamily_Thermic
    from .....models.load_case_family_wind import LoadCaseFamily_Wind
    from .....models.load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4
    from .....models.load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN
    from .....models.load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC
    from .....models.load_case_live_loads import LoadCase_LiveLoads
    from .....models.load_case_other import LoadCase_Other
    from .....models.load_case_push_over import LoadCase_PushOver
    from .....models.load_case_seismic import LoadCase_Seismic
    from .....models.load_case_seismic_c_b_n import LoadCase_SeismicCBN
    from .....models.load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
    from .....models.load_case_seismic_i_b_c import LoadCase_SeismicIBC
    from .....models.load_case_snow import LoadCase_Snow
    from .....models.load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3
    from .....models.load_case_snow_c_b_n import LoadCase_SnowCBN
    from .....models.load_case_snow_i_b_c import LoadCase_SnowIBC
    from .....models.load_case_thermic import LoadCase_Thermic
    from .....models.load_case_wind import LoadCase_Wind
    from .....models.load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
    from .....models.load_case_wind_c_b_n import LoadCase_WindCBN
    from .....models.load_case_wind_i_b_c import LoadCase_WindIBC

@dataclass
class CreateInformationalElementPostRequestBody(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes Combination, InformationalElementBase, LoadCase, LoadCaseFamily, LoadCaseFamily_Accidental, LoadCaseFamily_DeadLoads, LoadCaseFamily_DynamicTemporal, LoadCaseFamily_LiveLoads, LoadCaseFamily_Other, LoadCaseFamily_PushOver, LoadCaseFamily_Seismic, LoadCaseFamily_SeismicCBN, LoadCaseFamily_SeismicEN_1998_1, LoadCaseFamily_SeismicIBC, LoadCaseFamily_Snow, LoadCaseFamily_SnowCBN, LoadCaseFamily_SnowIBC, LoadCaseFamily_Snow_1991_1_3, LoadCaseFamily_Thermic, LoadCaseFamily_Wind, LoadCaseFamily_WindCBN, LoadCaseFamily_WindIBC, LoadCaseFamily_Wind_1991_1_4, LoadCase_Accidental, LoadCase_DeadLoads, LoadCase_DynamicTemporal, LoadCase_LiveLoads, LoadCase_Other, LoadCase_PushOver, LoadCase_Seismic, LoadCase_SeismicCBN, LoadCase_SeismicEN_1998_1, LoadCase_SeismicIBC, LoadCase_Snow, LoadCase_SnowCBN, LoadCase_SnowIBC, LoadCase_Snow_1991_1_3, LoadCase_Thermic, LoadCase_Wind, LoadCase_WindCBN, LoadCase_WindIBC, LoadCase_Wind_1991_1_4
    """
    # Composed type representation for type Combination
    combination: Optional[Combination] = None
    # Composed type representation for type InformationalElementBase
    informational_element_base: Optional[InformationalElementBase] = None
    # Composed type representation for type LoadCase
    load_case: Optional[LoadCase] = None
    # Composed type representation for type LoadCase_Accidental
    load_case_accidental: Optional[LoadCase_Accidental] = None
    # Composed type representation for type LoadCase_DeadLoads
    load_case_dead_loads: Optional[LoadCase_DeadLoads] = None
    # Composed type representation for type LoadCase_DynamicTemporal
    load_case_dynamic_temporal: Optional[LoadCase_DynamicTemporal] = None
    # Composed type representation for type LoadCaseFamily
    load_case_family: Optional[LoadCaseFamily] = None
    # Composed type representation for type LoadCaseFamily_Accidental
    load_case_family_accidental: Optional[LoadCaseFamily_Accidental] = None
    # Composed type representation for type LoadCaseFamily_DeadLoads
    load_case_family_dead_loads: Optional[LoadCaseFamily_DeadLoads] = None
    # Composed type representation for type LoadCaseFamily_DynamicTemporal
    load_case_family_dynamic_temporal: Optional[LoadCaseFamily_DynamicTemporal] = None
    # Composed type representation for type LoadCaseFamily_LiveLoads
    load_case_family_live_loads: Optional[LoadCaseFamily_LiveLoads] = None
    # Composed type representation for type LoadCaseFamily_Other
    load_case_family_other: Optional[LoadCaseFamily_Other] = None
    # Composed type representation for type LoadCaseFamily_PushOver
    load_case_family_push_over: Optional[LoadCaseFamily_PushOver] = None
    # Composed type representation for type LoadCaseFamily_Seismic
    load_case_family_seismic: Optional[LoadCaseFamily_Seismic] = None
    # Composed type representation for type LoadCaseFamily_SeismicCBN
    load_case_family_seismic_c_b_n: Optional[LoadCaseFamily_SeismicCBN] = None
    # Composed type representation for type LoadCaseFamily_SeismicEN_1998_1
    load_case_family_seismic_e_n_1998_1: Optional[LoadCaseFamily_SeismicEN_1998_1] = None
    # Composed type representation for type LoadCaseFamily_SeismicIBC
    load_case_family_seismic_i_b_c: Optional[LoadCaseFamily_SeismicIBC] = None
    # Composed type representation for type LoadCaseFamily_Snow
    load_case_family_snow: Optional[LoadCaseFamily_Snow] = None
    # Composed type representation for type LoadCaseFamily_Snow_1991_1_3
    load_case_family_snow_1991_1_3: Optional[LoadCaseFamily_Snow_1991_1_3] = None
    # Composed type representation for type LoadCaseFamily_SnowCBN
    load_case_family_snow_c_b_n: Optional[LoadCaseFamily_SnowCBN] = None
    # Composed type representation for type LoadCaseFamily_SnowIBC
    load_case_family_snow_i_b_c: Optional[LoadCaseFamily_SnowIBC] = None
    # Composed type representation for type LoadCaseFamily_Thermic
    load_case_family_thermic: Optional[LoadCaseFamily_Thermic] = None
    # Composed type representation for type LoadCaseFamily_Wind
    load_case_family_wind: Optional[LoadCaseFamily_Wind] = None
    # Composed type representation for type LoadCaseFamily_Wind_1991_1_4
    load_case_family_wind_1991_1_4: Optional[LoadCaseFamily_Wind_1991_1_4] = None
    # Composed type representation for type LoadCaseFamily_WindCBN
    load_case_family_wind_c_b_n: Optional[LoadCaseFamily_WindCBN] = None
    # Composed type representation for type LoadCaseFamily_WindIBC
    load_case_family_wind_i_b_c: Optional[LoadCaseFamily_WindIBC] = None
    # Composed type representation for type LoadCase_LiveLoads
    load_case_live_loads: Optional[LoadCase_LiveLoads] = None
    # Composed type representation for type LoadCase_Other
    load_case_other: Optional[LoadCase_Other] = None
    # Composed type representation for type LoadCase_PushOver
    load_case_push_over: Optional[LoadCase_PushOver] = None
    # Composed type representation for type LoadCase_Seismic
    load_case_seismic: Optional[LoadCase_Seismic] = None
    # Composed type representation for type LoadCase_SeismicCBN
    load_case_seismic_c_b_n: Optional[LoadCase_SeismicCBN] = None
    # Composed type representation for type LoadCase_SeismicEN_1998_1
    load_case_seismic_e_n_1998_1: Optional[LoadCase_SeismicEN_1998_1] = None
    # Composed type representation for type LoadCase_SeismicIBC
    load_case_seismic_i_b_c: Optional[LoadCase_SeismicIBC] = None
    # Composed type representation for type LoadCase_Snow
    load_case_snow: Optional[LoadCase_Snow] = None
    # Composed type representation for type LoadCase_Snow_1991_1_3
    load_case_snow_1991_1_3: Optional[LoadCase_Snow_1991_1_3] = None
    # Composed type representation for type LoadCase_SnowCBN
    load_case_snow_c_b_n: Optional[LoadCase_SnowCBN] = None
    # Composed type representation for type LoadCase_SnowIBC
    load_case_snow_i_b_c: Optional[LoadCase_SnowIBC] = None
    # Composed type representation for type LoadCase_Thermic
    load_case_thermic: Optional[LoadCase_Thermic] = None
    # Composed type representation for type LoadCase_Wind
    load_case_wind: Optional[LoadCase_Wind] = None
    # Composed type representation for type LoadCase_Wind_1991_1_4
    load_case_wind_1991_1_4: Optional[LoadCase_Wind_1991_1_4] = None
    # Composed type representation for type LoadCase_WindCBN
    load_case_wind_c_b_n: Optional[LoadCase_WindCBN] = None
    # Composed type representation for type LoadCase_WindIBC
    load_case_wind_i_b_c: Optional[LoadCase_WindIBC] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateInformationalElementPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateInformationalElementPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = CreateInformationalElementPostRequestBody()
        if mapping_value and mapping_value.casefold() == "Combination".casefold():
            from .....models.combination import Combination

            result.combination = Combination()
        elif mapping_value and mapping_value.casefold() == "InformationalElementBase".casefold():
            from .....models.informational_element_base import InformationalElementBase

            result.informational_element_base = InformationalElementBase()
        elif mapping_value and mapping_value.casefold() == "LoadCase".casefold():
            from .....models.load_case import LoadCase

            result.load_case = LoadCase()
        elif mapping_value and mapping_value.casefold() == "LoadCase_Accidental".casefold():
            from .....models.load_case_accidental import LoadCase_Accidental

            result.load_case_accidental = LoadCase_Accidental()
        elif mapping_value and mapping_value.casefold() == "LoadCase_DeadLoads".casefold():
            from .....models.load_case_dead_loads import LoadCase_DeadLoads

            result.load_case_dead_loads = LoadCase_DeadLoads()
        elif mapping_value and mapping_value.casefold() == "LoadCase_DynamicTemporal".casefold():
            from .....models.load_case_dynamic_temporal import LoadCase_DynamicTemporal

            result.load_case_dynamic_temporal = LoadCase_DynamicTemporal()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily".casefold():
            from .....models.load_case_family import LoadCaseFamily

            result.load_case_family = LoadCaseFamily()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_Accidental".casefold():
            from .....models.load_case_family_accidental import LoadCaseFamily_Accidental

            result.load_case_family_accidental = LoadCaseFamily_Accidental()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_DeadLoads".casefold():
            from .....models.load_case_family_dead_loads import LoadCaseFamily_DeadLoads

            result.load_case_family_dead_loads = LoadCaseFamily_DeadLoads()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_DynamicTemporal".casefold():
            from .....models.load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal

            result.load_case_family_dynamic_temporal = LoadCaseFamily_DynamicTemporal()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_LiveLoads".casefold():
            from .....models.load_case_family_live_loads import LoadCaseFamily_LiveLoads

            result.load_case_family_live_loads = LoadCaseFamily_LiveLoads()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_Other".casefold():
            from .....models.load_case_family_other import LoadCaseFamily_Other

            result.load_case_family_other = LoadCaseFamily_Other()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_PushOver".casefold():
            from .....models.load_case_family_push_over import LoadCaseFamily_PushOver

            result.load_case_family_push_over = LoadCaseFamily_PushOver()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_Seismic".casefold():
            from .....models.load_case_family_seismic import LoadCaseFamily_Seismic

            result.load_case_family_seismic = LoadCaseFamily_Seismic()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicCBN".casefold():
            from .....models.load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN

            result.load_case_family_seismic_c_b_n = LoadCaseFamily_SeismicCBN()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicEN_1998_1".casefold():
            from .....models.load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1

            result.load_case_family_seismic_e_n_1998_1 = LoadCaseFamily_SeismicEN_1998_1()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicIBC".casefold():
            from .....models.load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC

            result.load_case_family_seismic_i_b_c = LoadCaseFamily_SeismicIBC()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_Snow".casefold():
            from .....models.load_case_family_snow import LoadCaseFamily_Snow

            result.load_case_family_snow = LoadCaseFamily_Snow()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_Snow_1991_1_3".casefold():
            from .....models.load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3

            result.load_case_family_snow_1991_1_3 = LoadCaseFamily_Snow_1991_1_3()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_SnowCBN".casefold():
            from .....models.load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN

            result.load_case_family_snow_c_b_n = LoadCaseFamily_SnowCBN()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_SnowIBC".casefold():
            from .....models.load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC

            result.load_case_family_snow_i_b_c = LoadCaseFamily_SnowIBC()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_Thermic".casefold():
            from .....models.load_case_family_thermic import LoadCaseFamily_Thermic

            result.load_case_family_thermic = LoadCaseFamily_Thermic()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_Wind".casefold():
            from .....models.load_case_family_wind import LoadCaseFamily_Wind

            result.load_case_family_wind = LoadCaseFamily_Wind()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_Wind_1991_1_4".casefold():
            from .....models.load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4

            result.load_case_family_wind_1991_1_4 = LoadCaseFamily_Wind_1991_1_4()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_WindCBN".casefold():
            from .....models.load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN

            result.load_case_family_wind_c_b_n = LoadCaseFamily_WindCBN()
        elif mapping_value and mapping_value.casefold() == "LoadCaseFamily_WindIBC".casefold():
            from .....models.load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC

            result.load_case_family_wind_i_b_c = LoadCaseFamily_WindIBC()
        elif mapping_value and mapping_value.casefold() == "LoadCase_LiveLoads".casefold():
            from .....models.load_case_live_loads import LoadCase_LiveLoads

            result.load_case_live_loads = LoadCase_LiveLoads()
        elif mapping_value and mapping_value.casefold() == "LoadCase_Other".casefold():
            from .....models.load_case_other import LoadCase_Other

            result.load_case_other = LoadCase_Other()
        elif mapping_value and mapping_value.casefold() == "LoadCase_PushOver".casefold():
            from .....models.load_case_push_over import LoadCase_PushOver

            result.load_case_push_over = LoadCase_PushOver()
        elif mapping_value and mapping_value.casefold() == "LoadCase_Seismic".casefold():
            from .....models.load_case_seismic import LoadCase_Seismic

            result.load_case_seismic = LoadCase_Seismic()
        elif mapping_value and mapping_value.casefold() == "LoadCase_SeismicCBN".casefold():
            from .....models.load_case_seismic_c_b_n import LoadCase_SeismicCBN

            result.load_case_seismic_c_b_n = LoadCase_SeismicCBN()
        elif mapping_value and mapping_value.casefold() == "LoadCase_SeismicEN_1998_1".casefold():
            from .....models.load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1

            result.load_case_seismic_e_n_1998_1 = LoadCase_SeismicEN_1998_1()
        elif mapping_value and mapping_value.casefold() == "LoadCase_SeismicIBC".casefold():
            from .....models.load_case_seismic_i_b_c import LoadCase_SeismicIBC

            result.load_case_seismic_i_b_c = LoadCase_SeismicIBC()
        elif mapping_value and mapping_value.casefold() == "LoadCase_Snow".casefold():
            from .....models.load_case_snow import LoadCase_Snow

            result.load_case_snow = LoadCase_Snow()
        elif mapping_value and mapping_value.casefold() == "LoadCase_Snow_1991_1_3".casefold():
            from .....models.load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3

            result.load_case_snow_1991_1_3 = LoadCase_Snow_1991_1_3()
        elif mapping_value and mapping_value.casefold() == "LoadCase_SnowCBN".casefold():
            from .....models.load_case_snow_c_b_n import LoadCase_SnowCBN

            result.load_case_snow_c_b_n = LoadCase_SnowCBN()
        elif mapping_value and mapping_value.casefold() == "LoadCase_SnowIBC".casefold():
            from .....models.load_case_snow_i_b_c import LoadCase_SnowIBC

            result.load_case_snow_i_b_c = LoadCase_SnowIBC()
        elif mapping_value and mapping_value.casefold() == "LoadCase_Thermic".casefold():
            from .....models.load_case_thermic import LoadCase_Thermic

            result.load_case_thermic = LoadCase_Thermic()
        elif mapping_value and mapping_value.casefold() == "LoadCase_Wind".casefold():
            from .....models.load_case_wind import LoadCase_Wind

            result.load_case_wind = LoadCase_Wind()
        elif mapping_value and mapping_value.casefold() == "LoadCase_Wind_1991_1_4".casefold():
            from .....models.load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4

            result.load_case_wind_1991_1_4 = LoadCase_Wind_1991_1_4()
        elif mapping_value and mapping_value.casefold() == "LoadCase_WindCBN".casefold():
            from .....models.load_case_wind_c_b_n import LoadCase_WindCBN

            result.load_case_wind_c_b_n = LoadCase_WindCBN()
        elif mapping_value and mapping_value.casefold() == "LoadCase_WindIBC".casefold():
            from .....models.load_case_wind_i_b_c import LoadCase_WindIBC

            result.load_case_wind_i_b_c = LoadCase_WindIBC()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .....models.combination import Combination
        from .....models.informational_element_base import InformationalElementBase
        from .....models.load_case import LoadCase
        from .....models.load_case_accidental import LoadCase_Accidental
        from .....models.load_case_dead_loads import LoadCase_DeadLoads
        from .....models.load_case_dynamic_temporal import LoadCase_DynamicTemporal
        from .....models.load_case_family import LoadCaseFamily
        from .....models.load_case_family_accidental import LoadCaseFamily_Accidental
        from .....models.load_case_family_dead_loads import LoadCaseFamily_DeadLoads
        from .....models.load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal
        from .....models.load_case_family_live_loads import LoadCaseFamily_LiveLoads
        from .....models.load_case_family_other import LoadCaseFamily_Other
        from .....models.load_case_family_push_over import LoadCaseFamily_PushOver
        from .....models.load_case_family_seismic import LoadCaseFamily_Seismic
        from .....models.load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
        from .....models.load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
        from .....models.load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
        from .....models.load_case_family_snow import LoadCaseFamily_Snow
        from .....models.load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
        from .....models.load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
        from .....models.load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC
        from .....models.load_case_family_thermic import LoadCaseFamily_Thermic
        from .....models.load_case_family_wind import LoadCaseFamily_Wind
        from .....models.load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4
        from .....models.load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN
        from .....models.load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC
        from .....models.load_case_live_loads import LoadCase_LiveLoads
        from .....models.load_case_other import LoadCase_Other
        from .....models.load_case_push_over import LoadCase_PushOver
        from .....models.load_case_seismic import LoadCase_Seismic
        from .....models.load_case_seismic_c_b_n import LoadCase_SeismicCBN
        from .....models.load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
        from .....models.load_case_seismic_i_b_c import LoadCase_SeismicIBC
        from .....models.load_case_snow import LoadCase_Snow
        from .....models.load_case_snow_1991_1_3 import LoadCase_Snow_1991_1_3
        from .....models.load_case_snow_c_b_n import LoadCase_SnowCBN
        from .....models.load_case_snow_i_b_c import LoadCase_SnowIBC
        from .....models.load_case_thermic import LoadCase_Thermic
        from .....models.load_case_wind import LoadCase_Wind
        from .....models.load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
        from .....models.load_case_wind_c_b_n import LoadCase_WindCBN
        from .....models.load_case_wind_i_b_c import LoadCase_WindIBC

        if self.combination:
            return self.combination.get_field_deserializers()
        if self.informational_element_base:
            return self.informational_element_base.get_field_deserializers()
        if self.load_case:
            return self.load_case.get_field_deserializers()
        if self.load_case_accidental:
            return self.load_case_accidental.get_field_deserializers()
        if self.load_case_dead_loads:
            return self.load_case_dead_loads.get_field_deserializers()
        if self.load_case_dynamic_temporal:
            return self.load_case_dynamic_temporal.get_field_deserializers()
        if self.load_case_family:
            return self.load_case_family.get_field_deserializers()
        if self.load_case_family_accidental:
            return self.load_case_family_accidental.get_field_deserializers()
        if self.load_case_family_dead_loads:
            return self.load_case_family_dead_loads.get_field_deserializers()
        if self.load_case_family_dynamic_temporal:
            return self.load_case_family_dynamic_temporal.get_field_deserializers()
        if self.load_case_family_live_loads:
            return self.load_case_family_live_loads.get_field_deserializers()
        if self.load_case_family_other:
            return self.load_case_family_other.get_field_deserializers()
        if self.load_case_family_push_over:
            return self.load_case_family_push_over.get_field_deserializers()
        if self.load_case_family_seismic:
            return self.load_case_family_seismic.get_field_deserializers()
        if self.load_case_family_seismic_c_b_n:
            return self.load_case_family_seismic_c_b_n.get_field_deserializers()
        if self.load_case_family_seismic_e_n_1998_1:
            return self.load_case_family_seismic_e_n_1998_1.get_field_deserializers()
        if self.load_case_family_seismic_i_b_c:
            return self.load_case_family_seismic_i_b_c.get_field_deserializers()
        if self.load_case_family_snow:
            return self.load_case_family_snow.get_field_deserializers()
        if self.load_case_family_snow_1991_1_3:
            return self.load_case_family_snow_1991_1_3.get_field_deserializers()
        if self.load_case_family_snow_c_b_n:
            return self.load_case_family_snow_c_b_n.get_field_deserializers()
        if self.load_case_family_snow_i_b_c:
            return self.load_case_family_snow_i_b_c.get_field_deserializers()
        if self.load_case_family_thermic:
            return self.load_case_family_thermic.get_field_deserializers()
        if self.load_case_family_wind:
            return self.load_case_family_wind.get_field_deserializers()
        if self.load_case_family_wind_1991_1_4:
            return self.load_case_family_wind_1991_1_4.get_field_deserializers()
        if self.load_case_family_wind_c_b_n:
            return self.load_case_family_wind_c_b_n.get_field_deserializers()
        if self.load_case_family_wind_i_b_c:
            return self.load_case_family_wind_i_b_c.get_field_deserializers()
        if self.load_case_live_loads:
            return self.load_case_live_loads.get_field_deserializers()
        if self.load_case_other:
            return self.load_case_other.get_field_deserializers()
        if self.load_case_push_over:
            return self.load_case_push_over.get_field_deserializers()
        if self.load_case_seismic:
            return self.load_case_seismic.get_field_deserializers()
        if self.load_case_seismic_c_b_n:
            return self.load_case_seismic_c_b_n.get_field_deserializers()
        if self.load_case_seismic_e_n_1998_1:
            return self.load_case_seismic_e_n_1998_1.get_field_deserializers()
        if self.load_case_seismic_i_b_c:
            return self.load_case_seismic_i_b_c.get_field_deserializers()
        if self.load_case_snow:
            return self.load_case_snow.get_field_deserializers()
        if self.load_case_snow_1991_1_3:
            return self.load_case_snow_1991_1_3.get_field_deserializers()
        if self.load_case_snow_c_b_n:
            return self.load_case_snow_c_b_n.get_field_deserializers()
        if self.load_case_snow_i_b_c:
            return self.load_case_snow_i_b_c.get_field_deserializers()
        if self.load_case_thermic:
            return self.load_case_thermic.get_field_deserializers()
        if self.load_case_wind:
            return self.load_case_wind.get_field_deserializers()
        if self.load_case_wind_1991_1_4:
            return self.load_case_wind_1991_1_4.get_field_deserializers()
        if self.load_case_wind_c_b_n:
            return self.load_case_wind_c_b_n.get_field_deserializers()
        if self.load_case_wind_i_b_c:
            return self.load_case_wind_i_b_c.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.combination:
            writer.write_object_value(None, self.combination)
        elif self.informational_element_base:
            writer.write_object_value(None, self.informational_element_base)
        elif self.load_case:
            writer.write_object_value(None, self.load_case)
        elif self.load_case_accidental:
            writer.write_object_value(None, self.load_case_accidental)
        elif self.load_case_dead_loads:
            writer.write_object_value(None, self.load_case_dead_loads)
        elif self.load_case_dynamic_temporal:
            writer.write_object_value(None, self.load_case_dynamic_temporal)
        elif self.load_case_family:
            writer.write_object_value(None, self.load_case_family)
        elif self.load_case_family_accidental:
            writer.write_object_value(None, self.load_case_family_accidental)
        elif self.load_case_family_dead_loads:
            writer.write_object_value(None, self.load_case_family_dead_loads)
        elif self.load_case_family_dynamic_temporal:
            writer.write_object_value(None, self.load_case_family_dynamic_temporal)
        elif self.load_case_family_live_loads:
            writer.write_object_value(None, self.load_case_family_live_loads)
        elif self.load_case_family_other:
            writer.write_object_value(None, self.load_case_family_other)
        elif self.load_case_family_push_over:
            writer.write_object_value(None, self.load_case_family_push_over)
        elif self.load_case_family_seismic:
            writer.write_object_value(None, self.load_case_family_seismic)
        elif self.load_case_family_seismic_c_b_n:
            writer.write_object_value(None, self.load_case_family_seismic_c_b_n)
        elif self.load_case_family_seismic_e_n_1998_1:
            writer.write_object_value(None, self.load_case_family_seismic_e_n_1998_1)
        elif self.load_case_family_seismic_i_b_c:
            writer.write_object_value(None, self.load_case_family_seismic_i_b_c)
        elif self.load_case_family_snow:
            writer.write_object_value(None, self.load_case_family_snow)
        elif self.load_case_family_snow_1991_1_3:
            writer.write_object_value(None, self.load_case_family_snow_1991_1_3)
        elif self.load_case_family_snow_c_b_n:
            writer.write_object_value(None, self.load_case_family_snow_c_b_n)
        elif self.load_case_family_snow_i_b_c:
            writer.write_object_value(None, self.load_case_family_snow_i_b_c)
        elif self.load_case_family_thermic:
            writer.write_object_value(None, self.load_case_family_thermic)
        elif self.load_case_family_wind:
            writer.write_object_value(None, self.load_case_family_wind)
        elif self.load_case_family_wind_1991_1_4:
            writer.write_object_value(None, self.load_case_family_wind_1991_1_4)
        elif self.load_case_family_wind_c_b_n:
            writer.write_object_value(None, self.load_case_family_wind_c_b_n)
        elif self.load_case_family_wind_i_b_c:
            writer.write_object_value(None, self.load_case_family_wind_i_b_c)
        elif self.load_case_live_loads:
            writer.write_object_value(None, self.load_case_live_loads)
        elif self.load_case_other:
            writer.write_object_value(None, self.load_case_other)
        elif self.load_case_push_over:
            writer.write_object_value(None, self.load_case_push_over)
        elif self.load_case_seismic:
            writer.write_object_value(None, self.load_case_seismic)
        elif self.load_case_seismic_c_b_n:
            writer.write_object_value(None, self.load_case_seismic_c_b_n)
        elif self.load_case_seismic_e_n_1998_1:
            writer.write_object_value(None, self.load_case_seismic_e_n_1998_1)
        elif self.load_case_seismic_i_b_c:
            writer.write_object_value(None, self.load_case_seismic_i_b_c)
        elif self.load_case_snow:
            writer.write_object_value(None, self.load_case_snow)
        elif self.load_case_snow_1991_1_3:
            writer.write_object_value(None, self.load_case_snow_1991_1_3)
        elif self.load_case_snow_c_b_n:
            writer.write_object_value(None, self.load_case_snow_c_b_n)
        elif self.load_case_snow_i_b_c:
            writer.write_object_value(None, self.load_case_snow_i_b_c)
        elif self.load_case_thermic:
            writer.write_object_value(None, self.load_case_thermic)
        elif self.load_case_wind:
            writer.write_object_value(None, self.load_case_wind)
        elif self.load_case_wind_1991_1_4:
            writer.write_object_value(None, self.load_case_wind_1991_1_4)
        elif self.load_case_wind_c_b_n:
            writer.write_object_value(None, self.load_case_wind_c_b_n)
        elif self.load_case_wind_i_b_c:
            writer.write_object_value(None, self.load_case_wind_i_b_c)
    

