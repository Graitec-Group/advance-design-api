from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .....models.element_advanced_linear_support import ElementAdvancedLinearSupport
    from .....models.element_advanced_planar_support import ElementAdvancedPlanarSupport
    from .....models.element_advanced_punctual_support import ElementAdvancedPunctualSupport
    from .....models.element_base import ElementBase
    from .....models.element_elastic_linear_support import ElementElasticLinearSupport
    from .....models.element_elastic_planar_support import ElementElasticPlanarSupport
    from .....models.element_elastic_punctual_support import ElementElasticPunctualSupport
    from .....models.element_imposed_displacement import ElementImposedDisplacement
    from .....models.element_linear import ElementLinear
    from .....models.element_load_area import ElementLoadArea
    from .....models.element_load_linear import ElementLoadLinear
    from .....models.element_load_planar import ElementLoadPlanar
    from .....models.element_load_punctual import ElementLoadPunctual
    from .....models.element_mass import ElementMass
    from .....models.element_planar import ElementPlanar
    from .....models.element_rigid_linear_support import ElementRigidLinearSupport
    from .....models.element_rigid_planar_support import ElementRigidPlanarSupport
    from .....models.element_rigid_punctual_support import ElementRigidPunctualSupport
    from .....models.element_single_pile import ElementSinglePile
    from .....models.element_t_c_linear_support import ElementTCLinearSupport
    from .....models.element_t_c_planar_support import ElementTCPlanarSupport
    from .....models.element_t_c_punctual_support import ElementTCPunctualSupport
    from .....models.family_support_linear import FamilySupportLinear
    from .....models.family_support_planar import FamilySupportPlanar
    from .....models.family_support_punctual import FamilySupportPunctual

@dataclass
class CreateElementPostRequestBody(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ElementAdvancedLinearSupport, ElementAdvancedPlanarSupport, ElementAdvancedPunctualSupport, ElementBase, ElementElasticLinearSupport, ElementElasticPlanarSupport, ElementElasticPunctualSupport, ElementImposedDisplacement, ElementLinear, ElementLoadArea, ElementLoadLinear, ElementLoadPlanar, ElementLoadPunctual, ElementMass, ElementPlanar, ElementRigidLinearSupport, ElementRigidPlanarSupport, ElementRigidPunctualSupport, ElementSinglePile, ElementTCLinearSupport, ElementTCPlanarSupport, ElementTCPunctualSupport, FamilySupportLinear, FamilySupportPlanar, FamilySupportPunctual
    """
    # Composed type representation for type ElementAdvancedLinearSupport
    element_advanced_linear_support: Optional[ElementAdvancedLinearSupport] = None
    # Composed type representation for type ElementAdvancedPlanarSupport
    element_advanced_planar_support: Optional[ElementAdvancedPlanarSupport] = None
    # Composed type representation for type ElementAdvancedPunctualSupport
    element_advanced_punctual_support: Optional[ElementAdvancedPunctualSupport] = None
    # Composed type representation for type ElementBase
    element_base: Optional[ElementBase] = None
    # Composed type representation for type ElementElasticLinearSupport
    element_elastic_linear_support: Optional[ElementElasticLinearSupport] = None
    # Composed type representation for type ElementElasticPlanarSupport
    element_elastic_planar_support: Optional[ElementElasticPlanarSupport] = None
    # Composed type representation for type ElementElasticPunctualSupport
    element_elastic_punctual_support: Optional[ElementElasticPunctualSupport] = None
    # Composed type representation for type ElementImposedDisplacement
    element_imposed_displacement: Optional[ElementImposedDisplacement] = None
    # Composed type representation for type ElementLinear
    element_linear: Optional[ElementLinear] = None
    # Composed type representation for type ElementLoadArea
    element_load_area: Optional[ElementLoadArea] = None
    # Composed type representation for type ElementLoadLinear
    element_load_linear: Optional[ElementLoadLinear] = None
    # Composed type representation for type ElementLoadPlanar
    element_load_planar: Optional[ElementLoadPlanar] = None
    # Composed type representation for type ElementLoadPunctual
    element_load_punctual: Optional[ElementLoadPunctual] = None
    # Composed type representation for type ElementMass
    element_mass: Optional[ElementMass] = None
    # Composed type representation for type ElementPlanar
    element_planar: Optional[ElementPlanar] = None
    # Composed type representation for type ElementRigidLinearSupport
    element_rigid_linear_support: Optional[ElementRigidLinearSupport] = None
    # Composed type representation for type ElementRigidPlanarSupport
    element_rigid_planar_support: Optional[ElementRigidPlanarSupport] = None
    # Composed type representation for type ElementRigidPunctualSupport
    element_rigid_punctual_support: Optional[ElementRigidPunctualSupport] = None
    # Composed type representation for type ElementSinglePile
    element_single_pile: Optional[ElementSinglePile] = None
    # Composed type representation for type ElementTCLinearSupport
    element_t_c_linear_support: Optional[ElementTCLinearSupport] = None
    # Composed type representation for type ElementTCPlanarSupport
    element_t_c_planar_support: Optional[ElementTCPlanarSupport] = None
    # Composed type representation for type ElementTCPunctualSupport
    element_t_c_punctual_support: Optional[ElementTCPunctualSupport] = None
    # Composed type representation for type FamilySupportLinear
    family_support_linear: Optional[FamilySupportLinear] = None
    # Composed type representation for type FamilySupportPlanar
    family_support_planar: Optional[FamilySupportPlanar] = None
    # Composed type representation for type FamilySupportPunctual
    family_support_punctual: Optional[FamilySupportPunctual] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateElementPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateElementPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = CreateElementPostRequestBody()
        if mapping_value and mapping_value.casefold() == "ElementAdvancedLinearSupport".casefold():
            from .....models.element_advanced_linear_support import ElementAdvancedLinearSupport

            result.element_advanced_linear_support = ElementAdvancedLinearSupport()
        elif mapping_value and mapping_value.casefold() == "ElementAdvancedPlanarSupport".casefold():
            from .....models.element_advanced_planar_support import ElementAdvancedPlanarSupport

            result.element_advanced_planar_support = ElementAdvancedPlanarSupport()
        elif mapping_value and mapping_value.casefold() == "ElementAdvancedPunctualSupport".casefold():
            from .....models.element_advanced_punctual_support import ElementAdvancedPunctualSupport

            result.element_advanced_punctual_support = ElementAdvancedPunctualSupport()
        elif mapping_value and mapping_value.casefold() == "ElementBase".casefold():
            from .....models.element_base import ElementBase

            result.element_base = ElementBase()
        elif mapping_value and mapping_value.casefold() == "ElementElasticLinearSupport".casefold():
            from .....models.element_elastic_linear_support import ElementElasticLinearSupport

            result.element_elastic_linear_support = ElementElasticLinearSupport()
        elif mapping_value and mapping_value.casefold() == "ElementElasticPlanarSupport".casefold():
            from .....models.element_elastic_planar_support import ElementElasticPlanarSupport

            result.element_elastic_planar_support = ElementElasticPlanarSupport()
        elif mapping_value and mapping_value.casefold() == "ElementElasticPunctualSupport".casefold():
            from .....models.element_elastic_punctual_support import ElementElasticPunctualSupport

            result.element_elastic_punctual_support = ElementElasticPunctualSupport()
        elif mapping_value and mapping_value.casefold() == "ElementImposedDisplacement".casefold():
            from .....models.element_imposed_displacement import ElementImposedDisplacement

            result.element_imposed_displacement = ElementImposedDisplacement()
        elif mapping_value and mapping_value.casefold() == "ElementLinear".casefold():
            from .....models.element_linear import ElementLinear

            result.element_linear = ElementLinear()
        elif mapping_value and mapping_value.casefold() == "ElementLoadArea".casefold():
            from .....models.element_load_area import ElementLoadArea

            result.element_load_area = ElementLoadArea()
        elif mapping_value and mapping_value.casefold() == "ElementLoadLinear".casefold():
            from .....models.element_load_linear import ElementLoadLinear

            result.element_load_linear = ElementLoadLinear()
        elif mapping_value and mapping_value.casefold() == "ElementLoadPlanar".casefold():
            from .....models.element_load_planar import ElementLoadPlanar

            result.element_load_planar = ElementLoadPlanar()
        elif mapping_value and mapping_value.casefold() == "ElementLoadPunctual".casefold():
            from .....models.element_load_punctual import ElementLoadPunctual

            result.element_load_punctual = ElementLoadPunctual()
        elif mapping_value and mapping_value.casefold() == "ElementMass".casefold():
            from .....models.element_mass import ElementMass

            result.element_mass = ElementMass()
        elif mapping_value and mapping_value.casefold() == "ElementPlanar".casefold():
            from .....models.element_planar import ElementPlanar

            result.element_planar = ElementPlanar()
        elif mapping_value and mapping_value.casefold() == "ElementRigidLinearSupport".casefold():
            from .....models.element_rigid_linear_support import ElementRigidLinearSupport

            result.element_rigid_linear_support = ElementRigidLinearSupport()
        elif mapping_value and mapping_value.casefold() == "ElementRigidPlanarSupport".casefold():
            from .....models.element_rigid_planar_support import ElementRigidPlanarSupport

            result.element_rigid_planar_support = ElementRigidPlanarSupport()
        elif mapping_value and mapping_value.casefold() == "ElementRigidPunctualSupport".casefold():
            from .....models.element_rigid_punctual_support import ElementRigidPunctualSupport

            result.element_rigid_punctual_support = ElementRigidPunctualSupport()
        elif mapping_value and mapping_value.casefold() == "ElementSinglePile".casefold():
            from .....models.element_single_pile import ElementSinglePile

            result.element_single_pile = ElementSinglePile()
        elif mapping_value and mapping_value.casefold() == "ElementTCLinearSupport".casefold():
            from .....models.element_t_c_linear_support import ElementTCLinearSupport

            result.element_t_c_linear_support = ElementTCLinearSupport()
        elif mapping_value and mapping_value.casefold() == "ElementTCPlanarSupport".casefold():
            from .....models.element_t_c_planar_support import ElementTCPlanarSupport

            result.element_t_c_planar_support = ElementTCPlanarSupport()
        elif mapping_value and mapping_value.casefold() == "ElementTCPunctualSupport".casefold():
            from .....models.element_t_c_punctual_support import ElementTCPunctualSupport

            result.element_t_c_punctual_support = ElementTCPunctualSupport()
        elif mapping_value and mapping_value.casefold() == "FamilySupportLinear".casefold():
            from .....models.family_support_linear import FamilySupportLinear

            result.family_support_linear = FamilySupportLinear()
        elif mapping_value and mapping_value.casefold() == "FamilySupportPlanar".casefold():
            from .....models.family_support_planar import FamilySupportPlanar

            result.family_support_planar = FamilySupportPlanar()
        elif mapping_value and mapping_value.casefold() == "FamilySupportPunctual".casefold():
            from .....models.family_support_punctual import FamilySupportPunctual

            result.family_support_punctual = FamilySupportPunctual()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .....models.element_advanced_linear_support import ElementAdvancedLinearSupport
        from .....models.element_advanced_planar_support import ElementAdvancedPlanarSupport
        from .....models.element_advanced_punctual_support import ElementAdvancedPunctualSupport
        from .....models.element_base import ElementBase
        from .....models.element_elastic_linear_support import ElementElasticLinearSupport
        from .....models.element_elastic_planar_support import ElementElasticPlanarSupport
        from .....models.element_elastic_punctual_support import ElementElasticPunctualSupport
        from .....models.element_imposed_displacement import ElementImposedDisplacement
        from .....models.element_linear import ElementLinear
        from .....models.element_load_area import ElementLoadArea
        from .....models.element_load_linear import ElementLoadLinear
        from .....models.element_load_planar import ElementLoadPlanar
        from .....models.element_load_punctual import ElementLoadPunctual
        from .....models.element_mass import ElementMass
        from .....models.element_planar import ElementPlanar
        from .....models.element_rigid_linear_support import ElementRigidLinearSupport
        from .....models.element_rigid_planar_support import ElementRigidPlanarSupport
        from .....models.element_rigid_punctual_support import ElementRigidPunctualSupport
        from .....models.element_single_pile import ElementSinglePile
        from .....models.element_t_c_linear_support import ElementTCLinearSupport
        from .....models.element_t_c_planar_support import ElementTCPlanarSupport
        from .....models.element_t_c_punctual_support import ElementTCPunctualSupport
        from .....models.family_support_linear import FamilySupportLinear
        from .....models.family_support_planar import FamilySupportPlanar
        from .....models.family_support_punctual import FamilySupportPunctual

        if self.element_advanced_linear_support:
            return self.element_advanced_linear_support.get_field_deserializers()
        if self.element_advanced_planar_support:
            return self.element_advanced_planar_support.get_field_deserializers()
        if self.element_advanced_punctual_support:
            return self.element_advanced_punctual_support.get_field_deserializers()
        if self.element_base:
            return self.element_base.get_field_deserializers()
        if self.element_elastic_linear_support:
            return self.element_elastic_linear_support.get_field_deserializers()
        if self.element_elastic_planar_support:
            return self.element_elastic_planar_support.get_field_deserializers()
        if self.element_elastic_punctual_support:
            return self.element_elastic_punctual_support.get_field_deserializers()
        if self.element_imposed_displacement:
            return self.element_imposed_displacement.get_field_deserializers()
        if self.element_linear:
            return self.element_linear.get_field_deserializers()
        if self.element_load_area:
            return self.element_load_area.get_field_deserializers()
        if self.element_load_linear:
            return self.element_load_linear.get_field_deserializers()
        if self.element_load_planar:
            return self.element_load_planar.get_field_deserializers()
        if self.element_load_punctual:
            return self.element_load_punctual.get_field_deserializers()
        if self.element_mass:
            return self.element_mass.get_field_deserializers()
        if self.element_planar:
            return self.element_planar.get_field_deserializers()
        if self.element_rigid_linear_support:
            return self.element_rigid_linear_support.get_field_deserializers()
        if self.element_rigid_planar_support:
            return self.element_rigid_planar_support.get_field_deserializers()
        if self.element_rigid_punctual_support:
            return self.element_rigid_punctual_support.get_field_deserializers()
        if self.element_single_pile:
            return self.element_single_pile.get_field_deserializers()
        if self.element_t_c_linear_support:
            return self.element_t_c_linear_support.get_field_deserializers()
        if self.element_t_c_planar_support:
            return self.element_t_c_planar_support.get_field_deserializers()
        if self.element_t_c_punctual_support:
            return self.element_t_c_punctual_support.get_field_deserializers()
        if self.family_support_linear:
            return self.family_support_linear.get_field_deserializers()
        if self.family_support_planar:
            return self.family_support_planar.get_field_deserializers()
        if self.family_support_punctual:
            return self.family_support_punctual.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.element_advanced_linear_support:
            writer.write_object_value(None, self.element_advanced_linear_support)
        elif self.element_advanced_planar_support:
            writer.write_object_value(None, self.element_advanced_planar_support)
        elif self.element_advanced_punctual_support:
            writer.write_object_value(None, self.element_advanced_punctual_support)
        elif self.element_base:
            writer.write_object_value(None, self.element_base)
        elif self.element_elastic_linear_support:
            writer.write_object_value(None, self.element_elastic_linear_support)
        elif self.element_elastic_planar_support:
            writer.write_object_value(None, self.element_elastic_planar_support)
        elif self.element_elastic_punctual_support:
            writer.write_object_value(None, self.element_elastic_punctual_support)
        elif self.element_imposed_displacement:
            writer.write_object_value(None, self.element_imposed_displacement)
        elif self.element_linear:
            writer.write_object_value(None, self.element_linear)
        elif self.element_load_area:
            writer.write_object_value(None, self.element_load_area)
        elif self.element_load_linear:
            writer.write_object_value(None, self.element_load_linear)
        elif self.element_load_planar:
            writer.write_object_value(None, self.element_load_planar)
        elif self.element_load_punctual:
            writer.write_object_value(None, self.element_load_punctual)
        elif self.element_mass:
            writer.write_object_value(None, self.element_mass)
        elif self.element_planar:
            writer.write_object_value(None, self.element_planar)
        elif self.element_rigid_linear_support:
            writer.write_object_value(None, self.element_rigid_linear_support)
        elif self.element_rigid_planar_support:
            writer.write_object_value(None, self.element_rigid_planar_support)
        elif self.element_rigid_punctual_support:
            writer.write_object_value(None, self.element_rigid_punctual_support)
        elif self.element_single_pile:
            writer.write_object_value(None, self.element_single_pile)
        elif self.element_t_c_linear_support:
            writer.write_object_value(None, self.element_t_c_linear_support)
        elif self.element_t_c_planar_support:
            writer.write_object_value(None, self.element_t_c_planar_support)
        elif self.element_t_c_punctual_support:
            writer.write_object_value(None, self.element_t_c_punctual_support)
        elif self.family_support_linear:
            writer.write_object_value(None, self.family_support_linear)
        elif self.family_support_planar:
            writer.write_object_value(None, self.family_support_planar)
        elif self.family_support_punctual:
            writer.write_object_value(None, self.family_support_punctual)
    

