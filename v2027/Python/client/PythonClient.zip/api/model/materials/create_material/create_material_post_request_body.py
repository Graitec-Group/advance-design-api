from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .....models.material import Material
    from .....models.material_other import MaterialOther
    from .....models.material_reinforced_concrete import MaterialReinforcedConcrete
    from .....models.material_rigid import MaterialRigid
    from .....models.material_steel import MaterialSteel
    from .....models.material_wood import MaterialWood
    from .....models.material_wood_north_america import MaterialWoodNorthAmerica

@dataclass
class CreateMaterialPostRequestBody(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes Material, MaterialOther, MaterialReinforcedConcrete, MaterialRigid, MaterialSteel, MaterialWood, MaterialWoodNorthAmerica
    """
    # Composed type representation for type Material
    material: Optional[Material] = None
    # Composed type representation for type MaterialOther
    material_other: Optional[MaterialOther] = None
    # Composed type representation for type MaterialReinforcedConcrete
    material_reinforced_concrete: Optional[MaterialReinforcedConcrete] = None
    # Composed type representation for type MaterialRigid
    material_rigid: Optional[MaterialRigid] = None
    # Composed type representation for type MaterialSteel
    material_steel: Optional[MaterialSteel] = None
    # Composed type representation for type MaterialWood
    material_wood: Optional[MaterialWood] = None
    # Composed type representation for type MaterialWoodNorthAmerica
    material_wood_north_america: Optional[MaterialWoodNorthAmerica] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateMaterialPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateMaterialPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = CreateMaterialPostRequestBody()
        if mapping_value and mapping_value.casefold() == "Material".casefold():
            from .....models.material import Material

            result.material = Material()
        elif mapping_value and mapping_value.casefold() == "MaterialOther".casefold():
            from .....models.material_other import MaterialOther

            result.material_other = MaterialOther()
        elif mapping_value and mapping_value.casefold() == "MaterialReinforcedConcrete".casefold():
            from .....models.material_reinforced_concrete import MaterialReinforcedConcrete

            result.material_reinforced_concrete = MaterialReinforcedConcrete()
        elif mapping_value and mapping_value.casefold() == "MaterialRigid".casefold():
            from .....models.material_rigid import MaterialRigid

            result.material_rigid = MaterialRigid()
        elif mapping_value and mapping_value.casefold() == "MaterialSteel".casefold():
            from .....models.material_steel import MaterialSteel

            result.material_steel = MaterialSteel()
        elif mapping_value and mapping_value.casefold() == "MaterialWood".casefold():
            from .....models.material_wood import MaterialWood

            result.material_wood = MaterialWood()
        elif mapping_value and mapping_value.casefold() == "MaterialWoodNorthAmerica".casefold():
            from .....models.material_wood_north_america import MaterialWoodNorthAmerica

            result.material_wood_north_america = MaterialWoodNorthAmerica()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .....models.material import Material
        from .....models.material_other import MaterialOther
        from .....models.material_reinforced_concrete import MaterialReinforcedConcrete
        from .....models.material_rigid import MaterialRigid
        from .....models.material_steel import MaterialSteel
        from .....models.material_wood import MaterialWood
        from .....models.material_wood_north_america import MaterialWoodNorthAmerica

        if self.material:
            return self.material.get_field_deserializers()
        if self.material_other:
            return self.material_other.get_field_deserializers()
        if self.material_reinforced_concrete:
            return self.material_reinforced_concrete.get_field_deserializers()
        if self.material_rigid:
            return self.material_rigid.get_field_deserializers()
        if self.material_steel:
            return self.material_steel.get_field_deserializers()
        if self.material_wood:
            return self.material_wood.get_field_deserializers()
        if self.material_wood_north_america:
            return self.material_wood_north_america.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.material:
            writer.write_object_value(None, self.material)
        elif self.material_other:
            writer.write_object_value(None, self.material_other)
        elif self.material_reinforced_concrete:
            writer.write_object_value(None, self.material_reinforced_concrete)
        elif self.material_rigid:
            writer.write_object_value(None, self.material_rigid)
        elif self.material_steel:
            writer.write_object_value(None, self.material_steel)
        elif self.material_wood:
            writer.write_object_value(None, self.material_wood)
        elif self.material_wood_north_america:
            writer.write_object_value(None, self.material_wood_north_america)
    

