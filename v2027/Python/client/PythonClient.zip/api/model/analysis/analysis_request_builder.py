from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .get_mesh_connectivity.get_mesh_connectivity_request_builder import GetMeshConnectivityRequestBuilder
    from .get_mesh_nodes_position.get_mesh_nodes_position_request_builder import GetMeshNodesPositionRequestBuilder
    from .get_results.get_results_request_builder import GetResultsRequestBuilder
    from .launch_analysis.launch_analysis_request_builder import LaunchAnalysisRequestBuilder

class AnalysisRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/analysis
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new AnalysisRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/analysis", path_parameters)
    
    @property
    def get_mesh_connectivity(self) -> GetMeshConnectivityRequestBuilder:
        """
        The GetMeshConnectivity property
        """
        from .get_mesh_connectivity.get_mesh_connectivity_request_builder import GetMeshConnectivityRequestBuilder

        return GetMeshConnectivityRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def get_mesh_nodes_position(self) -> GetMeshNodesPositionRequestBuilder:
        """
        The GetMeshNodesPosition property
        """
        from .get_mesh_nodes_position.get_mesh_nodes_position_request_builder import GetMeshNodesPositionRequestBuilder

        return GetMeshNodesPositionRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def get_results(self) -> GetResultsRequestBuilder:
        """
        The GetResults property
        """
        from .get_results.get_results_request_builder import GetResultsRequestBuilder

        return GetResultsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def launch_analysis(self) -> LaunchAnalysisRequestBuilder:
        """
        The LaunchAnalysis property
        """
        from .launch_analysis.launch_analysis_request_builder import LaunchAnalysisRequestBuilder

        return LaunchAnalysisRequestBuilder(self.request_adapter, self.path_parameters)
    

