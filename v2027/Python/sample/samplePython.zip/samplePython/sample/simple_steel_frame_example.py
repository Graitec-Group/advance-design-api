import asyncio
from datetime import datetime
import math
import os
from pathlib import Path
import sys
from typing import Any

import httpx
from kiota_abstractions.authentication.authentication_provider import AuthenticationProvider
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.request_information import RequestInformation
from kiota_http.httpx_request_adapter import HttpxRequestAdapter

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from PythonClient.api.model.analysis.get_results.get_results_request_builder import GetResultsRequestBuilder
from PythonClient.api.model.elements.create_informational_element.create_informational_element_post_request_body import CreateInformationalElementPostRequestBody
from PythonClient.api.model.management.new_project.new_project_request_builder import NewProjectRequestBuilder
from PythonClient.api.model.sections.create_section.create_section_request_builder import CreateSectionRequestBuilder
from PythonClient.api.model.elements.create_element.create_element_post_request_body import CreateElementPostRequestBody
from PythonClient.api.model.materials.create_material.create_material_post_request_body import CreateMaterialPostRequestBody
from PythonClient.api_client import ApiClient
from PythonClient.models.degree_of_freedom_restraints import DegreeOfFreedomRestraints
from PythonClient.models.e_i_d import EID
from PythonClient.models.element_type_enum import ElementTypeEnum
from PythonClient.models.element_linear import ElementLinear
from PythonClient.models.element_load_punctual import ElementLoadPunctual
from PythonClient.models.element_rigid_punctual_support import ElementRigidPunctualSupport
from PythonClient.models.environments import Environments
from PythonClient.models.informational_element_type_enum import InformationalElementTypeEnum
from PythonClient.models.log_verbose_level import LogVerboseLevel
from PythonClient.models.load_case_live_loads import LoadCase_LiveLoads
from PythonClient.models.material_steel import MaterialSteel
from PythonClient.models.pt3_d import Pt3D

BASE_URL = os.getenv("KIOTA_BASE_URL", "http://localhost:52000").rstrip("/")
TIMEOUT_MS = 10000
PROJECT_NAME = "simple_steel_frame"


class NoAuthenticationProvider(AuthenticationProvider):
    async def authenticate_request(
        self,
        request: RequestInformation,
        additional_authentication_context: dict[str, Any] = {},
    ) -> None:
        return None


def ensure_success(response: Any, operation: str) -> Any:
    if response is None:
        raise RuntimeError(f"{operation} failed: empty response")

    details = getattr(response, "details", None)
    success = getattr(details, "success", None) if details is not None else None
    if success is False:
        diagnostics = getattr(details, "diagnostics", None) or []
        raise RuntimeError(f"{operation} failed: {diagnostics}")

    return response


def enum_to_string(value: Any) -> str:
    raw = value.value if hasattr(value, "value") else value
    if isinstance(raw, tuple):
        return str(raw[0])
    return str(raw)


def class_discriminator(instance: Any) -> str:
    return type(instance).__name__


async def create_project(client: ApiClient) -> None:
    model_dir = Path(__file__).resolve().parents[1] / "model"
    model_dir.mkdir(parents=True, exist_ok=True)
    run_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_file = model_dir / f"{PROJECT_NAME}_{run_stamp}.fto"

    body = Environments(log_verbosity=LogVerboseLevel.ErrorsAndWarnings)
    query = NewProjectRequestBuilder.NewProjectRequestBuilderPostQueryParameters(filename=str(model_file))
    config = RequestConfiguration(query_parameters=query)

    response = await client.api.model.management.new_project.post(body, config)
    ensure_success(response, "NewProject")


async def create_material_steel(client: ApiClient) -> int:
    steel = MaterialSteel(name="Steel_S235", type=class_discriminator(MaterialSteel()))
    body = CreateMaterialPostRequestBody(material_steel=steel)

    response = await client.api.model.materials.create_material.post(body)
    payload = ensure_success(response, "CreateMaterial")

    if payload.data is None or payload.data.value is None:
        raise RuntimeError("CreateMaterial returned no material ID")
    return int(payload.data.value)


async def create_section_ipe100(client: ApiClient) -> int:
    query = CreateSectionRequestBuilder.CreateSectionRequestBuilderPostQueryParameters(section_name="IPE100")
    config = RequestConfiguration(query_parameters=query)

    response = await client.api.model.sections.create_section.post(config)
    payload = ensure_success(response, "CreateSection")

    if payload.data is None or payload.data.value is None:
        raise RuntimeError("CreateSection returned no section ID")
    return int(payload.data.value)


async def create_load_case_live_loads(client: ApiClient) -> int:
    load_case_discriminator = enum_to_string(InformationalElementTypeEnum.LoadCase_LiveLoads)
    load_case = LoadCase_LiveLoads(
        type=load_case_discriminator,
        name="LC_Live_TopLoad",
        live_load_category=0,
    )
    body = CreateInformationalElementPostRequestBody(load_case_live_loads=load_case)

    response = await client.api.model.elements.create_informational_element.post(body)
    payload = ensure_success(response, "CreateInformationalElement (LoadCase_LiveLoads)")

    if payload.data is None or payload.data.value is None:
        raise RuntimeError("CreateLoadCase returned no load case ID")
    return int(payload.data.value)


def build_create_element_body(element: Any) -> CreateElementPostRequestBody:
    body = CreateElementPostRequestBody()
    if isinstance(element, ElementLinear):
        body.element_linear = element
    elif isinstance(element, ElementRigidPunctualSupport):
        body.element_rigid_punctual_support = element
    elif isinstance(element, ElementLoadPunctual):
        body.element_load_punctual = element
    else:
        raise TypeError(f"Unsupported element type: {type(element)}")
    return body


async def create_element(client: ApiClient, element: Any, op_name: str) -> int:
    request_body = build_create_element_body(element)
    response = await client.api.model.elements.create_element.post(request_body)
    payload = ensure_success(response, op_name)

    if payload.data is None or payload.data.value is None:
        raise RuntimeError(f"{op_name} returned no element ID")
    return int(payload.data.value)


async def create_frame_geometry(client: ApiClient, material_id: int, section_id: int) -> list[int]:
    fixed_restraints = DegreeOfFreedomRestraints(tx=True, ty=True, tz=True, rx=True, ry=True, rz=True)
    material = EID(value=material_id)
    support_discriminator = enum_to_string(ElementTypeEnum.ElementRigidPunctualSupport)
    linear_discriminator = enum_to_string(ElementTypeEnum.ElementLinear)

    left_support = ElementRigidPunctualSupport(
        type=support_discriminator,
        geom_pt=Pt3D(x=0.0, y=0.0, z=0.0),
        restraints=fixed_restraints,
        material=material,
    )
    right_support = ElementRigidPunctualSupport(
        type=support_discriminator,
        geom_pt=Pt3D(x=4.0, y=0.0, z=0.0),
        restraints=fixed_restraints,
        material=material,
    )

    await create_element(client, left_support, "Create left support")
    await create_element(client, right_support, "Create right support")

    section = EID(value=section_id)

    left_column = ElementLinear(
        type=linear_discriminator,
        geom_pt_start=Pt3D(x=0.0, y=0.0, z=0.0),
        geom_pt_end=Pt3D(x=0.0, y=0.0, z=3.0),
        material=material,
        section=section,
    )
    right_column = ElementLinear(
        type=linear_discriminator,
        geom_pt_start=Pt3D(x=4.0, y=0.0, z=0.0),
        geom_pt_end=Pt3D(x=4.0, y=0.0, z=3.0),
        material=material,
        section=section,
    )
    top_beam = ElementLinear(
        type=linear_discriminator,
        geom_pt_start=Pt3D(x=0.0, y=0.0, z=3.0),
        geom_pt_end=Pt3D(x=4.0, y=0.0, z=3.0),
        material=material,
        section=section,
    )

    left_column_id = await create_element(client, left_column, "Create left column")
    right_column_id = await create_element(client, right_column, "Create right column")
    top_beam_id = await create_element(client, top_beam, "Create top beam")

    return [left_column_id, right_column_id, top_beam_id]


async def add_top_load(client: ApiClient, load_case_id: int) -> int:
    load_discriminator = enum_to_string(ElementTypeEnum.ElementLoadPunctual)
    load = ElementLoadPunctual(
        type=load_discriminator,
        geom_pt=Pt3D(x=2.0, y=0.0, z=3.0),
        fz=-10000.0,
        load_case=EID(value=load_case_id),
    )
    return await create_element(client, load, "Create top load")


async def launch_analysis(client: ApiClient) -> None:
    response = await client.api.model.analysis.launch_analysis.post()
    ensure_success(response, "LaunchAnalysis")


async def get_max_displacement(client: ApiClient, linear_element_ids: list[int]) -> float:
    query = GetResultsRequestBuilder.GetResultsRequestBuilderPostQueryParameters(e_res_type="displacement")
    config = RequestConfiguration(query_parameters=query)
    response = await client.api.model.analysis.get_results.post(linear_element_ids, config)
    payload = ensure_success(response, "GetResults")

    max_disp = 0.0
    for result_item in payload.data or []:
        res_nodes = []

        if result_item.res_element_linear and result_item.res_element_linear.res_nodes:
            res_nodes.extend(result_item.res_element_linear.res_nodes)
        if result_item.res_linear_support and result_item.res_linear_support.res_nodes:
            res_nodes.extend(result_item.res_linear_support.res_nodes)
        if result_item.res_node:
            res_nodes.append(result_item.res_node)

        for node in res_nodes:
            disp = node.res_displacements
            if disp is None:
                continue

            d_total = disp.d
            if isinstance(d_total, (int, float)):
                max_disp = max(max_disp, abs(float(d_total)))
                continue

            dx = float(disp.dx or 0.0)
            dy = float(disp.dy or 0.0)
            dz = float(disp.dz or 0.0)
            magnitude = math.sqrt(dx * dx + dy * dy + dz * dz)
            max_disp = max(max_disp, magnitude)

    return max_disp


async def close_project(client: ApiClient) -> None:
    response = await client.api.model.management.close_project.post()
    ensure_success(response, "CloseProject")


async def run() -> None:
    timeout = httpx.Timeout(TIMEOUT_MS / 1000.0)
    async with httpx.AsyncClient(timeout=timeout) as http_client:
        adapter = HttpxRequestAdapter(NoAuthenticationProvider(), http_client=http_client)
        adapter.base_url = BASE_URL
        client = ApiClient(adapter)
        project_created = False

        try:
            await create_project(client)
            project_created = True

            material_id = await create_material_steel(client)
            section_id = await create_section_ipe100(client)
            load_case_id = await create_load_case_live_loads(client)

            linear_element_ids = await create_frame_geometry(client, material_id, section_id)
            await add_top_load(client, load_case_id)

            await launch_analysis(client)
            max_displacement = await get_max_displacement(client, linear_element_ids)

            print(f"Maximum displacement: {max_displacement:.6f} m")
        finally:
            if project_created:
                await close_project(client)

def main() -> None:
    try:
        asyncio.run(run())
    except httpx.ConnectError as exc:
        print(
            f"Connection error: could not reach API at {BASE_URL}. "
            "Start the server or set KIOTA_BASE_URL to a reachable endpoint.",
            file=sys.stderr,
        )
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
