from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.boolean_api_response import BooleanApiResponse
    from .update_informational_element_post_request_body import UpdateInformationalElementPostRequestBody

class UpdateInformationalElementRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/elements/UpdateInformationalElement
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new UpdateInformationalElementRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/elements/UpdateInformationalElement{?elementId*}", path_parameters)
    
    async def post(self,body: UpdateInformationalElementPostRequestBody, request_configuration: Optional[RequestConfiguration[UpdateInformationalElementRequestBuilderPostQueryParameters]] = None) -> Optional[BooleanApiResponse]:
        """
        update an existing informational non geometric element i.e. load case, load case family, combination
        param body: Base class for informational objects : load cases, load cases families, etc. Requires the `type_class` discriminator when serialized for the API.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[BooleanApiResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.boolean_api_response import BooleanApiResponse

        return await self.request_adapter.send_async(request_info, BooleanApiResponse, None)
    
    def to_post_request_information(self,body: UpdateInformationalElementPostRequestBody, request_configuration: Optional[RequestConfiguration[UpdateInformationalElementRequestBuilderPostQueryParameters]] = None) -> RequestInformation:
        """
        update an existing informational non geometric element i.e. load case, load case family, combination
        param body: Base class for informational objects : load cases, load cases families, etc. Requires the `type_class` discriminator when serialized for the API.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> UpdateInformationalElementRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: UpdateInformationalElementRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return UpdateInformationalElementRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class UpdateInformationalElementRequestBuilderPostQueryParameters():
        """
        update an existing informational non geometric element i.e. load case, load case family, combination
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "element_id":
                return "elementId"
            return original_name
        
        # The internal ID of the informational element to update.
        element_id: Optional[int] = None

    
    @dataclass
    class UpdateInformationalElementRequestBuilderPostRequestConfiguration(RequestConfiguration[UpdateInformationalElementRequestBuilderPostQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

