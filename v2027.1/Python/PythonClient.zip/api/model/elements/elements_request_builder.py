from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .assign_design_template_to_elements.assign_design_template_to_elements_request_builder import AssignDesignTemplateToElementsRequestBuilder
    from .create_element.create_element_request_builder import CreateElementRequestBuilder
    from .create_informational_element.create_informational_element_request_builder import CreateInformationalElementRequestBuilder
    from .delete_elements.delete_elements_request_builder import DeleteElementsRequestBuilder
    from .export_additional_enums.export_additional_enums_request_builder import ExportAdditionalEnumsRequestBuilder
    from .get_elements_i_d.get_elements_i_d_request_builder import GetElementsIDRequestBuilder
    from .get_elements_object.get_elements_object_request_builder import GetElementsObjectRequestBuilder
    from .get_informational_elements_object.get_informational_elements_object_request_builder import GetInformationalElementsObjectRequestBuilder
    from .update_element.update_element_request_builder import UpdateElementRequestBuilder
    from .update_informational_element.update_informational_element_request_builder import UpdateInformationalElementRequestBuilder

class ElementsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/elements
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ElementsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/elements", path_parameters)
    
    @property
    def assign_design_template_to_elements(self) -> AssignDesignTemplateToElementsRequestBuilder:
        """
        The AssignDesignTemplateToElements property
        """
        from .assign_design_template_to_elements.assign_design_template_to_elements_request_builder import AssignDesignTemplateToElementsRequestBuilder

        return AssignDesignTemplateToElementsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def create_element(self) -> CreateElementRequestBuilder:
        """
        The CreateElement property
        """
        from .create_element.create_element_request_builder import CreateElementRequestBuilder

        return CreateElementRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def create_informational_element(self) -> CreateInformationalElementRequestBuilder:
        """
        The CreateInformationalElement property
        """
        from .create_informational_element.create_informational_element_request_builder import CreateInformationalElementRequestBuilder

        return CreateInformationalElementRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def delete_elements(self) -> DeleteElementsRequestBuilder:
        """
        The DeleteElements property
        """
        from .delete_elements.delete_elements_request_builder import DeleteElementsRequestBuilder

        return DeleteElementsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def export_additional_enums(self) -> ExportAdditionalEnumsRequestBuilder:
        """
        The ExportAdditionalEnums property
        """
        from .export_additional_enums.export_additional_enums_request_builder import ExportAdditionalEnumsRequestBuilder

        return ExportAdditionalEnumsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def get_elements_i_d(self) -> GetElementsIDRequestBuilder:
        """
        The GetElementsID property
        """
        from .get_elements_i_d.get_elements_i_d_request_builder import GetElementsIDRequestBuilder

        return GetElementsIDRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def get_elements_object(self) -> GetElementsObjectRequestBuilder:
        """
        The GetElementsObject property
        """
        from .get_elements_object.get_elements_object_request_builder import GetElementsObjectRequestBuilder

        return GetElementsObjectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def get_informational_elements_object(self) -> GetInformationalElementsObjectRequestBuilder:
        """
        The GetInformationalElementsObject property
        """
        from .get_informational_elements_object.get_informational_elements_object_request_builder import GetInformationalElementsObjectRequestBuilder

        return GetInformationalElementsObjectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def update_element(self) -> UpdateElementRequestBuilder:
        """
        The UpdateElement property
        """
        from .update_element.update_element_request_builder import UpdateElementRequestBuilder

        return UpdateElementRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def update_informational_element(self) -> UpdateInformationalElementRequestBuilder:
        """
        The UpdateInformationalElement property
        """
        from .update_informational_element.update_informational_element_request_builder import UpdateInformationalElementRequestBuilder

        return UpdateInformationalElementRequestBuilder(self.request_adapter, self.path_parameters)
    

