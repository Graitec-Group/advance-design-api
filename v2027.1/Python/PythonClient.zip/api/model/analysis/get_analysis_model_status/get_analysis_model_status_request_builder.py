from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.analysis_model_status_api_response import AnalysisModelStatusApiResponse

class GetAnalysisModelStatusRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/analysis/GetAnalysisModelStatus
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new GetAnalysisModelStatusRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/analysis/GetAnalysisModelStatus", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[AnalysisModelStatusApiResponse]:
        """
        Whether an analysis model exists, the state of the mesh, whether the finite elementanalysis was run and how many analysis cases carry results, which of the four designexperts have calculated, and how construction stages stand - plus a single`OverallState` summarizing all of it.A pure read, and a cheap one: every value is a flag or a counter the model already carries,no element of the model is visited, and nothing is created, opened or calculated. Call it asoften as you like - before `LaunchAnalysis` to see there is nothing yet, after it tocheck what was produced, after `LaunchDesignCalculation` to see which family ran.One property must not be used as a freshness gate without reading its documentation:`FemIsUpToDate` is maintained by the desktop application only, so in a headless sessionit never reports that YOUR changes invalidated the results - and `OverallState` istherefore never `OutOfDate` there.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[AnalysisModelStatusApiResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.analysis_model_status_api_response import AnalysisModelStatusApiResponse

        return await self.request_adapter.send_async(request_info, AnalysisModelStatusApiResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        Whether an analysis model exists, the state of the mesh, whether the finite elementanalysis was run and how many analysis cases carry results, which of the four designexperts have calculated, and how construction stages stand - plus a single`OverallState` summarizing all of it.A pure read, and a cheap one: every value is a flag or a counter the model already carries,no element of the model is visited, and nothing is created, opened or calculated. Call it asoften as you like - before `LaunchAnalysis` to see there is nothing yet, after it tocheck what was produced, after `LaunchDesignCalculation` to see which family ran.One property must not be used as a freshness gate without reading its documentation:`FemIsUpToDate` is maintained by the desktop application only, so in a headless sessionit never reports that YOUR changes invalidated the results - and `OverallState` istherefore never `OutOfDate` there.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        return request_info
    
    def with_url(self,raw_url: str) -> GetAnalysisModelStatusRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: GetAnalysisModelStatusRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return GetAnalysisModelStatusRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class GetAnalysisModelStatusRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

