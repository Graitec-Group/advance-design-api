from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.boolean_api_response import BooleanApiResponse

class LaunchDesignCalculationRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/analysis/LaunchDesignCalculation
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new LaunchDesignCalculationRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/analysis/LaunchDesignCalculation{?designType*}", path_parameters)
    
    async def post(self,body: list[int], request_configuration: Optional[RequestConfiguration[LaunchDesignCalculationRequestBuilderPostQueryParameters]] = None) -> Optional[BooleanApiResponse]:
        """
        Launches the Expert design calculation of one material family on the model.The FEM analysis MUST have been run before (LaunchAnalysis): the design engines verify designcriteria against the finite element results, so the call fails with an explicit diagnostic whenthe model was never calculated. The design code (EC2/EC3/EC5/EC4, AISC, CM66, BS, ACI, CSA, ...)and the kind of each element are not parameters - the design modules decide them from the codeconfigured on the model and from what each element actually is.Everything the design engine reports while it calculates is returned in the responsediagnostics, so a partially successful calculation can be diagnosed element by element.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[BooleanApiResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.boolean_api_response import BooleanApiResponse

        return await self.request_adapter.send_async(request_info, BooleanApiResponse, None)
    
    def to_post_request_information(self,body: list[int], request_configuration: Optional[RequestConfiguration[LaunchDesignCalculationRequestBuilderPostQueryParameters]] = None) -> RequestInformation:
        """
        Launches the Expert design calculation of one material family on the model.The FEM analysis MUST have been run before (LaunchAnalysis): the design engines verify designcriteria against the finite element results, so the call fails with an explicit diagnostic whenthe model was never calculated. The design code (EC2/EC3/EC5/EC4, AISC, CM66, BS, ACI, CSA, ...)and the kind of each element are not parameters - the design modules decide them from the codeconfigured on the model and from what each element actually is.Everything the design engine reports while it calculates is returned in the responsediagnostics, so a partially successful calculation can be diagnosed element by element.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        request_info.set_content_from_scalar(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> LaunchDesignCalculationRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: LaunchDesignCalculationRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return LaunchDesignCalculationRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class LaunchDesignCalculationRequestBuilderPostQueryParameters():
        """
        Launches the Expert design calculation of one material family on the model.The FEM analysis MUST have been run before (LaunchAnalysis): the design engines verify designcriteria against the finite element results, so the call fails with an explicit diagnostic whenthe model was never calculated. The design code (EC2/EC3/EC5/EC4, AISC, CM66, BS, ACI, CSA, ...)and the kind of each element are not parameters - the design modules decide them from the codeconfigured on the model and from what each element actually is.Everything the design engine reports while it calculates is returned in the responsediagnostics, so a partially successful calculation can be diagnosed element by element.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "design_type":
                return "designType"
            return original_name
        
        # The material family whose design engine is launched.
        design_type: Optional[str] = None

    
    @dataclass
    class LaunchDesignCalculationRequestBuilderPostRequestConfiguration(RequestConfiguration[LaunchDesignCalculationRequestBuilderPostQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

