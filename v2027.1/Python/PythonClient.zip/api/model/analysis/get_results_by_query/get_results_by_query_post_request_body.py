from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .....models.results_query import ResultsQuery
    from .....models.results_query_design import ResultsQueryDesign
    from .....models.results_query_design_steel_linear import ResultsQueryDesignSteelLinear
    from .....models.results_query_f_e_m import ResultsQueryFEM

@dataclass
class GetResultsByQueryPostRequestBody(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ResultsQuery, ResultsQueryDesign, ResultsQueryDesignSteelLinear, ResultsQueryFEM
    """
    # Composed type representation for type ResultsQuery
    results_query: Optional[ResultsQuery] = None
    # Composed type representation for type ResultsQueryDesign
    results_query_design: Optional[ResultsQueryDesign] = None
    # Composed type representation for type ResultsQueryDesignSteelLinear
    results_query_design_steel_linear: Optional[ResultsQueryDesignSteelLinear] = None
    # Composed type representation for type ResultsQueryFEM
    results_query_f_e_m: Optional[ResultsQueryFEM] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> GetResultsByQueryPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: GetResultsByQueryPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = GetResultsByQueryPostRequestBody()
        if mapping_value and mapping_value.casefold() == "ResultsQuery".casefold():
            from .....models.results_query import ResultsQuery

            result.results_query = ResultsQuery()
        elif mapping_value and mapping_value.casefold() == "ResultsQueryDesign".casefold():
            from .....models.results_query_design import ResultsQueryDesign

            result.results_query_design = ResultsQueryDesign()
        elif mapping_value and mapping_value.casefold() == "ResultsQueryDesignSteelLinear".casefold():
            from .....models.results_query_design_steel_linear import ResultsQueryDesignSteelLinear

            result.results_query_design_steel_linear = ResultsQueryDesignSteelLinear()
        elif mapping_value and mapping_value.casefold() == "ResultsQueryFEM".casefold():
            from .....models.results_query_f_e_m import ResultsQueryFEM

            result.results_query_f_e_m = ResultsQueryFEM()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .....models.results_query import ResultsQuery
        from .....models.results_query_design import ResultsQueryDesign
        from .....models.results_query_design_steel_linear import ResultsQueryDesignSteelLinear
        from .....models.results_query_f_e_m import ResultsQueryFEM

        if self.results_query:
            return self.results_query.get_field_deserializers()
        if self.results_query_design:
            return self.results_query_design.get_field_deserializers()
        if self.results_query_design_steel_linear:
            return self.results_query_design_steel_linear.get_field_deserializers()
        if self.results_query_f_e_m:
            return self.results_query_f_e_m.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.results_query:
            writer.write_object_value(None, self.results_query)
        elif self.results_query_design:
            writer.write_object_value(None, self.results_query_design)
        elif self.results_query_design_steel_linear:
            writer.write_object_value(None, self.results_query_design_steel_linear)
        elif self.results_query_f_e_m:
            writer.write_object_value(None, self.results_query_f_e_m)
    

