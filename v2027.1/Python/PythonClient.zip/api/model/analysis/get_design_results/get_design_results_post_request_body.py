from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .....models.results_query_design import ResultsQueryDesign
    from .....models.results_query_design_steel_linear import ResultsQueryDesignSteelLinear

@dataclass
class GetDesignResultsPostRequestBody(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ResultsQueryDesign, ResultsQueryDesignSteelLinear
    """
    # Composed type representation for type ResultsQueryDesign
    results_query_design: Optional[ResultsQueryDesign] = None
    # Composed type representation for type ResultsQueryDesignSteelLinear
    results_query_design_steel_linear: Optional[ResultsQueryDesignSteelLinear] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> GetDesignResultsPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: GetDesignResultsPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = GetDesignResultsPostRequestBody()
        if mapping_value and mapping_value.casefold() == "ResultsQueryDesign".casefold():
            from .....models.results_query_design import ResultsQueryDesign

            result.results_query_design = ResultsQueryDesign()
        elif mapping_value and mapping_value.casefold() == "ResultsQueryDesignSteelLinear".casefold():
            from .....models.results_query_design_steel_linear import ResultsQueryDesignSteelLinear

            result.results_query_design_steel_linear = ResultsQueryDesignSteelLinear()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .....models.results_query_design import ResultsQueryDesign
        from .....models.results_query_design_steel_linear import ResultsQueryDesignSteelLinear

        if self.results_query_design:
            return self.results_query_design.get_field_deserializers()
        if self.results_query_design_steel_linear:
            return self.results_query_design_steel_linear.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.results_query_design:
            writer.write_object_value(None, self.results_query_design)
        elif self.results_query_design_steel_linear:
            writer.write_object_value(None, self.results_query_design_steel_linear)
    

