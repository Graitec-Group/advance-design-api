from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.boolean_api_response import BooleanApiResponse
    from .set_model_settings_post_request_body import SetModelSettingsPostRequestBody

class SetModelSettingsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/model/SetModelSettings
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new SetModelSettingsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/model/SetModelSettings", path_parameters)
    
    async def post(self,body: SetModelSettingsPostRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[BooleanApiResponse]:
        """
        There is no category parameter: the `$type` of the body says which group iswritten and in which shape, so adding a group of settings adds no action here.Partial by design - every group and every property is optional, and what is not sentkeeps the value the model has. A property the model derives from another one cannot beimposed: such a value is ignored and reported as a warning, not refused, so that anobject just read can be handed straight back.For `CombinationsGeneration`: call it before `GenerateCombinations`, which isthe only thing that reads those settings, and send the shape matching the standard themodel generates for, which `GetModelSettings` reports.
        param body: Base class of the GENERAL SETTINGS of a model: the options that apply to the model as awhole rather than to any one object of it, and that in the AD model live on`som.ModelProperties`.These are NOT properties of an element, a load case or a combination. They are what thedesktop application edits in its option dialogs - which project situations the combinationgeneration produces, which coefficients it applies, and, as they are added, the generaloptions of the Expert design calculations. They are read, written and reset through THREEgeneric functions, whatever the group:- `GetModelSettings(category)` returns the settings of one group,- `SetModelSettings(settings)` writes them, and- `ResetModelSettings(category)` puts back what the model's standard prescribes.THE OBJECT DECIDES WHAT IS WRITTEN. `SetModelSettings` takes this base class, so it isthe runtime type of the object - its `$type` - that says which group of model settingsthe call writes, exactly as `CreateInformationalElement` takesAD.API.InformationalElementBase and the object decides what is created. There is nofunction per group of settings, and adding a group adds no function.TWO LEVELS OF DERIVATION. Under this base, one class per group of settings(AD.API.CombinationsGenerationSettings, AD.API.SteelCalculationSettings andAD.API.AiscSteelCalculationSettings today) - and under that class, as many classes asthe group has shapes. The combination generation has five, one per combination standard,because the standards share no field; each of the two steel groups has one, because thecodes inside a family share every page of the dialog. So the class hierarchy reads: whatsettings (level 2), in which variant (level 3).TWO STEEL GROUPS, NOT ONE GROUP WITH TWO SHAPES. The Eurocode and the North-Americanfamilies do not answer the same question - the second has no Partial safety factors page atall and a Verification page of three controls instead of thirteen - so they are separatecategories with separate group classes. The five pages they do share are the same DTOclasses, held by both group classes.PARTIAL BY DESIGN. In every group, the properties are optional and what a request does notcarry keeps the value the model has, so a single switch can be changed without restatingthe rest. What each group refuses, what it recomputes rather than stores, and what itreports as a warning instead of an error is documented on that group's own class.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[BooleanApiResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.boolean_api_response import BooleanApiResponse

        return await self.request_adapter.send_async(request_info, BooleanApiResponse, None)
    
    def to_post_request_information(self,body: SetModelSettingsPostRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        There is no category parameter: the `$type` of the body says which group iswritten and in which shape, so adding a group of settings adds no action here.Partial by design - every group and every property is optional, and what is not sentkeeps the value the model has. A property the model derives from another one cannot beimposed: such a value is ignored and reported as a warning, not refused, so that anobject just read can be handed straight back.For `CombinationsGeneration`: call it before `GenerateCombinations`, which isthe only thing that reads those settings, and send the shape matching the standard themodel generates for, which `GetModelSettings` reports.
        param body: Base class of the GENERAL SETTINGS of a model: the options that apply to the model as awhole rather than to any one object of it, and that in the AD model live on`som.ModelProperties`.These are NOT properties of an element, a load case or a combination. They are what thedesktop application edits in its option dialogs - which project situations the combinationgeneration produces, which coefficients it applies, and, as they are added, the generaloptions of the Expert design calculations. They are read, written and reset through THREEgeneric functions, whatever the group:- `GetModelSettings(category)` returns the settings of one group,- `SetModelSettings(settings)` writes them, and- `ResetModelSettings(category)` puts back what the model's standard prescribes.THE OBJECT DECIDES WHAT IS WRITTEN. `SetModelSettings` takes this base class, so it isthe runtime type of the object - its `$type` - that says which group of model settingsthe call writes, exactly as `CreateInformationalElement` takesAD.API.InformationalElementBase and the object decides what is created. There is nofunction per group of settings, and adding a group adds no function.TWO LEVELS OF DERIVATION. Under this base, one class per group of settings(AD.API.CombinationsGenerationSettings, AD.API.SteelCalculationSettings andAD.API.AiscSteelCalculationSettings today) - and under that class, as many classes asthe group has shapes. The combination generation has five, one per combination standard,because the standards share no field; each of the two steel groups has one, because thecodes inside a family share every page of the dialog. So the class hierarchy reads: whatsettings (level 2), in which variant (level 3).TWO STEEL GROUPS, NOT ONE GROUP WITH TWO SHAPES. The Eurocode and the North-Americanfamilies do not answer the same question - the second has no Partial safety factors page atall and a Verification page of three controls instead of thirteen - so they are separatecategories with separate group classes. The five pages they do share are the same DTOclasses, held by both group classes.PARTIAL BY DESIGN. In every group, the properties are optional and what a request does notcarry keeps the value the model has, so a single switch can be changed without restatingthe rest. What each group refuses, what it recomputes rather than stores, and what itreports as a warning instead of an error is documented on that group's own class.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> SetModelSettingsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: SetModelSettingsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return SetModelSettingsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class SetModelSettingsRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

