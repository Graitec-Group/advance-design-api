from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.model_settings_base_api_response import ModelSettingsBaseApiResponse

class GetModelSettingsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/model/GetModelSettings
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new GetModelSettingsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/model/GetModelSettings{?category*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[GetModelSettingsRequestBuilderGetQueryParameters]] = None) -> Optional[ModelSettingsBaseApiResponse]:
        """
        The options that apply to the model as a whole rather than to any one of its objects -what the option dialogs of the desktop application edit, stored on the model itself.The `category` says WHICH settings; the `$type` of the returned object sayswhich SHAPE they have, because a group can have several.For `CombinationsGeneration` the shape follows the combination standard the modelgenerates for, and that standard comes from the session localization - so it is notsomething this call or its counterpart chooses.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[ModelSettingsBaseApiResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.model_settings_base_api_response import ModelSettingsBaseApiResponse

        return await self.request_adapter.send_async(request_info, ModelSettingsBaseApiResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[GetModelSettingsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        The options that apply to the model as a whole rather than to any one of its objects -what the option dialogs of the desktop application edit, stored on the model itself.The `category` says WHICH settings; the `$type` of the returned object sayswhich SHAPE they have, because a group can have several.For `CombinationsGeneration` the shape follows the combination standard the modelgenerates for, and that standard comes from the session localization - so it is notsomething this call or its counterpart chooses.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        return request_info
    
    def with_url(self,raw_url: str) -> GetModelSettingsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: GetModelSettingsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return GetModelSettingsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class GetModelSettingsRequestBuilderGetQueryParameters():
        """
        The options that apply to the model as a whole rather than to any one of its objects -what the option dialogs of the desktop application edit, stored on the model itself.The `category` says WHICH settings; the `$type` of the returned object sayswhich SHAPE they have, because a group can have several.For `CombinationsGeneration` the shape follows the combination standard the modelgenerates for, and that standard comes from the session localization - so it is notsomething this call or its counterpart chooses.
        """
        # Which group of settings to read.
        category: Optional[str] = None

    
    @dataclass
    class GetModelSettingsRequestBuilderGetRequestConfiguration(RequestConfiguration[GetModelSettingsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

