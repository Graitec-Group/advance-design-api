from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .get_model_settings.get_model_settings_request_builder import GetModelSettingsRequestBuilder
    from .reset_model_settings.reset_model_settings_request_builder import ResetModelSettingsRequestBuilder
    from .set_model_settings.set_model_settings_request_builder import SetModelSettingsRequestBuilder

class ModelRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/model
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ModelRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/model", path_parameters)
    
    @property
    def get_model_settings(self) -> GetModelSettingsRequestBuilder:
        """
        The GetModelSettings property
        """
        from .get_model_settings.get_model_settings_request_builder import GetModelSettingsRequestBuilder

        return GetModelSettingsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def reset_model_settings(self) -> ResetModelSettingsRequestBuilder:
        """
        The ResetModelSettings property
        """
        from .reset_model_settings.reset_model_settings_request_builder import ResetModelSettingsRequestBuilder

        return ResetModelSettingsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def set_model_settings(self) -> SetModelSettingsRequestBuilder:
        """
        The SetModelSettings property
        """
        from .set_model_settings.set_model_settings_request_builder import SetModelSettingsRequestBuilder

        return SetModelSettingsRequestBuilder(self.request_adapter, self.path_parameters)
    

