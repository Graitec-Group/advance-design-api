from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.combinations_generation_request import CombinationsGenerationRequest
    from .....models.combinations_generation_result_api_response import CombinationsGenerationResultApiResponse

class GenerateCombinationsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/combinations/GenerateCombinations
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new GenerateCombinationsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/combinations/GenerateCombinations", path_parameters)
    
    async def post(self,body: CombinationsGenerationRequest, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[CombinationsGenerationResultApiResponse]:
        """
        Runs the same generation the Combinations dialog of the desktop application runs.Everything is read from the model: the coefficients on each load case and thegenerator options in the model settings, including which combination standardapplies. Generation is additive - existing combinations are kept.
        param body: Input of the automatic combination generation.Everything the generation needs is read from the model: the per-load-casecoefficients (gamma EQU, gamma STR/GEO, psi0/psi1/psi2, duration, category, ...) liveon the load cases themselves and can be set throughAD.API.LoadCaseCombinationsCoefficients, while the generator options - whichproject situations are generated, the per-family coefficient tables, the equationoption - live on the model settings. This request therefore only says WHICHwork-flow to run, not how the standard is parameterized.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[CombinationsGenerationResultApiResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.combinations_generation_result_api_response import CombinationsGenerationResultApiResponse

        return await self.request_adapter.send_async(request_info, CombinationsGenerationResultApiResponse, None)
    
    def to_post_request_information(self,body: CombinationsGenerationRequest, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        Runs the same generation the Combinations dialog of the desktop application runs.Everything is read from the model: the coefficients on each load case and thegenerator options in the model settings, including which combination standardapplies. Generation is additive - existing combinations are kept.
        param body: Input of the automatic combination generation.Everything the generation needs is read from the model: the per-load-casecoefficients (gamma EQU, gamma STR/GEO, psi0/psi1/psi2, duration, category, ...) liveon the load cases themselves and can be set throughAD.API.LoadCaseCombinationsCoefficients, while the generator options - whichproject situations are generated, the per-family coefficient tables, the equationoption - live on the model settings. This request therefore only says WHICHwork-flow to run, not how the standard is parameterized.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> GenerateCombinationsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: GenerateCombinationsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return GenerateCombinationsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class GenerateCombinationsRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

