from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.boolean_api_response import BooleanApiResponse

class CloseSessionRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/management/CloseSession
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new CloseSessionRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/management/CloseSession", path_parameters)
    
    async def post(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[BooleanApiResponse]:
        """
        Use this endpoint when multiple automation sessions run in parallel and you want to releasethe resources associated with the current one.The call returns at once; the shutdown follows in the background, about 5 seconds later. Theserver then waits for an operation or analysis that is already running (or queued) to finish,saves and closes the open project - there is no need to call `CloseProject` first -releases the licence, and the process exits. How long that takes depends on the operation stillrunning and on the size of the project. To close the open project without saving it, call`CloseSessionWithoutSave` instead.From this call on, every other `api/Model` request is refused at once with HTTP 503 and theerror code `SERVICE_STOPPING`, and `GET api/Service/GetStatus` answers `Stopping`until the process has exited. Calling `CloseSession` again is harmless: the first close requested decides howthe project is closed, and the `SESSION_CLOSING` message of a later call says it joined that close andwhat it does.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[BooleanApiResponse]
        """
        request_info = self.to_post_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.boolean_api_response import BooleanApiResponse

        return await self.request_adapter.send_async(request_info, BooleanApiResponse, None)
    
    def to_post_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        Use this endpoint when multiple automation sessions run in parallel and you want to releasethe resources associated with the current one.The call returns at once; the shutdown follows in the background, about 5 seconds later. Theserver then waits for an operation or analysis that is already running (or queued) to finish,saves and closes the open project - there is no need to call `CloseProject` first -releases the licence, and the process exits. How long that takes depends on the operation stillrunning and on the size of the project. To close the open project without saving it, call`CloseSessionWithoutSave` instead.From this call on, every other `api/Model` request is refused at once with HTTP 503 and theerror code `SERVICE_STOPPING`, and `GET api/Service/GetStatus` answers `Stopping`until the process has exited. Calling `CloseSession` again is harmless: the first close requested decides howthe project is closed, and the `SESSION_CLOSING` message of a later call says it joined that close andwhat it does.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        return request_info
    
    def with_url(self,raw_url: str) -> CloseSessionRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: CloseSessionRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return CloseSessionRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class CloseSessionRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

