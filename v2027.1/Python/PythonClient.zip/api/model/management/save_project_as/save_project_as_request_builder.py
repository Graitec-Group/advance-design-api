from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.boolean_api_response import BooleanApiResponse

class SaveProjectAsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/management/SaveProjectAs
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new SaveProjectAsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/management/SaveProjectAs{?filename*}", path_parameters)
    
    async def post(self,request_configuration: Optional[RequestConfiguration[SaveProjectAsRequestBuilderPostQueryParameters]] = None) -> Optional[BooleanApiResponse]:
        """
        The same Save As as Advance Design's (File > Save As): the model and the analysis model, the results, and thedocuments, design and selected templates folders of the project are written to the new project, so that itopens in Advance Design in the same state. The file opened before is left as it was at its last save. From thiscall on the session works on the new file: `SaveProject` and `CloseProject` write to it.As in Advance Design, the spaces around the name and before the extension are dropped, a name holding theextension twice is refused, and the path must stay 28 characters shorter than the Windows path limit (260).Refused, before anything is written: `PROJECT_NOT_OPEN` when no project is open,`PROJECT_INVALID_FILENAME` / `PROJECT_INVALID_EXTENSION` as for `NewProject` (and for the extensiontwice),`PROJECT_FOLDER_NOT_FOUND` when the folder that is to contain the file does not exist (it is not created),`PROJECT_TARGET_EXISTS` when the file or its project folder (the file's path without `.fto`) alreadyexists - saving there would first empty it -, and `PROJECT_TARGET_INVALID` when the new project folder andthe open project's folder would lie one inside the other.`Data` is true and the diagnostics carry `PROJECT_SAVED_AS` (information) when the project was saved tothe new file. Otherwise `Data` is false with `PROJECT_SAVE_AS_FAILED` (or `PROJECT_SAVE_AS_EXCEPTION`for an internal error), whose message says which project the session is on:<list type="bullet"><item>"The session's project is still ..." - nothing was written. It is so for the refusals the engine side makesbefore writing: a path longer than the limit above, a folder that cannot be written to. The open project isunchanged and can still be saved and closed as usual.</item><item>"The session's project is now ..." - the engine had begun: the session is on the new, possibly partial,copy. Do NOT save it (no `SaveProject`, no `CloseProject`): close it with `CloseProjectWithoutSave`,check both folders, and open the original again.</item></list>
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[BooleanApiResponse]
        """
        request_info = self.to_post_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.boolean_api_response import BooleanApiResponse

        return await self.request_adapter.send_async(request_info, BooleanApiResponse, None)
    
    def to_post_request_information(self,request_configuration: Optional[RequestConfiguration[SaveProjectAsRequestBuilderPostQueryParameters]] = None) -> RequestInformation:
        """
        The same Save As as Advance Design's (File > Save As): the model and the analysis model, the results, and thedocuments, design and selected templates folders of the project are written to the new project, so that itopens in Advance Design in the same state. The file opened before is left as it was at its last save. From thiscall on the session works on the new file: `SaveProject` and `CloseProject` write to it.As in Advance Design, the spaces around the name and before the extension are dropped, a name holding theextension twice is refused, and the path must stay 28 characters shorter than the Windows path limit (260).Refused, before anything is written: `PROJECT_NOT_OPEN` when no project is open,`PROJECT_INVALID_FILENAME` / `PROJECT_INVALID_EXTENSION` as for `NewProject` (and for the extensiontwice),`PROJECT_FOLDER_NOT_FOUND` when the folder that is to contain the file does not exist (it is not created),`PROJECT_TARGET_EXISTS` when the file or its project folder (the file's path without `.fto`) alreadyexists - saving there would first empty it -, and `PROJECT_TARGET_INVALID` when the new project folder andthe open project's folder would lie one inside the other.`Data` is true and the diagnostics carry `PROJECT_SAVED_AS` (information) when the project was saved tothe new file. Otherwise `Data` is false with `PROJECT_SAVE_AS_FAILED` (or `PROJECT_SAVE_AS_EXCEPTION`for an internal error), whose message says which project the session is on:<list type="bullet"><item>"The session's project is still ..." - nothing was written. It is so for the refusals the engine side makesbefore writing: a path longer than the limit above, a folder that cannot be written to. The open project isunchanged and can still be saved and closed as usual.</item><item>"The session's project is now ..." - the engine had begun: the session is on the new, possibly partial,copy. Do NOT save it (no `SaveProject`, no `CloseProject`): close it with `CloseProjectWithoutSave`,check both folders, and open the original again.</item></list>
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        return request_info
    
    def with_url(self,raw_url: str) -> SaveProjectAsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: SaveProjectAsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return SaveProjectAsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class SaveProjectAsRequestBuilderPostQueryParameters():
        """
        The same Save As as Advance Design's (File > Save As): the model and the analysis model, the results, and thedocuments, design and selected templates folders of the project are written to the new project, so that itopens in Advance Design in the same state. The file opened before is left as it was at its last save. From thiscall on the session works on the new file: `SaveProject` and `CloseProject` write to it.As in Advance Design, the spaces around the name and before the extension are dropped, a name holding theextension twice is refused, and the path must stay 28 characters shorter than the Windows path limit (260).Refused, before anything is written: `PROJECT_NOT_OPEN` when no project is open,`PROJECT_INVALID_FILENAME` / `PROJECT_INVALID_EXTENSION` as for `NewProject` (and for the extensiontwice),`PROJECT_FOLDER_NOT_FOUND` when the folder that is to contain the file does not exist (it is not created),`PROJECT_TARGET_EXISTS` when the file or its project folder (the file's path without `.fto`) alreadyexists - saving there would first empty it -, and `PROJECT_TARGET_INVALID` when the new project folder andthe open project's folder would lie one inside the other.`Data` is true and the diagnostics carry `PROJECT_SAVED_AS` (information) when the project was saved tothe new file. Otherwise `Data` is false with `PROJECT_SAVE_AS_FAILED` (or `PROJECT_SAVE_AS_EXCEPTION`for an internal error), whose message says which project the session is on:<list type="bullet"><item>"The session's project is still ..." - nothing was written. It is so for the refusals the engine side makesbefore writing: a path longer than the limit above, a folder that cannot be written to. The open project isunchanged and can still be saved and closed as usual.</item><item>"The session's project is now ..." - the engine had begun: the session is on the new, possibly partial,copy. Do NOT save it (no `SaveProject`, no `CloseProject`): close it with `CloseProjectWithoutSave`,check both folders, and open the original again.</item></list>
        """
        # The name of the new project file, with the extension .fto. A relative name is resolved            against the working directory of the server (the /w startup option, else the folder the server was started from);            an absolute path is used as given. The folder that is to contain the file must already exist.
        filename: Optional[str] = None

    
    @dataclass
    class SaveProjectAsRequestBuilderPostRequestConfiguration(RequestConfiguration[SaveProjectAsRequestBuilderPostQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

