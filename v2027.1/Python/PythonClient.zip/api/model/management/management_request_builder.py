from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .close_project.close_project_request_builder import CloseProjectRequestBuilder
    from .close_project_without_save.close_project_without_save_request_builder import CloseProjectWithoutSaveRequestBuilder
    from .close_session.close_session_request_builder import CloseSessionRequestBuilder
    from .close_session_without_save.close_session_without_save_request_builder import CloseSessionWithoutSaveRequestBuilder
    from .get_environment.get_environment_request_builder import GetEnvironmentRequestBuilder
    from .new_project.new_project_request_builder import NewProjectRequestBuilder
    from .open_project.open_project_request_builder import OpenProjectRequestBuilder
    from .save_project.save_project_request_builder import SaveProjectRequestBuilder
    from .save_project_as.save_project_as_request_builder import SaveProjectAsRequestBuilder

class ManagementRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/management
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ManagementRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/management", path_parameters)
    
    @property
    def close_project(self) -> CloseProjectRequestBuilder:
        """
        The CloseProject property
        """
        from .close_project.close_project_request_builder import CloseProjectRequestBuilder

        return CloseProjectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def close_project_without_save(self) -> CloseProjectWithoutSaveRequestBuilder:
        """
        The CloseProjectWithoutSave property
        """
        from .close_project_without_save.close_project_without_save_request_builder import CloseProjectWithoutSaveRequestBuilder

        return CloseProjectWithoutSaveRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def close_session(self) -> CloseSessionRequestBuilder:
        """
        The CloseSession property
        """
        from .close_session.close_session_request_builder import CloseSessionRequestBuilder

        return CloseSessionRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def close_session_without_save(self) -> CloseSessionWithoutSaveRequestBuilder:
        """
        The CloseSessionWithoutSave property
        """
        from .close_session_without_save.close_session_without_save_request_builder import CloseSessionWithoutSaveRequestBuilder

        return CloseSessionWithoutSaveRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def get_environment(self) -> GetEnvironmentRequestBuilder:
        """
        The GetEnvironment property
        """
        from .get_environment.get_environment_request_builder import GetEnvironmentRequestBuilder

        return GetEnvironmentRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def new_project(self) -> NewProjectRequestBuilder:
        """
        The NewProject property
        """
        from .new_project.new_project_request_builder import NewProjectRequestBuilder

        return NewProjectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def open_project(self) -> OpenProjectRequestBuilder:
        """
        The OpenProject property
        """
        from .open_project.open_project_request_builder import OpenProjectRequestBuilder

        return OpenProjectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def save_project(self) -> SaveProjectRequestBuilder:
        """
        The SaveProject property
        """
        from .save_project.save_project_request_builder import SaveProjectRequestBuilder

        return SaveProjectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def save_project_as(self) -> SaveProjectAsRequestBuilder:
        """
        The SaveProjectAs property
        """
        from .save_project_as.save_project_as_request_builder import SaveProjectAsRequestBuilder

        return SaveProjectAsRequestBuilder(self.request_adapter, self.path_parameters)
    

