from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.environments_api_response import EnvironmentsApiResponse

class GetEnvironmentRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/management/GetEnvironment
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new GetEnvironmentRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/management/GetEnvironment", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[EnvironmentsApiResponse]:
        """
        Every design standard and annex comes back set, whether it was named in the`NewProject` / `OpenProject` request or resolved from the localization - this iswhat the session HOLDS, not an echo of what was asked for. Use it to find out what alocalization resolves to, and to confirm what an override actually changed.FAILS when no project is open, with `ENVIRONMENT_NO_SESSION`. The environment is aproperty of the session and the session lasts exactly as long as the project, so outside onethere is nothing to report - and reading the engine's defaults anyway would both describethe machine rather than this server and write those defaults into the per-user registry.A standard the session carries but this API does not publish - a 2nd generation Eurocode,CM66, BS 8110, all of which the desktop application can configure - comes back as`null` for that one property, with a warning naming the property and the raw number.It is not reported as a number: the generated clients renumber their copy of eachenumeration, so a number would be read back as a DIFFERENT standard.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[EnvironmentsApiResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.environments_api_response import EnvironmentsApiResponse

        return await self.request_adapter.send_async(request_info, EnvironmentsApiResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        Every design standard and annex comes back set, whether it was named in the`NewProject` / `OpenProject` request or resolved from the localization - this iswhat the session HOLDS, not an echo of what was asked for. Use it to find out what alocalization resolves to, and to confirm what an override actually changed.FAILS when no project is open, with `ENVIRONMENT_NO_SESSION`. The environment is aproperty of the session and the session lasts exactly as long as the project, so outside onethere is nothing to report - and reading the engine's defaults anyway would both describethe machine rather than this server and write those defaults into the per-user registry.A standard the session carries but this API does not publish - a 2nd generation Eurocode,CM66, BS 8110, all of which the desktop application can configure - comes back as`null` for that one property, with a warning naming the property and the raw number.It is not reported as a number: the generated clients renumber their copy of eachenumeration, so a number would be read back as a DIFFERENT standard.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        return request_info
    
    def with_url(self,raw_url: str) -> GetEnvironmentRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: GetEnvironmentRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return GetEnvironmentRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class GetEnvironmentRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

