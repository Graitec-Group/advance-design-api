from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.boolean_api_response import BooleanApiResponse
    from .....models.environments import Environments

class OpenProjectRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/management/OpenProject
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new OpenProjectRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/management/OpenProject{?filename*}", path_parameters)
    
    async def post(self,body: Environments, request_configuration: Optional[RequestConfiguration[OpenProjectRequestBuilderPostQueryParameters]] = None) -> Optional[BooleanApiResponse]:
        """
        Opens an existing project with the specified filename and environment.
        param body: Environment settings - the language, the localization, the diagnostics verbosity and thedesign standards a session runs under.IT CONFIGURES THE SESSION, AND A SESSION IS CONFIGURED ONCE. The environment takes effect onthe `NewProject` / `OpenProject` call that opens the session and lasts as long asthat project. A call sent while a project is still open is REFUSED - the whole call, notjust the environment: the localization and design standards were read while that model wasbuilt and are read again by the generation and by the design Experts, so running a secondproject on them would calculate it under standards it was never described with. Close theproject first; the next one takes a new environment.THE LANGUAGE IS NARROWER STILL - fixed for the life of the SERVER PROCESS. The firstenvironment settles it, and the two ways of changing it afterwards are treated differently:* an EXPLICIT AD.API.Environments.Language that disagrees with the one in force is REFUSED, and  the caller is told to restart the server;* a language merely IMPLIED by AD.API.Environments.Localization is HELD BACK with a warning, and  the rest of that localization - its eight design standards, which is what it is really  being asked for - is applied normally. Refusing here instead would tie a whole server to  one localization family, since sixteen of the eighteen localizations imply a language  other than English.The restriction is what the desktop application achieves by restarting itself: reloading theprompt database is not enough, because the catalogues, units and resources already loadedkeep the language they were read in.WHAT IT WRITES. Everything this environment configures lives in the server's memory for thelife of the session; no design standard, annex, localization or language chosen here iswritten back to the machine's Advance Design configuration. One thing is not in thatpromise, and it is not this API's doing: OPENING the in-memory session seeds it by readingthe per-user registry, and Advance Design's own accessors write a default back when theyfind a value missing. So on a machine where Advance Design has never run, the first requestmaterialises the default keys - with the values the read already resolved to, never withanything this request named.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[BooleanApiResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.boolean_api_response import BooleanApiResponse

        return await self.request_adapter.send_async(request_info, BooleanApiResponse, None)
    
    def to_post_request_information(self,body: Environments, request_configuration: Optional[RequestConfiguration[OpenProjectRequestBuilderPostQueryParameters]] = None) -> RequestInformation:
        """
        Opens an existing project with the specified filename and environment.
        param body: Environment settings - the language, the localization, the diagnostics verbosity and thedesign standards a session runs under.IT CONFIGURES THE SESSION, AND A SESSION IS CONFIGURED ONCE. The environment takes effect onthe `NewProject` / `OpenProject` call that opens the session and lasts as long asthat project. A call sent while a project is still open is REFUSED - the whole call, notjust the environment: the localization and design standards were read while that model wasbuilt and are read again by the generation and by the design Experts, so running a secondproject on them would calculate it under standards it was never described with. Close theproject first; the next one takes a new environment.THE LANGUAGE IS NARROWER STILL - fixed for the life of the SERVER PROCESS. The firstenvironment settles it, and the two ways of changing it afterwards are treated differently:* an EXPLICIT AD.API.Environments.Language that disagrees with the one in force is REFUSED, and  the caller is told to restart the server;* a language merely IMPLIED by AD.API.Environments.Localization is HELD BACK with a warning, and  the rest of that localization - its eight design standards, which is what it is really  being asked for - is applied normally. Refusing here instead would tie a whole server to  one localization family, since sixteen of the eighteen localizations imply a language  other than English.The restriction is what the desktop application achieves by restarting itself: reloading theprompt database is not enough, because the catalogues, units and resources already loadedkeep the language they were read in.WHAT IT WRITES. Everything this environment configures lives in the server's memory for thelife of the session; no design standard, annex, localization or language chosen here iswritten back to the machine's Advance Design configuration. One thing is not in thatpromise, and it is not this API's doing: OPENING the in-memory session seeds it by readingthe per-user registry, and Advance Design's own accessors write a default back when theyfind a value missing. So on a machine where Advance Design has never run, the first requestmaterialises the default keys - with the values the read already resolved to, never withanything this request named.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> OpenProjectRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: OpenProjectRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return OpenProjectRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class OpenProjectRequestBuilderPostQueryParameters():
        """
        Opens an existing project with the specified filename and environment.
        """
        # The path to the project file to open. Must have the .fto extension. A            relative path is resolved against the working directory of the server (the /w startup option,            else the folder the server was started from); an absolute path is used as given.
        filename: Optional[str] = None

    
    @dataclass
    class OpenProjectRequestBuilderPostRequestConfiguration(RequestConfiguration[OpenProjectRequestBuilderPostQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

