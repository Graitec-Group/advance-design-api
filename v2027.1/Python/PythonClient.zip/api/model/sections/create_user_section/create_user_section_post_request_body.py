from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .....models.section import Section
    from .....models.user_section import UserSection

@dataclass
class CreateUserSectionPostRequestBody(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes Section, UserSection
    """
    # Composed type representation for type Section
    section: Optional[Section] = None
    # Composed type representation for type UserSection
    user_section: Optional[UserSection] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateUserSectionPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateUserSectionPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = CreateUserSectionPostRequestBody()
        if mapping_value and mapping_value.casefold() == "Section".casefold():
            from .....models.section import Section

            result.section = Section()
        elif mapping_value and mapping_value.casefold() == "UserSection".casefold():
            from .....models.user_section import UserSection

            result.user_section = UserSection()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .....models.section import Section
        from .....models.user_section import UserSection

        if self.section:
            return self.section.get_field_deserializers()
        if self.user_section:
            return self.user_section.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.section:
            writer.write_object_value(None, self.section)
        elif self.user_section:
            writer.write_object_value(None, self.user_section)
    

