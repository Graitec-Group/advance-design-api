from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .get_status.get_status_request_builder import GetStatusRequestBuilder
    from .get_version.get_version_request_builder import GetVersionRequestBuilder

class ServiceRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Service
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ServiceRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Service", path_parameters)
    
    @property
    def get_status(self) -> GetStatusRequestBuilder:
        """
        The GetStatus property
        """
        from .get_status.get_status_request_builder import GetStatusRequestBuilder

        return GetStatusRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def get_version(self) -> GetVersionRequestBuilder:
        """
        The GetVersion property
        """
        from .get_version.get_version_request_builder import GetVersionRequestBuilder

        return GetVersionRequestBuilder(self.request_adapter, self.path_parameters)
    

