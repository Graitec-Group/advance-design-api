from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_combinations_action_family import ECombinationsActionFamily

@dataclass
class Eurocode2ndGenVariableActionRow(Parsable):
    """
    One variable action row of the 2nd generation settings, identified by its family.
    """
    # The category within the family, as the raw index the model stores. It is an indexand not an enumeration because the list differs per family: exploitation has 21entries (A, B, C, D, E, F, G1, G2, H, I1, I2, I3, K, S1..S4, T, then two userdefined ones), snow has 5, and the others have their own. Naming them with oneenumeration would mean the same name standing for different actions.
    category: Optional[int] = None
    # Which variable family this row is - exploitation, snow, wind, temperature,construction actions, icing, water actions, or waves and currents.REQUIRED, and nullable so that leaving it out is an error rather than a silentchoice: it is what identifies the row, and a default would quietly point everyunnamed row at the same family.
    family: Optional[ECombinationsActionFamily] = None
    # gamma for VC1.
    gamma_v_c1: Optional[float] = None
    # gamma for VC2a.
    gamma_v_c2a: Optional[float] = None
    # gamma for VC2b.
    gamma_v_c2b: Optional[float] = None
    # gamma for VC3.
    gamma_v_c3: Optional[float] = None
    # gamma for VC4.
    gamma_v_c4: Optional[float] = None
    # Generate combinations in which this family is the leading variable action.
    generate_as_leading_action: Optional[bool] = None
    # psi0 - combination value.
    psi0: Optional[float] = None
    # psi1 - frequent value.
    psi1: Optional[float] = None
    # psi2 - quasi-permanent value.
    psi2: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Eurocode2ndGenVariableActionRow:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Eurocode2ndGenVariableActionRow
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Eurocode2ndGenVariableActionRow()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_combinations_action_family import ECombinationsActionFamily

        from .e_combinations_action_family import ECombinationsActionFamily

        fields: dict[str, Callable[[Any], None]] = {
            "category": lambda n : setattr(self, 'category', n.get_int_value()),
            "family": lambda n : setattr(self, 'family', n.get_enum_value(ECombinationsActionFamily)),
            "gammaVC1": lambda n : setattr(self, 'gamma_v_c1', n.get_float_value()),
            "gammaVC2a": lambda n : setattr(self, 'gamma_v_c2a', n.get_float_value()),
            "gammaVC2b": lambda n : setattr(self, 'gamma_v_c2b', n.get_float_value()),
            "gammaVC3": lambda n : setattr(self, 'gamma_v_c3', n.get_float_value()),
            "gammaVC4": lambda n : setattr(self, 'gamma_v_c4', n.get_float_value()),
            "generateAsLeadingAction": lambda n : setattr(self, 'generate_as_leading_action', n.get_bool_value()),
            "psi0": lambda n : setattr(self, 'psi0', n.get_float_value()),
            "psi1": lambda n : setattr(self, 'psi1', n.get_float_value()),
            "psi2": lambda n : setattr(self, 'psi2', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("category", self.category)
        writer.write_enum_value("family", self.family)
        writer.write_float_value("gammaVC1", self.gamma_v_c1)
        writer.write_float_value("gammaVC2a", self.gamma_v_c2a)
        writer.write_float_value("gammaVC2b", self.gamma_v_c2b)
        writer.write_float_value("gammaVC3", self.gamma_v_c3)
        writer.write_float_value("gammaVC4", self.gamma_v_c4)
        writer.write_bool_value("generateAsLeadingAction", self.generate_as_leading_action)
        writer.write_float_value("psi0", self.psi0)
        writer.write_float_value("psi1", self.psi1)
        writer.write_float_value("psi2", self.psi2)
    

