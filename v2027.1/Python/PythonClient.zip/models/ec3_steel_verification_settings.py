from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .ec3_g2_verification_options import Ec3G2VerificationOptions
    from .e_steel_buckling_length_option import ESteelBucklingLengthOption
    from .e_steel_calculation_type import ESteelCalculationType
    from .e_steel_imperfection_generation import ESteelImperfectionGeneration
    from .e_steel_plate_buckling_method import ESteelPlateBucklingMethod

@dataclass
class Ec3SteelVerificationSettings(Parsable):
    """
    The Verification page: which checks the engine performs, and the imperfection and 2nd orderoptions that go with them.Every property is optional so that a `SetModelSettings` request can change one switchwithout restating the rest; what is not sent keeps the value the model has.
    """
    # Where the buckling length of the beams comes from. `imposed` ("buckling length = element properties") by default.A NARROWER CONDITION than the columns one: the dialog enables the beams group onAD.API.Ec3SteelVerificationSettings.LocalBowImperfections alone, so the global sway and crown imperfections donot unlock it. Sent with the local bow off, it is stored and reported.
    beams_buckling_length: Optional[ESteelBucklingLengthOption] = None
    # Which internal forces the verification combines. Oblique bending by default.
    calculation_type: Optional[ESteelCalculationType] = None
    # Where the buckling length of the columns comes from. `imposed` ("buckling length = element properties") by default.Read only while ANY of the three imperfections is enabled -AD.API.Ec3SteelVerificationSettings.GlobalSwayImperfections, AD.API.Ec3SteelVerificationSettings.LocalBowImperfections orAD.API.Ec3SteelVerificationSettings.CrownImperfections. Sent with all three off, it is stored and reported.
    columns_buckling_length: Optional[ESteelBucklingLengthOption] = None
    # Verify the strength of the cross-sections. On by default.
    cross_section_strength: Optional[bool] = None
    # Account for the crown imperfection of EN 13031-1. Offered only by installationsconfigured for greenhouses; stored otherwise, but nothing reads it.
    crown_imperfections: Optional[bool] = None
    # Verify the stability of the elements. On by default.
    element_stability: Optional[bool] = None
    # Fire resistance duration, IN SECONDS. The desktop dialog shows it in minutes; this isthe stored SI value, so 30 minutes is 1800. 0 by default.Read only while AD.API.Ec3SteelVerificationSettings.FireVerification is on - the dialog greys the field outotherwise - so a duration sent with the check off is stored and reported as a warning.
    fire_resistance_time: Optional[float] = None
    # Perform the fire verification. Off by default.
    fire_verification: Optional[bool] = None
    # Account for global sway imperfections. Off by default.
    global_sway_imperfections: Optional[bool] = None
    # Which combinations the imperfections are generated for.`eImperfectionGenerationForGoverningComb` by default on a Eurocode model.Read only while any of the three imperfections is enabled, likeAD.API.Ec3SteelVerificationSettings.ColumnsBucklingLength. `eImperfectionGenerationUndefined` cannot be chosen: it means "nooption selected", which only a model created under a steel code that has noimperfection generation carries.
    imperfection_generation: Optional[ESteelImperfectionGeneration] = None
    # Account for local bow imperfections. Off by default.
    local_bow_imperfections: Optional[bool] = None
    # How a slender web is verified. `eMethodWebBucklingEffectiveCrossSections` by default on a Eurocode model.`eMethodWebBucklingReducedStresses` is accepted everywhere but reported as a warning under the Czechand Slovak national annexes, whose EN 1993-1-5 recommendations restrict it - the samemessage the dialog shows. `eMethodWebBucklingUndefined` cannot be chosen, for the reasonAD.API.Ec3SteelVerificationSettings.ImperfectionGeneration gives.
    plate_buckling_method: Optional[ESteelPlateBucklingMethod] = None
    # The 2nd generation additions to this page. Left untouched when null, and ignored with awarning when the model is not a 2nd generation one.
    second_generation: Optional[Ec3G2VerificationOptions] = None
    # Run a 2nd order analysis for the static combinations.FORCED OFF when no imperfection is enabled. The dialog does not merely disable this boxin that state, it clears it - so a model carrying a 2nd order analysis with noimperfection is one the desktop application cannot hold, and a request that wouldproduce it has the flag turned off and reported as a warning.
    second_order_analysis: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Ec3SteelVerificationSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Ec3SteelVerificationSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Ec3SteelVerificationSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .ec3_g2_verification_options import Ec3G2VerificationOptions
        from .e_steel_buckling_length_option import ESteelBucklingLengthOption
        from .e_steel_calculation_type import ESteelCalculationType
        from .e_steel_imperfection_generation import ESteelImperfectionGeneration
        from .e_steel_plate_buckling_method import ESteelPlateBucklingMethod

        from .ec3_g2_verification_options import Ec3G2VerificationOptions
        from .e_steel_buckling_length_option import ESteelBucklingLengthOption
        from .e_steel_calculation_type import ESteelCalculationType
        from .e_steel_imperfection_generation import ESteelImperfectionGeneration
        from .e_steel_plate_buckling_method import ESteelPlateBucklingMethod

        fields: dict[str, Callable[[Any], None]] = {
            "beamsBucklingLength": lambda n : setattr(self, 'beams_buckling_length', n.get_enum_value(ESteelBucklingLengthOption)),
            "calculationType": lambda n : setattr(self, 'calculation_type', n.get_enum_value(ESteelCalculationType)),
            "columnsBucklingLength": lambda n : setattr(self, 'columns_buckling_length', n.get_enum_value(ESteelBucklingLengthOption)),
            "crossSectionStrength": lambda n : setattr(self, 'cross_section_strength', n.get_bool_value()),
            "crownImperfections": lambda n : setattr(self, 'crown_imperfections', n.get_bool_value()),
            "elementStability": lambda n : setattr(self, 'element_stability', n.get_bool_value()),
            "fireResistanceTime": lambda n : setattr(self, 'fire_resistance_time', n.get_float_value()),
            "fireVerification": lambda n : setattr(self, 'fire_verification', n.get_bool_value()),
            "globalSwayImperfections": lambda n : setattr(self, 'global_sway_imperfections', n.get_bool_value()),
            "imperfectionGeneration": lambda n : setattr(self, 'imperfection_generation', n.get_enum_value(ESteelImperfectionGeneration)),
            "localBowImperfections": lambda n : setattr(self, 'local_bow_imperfections', n.get_bool_value()),
            "plateBucklingMethod": lambda n : setattr(self, 'plate_buckling_method', n.get_enum_value(ESteelPlateBucklingMethod)),
            "secondGeneration": lambda n : setattr(self, 'second_generation', n.get_object_value(Ec3G2VerificationOptions)),
            "secondOrderAnalysis": lambda n : setattr(self, 'second_order_analysis', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("beamsBucklingLength", self.beams_buckling_length)
        writer.write_enum_value("calculationType", self.calculation_type)
        writer.write_enum_value("columnsBucklingLength", self.columns_buckling_length)
        writer.write_bool_value("crossSectionStrength", self.cross_section_strength)
        writer.write_bool_value("crownImperfections", self.crown_imperfections)
        writer.write_bool_value("elementStability", self.element_stability)
        writer.write_float_value("fireResistanceTime", self.fire_resistance_time)
        writer.write_bool_value("fireVerification", self.fire_verification)
        writer.write_bool_value("globalSwayImperfections", self.global_sway_imperfections)
        writer.write_enum_value("imperfectionGeneration", self.imperfection_generation)
        writer.write_bool_value("localBowImperfections", self.local_bow_imperfections)
        writer.write_enum_value("plateBucklingMethod", self.plate_buckling_method)
        writer.write_object_value("secondGeneration", self.second_generation)
        writer.write_bool_value("secondOrderAnalysis", self.second_order_analysis)
    

