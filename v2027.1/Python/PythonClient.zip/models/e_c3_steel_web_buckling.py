from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_c3_steel_web_buckling_longitudinal_stiffeners import EC3SteelWebBucklingLongitudinalStiffeners
    from .e_c3_steel_web_buckling_transverse_stiffeners import EC3SteelWebBucklingTransverseStiffeners

@dataclass
class EC3SteelWebBuckling(Parsable):
    """
    "Shear buckling of the web" group of an EC3 steel design template (maps to the AD model object`som.EC3RoleSDLinearWebBuckling`). EC3 only: Advance Design creates this group only when the model is configured for the Eurocode(1st or 2nd generation). It holds the EN 1993-1-5 verification of the web, together with thestiffeners that restrain it.
    """
    # Longitudinal (horizontal) stiffeners of the web (maps to"WebBucklingLongitudinalStiffeners"). Send null to leave the whole group unchanged on Update. Default value : null
    longitudinal_stiffeners: Optional[EC3SteelWebBucklingLongitudinalStiffeners] = None
    # Transverse (vertical) stiffeners of the web (maps to"WebBucklingTransverseStiffeners"). Send null to leave the whole group unchanged on Update. Default value : null
    transverse_stiffeners: Optional[EC3SteelWebBucklingTransverseStiffeners] = None
    # Whether the shear buckling of the web is verified (maps to "WebBucklingChecking"). When false, both stiffener groups are ignored by the design engine. Default value : false
    web_buckling_checking: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelWebBuckling:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelWebBuckling
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelWebBuckling()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_c3_steel_web_buckling_longitudinal_stiffeners import EC3SteelWebBucklingLongitudinalStiffeners
        from .e_c3_steel_web_buckling_transverse_stiffeners import EC3SteelWebBucklingTransverseStiffeners

        from .e_c3_steel_web_buckling_longitudinal_stiffeners import EC3SteelWebBucklingLongitudinalStiffeners
        from .e_c3_steel_web_buckling_transverse_stiffeners import EC3SteelWebBucklingTransverseStiffeners

        fields: dict[str, Callable[[Any], None]] = {
            "longitudinalStiffeners": lambda n : setattr(self, 'longitudinal_stiffeners', n.get_object_value(EC3SteelWebBucklingLongitudinalStiffeners)),
            "transverseStiffeners": lambda n : setattr(self, 'transverse_stiffeners', n.get_object_value(EC3SteelWebBucklingTransverseStiffeners)),
            "webBucklingChecking": lambda n : setattr(self, 'web_buckling_checking', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("longitudinalStiffeners", self.longitudinal_stiffeners)
        writer.write_object_value("transverseStiffeners", self.transverse_stiffeners)
        writer.write_bool_value("webBucklingChecking", self.web_buckling_checking)
    

