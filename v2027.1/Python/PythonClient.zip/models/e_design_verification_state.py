from enum import Enum

class EDesignVerificationState(str, Enum):
    Active = "Active",
    Inactive = "Inactive",

