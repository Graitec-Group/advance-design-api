from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_c3_steel_fire_protection import EC3SteelFireProtection
    from .steel_fire_emissivity_coeff_type import SteelFireEmissivityCoeffType
    from .steel_fire_exposed_faces import SteelFireExposedFaces

@dataclass
class EC3SteelFireVerification(Parsable):
    """
    "Fire verification" group of an EC3 steel design template (maps to the AD model object`som.EC3RoleFireVerificationObj`). Holds the EN 1993-1-2 fire-resistance verification.
    """
    from .steel_fire_emissivity_coeff_type import SteelFireEmissivityCoeffType

    # Surface emissivity of the steel member (maps to "FireEmissivityCoeff"). Default value : SteelFireEmissivityCoeffType.carbon_steel
    fire_emissivity_coeff: Optional[SteelFireEmissivityCoeffType] = SteelFireEmissivityCoeffType("carbon_steel")
    from .steel_fire_exposed_faces import SteelFireExposedFaces

    # Number of faces of the cross-section exposed to the fire (maps to"FireExposureFaces"). Drives the section factor Am/V. Default value : SteelFireExposedFaces.four_faces
    fire_exposure_faces: Optional[SteelFireExposedFaces] = SteelFireExposedFaces("four_faces")
    # Imposed emissivity value (maps to "FireEmValue"). Used only when AD.API.EC3SteelFireVerification.FireEmissivityCoeff isAD.API.SteelFireEmissivityCoeffType.imposed; Advance Design resets it to the defaultwhenever the coefficient type changes. Unit : adimensional Default value : 0.7
    fire_emissivity_value: Optional[float] = None
    # Passive fire protection applied to the member (maps to "RoleFireProtection"). Send null to leave the whole group unchanged on Update. Default value : null
    fire_protection: Optional[EC3SteelFireProtection] = None
    # Required fire resistance duration (maps to "FireResistance"). A plain duration in MINUTES, not an enumeration: 0 means no fire verification, and the usualvalues are 30, 60, 90, 120, 180 and 240 (the R30..R240 classes). Unit : min Default value : 0
    fire_resistance: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelFireVerification:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelFireVerification
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelFireVerification()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_c3_steel_fire_protection import EC3SteelFireProtection
        from .steel_fire_emissivity_coeff_type import SteelFireEmissivityCoeffType
        from .steel_fire_exposed_faces import SteelFireExposedFaces

        from .e_c3_steel_fire_protection import EC3SteelFireProtection
        from .steel_fire_emissivity_coeff_type import SteelFireEmissivityCoeffType
        from .steel_fire_exposed_faces import SteelFireExposedFaces

        fields: dict[str, Callable[[Any], None]] = {
            "fireEmissivityCoeff": lambda n : setattr(self, 'fire_emissivity_coeff', n.get_enum_value(SteelFireEmissivityCoeffType)),
            "fireEmissivityValue": lambda n : setattr(self, 'fire_emissivity_value', n.get_float_value()),
            "fireExposureFaces": lambda n : setattr(self, 'fire_exposure_faces', n.get_enum_value(SteelFireExposedFaces)),
            "fireProtection": lambda n : setattr(self, 'fire_protection', n.get_object_value(EC3SteelFireProtection)),
            "fireResistance": lambda n : setattr(self, 'fire_resistance', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("fireEmissivityCoeff", self.fire_emissivity_coeff)
        writer.write_float_value("fireEmissivityValue", self.fire_emissivity_value)
        writer.write_enum_value("fireExposureFaces", self.fire_exposure_faces)
        writer.write_object_value("fireProtection", self.fire_protection)
        writer.write_int_value("fireResistance", self.fire_resistance)
    

