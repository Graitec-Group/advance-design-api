from enum import Enum

class LinearReleaseType(str, Enum):
    Default_release = "default_release",
    User_defined_release = "user_defined_release",

