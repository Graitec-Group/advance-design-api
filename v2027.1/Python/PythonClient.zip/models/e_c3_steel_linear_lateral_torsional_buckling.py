from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_c3_steel_lateral_torsional_buckling_length import EC3SteelLateralTorsionalBucklingLength

@dataclass
class EC3SteelLinearLateralTorsionalBuckling(Parsable):
    """
    "Lateral torsional buckling" group of an EC3 steel design template (maps to the AD model object`som.EC3RoleSDLinearLateralTorsionBuckling`).
    """
    # Whether lateral-torsional buckling is verified (maps to"LateralTorsionBucklingChecking"). Displayed as "Elem. Verification". When false, the wholeAD.API.EC3SteelLinearLateralTorsionalBuckling.LateralTorsionalBucklingLength group is ignored by the design engine. Default value : true
    element_verification: Optional[bool] = None
    # Lateral-torsional buckling lengths and parameters (maps to"RoleLateralTorsionBucklingLength"). Send null to leave the whole group unchanged on Update. Default value : null
    lateral_torsional_buckling_length: Optional[EC3SteelLateralTorsionalBucklingLength] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelLinearLateralTorsionalBuckling:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelLinearLateralTorsionalBuckling
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelLinearLateralTorsionalBuckling()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_c3_steel_lateral_torsional_buckling_length import EC3SteelLateralTorsionalBucklingLength

        from .e_c3_steel_lateral_torsional_buckling_length import EC3SteelLateralTorsionalBucklingLength

        fields: dict[str, Callable[[Any], None]] = {
            "elementVerification": lambda n : setattr(self, 'element_verification', n.get_bool_value()),
            "lateralTorsionalBucklingLength": lambda n : setattr(self, 'lateral_torsional_buckling_length', n.get_object_value(EC3SteelLateralTorsionalBucklingLength)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("elementVerification", self.element_verification)
        writer.write_object_value("lateralTorsionalBucklingLength", self.lateral_torsional_buckling_length)
    

