from enum import Enum

class Ec3CylinderLength(str, Enum):
    Short = "Short",
    Medium = "Medium",
    Long = "Long",

