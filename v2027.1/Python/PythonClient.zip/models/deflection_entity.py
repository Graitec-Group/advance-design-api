from enum import Enum

class DeflectionEntity(str, Enum):
    Element = "Element",
    SuperElement = "SuperElement",

