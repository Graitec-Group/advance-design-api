from enum import Enum

class NorthAmericanSteelCode(str, Enum):
    Aisc360 = "Aisc360",
    CsaS16_2009 = "CsaS16_2009",
    CsaS16_2014 = "CsaS16_2014",
    Aisc360_2016 = "Aisc360_2016",
    CsaS16_2019 = "CsaS16_2019",
    CsaS16_2024 = "CsaS16_2024",

