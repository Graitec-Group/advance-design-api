from enum import Enum

class ECombinationsEurocodeAnnex(str, Enum):
    General = "General",
    France = "France",
    UK = "UK",
    Germany = "Germany",
    Czech = "Czech",
    Romania = "Romania",
    Slovakia = "Slovakia",
    Poland = "Poland",
    Spain = "Spain",
    Portugal = "Portugal",

