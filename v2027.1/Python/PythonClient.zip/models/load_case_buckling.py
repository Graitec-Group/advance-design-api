from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID
    from .load_case import LoadCase

from .load_case import LoadCase

@dataclass
class LoadCase_Buckling(LoadCase, AdditionalDataHolder, Parsable):
    """
    Buckling load case
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Referenced analysis identifier (maps to analysisId / InnerLoadCaseId)Unit : -Default value : 0
    inner_load_case_id: Optional[EID] = None
    # Maximum number of iterationsUnit : -Default value : 100
    max_iterations: Optional[int] = None
    # Maximum lambda valueUnit : -Default value : 0.0
    max_lambda: Optional[float] = None
    # Number of buckling modesUnit : -Default value : 1
    no_modes: Optional[int] = None
    # Convergence toleranceUnit : -Default value : 1e-06
    tolerance: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_Buckling:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_Buckling
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_Buckling()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID
        from .load_case import LoadCase

        from .e_i_d import EID
        from .load_case import LoadCase

        fields: dict[str, Callable[[Any], None]] = {
            "innerLoadCaseId": lambda n : setattr(self, 'inner_load_case_id', n.get_object_value(EID)),
            "maxIterations": lambda n : setattr(self, 'max_iterations', n.get_int_value()),
            "maxLambda": lambda n : setattr(self, 'max_lambda', n.get_float_value()),
            "noModes": lambda n : setattr(self, 'no_modes', n.get_int_value()),
            "tolerance": lambda n : setattr(self, 'tolerance', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("innerLoadCaseId", self.inner_load_case_id)
        writer.write_int_value("maxIterations", self.max_iterations)
        writer.write_float_value("maxLambda", self.max_lambda)
        writer.write_int_value("noModes", self.no_modes)
        writer.write_float_value("tolerance", self.tolerance)
        writer.write_additional_data_value(self.additional_data)
    

