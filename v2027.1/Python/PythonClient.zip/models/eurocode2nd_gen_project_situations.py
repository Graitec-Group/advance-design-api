from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e2nd_gen_combination_equation import E2ndGenCombinationEquation
    from .e2nd_gen_consequence_class import E2ndGenConsequenceClass

@dataclass
class Eurocode2ndGenProjectSituations(Parsable):
    """
    Which verification cases and serviceability combinations the 2nd generation generationproduces, and the fundamental design situation parameters.EN 1990:2023 replaces the EQU / STR / GEO trio of the 1st generation with numberedverification cases: VC1 corresponds to STR/GEO set B, VC2a and VC2b replace EQU(set A) with two approaches, VC3 corresponds to set C, and VC4 is new.
    """
    # Consequence class, which fixes AD.API.Eurocode2ndGenProjectSituations.ConsequenceFactorK unless it is`Other`.
    consequence_class: Optional[E2ndGenConsequenceClass] = None
    # Consequence factor k_F. Stored as sent - unlike the 1st generation coefficients,the 2nd generation derivation still lives in the desktop options dialog, so nothingrecomputes it here.
    consequence_factor_k: Optional[float] = None
    # Which ULS equation the fundamental combinations use.
    equation: Optional[E2ndGenCombinationEquation] = None
    # SLS characteristic.
    sls_characteristic: Optional[bool] = None
    # SLS frequent.
    sls_frequent: Optional[bool] = None
    # SLS quasi-permanent.
    sls_quasi_permanent: Optional[bool] = None
    # SLS seismic - new in EN 1990:2023.
    sls_seismic: Optional[bool] = None
    # ULS accidental.
    uls_accidental: Optional[bool] = None
    # ULS seismic.
    uls_seismic: Optional[bool] = None
    # ULS VC1 - the equivalent of STR/GEO set B.
    uls_v_c1: Optional[bool] = None
    # ULS VC2a - the first approach replacing EQU (set A).
    uls_v_c2_a: Optional[bool] = None
    # ULS VC2b - the second approach replacing EQU (set A).
    uls_v_c2_b: Optional[bool] = None
    # ULS VC3 - the equivalent of set C.
    uls_v_c3: Optional[bool] = None
    # ULS VC4 - new in EN 1990:2023.
    uls_v_c4: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Eurocode2ndGenProjectSituations:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Eurocode2ndGenProjectSituations
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Eurocode2ndGenProjectSituations()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e2nd_gen_combination_equation import E2ndGenCombinationEquation
        from .e2nd_gen_consequence_class import E2ndGenConsequenceClass

        from .e2nd_gen_combination_equation import E2ndGenCombinationEquation
        from .e2nd_gen_consequence_class import E2ndGenConsequenceClass

        fields: dict[str, Callable[[Any], None]] = {
            "consequenceClass": lambda n : setattr(self, 'consequence_class', n.get_enum_value(E2ndGenConsequenceClass)),
            "consequenceFactorK": lambda n : setattr(self, 'consequence_factor_k', n.get_float_value()),
            "equation": lambda n : setattr(self, 'equation', n.get_enum_value(E2ndGenCombinationEquation)),
            "slsCharacteristic": lambda n : setattr(self, 'sls_characteristic', n.get_bool_value()),
            "slsFrequent": lambda n : setattr(self, 'sls_frequent', n.get_bool_value()),
            "slsQuasiPermanent": lambda n : setattr(self, 'sls_quasi_permanent', n.get_bool_value()),
            "slsSeismic": lambda n : setattr(self, 'sls_seismic', n.get_bool_value()),
            "ulsAccidental": lambda n : setattr(self, 'uls_accidental', n.get_bool_value()),
            "ulsSeismic": lambda n : setattr(self, 'uls_seismic', n.get_bool_value()),
            "ulsVC1": lambda n : setattr(self, 'uls_v_c1', n.get_bool_value()),
            "ulsVC2A": lambda n : setattr(self, 'uls_v_c2_a', n.get_bool_value()),
            "ulsVC2B": lambda n : setattr(self, 'uls_v_c2_b', n.get_bool_value()),
            "ulsVC3": lambda n : setattr(self, 'uls_v_c3', n.get_bool_value()),
            "ulsVC4": lambda n : setattr(self, 'uls_v_c4', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("consequenceClass", self.consequence_class)
        writer.write_float_value("consequenceFactorK", self.consequence_factor_k)
        writer.write_enum_value("equation", self.equation)
        writer.write_bool_value("slsCharacteristic", self.sls_characteristic)
        writer.write_bool_value("slsFrequent", self.sls_frequent)
        writer.write_bool_value("slsQuasiPermanent", self.sls_quasi_permanent)
        writer.write_bool_value("slsSeismic", self.sls_seismic)
        writer.write_bool_value("ulsAccidental", self.uls_accidental)
        writer.write_bool_value("ulsSeismic", self.uls_seismic)
        writer.write_bool_value("ulsVC1", self.uls_v_c1)
        writer.write_bool_value("ulsVC2A", self.uls_v_c2_a)
        writer.write_bool_value("ulsVC2B", self.uls_v_c2_b)
        writer.write_bool_value("ulsVC3", self.uls_v_c3)
        writer.write_bool_value("ulsVC4", self.uls_v_c4)
    

