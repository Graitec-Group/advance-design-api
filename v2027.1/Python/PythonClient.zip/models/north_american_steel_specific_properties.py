from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .steel_hss_design_thickness import SteelHssDesignThickness

@dataclass
class NorthAmericanSteelSpecificProperties(Parsable):
    """
    "Steel specific properties" group of a North-American steel design template (maps to the ADmodel object `som.RoleSteelSpecificProperties`). The group has no Eurocode counterpart: Advance Design allocates it only under AISC 360 andCAN/CSA S16. Several of its rows only apply to a family of sections - the HSS design thicknessto circular and rectangular tubes, the web stiffeners to I, U and T profiles, the connectorspacing to double angles - and the design engine simply ignores the others. The property liststill shows them all, so they are all writable here. TWO ROWS ARE CAN/CSA-ONLY. AD.API.NorthAmericanSteelSpecificProperties.StiffenersSpacing is hidden by the property list underAISC and AD.API.NorthAmericanSteelSpecificProperties.CheckForTorsionAndShear under anything but CAN/CSA. Sending anon-default value for either one on an AD.API.AISCSteelLinearDesignTemplate is REFUSED,so a payload can never store a value the desktop could not have produced; use aAD.API.CSASteelLinearDesignTemplate for them.
    """
    from .steel_hss_design_thickness import SteelHssDesignThickness

    # Fraction of the nominal wall thickness used as the design wall thickness of a hollowstructural section (maps to "HssDesignThicknessChoice"). Displayed as "HSS design thickness". Applies to circular and rectangular tubes only. Default value : SteelHssDesignThickness.reduced
    hss_design_thickness_choice: Optional[SteelHssDesignThickness] = SteelHssDesignThickness("reduced")
    # Whether the combined torsion and shear verification is performed (maps to"CheckForTorsionAndShear"). CAN/CSA ONLY: the property list hides this row under AISC, and sending true on anAD.API.AISCSteelLinearDesignTemplate is refused. Default value : false
    check_for_torsion_and_shear: Optional[bool] = None
    # Spacing of the connectors between the two angles of a double-angle section (maps to"ConnectorsSpacing"). Applies to double-angle profiles only. Unit : m Default value : 1.0
    connectors_spacing: Optional[float] = None
    # Whether the HSS is axially stress-relieved (maps to"HssDesignAxialStressRelieved"). Applies to circular and rectangular tubes only. Default value : false
    hss_design_axial_stress_relieved: Optional[bool] = None
    # Numeric factor the chosen HSS design thickness resolves to (maps to"HssDesignThicknessValue"). Output only: Advance Design derives it from AD.API.NorthAmericanSteelSpecificProperties.HssDesignThicknessChoice AND fromthe model's steel code - 0.93 / 1.00 under AISC, 0.90 / 1.00 under CAN/CSA - and the propertylist does not expose it (the combo of the choice above is labelled with these very numbers).A value sent here is overwritten. It carries NO documented default on purpose: the value depends on the design code, so it neverreads back as 0 and there is no single number a contract could honestly advertise. Unit : adimensional
    hss_design_thickness_value: Optional[float] = None
    # Whether the shear lag factor Kt is verified (maps to "KtFactorCheck"). Default value : true
    kt_factor_check: Optional[bool] = None
    # Imposed value of the shear lag factor Kt (maps to "KtFactorValue"). Used only when AD.API.NorthAmericanSteelSpecificProperties.KtFactorCheck is true. Unit : adimensional Default value : 0.8
    kt_factor_value: Optional[float] = None
    # Spacing of the transverse web stiffeners (maps to "StiffenersSpacing"). CAN/CSA ONLY: the property list hides this row under AISC, and sending a non-zero value on anAD.API.AISCSteelLinearDesignTemplate is refused. Applies to I, U and T profilesonly. Unit : m Default value : 0.0
    stiffeners_spacing: Optional[float] = None
    # Whether the tension field action of the stiffened web is taken into account (maps to"StiffenersTensionField"). Applies to I, U and T profiles only. Default value : false
    stiffeners_tension_field: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NorthAmericanSteelSpecificProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NorthAmericanSteelSpecificProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NorthAmericanSteelSpecificProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .steel_hss_design_thickness import SteelHssDesignThickness

        from .steel_hss_design_thickness import SteelHssDesignThickness

        fields: dict[str, Callable[[Any], None]] = {
            "checkForTorsionAndShear": lambda n : setattr(self, 'check_for_torsion_and_shear', n.get_bool_value()),
            "connectorsSpacing": lambda n : setattr(self, 'connectors_spacing', n.get_float_value()),
            "hssDesignAxialStressRelieved": lambda n : setattr(self, 'hss_design_axial_stress_relieved', n.get_bool_value()),
            "hssDesignThicknessChoice": lambda n : setattr(self, 'hss_design_thickness_choice', n.get_enum_value(SteelHssDesignThickness)),
            "hssDesignThicknessValue": lambda n : setattr(self, 'hss_design_thickness_value', n.get_float_value()),
            "ktFactorCheck": lambda n : setattr(self, 'kt_factor_check', n.get_bool_value()),
            "ktFactorValue": lambda n : setattr(self, 'kt_factor_value', n.get_float_value()),
            "stiffenersSpacing": lambda n : setattr(self, 'stiffeners_spacing', n.get_float_value()),
            "stiffenersTensionField": lambda n : setattr(self, 'stiffeners_tension_field', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("checkForTorsionAndShear", self.check_for_torsion_and_shear)
        writer.write_float_value("connectorsSpacing", self.connectors_spacing)
        writer.write_bool_value("hssDesignAxialStressRelieved", self.hss_design_axial_stress_relieved)
        writer.write_enum_value("hssDesignThicknessChoice", self.hss_design_thickness_choice)
        writer.write_float_value("hssDesignThicknessValue", self.hss_design_thickness_value)
        writer.write_bool_value("ktFactorCheck", self.kt_factor_check)
        writer.write_float_value("ktFactorValue", self.kt_factor_value)
        writer.write_float_value("stiffenersSpacing", self.stiffeners_spacing)
        writer.write_bool_value("stiffenersTensionField", self.stiffeners_tension_field)
    

