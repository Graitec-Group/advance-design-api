from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .results_query import ResultsQuery
    from .results_query_f_e_m_analysis_case_info import ResultsQueryFEM_analysisCaseInfo
    from .result_type import ResultType

from .results_query import ResultsQuery

@dataclass
class ResultsQueryFEM(ResultsQuery, AdditionalDataHolder, Parsable):
    """
    Query payload for finite-element results: the result type, the target element EIDs,and the (possibly specialized) load case / analysis identifier.The AD.API.ResultsQueryFEM.AnalysisCaseInfo is polymorphic: a plain AD.API.LoadCaseInfocarries only the EID, while derived types (e.g. AD.API.LoadCaseAnalysisBuckling)add their own indices such as the buckling mode.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Load case / analysis the results are requested for.
    analysis_case_info: Optional[ResultsQueryFEM_analysisCaseInfo] = None
    # Analysis result type to extract.
    e_res_type: Optional[ResultType] = None
    # EIDs of the elements for which the results are requested.
    list_elements_i_ds: Optional[list[int]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResultsQueryFEM:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResultsQueryFEM
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResultsQueryFEM()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .results_query import ResultsQuery
        from .results_query_f_e_m_analysis_case_info import ResultsQueryFEM_analysisCaseInfo
        from .result_type import ResultType

        from .results_query import ResultsQuery
        from .results_query_f_e_m_analysis_case_info import ResultsQueryFEM_analysisCaseInfo
        from .result_type import ResultType

        fields: dict[str, Callable[[Any], None]] = {
            "analysisCaseInfo": lambda n : setattr(self, 'analysis_case_info', n.get_object_value(ResultsQueryFEM_analysisCaseInfo)),
            "eResType": lambda n : setattr(self, 'e_res_type', n.get_enum_value(ResultType)),
            "listElementsIDs": lambda n : setattr(self, 'list_elements_i_ds', n.get_collection_of_primitive_values(int)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("analysisCaseInfo", self.analysis_case_info)
        writer.write_enum_value("eResType", self.e_res_type)
        writer.write_collection_of_primitive_values("listElementsIDs", self.list_elements_i_ds)
        writer.write_additional_data_value(self.additional_data)
    

