from enum import Enum

class Ec3GoverningCheck(str, Enum):
    None_ = "None",
    Axial = "Axial",
    ShearY = "ShearY",
    ShearZ = "ShearZ",
    BendingYY = "BendingYY",
    BendingZZ = "BendingZZ",
    CombinedBending = "CombinedBending",
    BendingYYAndAxial = "BendingYYAndAxial",
    BendingZZAndAxial = "BendingZZAndAxial",
    BendingYYAndShearZ = "BendingYYAndShearZ",
    BendingZZAndShearY = "BendingZZAndShearY",
    BiaxialBending = "BiaxialBending",
    Torsion = "Torsion",
    Stability = "Stability",

