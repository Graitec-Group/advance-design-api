from enum import Enum

class EModelSettingsCategory(str, Enum):
    None_ = "None",
    CombinationsGeneration = "CombinationsGeneration",
    SteelEc3Calculation = "SteelEc3Calculation",
    SteelAiscCalculation = "SteelAiscCalculation",

