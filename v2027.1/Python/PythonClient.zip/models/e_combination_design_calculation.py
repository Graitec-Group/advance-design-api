from enum import Enum

class ECombinationDesignCalculation(str, Enum):
    ConcreteDesign = "ConcreteDesign",
    SteelProfiles = "SteelProfiles",
    SteelConnections = "SteelConnections",
    SteelDeflections = "SteelDeflections",
    SteelFire = "SteelFire",
    TimberDeflections = "TimberDeflections",
    TimberProfiles = "TimberProfiles",
    TimberFire = "TimberFire",
    PreCompositeDeflections = "PreCompositeDeflections",
    PostCompositeDeflections = "PostCompositeDeflections",
    PreCompositeProfiles = "PreCompositeProfiles",
    PostCompositeProfiles = "PostCompositeProfiles",

