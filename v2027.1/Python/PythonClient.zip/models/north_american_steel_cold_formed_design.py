from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .north_american_steel_web_crippling_info import NorthAmericanSteelWebCripplingInfo

@dataclass
class NorthAmericanSteelColdFormedDesign(Parsable):
    """
    "Cold formed design options" group of a North-American steel design template - the AISI S100options (maps to the AD model object `som.AISCRoleColdFormedDesign`, which derives from`som.AISIColdFormedDesign`). A different object from the Eurocode AD.API.EC3SteelColdFormedDesign, and reached througha differently named slot of the expert object ("ColdFormedDesignOptions" against the Eurocode"RoleColdFormedDesignOptions"). Most of the group describes WEB CRIPPLING (AISI S100 clause G5): the bearing length and thesupport conditions at the two kinds of support decide which coefficient row of the standard'stable the design engine picks.
    """
    # Bearing length over which the concentrated load or reaction is applied (maps to"BearingLength"), used by the web crippling verification. Unit : m Default value : 0.0
    bearing_length: Optional[float] = None
    # Whether the exact cold-formed design calculation is used instead of the simplified one (mapsto "ExactCFDCalculation"). Default value : false
    exact_c_f_d_calculation: Optional[bool] = None
    # Web crippling conditions at an EXTERIOR (end) support (maps to "ExteriorSupport"). Send null to leave the whole group unchanged on Update. Default value : null
    exterior_support: Optional[NorthAmericanSteelWebCripplingInfo] = None
    # Web crippling conditions at an INTERIOR support (maps to "InteriorSupport"). Send null to leave the whole group unchanged on Update. Default value : null
    interior_support: Optional[NorthAmericanSteelWebCripplingInfo] = None
    # Rotational stiffness k of the elastic restraint provided by the sheeting (maps to"K_phie"). Unit : adimensional Default value : 0.0
    k_phi_e: Optional[float] = None
    # Length of the overhang at the support (maps to "OverhangLengthAtSupport"). Unit : m Default value : 0.0
    overhang_length_at_support: Optional[float] = None
    # Whether the sections overlap at the support (maps to "OverlapSectionAtSupport"). Default value : false
    overlap_section_at_support: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NorthAmericanSteelColdFormedDesign:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NorthAmericanSteelColdFormedDesign
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NorthAmericanSteelColdFormedDesign()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .north_american_steel_web_crippling_info import NorthAmericanSteelWebCripplingInfo

        from .north_american_steel_web_crippling_info import NorthAmericanSteelWebCripplingInfo

        fields: dict[str, Callable[[Any], None]] = {
            "bearingLength": lambda n : setattr(self, 'bearing_length', n.get_float_value()),
            "exactCFDCalculation": lambda n : setattr(self, 'exact_c_f_d_calculation', n.get_bool_value()),
            "exteriorSupport": lambda n : setattr(self, 'exterior_support', n.get_object_value(NorthAmericanSteelWebCripplingInfo)),
            "interiorSupport": lambda n : setattr(self, 'interior_support', n.get_object_value(NorthAmericanSteelWebCripplingInfo)),
            "kPhiE": lambda n : setattr(self, 'k_phi_e', n.get_float_value()),
            "overhangLengthAtSupport": lambda n : setattr(self, 'overhang_length_at_support', n.get_float_value()),
            "overlapSectionAtSupport": lambda n : setattr(self, 'overlap_section_at_support', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("bearingLength", self.bearing_length)
        writer.write_bool_value("exactCFDCalculation", self.exact_c_f_d_calculation)
        writer.write_object_value("exteriorSupport", self.exterior_support)
        writer.write_object_value("interiorSupport", self.interior_support)
        writer.write_float_value("kPhiE", self.k_phi_e)
        writer.write_float_value("overhangLengthAtSupport", self.overhang_length_at_support)
        writer.write_bool_value("overlapSectionAtSupport", self.overlap_section_at_support)
    

