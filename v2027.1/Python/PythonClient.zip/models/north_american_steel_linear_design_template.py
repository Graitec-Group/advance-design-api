from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate
    from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate
    from .north_american_steel_cold_formed_design import NorthAmericanSteelColdFormedDesign
    from .north_american_steel_linear_lateral_torsional_buckling import NorthAmericanSteelLinearLateralTorsionalBuckling
    from .north_american_steel_specific_properties import NorthAmericanSteelSpecificProperties
    from .steel_angle_verification import SteelAngleVerification
    from .steel_linear_buckling import SteelLinearBuckling
    from .steel_linear_deflection import SteelLinearDeflection
    from .steel_linear_design_template import SteelLinearDesignTemplate
    from .steel_non_linear_f_e_m import SteelNonLinearFEM

from .steel_linear_design_template import SteelLinearDesignTemplate

@dataclass
class NorthAmericanSteelLinearDesignTemplate(SteelLinearDesignTemplate, AdditionalDataHolder, Parsable):
    """
    Base class of the Expert design templates for linear STEEL elements verified to a NORTH-AMERICANcode - AISC 360 or CAN/CSA S16 (maps to the AD model objects `som.AISCSteelLinearRole` and`som.CSASteelLinearRole`, held by `som.Role` in its "AISCSteelLinearExpertProperties"and "CSASteelLinearExpertProperties" slots). WHY THE TWO CODES SHARE A BASE. Advance Design gives them two distinct SOM classes, but those twoclasses differ by exactly two things: the meaning of the cross-section class, and the Class 4effective characteristics, which only CAN/CSA carries. Everything else - the 2nd-order analysis,the deflections, the flexural and torsional buckling, the lateral-torsional buckling, theAISC/CSA specific properties, the cold-formed options and the angle verification - is the sameobject graph, initialized by the same branch of `CRoleManager::CreateLinearMetalExpert` andcopied to the element by the same branch of `CLinearElementAccessor::ApplyRole`. Thatshared part lives here; AD.API.AISCSteelLinearDesignTemplate andAD.API.CSASteelLinearDesignTemplate only add what genuinely differs. This class is NOT creatable on its own: a template always belongs to one of the two codes, soCreate and Update require one of the two leaves. Sending this base is refused. HOW IT DIFFERS FROM THE EUROCODE LEAF. Compared withAD.API.EC3SteelLinearDesignTemplate, the North-American templates have NO manufacturingquality, NO execution class, NO family of element, NO global sway imperfections, NO fireverification and NO web-buckling group - Advance Design does not allocate those sub-objectsoutside the Eurocode. They gainAD.API.NorthAmericanSteelLinearDesignTemplate.SteelSpecificProperties (the HSS designthickness, the Kt factor, the web stiffeners and the double-angle connector spacing) and asimpler lateral-torsional-buckling group built around the Cb moment modification factor insteadof the Eurocode C1/C2/C3 coefficients. PARTIAL UPDATE - every group below is nullable. On Update, a group left null keeps its storedvalue, so a caller can patch one group without restating the rest. Lists inside a group are theexception: when a list is sent it replaces the stored one in full. Available for the descriptive model only.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # "Angle verification" group - the net-area verification of angle sections connected through oneleg (maps to "RoleAngleVerification"). The same `som.AngleVerification` object as under the Eurocode. Send null to leave the whole group unchanged on Update. Default value : null
    angle_verification: Optional[SteelAngleVerification] = None
    # "Buckling" group - the flexural and torsional buckling lengths (maps to"RoleLinearBuckling"). The same `som.RoleSDLinearBuckling` object as under the Eurocode. Note thatAD.API.SteelBucklingLength.TorsionalBucklingVerification is a CAN/CSA-only row - theAISC property list hides it - so setting it to false is refused on anAD.API.AISCSteelLinearDesignTemplate. Send null to leave the whole group unchanged on Update. Default value : null
    buckling: Optional[SteelLinearBuckling] = None
    # "Cold formed design options" group - the AISI S100 options and the web crippling conditions atthe exterior and interior supports (maps to "ColdFormedDesignOptions"). A DIFFERENT object from the Eurocode one (`som.AISCRoleColdFormedDesign` against`som.EC3RoleColdFormedDesign`) and reached through a differently named slot. NOTE - the model allocates this group and propagates it to the element for BOTH codes, but the"Design template description" dialog only lists it under AISC: the CAN/CSA template is missingits resource entry, so the values sent here for a CAN/CSA template reach the design engine andthe element, yet do not show in the desktop property list. Send null to leave the whole group unchanged on Update. Default value : null
    cold_formed_design: Optional[NorthAmericanSteelColdFormedDesign] = None
    # "Deflections" group - the serviceability deflection checks of the element and of itssuper-element (maps to "RoleLinearDeflection"). The same `som.RoleSDLinearDeflection` object as under the Eurocode. Send null to leave the whole group unchanged on Update. Default value : null
    deflection: Optional[SteelLinearDeflection] = None
    # "Lateral torsional buckling" group, per flange (maps to"RoleLinearLateralTorsionBuckling"). A DIFFERENT object from the Eurocode one: the North-American codes use`som.CM66RoleSDLinearLateralTorsionBuckling`, whose parameters are the Cb momentmodification factor rather than the Eurocode C1/C2/C3 set. Send null to leave the whole group unchanged on Update. Default value : null
    lateral_torsional_buckling: Optional[NorthAmericanSteelLinearLateralTorsionalBuckling] = None
    # "Advance stability (2nd order)" group - the non-linear finite-element analysis with warping andimperfections (maps to "RoleMetalNonLinearFEM"). The same `som.RoleMetalNonLinearFEM` object as under the Eurocode, so the group isidentical to AD.API.EC3SteelLinearDesignTemplate.NonLinearFEM. Send null to leave the whole group unchanged on Update. Default value : null
    non_linear_f_e_m: Optional[SteelNonLinearFEM] = None
    # "Steel specific properties" group - the HSS design thickness, the combined torsion and shearverification, the web stiffeners, the Kt factor and the double-angle connector spacing (mapsto "RoleSteelSpecificProperties"). North-American only: Advance Design creates this group only for the AISC and CAN/CSA codes,so it has no Eurocode counterpart. Send null to leave the whole group unchanged on Update. Default value : null
    steel_specific_properties: Optional[NorthAmericanSteelSpecificProperties] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NorthAmericanSteelLinearDesignTemplate:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NorthAmericanSteelLinearDesignTemplate
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "AISCSteelLinearDesignTemplate".casefold():
            from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate

            return AISCSteelLinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "CSASteelLinearDesignTemplate".casefold():
            from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate

            return CSASteelLinearDesignTemplate()
        return NorthAmericanSteelLinearDesignTemplate()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate
        from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate
        from .north_american_steel_cold_formed_design import NorthAmericanSteelColdFormedDesign
        from .north_american_steel_linear_lateral_torsional_buckling import NorthAmericanSteelLinearLateralTorsionalBuckling
        from .north_american_steel_specific_properties import NorthAmericanSteelSpecificProperties
        from .steel_angle_verification import SteelAngleVerification
        from .steel_linear_buckling import SteelLinearBuckling
        from .steel_linear_deflection import SteelLinearDeflection
        from .steel_linear_design_template import SteelLinearDesignTemplate
        from .steel_non_linear_f_e_m import SteelNonLinearFEM

        from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate
        from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate
        from .north_american_steel_cold_formed_design import NorthAmericanSteelColdFormedDesign
        from .north_american_steel_linear_lateral_torsional_buckling import NorthAmericanSteelLinearLateralTorsionalBuckling
        from .north_american_steel_specific_properties import NorthAmericanSteelSpecificProperties
        from .steel_angle_verification import SteelAngleVerification
        from .steel_linear_buckling import SteelLinearBuckling
        from .steel_linear_deflection import SteelLinearDeflection
        from .steel_linear_design_template import SteelLinearDesignTemplate
        from .steel_non_linear_f_e_m import SteelNonLinearFEM

        fields: dict[str, Callable[[Any], None]] = {
            "angleVerification": lambda n : setattr(self, 'angle_verification', n.get_object_value(SteelAngleVerification)),
            "buckling": lambda n : setattr(self, 'buckling', n.get_object_value(SteelLinearBuckling)),
            "coldFormedDesign": lambda n : setattr(self, 'cold_formed_design', n.get_object_value(NorthAmericanSteelColdFormedDesign)),
            "deflection": lambda n : setattr(self, 'deflection', n.get_object_value(SteelLinearDeflection)),
            "lateralTorsionalBuckling": lambda n : setattr(self, 'lateral_torsional_buckling', n.get_object_value(NorthAmericanSteelLinearLateralTorsionalBuckling)),
            "nonLinearFEM": lambda n : setattr(self, 'non_linear_f_e_m', n.get_object_value(SteelNonLinearFEM)),
            "steelSpecificProperties": lambda n : setattr(self, 'steel_specific_properties', n.get_object_value(NorthAmericanSteelSpecificProperties)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("angleVerification", self.angle_verification)
        writer.write_object_value("buckling", self.buckling)
        writer.write_object_value("coldFormedDesign", self.cold_formed_design)
        writer.write_object_value("deflection", self.deflection)
        writer.write_object_value("lateralTorsionalBuckling", self.lateral_torsional_buckling)
        writer.write_object_value("nonLinearFEM", self.non_linear_f_e_m)
        writer.write_object_value("steelSpecificProperties", self.steel_specific_properties)
        writer.write_additional_data_value(self.additional_data)
    

