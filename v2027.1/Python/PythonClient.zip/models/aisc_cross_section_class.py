from enum import Enum

class AiscCrossSectionClass(str, Enum):
    Auto = "Auto",
    Compact = "Compact",
    NonCompact = "NonCompact",
    SlenderElement = "SlenderElement",
    Unknown = "Unknown",

