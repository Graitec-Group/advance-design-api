from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .eurocode_live_load_settings import EurocodeLiveLoadSettings
    from .eurocode_snow_load_settings import EurocodeSnowLoadSettings
    from .eurocode_temperature_load_settings import EurocodeTemperatureLoadSettings
    from .eurocode_wind_load_settings import EurocodeWindLoadSettings

@dataclass
class EurocodeVariableActionSettings(Parsable):
    """
    One variable action row of the options grid. The four families - live loads, snow, windand temperature - carry the same coefficients and differ only in the category thatgoverns them, so each has its own derived type with its own category enumeration.
    """
    # READ ONLY, filled by `GetModelSettings`: how many realcategories this family has under the active standard and annex. Ignored in arequest.
    available_category_count: Optional[int] = None
    # gamma_Q for the EQU situation. Writable only for the user defined category.
    gamma_equ: Optional[float] = None
    # gamma_Q for the GEO situation. Writable only for the user defined category, and onlyread by the generation under the Italian standards.
    gamma_geo: Optional[float] = None
    # gamma_Q for the STR/GEO situation. Writable only for the user defined category.
    gamma_str_geo: Optional[float] = None
    # Generate combinations in which this family is the leading variable action. At leastone of the four families must stay on, so a request that would turn the last one offis refused.
    generate_as_leading_action: Optional[bool] = None
    # psi0 - combination value. Writable only for the user defined category.
    psi0: Optional[float] = None
    # psi1 - frequent value. Writable only for the user defined category.
    psi1: Optional[float] = None
    # psi2 - quasi-permanent value. Writable only for the user defined category.
    psi2: Optional[float] = None
    # The Type property
    type: Optional[str] = None
    # READ ONLY, filled by `GetModelSettings`: the numeric value ofthe "user defined" category under the active standard and annex - which is alsoAD.API.EurocodeVariableActionSettings.AvailableCategoryCount, since the real categories are numbered fromzero. Ignored in a request.It is here because it is not a constant: the live load category list is thirteenlong under the French annex and eight under the Czech one.
    user_defined_category: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EurocodeVariableActionSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EurocodeVariableActionSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "EurocodeLiveLoadSettings".casefold():
            from .eurocode_live_load_settings import EurocodeLiveLoadSettings

            return EurocodeLiveLoadSettings()
        if mapping_value and mapping_value.casefold() == "EurocodeSnowLoadSettings".casefold():
            from .eurocode_snow_load_settings import EurocodeSnowLoadSettings

            return EurocodeSnowLoadSettings()
        if mapping_value and mapping_value.casefold() == "EurocodeTemperatureLoadSettings".casefold():
            from .eurocode_temperature_load_settings import EurocodeTemperatureLoadSettings

            return EurocodeTemperatureLoadSettings()
        if mapping_value and mapping_value.casefold() == "EurocodeWindLoadSettings".casefold():
            from .eurocode_wind_load_settings import EurocodeWindLoadSettings

            return EurocodeWindLoadSettings()
        return EurocodeVariableActionSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .eurocode_live_load_settings import EurocodeLiveLoadSettings
        from .eurocode_snow_load_settings import EurocodeSnowLoadSettings
        from .eurocode_temperature_load_settings import EurocodeTemperatureLoadSettings
        from .eurocode_wind_load_settings import EurocodeWindLoadSettings

        from .eurocode_live_load_settings import EurocodeLiveLoadSettings
        from .eurocode_snow_load_settings import EurocodeSnowLoadSettings
        from .eurocode_temperature_load_settings import EurocodeTemperatureLoadSettings
        from .eurocode_wind_load_settings import EurocodeWindLoadSettings

        fields: dict[str, Callable[[Any], None]] = {
            "availableCategoryCount": lambda n : setattr(self, 'available_category_count', n.get_int_value()),
            "gammaEqu": lambda n : setattr(self, 'gamma_equ', n.get_float_value()),
            "gammaGeo": lambda n : setattr(self, 'gamma_geo', n.get_float_value()),
            "gammaStrGeo": lambda n : setattr(self, 'gamma_str_geo', n.get_float_value()),
            "generateAsLeadingAction": lambda n : setattr(self, 'generate_as_leading_action', n.get_bool_value()),
            "psi0": lambda n : setattr(self, 'psi0', n.get_float_value()),
            "psi1": lambda n : setattr(self, 'psi1', n.get_float_value()),
            "psi2": lambda n : setattr(self, 'psi2', n.get_float_value()),
            "$type": lambda n : setattr(self, 'type', n.get_str_value()),
            "userDefinedCategory": lambda n : setattr(self, 'user_defined_category', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("availableCategoryCount", self.available_category_count)
        writer.write_float_value("gammaEqu", self.gamma_equ)
        writer.write_float_value("gammaGeo", self.gamma_geo)
        writer.write_float_value("gammaStrGeo", self.gamma_str_geo)
        writer.write_bool_value("generateAsLeadingAction", self.generate_as_leading_action)
        writer.write_float_value("psi0", self.psi0)
        writer.write_float_value("psi1", self.psi1)
        writer.write_float_value("psi2", self.psi2)
        writer.write_str_value("$type", self.type)
        writer.write_int_value("userDefinedCategory", self.user_defined_category)
    

