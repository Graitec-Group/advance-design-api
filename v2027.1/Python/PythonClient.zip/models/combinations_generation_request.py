from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_combinations_generation_mode import ECombinationsGenerationMode

@dataclass
class CombinationsGenerationRequest(Parsable):
    """
    Input of the automatic combination generation.Everything the generation needs is read from the model: the per-load-casecoefficients (gamma EQU, gamma STR/GEO, psi0/psi1/psi2, duration, category, ...) liveon the load cases themselves and can be set throughAD.API.LoadCaseCombinationsCoefficients, while the generator options - whichproject situations are generated, the per-family coefficient tables, the equationoption - live on the model settings. This request therefore only says WHICHwork-flow to run, not how the standard is parameterized.
    """
    # `DetailedMatrix` only: re-apply the default concomitance rules between load            case families and load cases before generating, which reinitializes the            concomitance matrix. When `false` - the default - the rules set already stored            in the model is used as it is, which is what a model opened from a project file            wants: those rules are what its author set up.
    apply_default_concomitance_rules: Optional[bool] = None
    # Which generation work-flow to run. Defaults to `Simplified`, the templatebased generation.
    mode: Optional[ECombinationsGenerationMode] = None
    # Refresh the normative code of every load case from the combination templatebefore generating (ECG, ECQ, ECN, ...).Leave it unset - which means `true` - for a model built through the API. Thecombination templates match load cases on exactly that code, and a load casecreated through the API carries a neutral default one, so a generation with thisturned off returns no combination at all on such a model. Send `false` onlywhen the codes were already set deliberately and must not be touched, which todaymeans only a model opened from a project file.Nullable on purpose, and not a plain `bool` with a default: a generated clientmirrors the property type, not the initializer, so a non-nullable bool would reachthe server as an explicit `false` whenever the caller did not set it - makingthe useful default unreachable through the client.
    update_load_case_codes: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CombinationsGenerationRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CombinationsGenerationRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CombinationsGenerationRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_combinations_generation_mode import ECombinationsGenerationMode

        from .e_combinations_generation_mode import ECombinationsGenerationMode

        fields: dict[str, Callable[[Any], None]] = {
            "applyDefaultConcomitanceRules": lambda n : setattr(self, 'apply_default_concomitance_rules', n.get_bool_value()),
            "mode": lambda n : setattr(self, 'mode', n.get_enum_value(ECombinationsGenerationMode)),
            "updateLoadCaseCodes": lambda n : setattr(self, 'update_load_case_codes', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("applyDefaultConcomitanceRules", self.apply_default_concomitance_rules)
        writer.write_enum_value("mode", self.mode)
        writer.write_bool_value("updateLoadCaseCodes", self.update_load_case_codes)
    

