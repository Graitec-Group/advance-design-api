from enum import Enum

class Ec3ClassLoadingPattern(str, Enum):
    TensionCompression = "TensionCompression",
    ComposedBending = "ComposedBending",
    FlexuralBuckling = "FlexuralBuckling",
    LateralTorsionalBuckling = "LateralTorsionalBuckling",

