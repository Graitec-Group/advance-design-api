from enum import Enum

class EMeshState(str, Enum):
    Mesh_no = "mesh_no",
    Mesh_available = "mesh_available",
    Mesh_incomplete = "mesh_incomplete",

