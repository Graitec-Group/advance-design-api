from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .steel_non_linear_f_e_m_offset_position import SteelNonLinearFEMOffsetPosition

@dataclass
class NonLinearFEMDistributedSpring(Parsable):
    """
    One distributed elastic spring of the non-linear (2nd order) analysis (maps to the AD modelobject `som.DistributedSpringSupportNLFem`). Typically models the restraint provided by asheeting or a slab over a portion of the element.
    """
    from .steel_non_linear_f_e_m_offset_position import SteelNonLinearFEMOffsetPosition

    # Position of the spring over the height of the cross-section (maps to"OffsetPosition"). Default value : SteelNonLinearFEMOffsetPosition.neutral_fiber
    offset_position: Optional[SteelNonLinearFEMOffsetPosition] = SteelNonLinearFEMOffsetPosition("neutral_fiber")
    # End position of the spring along the element (maps to "AbscissaEnd"). Unit : m Default value : 0.0
    abscissa_end: Optional[float] = None
    # Start position of the spring along the element (maps to "AbscissaStart"). Unit : m Default value : 0.0
    abscissa_start: Optional[float] = None
    # Imposed offset over the height of the cross-section (maps to "OffsetValue"). Unit : m Default value : 0.0
    offset_value: Optional[float] = None
    # Shear field stiffness provided by the sheeting (maps to "ShearField"). Default value : 0.0
    shear_field: Optional[float] = None
    # Torsional spring stiffness KRx (maps to "StiffnessKRx"). Unit : kNm/rad/m Default value : 0.0
    stiffness_k_rx: Optional[float] = None
    # Lateral spring stiffness Ky (maps to "StiffnessKy"). Unit : kN/m/m Default value : 0.0
    stiffness_ky: Optional[float] = None
    # Vertical spring stiffness Kz (maps to "StiffnessKz"). Unit : kN/m/m Default value : 0.0
    stiffness_kz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NonLinearFEMDistributedSpring:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NonLinearFEMDistributedSpring
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NonLinearFEMDistributedSpring()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .steel_non_linear_f_e_m_offset_position import SteelNonLinearFEMOffsetPosition

        from .steel_non_linear_f_e_m_offset_position import SteelNonLinearFEMOffsetPosition

        fields: dict[str, Callable[[Any], None]] = {
            "abscissaEnd": lambda n : setattr(self, 'abscissa_end', n.get_float_value()),
            "abscissaStart": lambda n : setattr(self, 'abscissa_start', n.get_float_value()),
            "offsetPosition": lambda n : setattr(self, 'offset_position', n.get_enum_value(SteelNonLinearFEMOffsetPosition)),
            "offsetValue": lambda n : setattr(self, 'offset_value', n.get_float_value()),
            "shearField": lambda n : setattr(self, 'shear_field', n.get_float_value()),
            "stiffnessKRx": lambda n : setattr(self, 'stiffness_k_rx', n.get_float_value()),
            "stiffnessKy": lambda n : setattr(self, 'stiffness_ky', n.get_float_value()),
            "stiffnessKz": lambda n : setattr(self, 'stiffness_kz', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("abscissaEnd", self.abscissa_end)
        writer.write_float_value("abscissaStart", self.abscissa_start)
        writer.write_enum_value("offsetPosition", self.offset_position)
        writer.write_float_value("offsetValue", self.offset_value)
        writer.write_float_value("shearField", self.shear_field)
        writer.write_float_value("stiffnessKRx", self.stiffness_k_rx)
        writer.write_float_value("stiffnessKy", self.stiffness_ky)
        writer.write_float_value("stiffnessKz", self.stiffness_kz)
    

