from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .eurocode_variable_action_settings import EurocodeVariableActionSettings
    from .e_wind_load_category import EWindLoadCategory

from .eurocode_variable_action_settings import EurocodeVariableActionSettings

@dataclass
class EurocodeWindLoadSettings(EurocodeVariableActionSettings, AdditionalDataHolder, Parsable):
    """
    The wind row of the variable actions grid.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Wind category. The standard tabulates a single one, so this is in practice thechoice between the annex's psi values and your own.
    category: Optional[EWindLoadCategory] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EurocodeWindLoadSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EurocodeWindLoadSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EurocodeWindLoadSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .eurocode_variable_action_settings import EurocodeVariableActionSettings
        from .e_wind_load_category import EWindLoadCategory

        from .eurocode_variable_action_settings import EurocodeVariableActionSettings
        from .e_wind_load_category import EWindLoadCategory

        fields: dict[str, Callable[[Any], None]] = {
            "category": lambda n : setattr(self, 'category', n.get_enum_value(EWindLoadCategory)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("category", self.category)
        writer.write_additional_data_value(self.additional_data)
    

