from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .aisc_formula import AiscFormula
    from .aisc_resistance_check_id import AiscResistanceCheckId
    from .aisc_resistance_error import AiscResistanceError
    from .aisc_resistance_warning import AiscResistanceWarning
    from .csa_formula import CsaFormula

@dataclass
class ResAiscResistanceCheck(Parsable):
    """
    One cross-section resistance check. Native: one of the seven eight-field blocks of aisc_Resistance.
    """
    # The acting (required) strength - a force in N or a moment in N*m depending onAD.API.ResAiscResistanceCheck.Check. Native: df_Action*.
    action: Optional[float] = None
    # The AISC 360 equation the check applied. Set only whenAD.API.ResNorthAmericaSteelLinearDesignData.DesignCode is an AISC edition; null underCSA S16, where AD.API.ResAiscResistanceCheck.AppliedCsaFormula carries it instead. Native: iFormula* holding aFORMULA_* value.
    applied_aisc_formula: Optional[AiscFormula] = None
    # The CSA S16 clause the check applied. Set only whenAD.API.ResNorthAmericaSteelLinearDesignData.DesignCode is a CSA edition; null underAISC 360. Native: the same iFormula* field, holding a CSA_FORMULA_* value.
    applied_csa_formula: Optional[CsaFormula] = None
    # Index of the most unfavourable load combination FOR THIS CHECK, as the engine stores it. Eachcheck keeps its own, so different checks of the same mesh cell normally report differentcombinations. -1 when the check was not performed. Native: iCaseNumber*.
    case_number: Optional[int] = None
    # Which check this is - the suffix of the native field group.
    check: Optional[AiscResistanceCheckId] = None
    # Whether the engine performed this check, and if not, why not. Native: iError*.
    error: Optional[AiscResistanceError] = None
    # True when the engine actually performed this check, so the numbers above are a result rather thanfour zeros. Equivalent to AD.API.ResAiscResistanceCheck.Error being AD.API.AiscResistanceError.None, andreported alongside it so that a client can treat a North American and a Eurocode check the sameway without knowing which flag each carries.
    is_calculated: Optional[bool] = None
    # Abscissa within the mesh cell where the extreme occurred, as an index in the range 0 to 4 - thecell is sampled at its start, quarter points, mid-point and end. -1 when not recorded.Native: iMeshPoint*.
    mesh_point: Optional[int] = None
    # The AVAILABLE strength, in the same unit as AD.API.ResAiscResistanceCheck.Action. What "available" means dependson AD.API.ResAiscResistance.DesignMethod: it is phi * Rn under LRFD and Rn / Omega underASD, the engine having applied the factor before storing it. Native: df_Strength*.
    strength: Optional[float] = None
    # A note the engine attached to the check. Does NOT invalidate the numbers above - the check ran.Native: iWarning*.
    warning: Optional[AiscResistanceWarning] = None
    # Work ratio, dimensionless. Above 1 means the check is not satisfied. Not multiplied by 100.Native: df_WorkRatio*.
    work_ratio: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscResistanceCheck:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscResistanceCheck
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscResistanceCheck()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .aisc_formula import AiscFormula
        from .aisc_resistance_check_id import AiscResistanceCheckId
        from .aisc_resistance_error import AiscResistanceError
        from .aisc_resistance_warning import AiscResistanceWarning
        from .csa_formula import CsaFormula

        from .aisc_formula import AiscFormula
        from .aisc_resistance_check_id import AiscResistanceCheckId
        from .aisc_resistance_error import AiscResistanceError
        from .aisc_resistance_warning import AiscResistanceWarning
        from .csa_formula import CsaFormula

        fields: dict[str, Callable[[Any], None]] = {
            "action": lambda n : setattr(self, 'action', n.get_float_value()),
            "appliedAiscFormula": lambda n : setattr(self, 'applied_aisc_formula', n.get_enum_value(AiscFormula)),
            "appliedCsaFormula": lambda n : setattr(self, 'applied_csa_formula', n.get_enum_value(CsaFormula)),
            "caseNumber": lambda n : setattr(self, 'case_number', n.get_int_value()),
            "check": lambda n : setattr(self, 'check', n.get_enum_value(AiscResistanceCheckId)),
            "error": lambda n : setattr(self, 'error', n.get_enum_value(AiscResistanceError)),
            "isCalculated": lambda n : setattr(self, 'is_calculated', n.get_bool_value()),
            "meshPoint": lambda n : setattr(self, 'mesh_point', n.get_int_value()),
            "strength": lambda n : setattr(self, 'strength', n.get_float_value()),
            "warning": lambda n : setattr(self, 'warning', n.get_enum_value(AiscResistanceWarning)),
            "workRatio": lambda n : setattr(self, 'work_ratio', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("action", self.action)
        writer.write_enum_value("appliedAiscFormula", self.applied_aisc_formula)
        writer.write_enum_value("appliedCsaFormula", self.applied_csa_formula)
        writer.write_int_value("caseNumber", self.case_number)
        writer.write_enum_value("check", self.check)
        writer.write_enum_value("error", self.error)
        writer.write_bool_value("isCalculated", self.is_calculated)
        writer.write_int_value("meshPoint", self.mesh_point)
        writer.write_float_value("strength", self.strength)
        writer.write_enum_value("warning", self.warning)
        writer.write_float_value("workRatio", self.work_ratio)
    

