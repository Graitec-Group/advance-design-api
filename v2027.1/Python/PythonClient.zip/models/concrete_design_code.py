from enum import Enum

class ConcreteDesignCode(str, Enum):
    Bael91 = "bael91",
    Eurocode = "eurocode",
    Aci = "aci",
    Can_csa = "can_csa",
    Ntc2008 = "ntc2008",
    Ntc2018 = "ntc2018",
    Can_csa_2019 = "can_csa_2019",

