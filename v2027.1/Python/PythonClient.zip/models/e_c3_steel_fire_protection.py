from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .steel_fire_protection_mode import SteelFireProtectionMode

@dataclass
class EC3SteelFireProtection(Parsable):
    """
    Passive fire protection of an EC3 steel design template (maps to the AD model object`som.EC3RoleFireProtection`). All the material properties below are ignored by the design engine unlessAD.API.EC3SteelFireProtection.FireProtectionCheck is true.
    """
    from .steel_fire_protection_mode import SteelFireProtectionMode

    # Shape of the protection around the section (maps to "FireProtectionMode"). Default value : SteelFireProtectionMode.contour_encasement
    fire_protection_mode: Optional[SteelFireProtectionMode] = SteelFireProtectionMode("contour_encasement")
    # Whether the member carries a passive fire protection (maps to"FireProtectionCheck"). Default value : false
    fire_protection_check: Optional[bool] = None
    # Density of the protection material (maps to "FireProtectionMaterialDensity"). Unit : kg/m3 Default value : 800.0
    fire_protection_material_density: Optional[float] = None
    # Thickness of the protection material (maps to "FireProtectionThickness"). Unit : m Default value : 0.02
    fire_protection_thickness: Optional[float] = None
    # Specific heat of the protection material (maps to "FireSpecialHeat"). Unit : J/kg/K Default value : 1700.0
    fire_specific_heat: Optional[float] = None
    # Thermal conductivity of the protection material (maps to "ThermalConductivity"). Unit : W/m/K Default value : 0.2
    thermal_conductivity: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelFireProtection:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelFireProtection
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelFireProtection()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .steel_fire_protection_mode import SteelFireProtectionMode

        from .steel_fire_protection_mode import SteelFireProtectionMode

        fields: dict[str, Callable[[Any], None]] = {
            "fireProtectionCheck": lambda n : setattr(self, 'fire_protection_check', n.get_bool_value()),
            "fireProtectionMaterialDensity": lambda n : setattr(self, 'fire_protection_material_density', n.get_float_value()),
            "fireProtectionMode": lambda n : setattr(self, 'fire_protection_mode', n.get_enum_value(SteelFireProtectionMode)),
            "fireProtectionThickness": lambda n : setattr(self, 'fire_protection_thickness', n.get_float_value()),
            "fireSpecificHeat": lambda n : setattr(self, 'fire_specific_heat', n.get_float_value()),
            "thermalConductivity": lambda n : setattr(self, 'thermal_conductivity', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("fireProtectionCheck", self.fire_protection_check)
        writer.write_float_value("fireProtectionMaterialDensity", self.fire_protection_material_density)
        writer.write_enum_value("fireProtectionMode", self.fire_protection_mode)
        writer.write_float_value("fireProtectionThickness", self.fire_protection_thickness)
        writer.write_float_value("fireSpecificHeat", self.fire_specific_heat)
        writer.write_float_value("thermalConductivity", self.thermal_conductivity)
    

