from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .steel_non_linear_f_e_m_loads_offset import SteelNonLinearFEMLoadsOffset

@dataclass
class NonLinearFEMLoadsOffset(Parsable):
    """
    Point of the cross-section at which the loads are applied in the non-linear (2nd order) analysis(maps to the AD model object `som.LoadsOffset`).
    """
    from .steel_non_linear_f_e_m_loads_offset import SteelNonLinearFEMLoadsOffset

    # Point of application of the loads (maps to "OptionOffset"). Default value : SteelNonLinearFEMLoadsOffset.center
    option_offset: Optional[SteelNonLinearFEMLoadsOffset] = SteelNonLinearFEMLoadsOffset("center")
    # Imposed offset of the loads along the local y axis (maps to "ValueOffsetY"). Used only whenAD.API.NonLinearFEMLoadsOffset.OptionOffset isAD.API.SteelNonLinearFEMLoadsOffset.user_defined. Unit : m Default value : 0.0
    value_offset_y: Optional[float] = None
    # Imposed offset of the loads along the local z axis (maps to "ValueOffsetZ"). Unit : m Default value : 0.0
    value_offset_z: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NonLinearFEMLoadsOffset:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NonLinearFEMLoadsOffset
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NonLinearFEMLoadsOffset()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .steel_non_linear_f_e_m_loads_offset import SteelNonLinearFEMLoadsOffset

        from .steel_non_linear_f_e_m_loads_offset import SteelNonLinearFEMLoadsOffset

        fields: dict[str, Callable[[Any], None]] = {
            "optionOffset": lambda n : setattr(self, 'option_offset', n.get_enum_value(SteelNonLinearFEMLoadsOffset)),
            "valueOffsetY": lambda n : setattr(self, 'value_offset_y', n.get_float_value()),
            "valueOffsetZ": lambda n : setattr(self, 'value_offset_z', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("optionOffset", self.option_offset)
        writer.write_float_value("valueOffsetY", self.value_offset_y)
        writer.write_float_value("valueOffsetZ", self.value_offset_z)
    

