from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_steel_calculation_type import ESteelCalculationType

@dataclass
class AiscSteelVerificationSettings(Parsable):
    """
    The Verification page of a model designed to a North-American steel code: which checks theengine performs, and which internal forces it combines.THREE PROPERTIES, AND THAT IS THE WHOLE PAGE. The Eurocode version of this page carriesthirteen; `CGrHypothesesMetalVerificationPage::OnInitDialog` hides all the others underAISC and CAN/CSA, and a hidden control is a setting the desktop application cannot produce:the fire check and its duration - hidden for the six North-American codes, which have nofire verification in Advance Design;the three imperfections, the 2nd order analysis, the columns and beams buckling lengths andthe imperfection generation - hidden for every code outside the Eurocode family, becausethey are EN 1993-1-1 5.3 constructs;the plate (web) buckling method - hidden for every code outside CM66 and the Eurocodefamily, because it is EN 1993-1-5. A North-American model therefore keeps`eMethodWebBucklingUndefined`, which is exactly why that enumeration exposes a"not decided" member;the two 2nd-generation Eurocode groups.The model still STORES all of them, and this API leaves every one of them exactly as itfound it: a read-modify-write of a North-American model touches only the three propertiesbelow, so nothing an older file or a code conversion left behind is disturbed.Every property is optional, so that a `SetModelSettings` request can change one switchwithout restating the rest.
    """
    # Which internal forces the verification combines. Oblique bending by default.
    calculation_type: Optional[ESteelCalculationType] = None
    # Verify the strength of the cross-sections. On by default.
    cross_section_strength: Optional[bool] = None
    # Verify the stability of the elements. On by default.
    element_stability: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AiscSteelVerificationSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AiscSteelVerificationSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AiscSteelVerificationSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_steel_calculation_type import ESteelCalculationType

        from .e_steel_calculation_type import ESteelCalculationType

        fields: dict[str, Callable[[Any], None]] = {
            "calculationType": lambda n : setattr(self, 'calculation_type', n.get_enum_value(ESteelCalculationType)),
            "crossSectionStrength": lambda n : setattr(self, 'cross_section_strength', n.get_bool_value()),
            "elementStability": lambda n : setattr(self, 'element_stability', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("calculationType", self.calculation_type)
        writer.write_bool_value("crossSectionStrength", self.cross_section_strength)
        writer.write_bool_value("elementStability", self.element_stability)
    

