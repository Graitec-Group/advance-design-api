from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class EC3SteelLongitudinalStiffenersRelativePosition(Parsable):
    """
    Positions of the longitudinal stiffeners over the height of the web (maps to the AD model object`som.EC3RoleSDLongitudinalStiffenersRelativePosition`). Both values are relative to the web height, so they belong to the range 0..1.
    """
    # Relative position of the bottom longitudinal stiffener (maps to"BottomStiffenerRelativePosition"). Unit : adimensional, range 0..1 Default value : 0.5
    bottom_stiffener_relative_position: Optional[float] = None
    # Relative position of the top longitudinal stiffener (maps to"TopStiffenerRelativePosition"). Used only when AD.API.EC3SteelWebBucklingLongitudinalStiffeners.LongitudinalStiffenersNumberis AD.API.SteelWebLongitudinalStiffenersNumber.two_stiffeners. Unit : adimensional, range 0..1 Default value : 0.0
    top_stiffener_relative_position: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelLongitudinalStiffenersRelativePosition:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelLongitudinalStiffenersRelativePosition
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelLongitudinalStiffenersRelativePosition()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "bottomStiffenerRelativePosition": lambda n : setattr(self, 'bottom_stiffener_relative_position', n.get_float_value()),
            "topStiffenerRelativePosition": lambda n : setattr(self, 'top_stiffener_relative_position', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("bottomStiffenerRelativePosition", self.bottom_stiffener_relative_position)
        writer.write_float_value("topStiffenerRelativePosition", self.top_stiffener_relative_position)
    

