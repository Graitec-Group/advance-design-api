from enum import Enum

class LicenceProtectionType(str, Enum):
    NoLicence = "NoLicence",
    Demo = "Demo",
    Evaluation = "Evaluation",
    Education = "Education",
    Commercial = "Commercial",
    Reseller = "Reseller",
    Internal = "Internal",
    HomeUse = "HomeUse",
    Unknown = "Unknown",

