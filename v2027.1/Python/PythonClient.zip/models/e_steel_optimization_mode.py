from enum import Enum

class ESteelOptimizationMode(str, Enum):
    EOptimizationParElements = "eOptimizationParElements",
    EOptimizationParSections = "eOptimizationParSections",
    EOptimizationParRole = "eOptimizationParRole",
    EOptimizationParName = "eOptimizationParName",
    EOptimizationParSystems = "eOptimizationParSystems",
    EOptimizationNonExistant = "eOptimizationNonExistant",

