from enum import Enum

class EConcreteCombinationType(str, Enum):
    Uls = "Uls",
    UlsAccidental = "UlsAccidental",
    Sls = "Sls",
    None_ = "None",

