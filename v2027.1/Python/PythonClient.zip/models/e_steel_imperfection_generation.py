from enum import Enum

class ESteelImperfectionGeneration(str, Enum):
    EImperfectionGenerationForGoverningComb = "eImperfectionGenerationForGoverningComb",
    EImperfectionGenerationForAllComb = "eImperfectionGenerationForAllComb",
    EImperfectionGenerationUndefined = "eImperfectionGenerationUndefined",

