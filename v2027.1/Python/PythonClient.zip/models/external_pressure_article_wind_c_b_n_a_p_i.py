from enum import Enum

class ExternalPressureArticle_WindCBN_API(str, Enum):
    Cp_zones_cornersenvelope_using_4_1_7_6__2 = "cp_zones_cornersenvelope_using_4_1_7_6__2",
    Cp_zones_nocorners_4_1_7_5__2and3 = "cp_zones_nocorners_4_1_7_5__2and3",

