from enum import Enum

class AisiSupportLocation(str, Enum):
    End = "End",
    Interior = "Interior",

