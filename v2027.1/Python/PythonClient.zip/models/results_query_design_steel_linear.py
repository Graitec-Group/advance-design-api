from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .results_query_design import ResultsQueryDesign
    from .steel_design_result_set import SteelDesignResultSet
    from .steel_linear_design_result_type import SteelLinearDesignResultType

from .results_query_design import ResultsQueryDesign

@dataclass
class ResultsQueryDesignSteelLinear(ResultsQueryDesign, AdditionalDataHolder, Parsable):
    """
    Query for the design results of steel linear elements.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Result family to extract. Use AD.API.SteelLinearDesignResultType.All to get every familyavailable for the element.
    e_res_type: Optional[SteelLinearDesignResultType] = None
    # Which design engine's results to read. Leave at AD.API.SteelDesignResultSet.Standardunless the cold-formed or the non-linear FEM engine was run: the result types whose names sayso - the ColdFormed* ones andAD.API.SteelLinearDesignResultType.AdvancedStabilityResistance - imply their own resultset and override this property.
    e_result_set: Optional[SteelDesignResultSet] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResultsQueryDesignSteelLinear:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResultsQueryDesignSteelLinear
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResultsQueryDesignSteelLinear()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .results_query_design import ResultsQueryDesign
        from .steel_design_result_set import SteelDesignResultSet
        from .steel_linear_design_result_type import SteelLinearDesignResultType

        from .results_query_design import ResultsQueryDesign
        from .steel_design_result_set import SteelDesignResultSet
        from .steel_linear_design_result_type import SteelLinearDesignResultType

        fields: dict[str, Callable[[Any], None]] = {
            "eResType": lambda n : setattr(self, 'e_res_type', n.get_enum_value(SteelLinearDesignResultType)),
            "eResultSet": lambda n : setattr(self, 'e_result_set', n.get_enum_value(SteelDesignResultSet)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("eResType", self.e_res_type)
        writer.write_enum_value("eResultSet", self.e_result_set)
        writer.write_additional_data_value(self.additional_data)
    

