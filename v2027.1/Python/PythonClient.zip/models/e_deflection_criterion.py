from enum import Enum

class EDeflectionCriterion(str, Enum):
    FirstCriterion = "FirstCriterion",
    SecondCriterion = "SecondCriterion",
    BothCriteria = "BothCriteria",
    None_ = "None",

