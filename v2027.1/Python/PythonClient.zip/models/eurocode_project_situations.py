from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_eurocode_combination_equation import EEurocodeCombinationEquation
    from .e_sls_combination_situation import ESlsCombinationSituation

@dataclass
class EurocodeProjectSituations(Parsable):
    """
    Which project situations the generation produces, and how the serviceability ones arelabelled.Every property is nullable so that a `SetModelSettings` requestcan change one switch without restating the others: what is not sent is left as themodel has it. At least one of the six switches must end up on - a generation with noneproduces nothing - so a request that would turn the last one off is refused.
    """
    # Which ULS equation the fundamental combinations use. Offered by the General,Poland, Czech and Slovakia annexes only.
    equation: Optional[EEurocodeCombinationEquation] = None
    # SLS characteristic. On by default.
    sls_characteristic: Optional[bool] = None
    # Include the permanent actions in the SLS characteristic combinations. Offered bythe UK annex only.
    sls_characteristic_includes_permanent: Optional[bool] = None
    # SLS frequent. Off by default.
    sls_frequent: Optional[bool] = None
    # SLS quasi-permanent. On by default.
    sls_quasi_permanent: Optional[bool] = None
    # Which serviceability situation the generated SLS combinations are labelled with.Independent of the three switches above, which decide which ones are generated atall.
    sls_situation: Optional[ESlsCombinationSituation] = None
    # ULS EQU - loss of static equilibrium. Off by default.
    uls_equilibrium: Optional[bool] = None
    # ULS GEO as a situation of its own, with its own gamma column. Offered by theItalian standards only (Eurocode Italia and NTC 2018); under any other standard thegeneration does not read it.
    uls_geotechnical: Optional[bool] = None
    # ULS STR/GEO - failure of the structure or of the ground. On by default.
    uls_structural_geotechnical: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EurocodeProjectSituations:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EurocodeProjectSituations
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EurocodeProjectSituations()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_eurocode_combination_equation import EEurocodeCombinationEquation
        from .e_sls_combination_situation import ESlsCombinationSituation

        from .e_eurocode_combination_equation import EEurocodeCombinationEquation
        from .e_sls_combination_situation import ESlsCombinationSituation

        fields: dict[str, Callable[[Any], None]] = {
            "equation": lambda n : setattr(self, 'equation', n.get_enum_value(EEurocodeCombinationEquation)),
            "slsCharacteristic": lambda n : setattr(self, 'sls_characteristic', n.get_bool_value()),
            "slsCharacteristicIncludesPermanent": lambda n : setattr(self, 'sls_characteristic_includes_permanent', n.get_bool_value()),
            "slsFrequent": lambda n : setattr(self, 'sls_frequent', n.get_bool_value()),
            "slsQuasiPermanent": lambda n : setattr(self, 'sls_quasi_permanent', n.get_bool_value()),
            "slsSituation": lambda n : setattr(self, 'sls_situation', n.get_enum_value(ESlsCombinationSituation)),
            "ulsEquilibrium": lambda n : setattr(self, 'uls_equilibrium', n.get_bool_value()),
            "ulsGeotechnical": lambda n : setattr(self, 'uls_geotechnical', n.get_bool_value()),
            "ulsStructuralGeotechnical": lambda n : setattr(self, 'uls_structural_geotechnical', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("equation", self.equation)
        writer.write_bool_value("slsCharacteristic", self.sls_characteristic)
        writer.write_bool_value("slsCharacteristicIncludesPermanent", self.sls_characteristic_includes_permanent)
        writer.write_bool_value("slsFrequent", self.sls_frequent)
        writer.write_bool_value("slsQuasiPermanent", self.sls_quasi_permanent)
        writer.write_enum_value("slsSituation", self.sls_situation)
        writer.write_bool_value("ulsEquilibrium", self.uls_equilibrium)
        writer.write_bool_value("ulsGeotechnical", self.uls_geotechnical)
        writer.write_bool_value("ulsStructuralGeotechnical", self.uls_structural_geotechnical)
    

