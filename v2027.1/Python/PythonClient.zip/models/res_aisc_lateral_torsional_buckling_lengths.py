from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

@dataclass
class ResAiscLateralTorsionalBucklingLengths(ResNorthAmericaSteelLinearDesignData, AdditionalDataHolder, Parsable):
    """
    Lateral-torsional buckling (unbraced) lengths and slendernesses.Native: aisc_TorsionalBuckling.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Unbraced length for the inferior flange, in m. Native: dfLbi.
    lbi: Optional[float] = None
    # Ratio of Lbi to the length of the super element. Native: dfLbiOnLSElt.
    lbi_over_super_element_length: Optional[float] = None
    # Unbraced length for the superior flange, in m. Native: dfLbs.
    lbs: Optional[float] = None
    # Ratio of Lbs to the length of the super element. Native: dfLbsOnLSElt.
    lbs_over_super_element_length: Optional[float] = None
    # Slenderness associated with Lbi, dimensionless. Native: dfSlendernessLbi.
    slenderness_lbi: Optional[float] = None
    # Slenderness associated with Lbs, dimensionless. Native: dfSlendernessLbs.
    slenderness_lbs: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscLateralTorsionalBucklingLengths:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscLateralTorsionalBucklingLengths
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscLateralTorsionalBucklingLengths()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

        fields: dict[str, Callable[[Any], None]] = {
            "lbi": lambda n : setattr(self, 'lbi', n.get_float_value()),
            "lbiOverSuperElementLength": lambda n : setattr(self, 'lbi_over_super_element_length', n.get_float_value()),
            "lbs": lambda n : setattr(self, 'lbs', n.get_float_value()),
            "lbsOverSuperElementLength": lambda n : setattr(self, 'lbs_over_super_element_length', n.get_float_value()),
            "slendernessLbi": lambda n : setattr(self, 'slenderness_lbi', n.get_float_value()),
            "slendernessLbs": lambda n : setattr(self, 'slenderness_lbs', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("lbi", self.lbi)
        writer.write_float_value("lbiOverSuperElementLength", self.lbi_over_super_element_length)
        writer.write_float_value("lbs", self.lbs)
        writer.write_float_value("lbsOverSuperElementLength", self.lbs_over_super_element_length)
        writer.write_float_value("slendernessLbi", self.slenderness_lbi)
        writer.write_float_value("slendernessLbs", self.slenderness_lbs)
        writer.write_additional_data_value(self.additional_data)
    

