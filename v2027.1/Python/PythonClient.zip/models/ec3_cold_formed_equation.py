from enum import Enum

class Ec3ColdFormedEquation(str, Enum):
    NoRef = "noRef",
    Eq6_1 = "eq6_1",
    Eq6_2 = "eq6_2",
    Eq6_3 = "eq6_3",
    Eq6_4 = "eq6_4",
    Eq6_5 = "eq6_5",
    Eq6_6 = "eq6_6",
    Eq6_7 = "eq6_7",
    Eq6_8 = "eq6_8",
    Eq6_11a = "eq6_11a",
    Eq6_11b = "eq6_11b",
    Eq6_11c = "eq6_11c",
    Eq6_23 = "eq6_23",
    Eq6_24 = "eq6_24",
    Eq6_25 = "eq6_25",
    Eq6_26 = "eq6_26",
    VERIF_NOT_NECCESSARY = "VERIF_NOT_NECCESSARY",
    Eq8_59 = "eq8_59",
    Eq8_58 = "eq8_58",
    Eq8_57 = "eq8_57",

