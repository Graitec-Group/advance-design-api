from enum import Enum

class ESlsCombinationSituation(str, Enum):
    Characteristic = "Characteristic",
    Frequent = "Frequent",
    QuasiPermanent = "QuasiPermanent",

