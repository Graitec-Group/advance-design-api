from enum import Enum

class ClimaticEurocodeAnnex(str, Enum):
    France = "france",
    Romania = "romania",
    General = "general",
    Uk = "uk",
    Germany = "germany",
    Czech = "czech",
    Poland = "poland",
    Slovakia = "slovakia",
    Spain = "spain",
    Portugal = "portugal",

