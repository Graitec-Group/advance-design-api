from enum import Enum

class AiscClassLoadingPattern(str, Enum):
    AxialForce = "AxialForce",
    BendingYY = "BendingYY",
    BendingZZ = "BendingZZ",
    CombinedForces = "CombinedForces",

