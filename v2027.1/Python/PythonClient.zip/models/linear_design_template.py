from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate
    from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate
    from .design_template import DesignTemplate
    from .e_c3_steel_linear_design_template import EC3SteelLinearDesignTemplate
    from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
    from .steel_linear_design_template import SteelLinearDesignTemplate

from .design_template import DesignTemplate

@dataclass
class LinearDesignTemplate(DesignTemplate, AdditionalDataHolder, Parsable):
    """
    Base class of the Expert design templates that apply to LINEAR elements (beams, columns, bars) -the templates whose AD.API.DesignTemplate.ElementType isAD.API.DesignTemplateElementType.linear. This level of the hierarchy carries no property of its own: it exists so that a linear elementcan refer to "a linear design template" independently of the material family and of the designcode, and so that the planar counterpart can be added later without restructuring. The designproperties are on the leaf classes, e.g. AD.API.EC3SteelLinearDesignTemplate. A linear element references one of these templates throughAD.API.ElementLinear.DesignTemplateId. Available for the descriptive model only.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LinearDesignTemplate:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LinearDesignTemplate
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "AISCSteelLinearDesignTemplate".casefold():
            from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate

            return AISCSteelLinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "CSASteelLinearDesignTemplate".casefold():
            from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate

            return CSASteelLinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "EC3SteelLinearDesignTemplate".casefold():
            from .e_c3_steel_linear_design_template import EC3SteelLinearDesignTemplate

            return EC3SteelLinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "NorthAmericanSteelLinearDesignTemplate".casefold():
            from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate

            return NorthAmericanSteelLinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "SteelLinearDesignTemplate".casefold():
            from .steel_linear_design_template import SteelLinearDesignTemplate

            return SteelLinearDesignTemplate()
        return LinearDesignTemplate()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate
        from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate
        from .design_template import DesignTemplate
        from .e_c3_steel_linear_design_template import EC3SteelLinearDesignTemplate
        from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
        from .steel_linear_design_template import SteelLinearDesignTemplate

        from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate
        from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate
        from .design_template import DesignTemplate
        from .e_c3_steel_linear_design_template import EC3SteelLinearDesignTemplate
        from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
        from .steel_linear_design_template import SteelLinearDesignTemplate

        fields: dict[str, Callable[[Any], None]] = {
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_additional_data_value(self.additional_data)
    

