from enum import Enum

class DesignParameterUnitType(str, Enum):
    InequalitySign = "InequalitySign",
    Force = "Force",
    Moment = "Moment",
    BiMoment = "BiMoment",
    Pressure = "Pressure",
    Adimensional = "Adimensional",
    LengthFeature = "LengthFeature",
    LengthDimension = "LengthDimension",
    LengthElement = "LengthElement",
    Area = "Area",
    SectionModulus = "SectionModulus",
    Inertia = "Inertia",
    WarpingConstant = "WarpingConstant",
    Text = "Text",
    None_ = "None",

