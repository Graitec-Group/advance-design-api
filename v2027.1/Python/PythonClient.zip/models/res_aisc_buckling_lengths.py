from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

@dataclass
class ResAiscBucklingLengths(ResNorthAmericaSteelLinearDesignData, AdditionalDataHolder, Parsable):
    """
    Flexural buckling lengths and the slendernesses derived from them. Native: aisc_Buckling.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Buckling length about y-y, in m - the KL of AISC 360 chapter E and CSA S16 clause 13.3.Native: dfLfy.
    lfy: Optional[float] = None
    # Ratio of a buckling length to the length of the super element, as the engine stores it in thefield named for y-y. Native: dfLfyOnLSElt.
    lfy_over_super_element_length: Optional[float] = None
    # Buckling length about z-z, in m. Native: dfLfz.
    lfz: Optional[float] = None
    # The companion ratio, as stored in the field named for z-z. SeeAD.API.ResAiscBucklingLengths.LfyOverSuperElementLength. Native: dfLfzOnLSElt.
    lfz_over_super_element_length: Optional[float] = None
    # Slenderness ratio KL/r for buckling about y-y, dimensionless. Native: dfSlendernessLfy. A valueabove 200 is what raises AD.API.AiscResistanceWarning.SlendernessRatioAbove200 on theaxial check.
    slenderness_lfy: Optional[float] = None
    # Slenderness ratio KL/r for buckling about z-z, dimensionless. Native: dfSlendernessLfz.
    slenderness_lfz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscBucklingLengths:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscBucklingLengths
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscBucklingLengths()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

        fields: dict[str, Callable[[Any], None]] = {
            "lfy": lambda n : setattr(self, 'lfy', n.get_float_value()),
            "lfyOverSuperElementLength": lambda n : setattr(self, 'lfy_over_super_element_length', n.get_float_value()),
            "lfz": lambda n : setattr(self, 'lfz', n.get_float_value()),
            "lfzOverSuperElementLength": lambda n : setattr(self, 'lfz_over_super_element_length', n.get_float_value()),
            "slendernessLfy": lambda n : setattr(self, 'slenderness_lfy', n.get_float_value()),
            "slendernessLfz": lambda n : setattr(self, 'slenderness_lfz', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("lfy", self.lfy)
        writer.write_float_value("lfyOverSuperElementLength", self.lfy_over_super_element_length)
        writer.write_float_value("lfz", self.lfz)
        writer.write_float_value("lfzOverSuperElementLength", self.lfz_over_super_element_length)
        writer.write_float_value("slendernessLfy", self.slenderness_lfy)
        writer.write_float_value("slendernessLfz", self.slenderness_lfz)
        writer.write_additional_data_value(self.additional_data)
    

