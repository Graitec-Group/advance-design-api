from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .steel_buckling_length_mode import SteelBucklingLengthMode
    from .steel_ltb_critical_moment_mode import SteelLtbCriticalMomentMode
    from .steel_ltb_curve_method import SteelLtbCurveMethod
    from .steel_ltb_end_restraint import SteelLtbEndRestraint
    from .steel_ltb_factor_f_m_mode import SteelLtbFactorFMMode
    from .steel_ltb_f_coefficient_mode import SteelLtbFCoefficientMode
    from .steel_ltb_intermediate_restraint_type import SteelLtbIntermediateRestraintType
    from .steel_ltb_load_application_point import SteelLtbLoadApplicationPoint
    from .steel_ltb_load_type import SteelLtbLoadType
    from .steel_ltb_reference_critical_moment_mode import SteelLtbReferenceCriticalMomentMode
    from .steel_ltb_restraint_definition_type import SteelLtbRestraintDefinitionType

@dataclass
class EC3SteelLateralTorsionalBucklingParameters(Parsable):
    """
    Lateral-torsional buckling parameters of one flange of an EC3 steel design template (maps to theAD model object `som.EC3RoleSDLateralTorsionBucklingParameters`). The same class is used twice, once per flange. It gathers the lateral restraints of the flange,the effective length factors k and kw, the C1 / C2 / C3 coefficients of the elastic criticalmoment Mcr, the point of application of the load, and the method used for the reduction factor.In Advance Design only the load application point and zg / zj appear directly in thedesign-template property list; the rest is edited through the lateral-torsional bucklingparameters dialog. All of them are exposed here.
    """
    from .steel_buckling_length_mode import SteelBucklingLengthMode

    # How the C1 coefficient of the elastic critical moment is obtained (maps to "C1"). Default value : SteelBucklingLengthMode.auto_length
    c1_mode: Optional[SteelBucklingLengthMode] = SteelBucklingLengthMode("auto_length")
    from .steel_buckling_length_mode import SteelBucklingLengthMode

    # How the C2 coefficient of the elastic critical moment is obtained (maps to "C2"). Default value : SteelBucklingLengthMode.auto_length
    c2_mode: Optional[SteelBucklingLengthMode] = SteelBucklingLengthMode("auto_length")
    from .steel_buckling_length_mode import SteelBucklingLengthMode

    # How the C3 coefficient of the elastic critical moment is obtained (maps to "C3"). Default value : SteelBucklingLengthMode.auto_length
    c3_mode: Optional[SteelBucklingLengthMode] = SteelBucklingLengthMode("auto_length")
    from .steel_ltb_curve_method import SteelLtbCurveMethod

    # Method used for the lateral-torsional buckling reduction factor (maps to "CourbeDeversement",French for "lateral-torsional buckling curve"). BEWARE - the members of this enumeration are named after the 1st-generation option list, andunder the 2nd generation Eurocode 3 - which this API does not expose - the very same stored integer isinterpreted against a DIFFERENT and longer list, which agrees with the 1st-generation one onlyon AD.API.SteelLtbCurveMethod.general_case. On a 2nd-generation modelAD.API.SteelLtbCurveMethod.least_favorable therefore selects the buckling of thecompression flange, and AD.API.SteelLtbCurveMethod.most_favorable selects the leastfavourable method; the 2nd generation's own "most favourable" isAD.API.SteelLtbCurveMethod.second_generation_most_favorable, which does not exist underthe 1st generation. Read the full ordinal-by-ordinal table onAD.API.SteelLtbCurveMethod before setting this on a 2nd-generation model. Note also that Advance Design stores AD.API.SteelLtbCurveMethod.least_favorable in everynewly created template whatever the generation, and never converts a template's value when themodel switches generation, so a 2nd-generation template starts out on the buckling of thecompression flange rather than on the 2nd generation's default. Default value : SteelLtbCurveMethod.least_favorable
    curve_method: Optional[SteelLtbCurveMethod] = SteelLtbCurveMethod("least_favorable")
    from .steel_ltb_end_restraint import SteelLtbEndRestraint

    # Lateral restraint at the END end of the element (maps to "MaintienJ"). Default value : SteelLtbEndRestraint.pinned
    end_restraint: Optional[SteelLtbEndRestraint] = SteelLtbEndRestraint("pinned")
    from .steel_ltb_f_coefficient_mode import SteelLtbFCoefficientMode

    # How the f correction coefficient of the reduction factor is obtained (maps to"CoeffF"). Default value : SteelLtbFCoefficientMode.none
    f_coefficient_mode: Optional[SteelLtbFCoefficientMode] = SteelLtbFCoefficientMode("none")
    from .steel_ltb_factor_f_m_mode import SteelLtbFactorFMMode

    # How the fM factor is obtained (maps to "FactorFMChoice"). Default value : SteelLtbFactorFMMode.auto_factor
    factor_f_m_mode: Optional[SteelLtbFactorFMMode] = SteelLtbFactorFMMode("auto_factor")
    from .steel_buckling_length_mode import SteelBucklingLengthMode

    # How the effective length factor k is obtained (maps to "K"). Default value : SteelBucklingLengthMode.imposed
    k_mode: Optional[SteelBucklingLengthMode] = SteelBucklingLengthMode("imposed")
    from .steel_buckling_length_mode import SteelBucklingLengthMode

    # How the warping effective length factor kw is obtained (maps to "KW"). Default value : SteelBucklingLengthMode.imposed
    kw_mode: Optional[SteelBucklingLengthMode] = SteelBucklingLengthMode("imposed")
    from .steel_buckling_length_mode import SteelBucklingLengthMode

    # How the lateral-torsional buckling length is obtained (maps to "Longueur", French for"length"). Default value : SteelBucklingLengthMode.auto_length
    length_mode: Optional[SteelBucklingLengthMode] = SteelBucklingLengthMode("auto_length")
    from .steel_ltb_load_application_point import SteelLtbLoadApplicationPoint

    # Point of application of the transverse load (maps to "PointDeCharge", French for "loadpoint"). Displayed as "Application point". Decides whether the load is destabilising orstabilising. Default value : SteelLtbLoadApplicationPoint.neutral_fiber (the British national annexdefaults to AD.API.SteelLtbLoadApplicationPoint.destabilising instead)
    load_application_point: Optional[SteelLtbLoadApplicationPoint] = SteelLtbLoadApplicationPoint("neutral_fiber")
    from .steel_ltb_load_type import SteelLtbLoadType

    # Loading pattern used to pick the C1 / C2 / C3 coefficients (maps to "TypeChargement", Frenchfor "loading type"). Default value : SteelLtbLoadType.auto_load_type
    load_type: Optional[SteelLtbLoadType] = SteelLtbLoadType("auto_load_type")
    from .steel_ltb_critical_moment_mode import SteelLtbCriticalMomentMode

    # How the elastic critical moment Mcr is obtained (maps to "Mcr"). Only AD.API.SteelLtbCriticalMomentMode.imposed_mcr usesAD.API.EC3SteelLateralTorsionalBucklingParameters.McrValue. Default value : SteelLtbCriticalMomentMode.auto_mcr
    mcr_mode: Optional[SteelLtbCriticalMomentMode] = SteelLtbCriticalMomentMode("auto_mcr")
    from .steel_ltb_reference_critical_moment_mode import SteelLtbReferenceCriticalMomentMode

    # How the reference elastic critical moment Mcr,0 is obtained (maps to "Mcr0"). A DIFFERENT enumeration from AD.API.EC3SteelLateralTorsionalBucklingParameters.McrMode, because the third option of the two nativelists differs: Mcr can be taken from the advanced stability analysis, whereas Mcr,0 can be madeequal to Mcr. Only AD.API.SteelLtbReferenceCriticalMomentMode.imposed_mcr0 usesAD.API.EC3SteelLateralTorsionalBucklingParameters.Mcr0Value. Default value : SteelLtbReferenceCriticalMomentMode.auto_mcr0
    mcr0_mode: Optional[SteelLtbReferenceCriticalMomentMode] = SteelLtbReferenceCriticalMomentMode("auto_mcr0")
    from .steel_ltb_restraint_definition_type import SteelLtbRestraintDefinitionType

    # How the intermediate lateral restraints are positioned along the element (maps to"RestraintDefinitionType"). Default value : SteelLtbRestraintDefinitionType.by_abscissa
    restraint_definition_type: Optional[SteelLtbRestraintDefinitionType] = SteelLtbRestraintDefinitionType("by_abscissa")
    from .steel_ltb_intermediate_restraint_type import SteelLtbIntermediateRestraintType

    # Nature of the intermediate lateral restraints (maps to "RestraintType"). Default value : SteelLtbIntermediateRestraintType.pinned
    restraint_type: Optional[SteelLtbIntermediateRestraintType] = SteelLtbIntermediateRestraintType("pinned")
    from .steel_ltb_end_restraint import SteelLtbEndRestraint

    # Lateral restraint at the START end of the element (maps to "MaintienI", from the French"maintien"). Default value : SteelLtbEndRestraint.pinned
    start_restraint: Optional[SteelLtbEndRestraint] = SteelLtbEndRestraint("pinned")
    # Imposed C1 coefficient (maps to "C1Value"). Unit : adimensional Default value : 0.0
    c1_value: Optional[float] = None
    # Imposed C2 coefficient (maps to "C2Value"). Unit : adimensional Default value : 0.0
    c2_value: Optional[float] = None
    # Imposed C3 coefficient (maps to "C3Value"). Unit : adimensional Default value : 0.0
    c3_value: Optional[float] = None
    # Imposed f coefficient, or imposed kc whenAD.API.EC3SteelLateralTorsionalBucklingParameters.FCoefficientMode is AD.API.SteelLtbFCoefficientMode.imposed_kc (maps to"CoeffFValue"). Unit : adimensional Default value : 0.0
    f_coefficient_value: Optional[float] = None
    # Imposed fM factor (maps to "FactorFMValue"). Used only when AD.API.EC3SteelLateralTorsionalBucklingParameters.FactorFMMode isAD.API.SteelLtbFactorFMMode.user_defined. Unit : adimensional Default value : 1.0
    factor_f_m_value: Optional[float] = None
    # Whether the element is a catalogue profile (maps to "IsProfile"). Default value : true
    is_profile: Optional[bool] = None
    # Effective length factor k (maps to "KValue"). Unit : adimensional Default value : 1.0
    k_value: Optional[float] = None
    # Warping effective length factor kw (maps to "KWValue"). Unit : adimensional Default value : 1.0
    kw_value: Optional[float] = None
    # Imposed lateral-torsional buckling length (maps to "LongueurValue"). Used only whenAD.API.EC3SteelLateralTorsionalBucklingParameters.LengthMode is AD.API.SteelBucklingLengthMode.imposed. Unit : m Default value : 1.0
    length_value: Optional[float] = None
    # Imposed elastic critical moment Mcr (maps to "McrValue"). Unit : kNm Default value : 0.0
    mcr_value: Optional[float] = None
    # Imposed reference elastic critical moment Mcr,0 (maps to "Mcr0Value"). Unit : kNm Default value : 0.0
    mcr0_value: Optional[float] = None
    # The intermediate restraint positions themselves (maps to "RestraintDefinitionValues"). A single string whose content is interpreted according toAD.API.EC3SteelLateralTorsionalBucklingParameters.RestraintDefinitionType: a count, a list of abscissae in metres, or a list ofratios in the range 0..1. Limited to 50 characters. Empty means no intermediaterestraint. Default value : null
    restraint_definition_values: Optional[str] = None
    # Distance zg from the shear centre to the point of load application (maps to "ZG"). Unit : m Default value : 0.0
    zg: Optional[float] = None
    # Mono-symmetry parameter zj of the cross-section (maps to "ZJ"). Unit : m Default value : 0.0
    zj: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelLateralTorsionalBucklingParameters:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelLateralTorsionalBucklingParameters
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelLateralTorsionalBucklingParameters()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .steel_buckling_length_mode import SteelBucklingLengthMode
        from .steel_ltb_critical_moment_mode import SteelLtbCriticalMomentMode
        from .steel_ltb_curve_method import SteelLtbCurveMethod
        from .steel_ltb_end_restraint import SteelLtbEndRestraint
        from .steel_ltb_factor_f_m_mode import SteelLtbFactorFMMode
        from .steel_ltb_f_coefficient_mode import SteelLtbFCoefficientMode
        from .steel_ltb_intermediate_restraint_type import SteelLtbIntermediateRestraintType
        from .steel_ltb_load_application_point import SteelLtbLoadApplicationPoint
        from .steel_ltb_load_type import SteelLtbLoadType
        from .steel_ltb_reference_critical_moment_mode import SteelLtbReferenceCriticalMomentMode
        from .steel_ltb_restraint_definition_type import SteelLtbRestraintDefinitionType

        from .steel_buckling_length_mode import SteelBucklingLengthMode
        from .steel_ltb_critical_moment_mode import SteelLtbCriticalMomentMode
        from .steel_ltb_curve_method import SteelLtbCurveMethod
        from .steel_ltb_end_restraint import SteelLtbEndRestraint
        from .steel_ltb_factor_f_m_mode import SteelLtbFactorFMMode
        from .steel_ltb_f_coefficient_mode import SteelLtbFCoefficientMode
        from .steel_ltb_intermediate_restraint_type import SteelLtbIntermediateRestraintType
        from .steel_ltb_load_application_point import SteelLtbLoadApplicationPoint
        from .steel_ltb_load_type import SteelLtbLoadType
        from .steel_ltb_reference_critical_moment_mode import SteelLtbReferenceCriticalMomentMode
        from .steel_ltb_restraint_definition_type import SteelLtbRestraintDefinitionType

        fields: dict[str, Callable[[Any], None]] = {
            "c1Mode": lambda n : setattr(self, 'c1_mode', n.get_enum_value(SteelBucklingLengthMode)),
            "c1Value": lambda n : setattr(self, 'c1_value', n.get_float_value()),
            "c2Mode": lambda n : setattr(self, 'c2_mode', n.get_enum_value(SteelBucklingLengthMode)),
            "c2Value": lambda n : setattr(self, 'c2_value', n.get_float_value()),
            "c3Mode": lambda n : setattr(self, 'c3_mode', n.get_enum_value(SteelBucklingLengthMode)),
            "c3Value": lambda n : setattr(self, 'c3_value', n.get_float_value()),
            "curveMethod": lambda n : setattr(self, 'curve_method', n.get_enum_value(SteelLtbCurveMethod)),
            "endRestraint": lambda n : setattr(self, 'end_restraint', n.get_enum_value(SteelLtbEndRestraint)),
            "fCoefficientMode": lambda n : setattr(self, 'f_coefficient_mode', n.get_enum_value(SteelLtbFCoefficientMode)),
            "fCoefficientValue": lambda n : setattr(self, 'f_coefficient_value', n.get_float_value()),
            "factorFMMode": lambda n : setattr(self, 'factor_f_m_mode', n.get_enum_value(SteelLtbFactorFMMode)),
            "factorFMValue": lambda n : setattr(self, 'factor_f_m_value', n.get_float_value()),
            "isProfile": lambda n : setattr(self, 'is_profile', n.get_bool_value()),
            "kMode": lambda n : setattr(self, 'k_mode', n.get_enum_value(SteelBucklingLengthMode)),
            "kValue": lambda n : setattr(self, 'k_value', n.get_float_value()),
            "kwMode": lambda n : setattr(self, 'kw_mode', n.get_enum_value(SteelBucklingLengthMode)),
            "kwValue": lambda n : setattr(self, 'kw_value', n.get_float_value()),
            "lengthMode": lambda n : setattr(self, 'length_mode', n.get_enum_value(SteelBucklingLengthMode)),
            "lengthValue": lambda n : setattr(self, 'length_value', n.get_float_value()),
            "loadApplicationPoint": lambda n : setattr(self, 'load_application_point', n.get_enum_value(SteelLtbLoadApplicationPoint)),
            "loadType": lambda n : setattr(self, 'load_type', n.get_enum_value(SteelLtbLoadType)),
            "mcrMode": lambda n : setattr(self, 'mcr_mode', n.get_enum_value(SteelLtbCriticalMomentMode)),
            "mcrValue": lambda n : setattr(self, 'mcr_value', n.get_float_value()),
            "mcr0Mode": lambda n : setattr(self, 'mcr0_mode', n.get_enum_value(SteelLtbReferenceCriticalMomentMode)),
            "mcr0Value": lambda n : setattr(self, 'mcr0_value', n.get_float_value()),
            "restraintDefinitionType": lambda n : setattr(self, 'restraint_definition_type', n.get_enum_value(SteelLtbRestraintDefinitionType)),
            "restraintDefinitionValues": lambda n : setattr(self, 'restraint_definition_values', n.get_str_value()),
            "restraintType": lambda n : setattr(self, 'restraint_type', n.get_enum_value(SteelLtbIntermediateRestraintType)),
            "startRestraint": lambda n : setattr(self, 'start_restraint', n.get_enum_value(SteelLtbEndRestraint)),
            "zg": lambda n : setattr(self, 'zg', n.get_float_value()),
            "zj": lambda n : setattr(self, 'zj', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("c1Mode", self.c1_mode)
        writer.write_float_value("c1Value", self.c1_value)
        writer.write_enum_value("c2Mode", self.c2_mode)
        writer.write_float_value("c2Value", self.c2_value)
        writer.write_enum_value("c3Mode", self.c3_mode)
        writer.write_float_value("c3Value", self.c3_value)
        writer.write_enum_value("curveMethod", self.curve_method)
        writer.write_enum_value("endRestraint", self.end_restraint)
        writer.write_enum_value("fCoefficientMode", self.f_coefficient_mode)
        writer.write_float_value("fCoefficientValue", self.f_coefficient_value)
        writer.write_enum_value("factorFMMode", self.factor_f_m_mode)
        writer.write_float_value("factorFMValue", self.factor_f_m_value)
        writer.write_bool_value("isProfile", self.is_profile)
        writer.write_enum_value("kMode", self.k_mode)
        writer.write_float_value("kValue", self.k_value)
        writer.write_enum_value("kwMode", self.kw_mode)
        writer.write_float_value("kwValue", self.kw_value)
        writer.write_enum_value("lengthMode", self.length_mode)
        writer.write_float_value("lengthValue", self.length_value)
        writer.write_enum_value("loadApplicationPoint", self.load_application_point)
        writer.write_enum_value("loadType", self.load_type)
        writer.write_enum_value("mcrMode", self.mcr_mode)
        writer.write_float_value("mcrValue", self.mcr_value)
        writer.write_enum_value("mcr0Mode", self.mcr0_mode)
        writer.write_float_value("mcr0Value", self.mcr0_value)
        writer.write_enum_value("restraintDefinitionType", self.restraint_definition_type)
        writer.write_str_value("restraintDefinitionValues", self.restraint_definition_values)
        writer.write_enum_value("restraintType", self.restraint_type)
        writer.write_enum_value("startRestraint", self.start_restraint)
        writer.write_float_value("zg", self.zg)
        writer.write_float_value("zj", self.zj)
    

