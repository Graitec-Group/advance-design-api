from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_c3_steel_cold_formed_design import EC3SteelColdFormedDesign
    from .e_c3_steel_fire_verification import EC3SteelFireVerification
    from .e_c3_steel_linear_lateral_torsional_buckling import EC3SteelLinearLateralTorsionalBuckling
    from .e_c3_steel_web_buckling import EC3SteelWebBuckling
    from .steel_angle_verification import SteelAngleVerification
    from .steel_execution_class import SteelExecutionClass
    from .steel_execution_class_type import SteelExecutionClassType
    from .steel_family_of_element import SteelFamilyOfElement
    from .steel_global_sway_imperfections import SteelGlobalSwayImperfections
    from .steel_linear_buckling import SteelLinearBuckling
    from .steel_linear_deflection import SteelLinearDeflection
    from .steel_linear_design_template import SteelLinearDesignTemplate
    from .steel_manufacturing_quality import SteelManufacturingQuality
    from .steel_non_linear_f_e_m import SteelNonLinearFEM
    from .steel_section_class import SteelSectionClass

from .steel_linear_design_template import SteelLinearDesignTemplate

@dataclass
class EC3SteelLinearDesignTemplate(SteelLinearDesignTemplate, AdditionalDataHolder, Parsable):
    """
    Expert design template for linear STEEL elements verified to the EUROCODE (maps to the AD modelobject `som.EC3SteelLinearRole`, held by `som.Role` in its"EC3SteelLinearExpertProperties" slot). This is the leaf of the design-template hierarchy and the class that actually carries the designproperties. It corresponds to the "Design template description" dialog of Advance Design when thematerial is Steel, the element type is Linear and the model's steel design code is a Eurocodeone. The template name is the base-class member AD.API.InformationalElementBase.UserName; itmust be unique among the steel/linear templates of the model and is limited to 50characters. USED BY WHICH DESIGN CODES - this property set is the one Advance Design allocates forAD.API.SteelDesignCode.eurocode,AD.API.SteelDesignCode.ntc2008 and AD.API.SteelDesignCode.ntc2018. Creating thistemplate in a model configured for any other steel code is refused, because the engine wouldnever allocate the Eurocode property set for it; the response diagnostics then name the activecode. A few properties are further restricted to the 2nd-generation Eurocode and are documentedas such. PROPAGATION - assigning the template to a linear element, or editing the template afterwards,copies these properties onto the element's own expert properties through the same mechanism theuser interface uses. Editing a template therefore changes every element that references it. PARTIAL UPDATE - every group below is nullable. On Update, a group left null keeps its storedvalue, so a caller can patch one group without restating the rest. Lists inside a group are theexception: when a list is sent it replaces the stored one in full. Available for the descriptive model only.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .steel_execution_class_type import SteelExecutionClassType

    # Whether the EN 1090-2 execution class is taken from the model settings or imposed on thistemplate (maps to "ExecutionClassType"). Displayed as "Execution class type". Default value : SteelExecutionClassType.global_execution_class
    execution_class_type: Optional[SteelExecutionClassType] = SteelExecutionClassType("global_execution_class")
    from .steel_execution_class import SteelExecutionClass

    # Execution class imposed on this template (maps to "ExecutionClassValue"). Displayed as "Execution class value". Used only when AD.API.EC3SteelLinearDesignTemplate.ExecutionClassType isAD.API.SteelExecutionClassType.imposed_execution_class. Default value : SteelExecutionClass.exc2
    execution_class_value: Optional[SteelExecutionClass] = SteelExecutionClass("exc2")
    from .steel_family_of_element import SteelFamilyOfElement

    # Family of element used together with the consequence class to determine the execution class(maps to "FamilyOfElement"). Displayed as "Family of element". Default value : SteelFamilyOfElement.family_e
    family_of_element: Optional[SteelFamilyOfElement] = SteelFamilyOfElement("family_e")
    from .steel_manufacturing_quality import SteelManufacturingQuality

    # EN 1993-1-6 fabrication tolerance quality class (maps to "ManufacturingQuality"). Displayed as "Manufacturing quality". Default value : SteelManufacturingQuality.class_c
    manufacturing_quality: Optional[SteelManufacturingQuality] = SteelManufacturingQuality("class_c")
    from .steel_section_class import SteelSectionClass

    # Cross-section class (maps to "SectionClass"). Displayed as "Cross section class". OnlyAD.API.SteelSectionClass.class_4 makes the effective characteristics belowmeaningful. Default value : SteelSectionClass.auto_class
    section_class: Optional[SteelSectionClass] = SteelSectionClass("auto_class")
    # "Angle verification" group - the net-area verification of angle sections connected through oneleg (maps to "RoleAngleVerification"). Send null to leave the whole group unchanged on Update. Default value : null
    angle_verification: Optional[SteelAngleVerification] = None
    # "Buckling" group - the flexural and torsional buckling lengths (maps to"RoleLinearBuckling"). Send null to leave the whole group unchanged on Update. Default value : null
    buckling: Optional[SteelLinearBuckling] = None
    # "Cold formed design options" group - the EN 1993-1-3 options (maps to"RoleColdFormedDesignOptions"). Send null to leave the whole group unchanged on Update. Default value : null
    cold_formed_design: Optional[EC3SteelColdFormedDesign] = None
    # "Deflections" group - the serviceability deflection checks of the element and of itssuper-element (maps to "RoleLinearDeflection"). Send null to leave the whole group unchanged on Update. Default value : null
    deflection: Optional[SteelLinearDeflection] = None
    # Imposed shift of the centroid of the effective area along the y axis (maps to "eNy"). Unit : m Default value : 0.0
    e_ny: Optional[float] = None
    # Imposed shift of the centroid of the effective area along the z axis (maps to "eNz"). Unit : m Default value : 0.0
    e_nz: Optional[float] = None
    # "Fire verification" group - the EN 1993-1-2 fire resistance and its passive protection (maps to"RoleFireVerification"). Send null to leave the whole group unchanged on Update. Default value : null
    fire_verification: Optional[EC3SteelFireVerification] = None
    # "Global sway imperfections" group - the EN 1993-1-1 clause 5.3 equivalent geometricimperfections (maps to "RoleGlobalSwayImperfections"). Eurocode only: Advance Design creates this group only for the 1st- and 2nd-generation Eurocode,so it reads back as null under any other steel code. Send null to leave the whole group unchanged on Update. Default value : null
    global_sway_imperfections: Optional[SteelGlobalSwayImperfections] = None
    # Whether the effective Class 4 characteristics below are imposed rather than computed (maps to"ImposedValues"). Meaningful only when AD.API.EC3SteelLinearDesignTemplate.SectionClass isAD.API.SteelSectionClass.class_4. Default value : false
    imposed_values: Optional[bool] = None
    # "Lateral torsional buckling" group, per flange (maps to"RoleLinearLateralTorsionBuckling"). Send null to leave the whole group unchanged on Update. Default value : null
    lateral_torsional_buckling: Optional[EC3SteelLinearLateralTorsionalBuckling] = None
    # "Advance stability (2nd order)" group - the non-linear finite-element analysis with warping andimperfections (maps to "RoleMetalNonLinearFEM"). Send null to leave the whole group unchanged on Update. Default value : null
    non_linear_f_e_m: Optional[SteelNonLinearFEM] = None
    # Imposed effective area of the cross-section (maps to "Sxeff"). Unit : m2 Default value : 0.0
    sxeff: Optional[float] = None
    # "Shear buckling of the web" group - the EN 1993-1-5 verification and its stiffeners (maps to"LinearWebBuckling"). Eurocode only, like AD.API.EC3SteelLinearDesignTemplate.GlobalSwayImperfections. Send null to leave the whole group unchanged on Update. Default value : null
    web_buckling: Optional[EC3SteelWebBuckling] = None
    # Imposed effective section modulus Weff,1 about the y axis (maps to "Weff1y"). Unit : m3 Default value : 0.0
    weff1y: Optional[float] = None
    # Imposed effective section modulus Weff,1 about the z axis (maps to "Weff1z"). Unit : m3 Default value : 0.0
    weff1z: Optional[float] = None
    # Imposed effective section modulus Weff,2 about the y axis (maps to "Weff2y"). Unit : m3 Default value : 0.0
    weff2y: Optional[float] = None
    # Imposed effective section modulus Weff,2 about the z axis (maps to "Weff2z"). Unit : m3 Default value : 0.0
    weff2z: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelLinearDesignTemplate:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelLinearDesignTemplate
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelLinearDesignTemplate()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_c3_steel_cold_formed_design import EC3SteelColdFormedDesign
        from .e_c3_steel_fire_verification import EC3SteelFireVerification
        from .e_c3_steel_linear_lateral_torsional_buckling import EC3SteelLinearLateralTorsionalBuckling
        from .e_c3_steel_web_buckling import EC3SteelWebBuckling
        from .steel_angle_verification import SteelAngleVerification
        from .steel_execution_class import SteelExecutionClass
        from .steel_execution_class_type import SteelExecutionClassType
        from .steel_family_of_element import SteelFamilyOfElement
        from .steel_global_sway_imperfections import SteelGlobalSwayImperfections
        from .steel_linear_buckling import SteelLinearBuckling
        from .steel_linear_deflection import SteelLinearDeflection
        from .steel_linear_design_template import SteelLinearDesignTemplate
        from .steel_manufacturing_quality import SteelManufacturingQuality
        from .steel_non_linear_f_e_m import SteelNonLinearFEM
        from .steel_section_class import SteelSectionClass

        from .e_c3_steel_cold_formed_design import EC3SteelColdFormedDesign
        from .e_c3_steel_fire_verification import EC3SteelFireVerification
        from .e_c3_steel_linear_lateral_torsional_buckling import EC3SteelLinearLateralTorsionalBuckling
        from .e_c3_steel_web_buckling import EC3SteelWebBuckling
        from .steel_angle_verification import SteelAngleVerification
        from .steel_execution_class import SteelExecutionClass
        from .steel_execution_class_type import SteelExecutionClassType
        from .steel_family_of_element import SteelFamilyOfElement
        from .steel_global_sway_imperfections import SteelGlobalSwayImperfections
        from .steel_linear_buckling import SteelLinearBuckling
        from .steel_linear_deflection import SteelLinearDeflection
        from .steel_linear_design_template import SteelLinearDesignTemplate
        from .steel_manufacturing_quality import SteelManufacturingQuality
        from .steel_non_linear_f_e_m import SteelNonLinearFEM
        from .steel_section_class import SteelSectionClass

        fields: dict[str, Callable[[Any], None]] = {
            "angleVerification": lambda n : setattr(self, 'angle_verification', n.get_object_value(SteelAngleVerification)),
            "buckling": lambda n : setattr(self, 'buckling', n.get_object_value(SteelLinearBuckling)),
            "coldFormedDesign": lambda n : setattr(self, 'cold_formed_design', n.get_object_value(EC3SteelColdFormedDesign)),
            "deflection": lambda n : setattr(self, 'deflection', n.get_object_value(SteelLinearDeflection)),
            "eNy": lambda n : setattr(self, 'e_ny', n.get_float_value()),
            "eNz": lambda n : setattr(self, 'e_nz', n.get_float_value()),
            "executionClassType": lambda n : setattr(self, 'execution_class_type', n.get_enum_value(SteelExecutionClassType)),
            "executionClassValue": lambda n : setattr(self, 'execution_class_value', n.get_enum_value(SteelExecutionClass)),
            "familyOfElement": lambda n : setattr(self, 'family_of_element', n.get_enum_value(SteelFamilyOfElement)),
            "fireVerification": lambda n : setattr(self, 'fire_verification', n.get_object_value(EC3SteelFireVerification)),
            "globalSwayImperfections": lambda n : setattr(self, 'global_sway_imperfections', n.get_object_value(SteelGlobalSwayImperfections)),
            "imposedValues": lambda n : setattr(self, 'imposed_values', n.get_bool_value()),
            "lateralTorsionalBuckling": lambda n : setattr(self, 'lateral_torsional_buckling', n.get_object_value(EC3SteelLinearLateralTorsionalBuckling)),
            "manufacturingQuality": lambda n : setattr(self, 'manufacturing_quality', n.get_enum_value(SteelManufacturingQuality)),
            "nonLinearFEM": lambda n : setattr(self, 'non_linear_f_e_m', n.get_object_value(SteelNonLinearFEM)),
            "sectionClass": lambda n : setattr(self, 'section_class', n.get_enum_value(SteelSectionClass)),
            "sxeff": lambda n : setattr(self, 'sxeff', n.get_float_value()),
            "webBuckling": lambda n : setattr(self, 'web_buckling', n.get_object_value(EC3SteelWebBuckling)),
            "weff1y": lambda n : setattr(self, 'weff1y', n.get_float_value()),
            "weff1z": lambda n : setattr(self, 'weff1z', n.get_float_value()),
            "weff2y": lambda n : setattr(self, 'weff2y', n.get_float_value()),
            "weff2z": lambda n : setattr(self, 'weff2z', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("angleVerification", self.angle_verification)
        writer.write_object_value("buckling", self.buckling)
        writer.write_object_value("coldFormedDesign", self.cold_formed_design)
        writer.write_object_value("deflection", self.deflection)
        writer.write_float_value("eNy", self.e_ny)
        writer.write_float_value("eNz", self.e_nz)
        writer.write_enum_value("executionClassType", self.execution_class_type)
        writer.write_enum_value("executionClassValue", self.execution_class_value)
        writer.write_enum_value("familyOfElement", self.family_of_element)
        writer.write_object_value("fireVerification", self.fire_verification)
        writer.write_object_value("globalSwayImperfections", self.global_sway_imperfections)
        writer.write_bool_value("imposedValues", self.imposed_values)
        writer.write_object_value("lateralTorsionalBuckling", self.lateral_torsional_buckling)
        writer.write_enum_value("manufacturingQuality", self.manufacturing_quality)
        writer.write_object_value("nonLinearFEM", self.non_linear_f_e_m)
        writer.write_enum_value("sectionClass", self.section_class)
        writer.write_float_value("sxeff", self.sxeff)
        writer.write_object_value("webBuckling", self.web_buckling)
        writer.write_float_value("weff1y", self.weff1y)
        writer.write_float_value("weff1z", self.weff1z)
        writer.write_float_value("weff2y", self.weff2y)
        writer.write_float_value("weff2z", self.weff2z)
        writer.write_additional_data_value(self.additional_data)
    

