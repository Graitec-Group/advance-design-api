from enum import Enum

class EUSLiveLoadFactorF1(str, Enum):
    PublicAssembly = "PublicAssembly",
    Others = "Others",

