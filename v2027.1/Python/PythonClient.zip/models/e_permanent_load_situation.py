from enum import Enum

class EPermanentLoadSituation(str, Enum):
    Unfavorable = "Unfavorable",
    Favorable = "Favorable",
    FavorableAndUnfavorable = "FavorableAndUnfavorable",
    UserDefined = "UserDefined",

