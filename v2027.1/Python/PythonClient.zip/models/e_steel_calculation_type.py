from enum import Enum

class ESteelCalculationType(str, Enum):
    ETypeDeCalculTractionCompression = "eTypeDeCalculTractionCompression",
    ETypeDeCalculComposedBending = "eTypeDeCalculComposedBending",
    ETypeDeCalculBiaxialBending = "eTypeDeCalculBiaxialBending",

