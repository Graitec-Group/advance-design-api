from enum import Enum

class AiscDesignMethod(str, Enum):
    Unknown = "Unknown",
    ASD = "ASD",
    LRFD = "LRFD",

