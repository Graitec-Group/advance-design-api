from enum import Enum

class ETimberCombinationType(str, Enum):
    Uls = "Uls",
    Sls = "Sls",
    UlsAccidental = "UlsAccidental",

