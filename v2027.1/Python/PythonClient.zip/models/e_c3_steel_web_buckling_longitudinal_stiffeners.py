from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_c3_steel_longitudinal_stiffeners_relative_position import EC3SteelLongitudinalStiffenersRelativePosition
    from .steel_web_longitudinal_stiffeners_number import SteelWebLongitudinalStiffenersNumber
    from .steel_web_stiffeners_sides import SteelWebStiffenersSides

@dataclass
class EC3SteelWebBucklingLongitudinalStiffeners(Parsable):
    """
    Longitudinal stiffeners of the web (maps to the AD model object`som.EC3RoleSDWebBucklingLongitudinalStiffeners`).
    """
    from .steel_web_longitudinal_stiffeners_number import SteelWebLongitudinalStiffenersNumber

    # Number of longitudinal stiffeners (maps to "LongitudinalStiffenersNumber"). With one stiffener only the bottom relative position is used. Default value : SteelWebLongitudinalStiffenersNumber.one_stiffener
    longitudinal_stiffeners_number: Optional[SteelWebLongitudinalStiffenersNumber] = SteelWebLongitudinalStiffenersNumber("one_stiffener")
    from .steel_web_stiffeners_sides import SteelWebStiffenersSides

    # On which sides of the web the longitudinal stiffeners are welded (maps to"LongitudinalStiffenersSides"). Default value : SteelWebStiffenersSides.both_sides_of_web
    longitudinal_stiffeners_sides: Optional[SteelWebStiffenersSides] = SteelWebStiffenersSides("both_sides_of_web")
    # Whether the longitudinal stiffeners are taken into account (maps to"LongitudinalStiffenersChecking"). Default value : false
    longitudinal_stiffeners_checking: Optional[bool] = None
    # Positions of the longitudinal stiffeners over the height of the web (maps to"LongitudinalStiffenersRelativePosition"). Send null to leave the whole group unchanged on Update. Default value : null
    longitudinal_stiffeners_relative_position: Optional[EC3SteelLongitudinalStiffenersRelativePosition] = None
    # Thickness of the longitudinal stiffeners (maps to"LongitudinalStiffenersThickness"). Unit : m Default value : 0.005
    longitudinal_stiffeners_thickness: Optional[float] = None
    # Width of the longitudinal stiffeners (maps to "LongitudinalStiffenersWidth"). Unit : m Default value : 0.1
    longitudinal_stiffeners_width: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelWebBucklingLongitudinalStiffeners:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelWebBucklingLongitudinalStiffeners
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelWebBucklingLongitudinalStiffeners()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_c3_steel_longitudinal_stiffeners_relative_position import EC3SteelLongitudinalStiffenersRelativePosition
        from .steel_web_longitudinal_stiffeners_number import SteelWebLongitudinalStiffenersNumber
        from .steel_web_stiffeners_sides import SteelWebStiffenersSides

        from .e_c3_steel_longitudinal_stiffeners_relative_position import EC3SteelLongitudinalStiffenersRelativePosition
        from .steel_web_longitudinal_stiffeners_number import SteelWebLongitudinalStiffenersNumber
        from .steel_web_stiffeners_sides import SteelWebStiffenersSides

        fields: dict[str, Callable[[Any], None]] = {
            "longitudinalStiffenersChecking": lambda n : setattr(self, 'longitudinal_stiffeners_checking', n.get_bool_value()),
            "longitudinalStiffenersNumber": lambda n : setattr(self, 'longitudinal_stiffeners_number', n.get_enum_value(SteelWebLongitudinalStiffenersNumber)),
            "longitudinalStiffenersRelativePosition": lambda n : setattr(self, 'longitudinal_stiffeners_relative_position', n.get_object_value(EC3SteelLongitudinalStiffenersRelativePosition)),
            "longitudinalStiffenersSides": lambda n : setattr(self, 'longitudinal_stiffeners_sides', n.get_enum_value(SteelWebStiffenersSides)),
            "longitudinalStiffenersThickness": lambda n : setattr(self, 'longitudinal_stiffeners_thickness', n.get_float_value()),
            "longitudinalStiffenersWidth": lambda n : setattr(self, 'longitudinal_stiffeners_width', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("longitudinalStiffenersChecking", self.longitudinal_stiffeners_checking)
        writer.write_enum_value("longitudinalStiffenersNumber", self.longitudinal_stiffeners_number)
        writer.write_object_value("longitudinalStiffenersRelativePosition", self.longitudinal_stiffeners_relative_position)
        writer.write_enum_value("longitudinalStiffenersSides", self.longitudinal_stiffeners_sides)
        writer.write_float_value("longitudinalStiffenersThickness", self.longitudinal_stiffeners_thickness)
        writer.write_float_value("longitudinalStiffenersWidth", self.longitudinal_stiffeners_width)
    

