from enum import Enum

class Ec3FabricationQuality(str, Enum):
    ClassA = "ClassA",
    ClassB = "ClassB",
    ClassC = "ClassC",

