from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResAiscFlexuralDetail(Parsable):
    """
    The quantities behind one flexural strength, AISC 360 chapter F / CSA S16 clauses 13.5 and 13.6.Native: the dfLp* / dfLr* / dfLb* / dfCb* / dfFcr* / dfMn* fields of aisc_Resistance.
    """
    # Lateral-torsional buckling modification factor Cb, dimensionless - the allowance for anon-uniform moment diagram, AISC 360 equation (F1-1). Native: dfCb*.
    cb: Optional[float] = None
    # Critical stress Fcr for lateral-torsional buckling, in N/m^2. Native: dfFcr*.
    fcr: Optional[float] = None
    # Actual unbraced length Lb, in m, for the combination that governed this check - the same quantityAD.API.ResAiscLateralTorsionalBucklingLengths reports per flange along the whole member.Native: dfLb*.
    lb: Optional[float] = None
    # Limiting unbraced length for the plastic moment, Lp, in m. AISC 360 equation (F2-5).Native: dfLp*.
    lp: Optional[float] = None
    # Limiting unbraced length for inelastic lateral-torsional buckling, Lr, in m. AISC 360 equation(F2-6). Native: dfLr*.
    lr: Optional[float] = None
    # NOMINAL flexural strength Mn, in N*m - the governing (smallest) of the applicable limit states.Not reduced by phi or Omega; the reduced value isAD.API.ResAiscResistanceCheck.Strength of the corresponding bending check.Native: dfMn*.
    mn: Optional[float] = None
    # Nominal flexural strength for the FLANGE LOCAL BUCKLING limit state, in N*m. Major axis andAISC 360 only. Native: df_Mny_FLB.
    mn_flange_local_buckling: Optional[float] = None
    # Nominal flexural strength for the LATERAL-TORSIONAL BUCKLING limit state, in N*m. Major axis andAISC 360 only. Native: df_Mny_LTB.
    mn_lateral_torsional_buckling: Optional[float] = None
    # Nominal flexural strength for the WEB LOCAL BUCKLING limit state - or, for the shapes where thatis what applies, local buckling or leg local buckling - in N*m. Major axis and AISC 360 only.Native: df_Mny_LB.
    mn_local_buckling: Optional[float] = None
    # Nominal flexural strength for the TENSION FLANGE YIELDING limit state, in N*m. Major axis andAISC 360 only. Native: df_Mny_TFY.
    mn_tension_flange_yielding: Optional[float] = None
    # Nominal flexural strength for the YIELDING limit state, in N*m. Major axis and AISC 360 only;see the note above. Native: df_Mny_Y.
    mn_yielding: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscFlexuralDetail:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscFlexuralDetail
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscFlexuralDetail()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "cb": lambda n : setattr(self, 'cb', n.get_float_value()),
            "fcr": lambda n : setattr(self, 'fcr', n.get_float_value()),
            "lb": lambda n : setattr(self, 'lb', n.get_float_value()),
            "lp": lambda n : setattr(self, 'lp', n.get_float_value()),
            "lr": lambda n : setattr(self, 'lr', n.get_float_value()),
            "mn": lambda n : setattr(self, 'mn', n.get_float_value()),
            "mn_FlangeLocalBuckling": lambda n : setattr(self, 'mn_flange_local_buckling', n.get_float_value()),
            "mn_LateralTorsionalBuckling": lambda n : setattr(self, 'mn_lateral_torsional_buckling', n.get_float_value()),
            "mn_LocalBuckling": lambda n : setattr(self, 'mn_local_buckling', n.get_float_value()),
            "mn_TensionFlangeYielding": lambda n : setattr(self, 'mn_tension_flange_yielding', n.get_float_value()),
            "mn_Yielding": lambda n : setattr(self, 'mn_yielding', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("cb", self.cb)
        writer.write_float_value("fcr", self.fcr)
        writer.write_float_value("lb", self.lb)
        writer.write_float_value("lp", self.lp)
        writer.write_float_value("lr", self.lr)
        writer.write_float_value("mn", self.mn)
        writer.write_float_value("mn_FlangeLocalBuckling", self.mn_flange_local_buckling)
        writer.write_float_value("mn_LateralTorsionalBuckling", self.mn_lateral_torsional_buckling)
        writer.write_float_value("mn_LocalBuckling", self.mn_local_buckling)
        writer.write_float_value("mn_TensionFlangeYielding", self.mn_tension_flange_yielding)
        writer.write_float_value("mn_Yielding", self.mn_yielding)
    

