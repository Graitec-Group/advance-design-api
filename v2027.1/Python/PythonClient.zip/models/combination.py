from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .composite_combination_design import CompositeCombinationDesign
    from .concrete_combination_design import ConcreteCombinationDesign
    from .e_combination_design_calculation import ECombinationDesignCalculation
    from .e_combination_type import ECombinationType
    from .e_i_d_double_pair import EIDDoublePair
    from .informational_element_base import InformationalElementBase
    from .steel_combination_design import SteelCombinationDesign
    from .timber_combination_design import TimberCombinationDesign

from .informational_element_base import InformationalElementBase

@dataclass
class Combination(InformationalElementBase, AdditionalDataHolder, Parsable):
    """
    Combination object definition
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Properties applied by the composite beam design engine to this combination (pre- andpost-composite profiles and deflections). Default value : null
    composite_design: Optional[CompositeCombinationDesign] = None
    # Properties applied by the reinforced concrete design engine to this combination. Used when AD.API.Combination.DesignCalculations listsAD.API.eCombinationDesignCalculation.ConcreteDesign. Default value : null
    concrete_design: Optional[ConcreteCombinationDesign] = None
    # The design (Expert) calculations this combination takes part in - the API replacement of the"ExpertSelection" bit mask of the AD model. List the calculations by name, in any order; avalue listed twice is applied once. On Create, null and an empty list both mean "no design calculation at all". On Update the two differ: null leaves the selection exactly as it is, so a caller that onlywants to change a load coefficient does not have to restate it, while an empty list is theexplicit "take this combination out of every design calculation". A non-empty list replaceswhatever was selected before. Listing a calculation makes its coefficients mandatory on the AD combination: when thematching group of AD.API.Combination.ConcreteDesign / AD.API.Combination.SteelDesign /AD.API.Combination.TimberDesign / AD.API.Combination.CompositeDesign is not supplied and thecombination does not carry those values yet, they are created with default values and awarning is reported in the response diagnostics. Default value : null (no design calculation)
    design_calculations: Optional[list[ECombinationDesignCalculation]] = None
    # type of combination
    e_combination_type: Optional[ECombinationType] = None
    # ID of the combination - is not an input data, is managed in AD, use it only for get
    id_comb: Optional[int] = None
    # Gets the collection of case coefficients associated with their corresponding AD.API.EID values.
    list_cases_coeffs: Optional[list[EIDDoublePair]] = None
    # Properties applied by the steelwork design engine to this combination (profiles,deflections, connections, fire). Default value : null
    steel_design: Optional[SteelCombinationDesign] = None
    # Properties applied by the timber design engine to this combination (deflections, profiles,fire). Default value : null
    timber_design: Optional[TimberCombinationDesign] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Combination:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Combination
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Combination()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .composite_combination_design import CompositeCombinationDesign
        from .concrete_combination_design import ConcreteCombinationDesign
        from .e_combination_design_calculation import ECombinationDesignCalculation
        from .e_combination_type import ECombinationType
        from .e_i_d_double_pair import EIDDoublePair
        from .informational_element_base import InformationalElementBase
        from .steel_combination_design import SteelCombinationDesign
        from .timber_combination_design import TimberCombinationDesign

        from .composite_combination_design import CompositeCombinationDesign
        from .concrete_combination_design import ConcreteCombinationDesign
        from .e_combination_design_calculation import ECombinationDesignCalculation
        from .e_combination_type import ECombinationType
        from .e_i_d_double_pair import EIDDoublePair
        from .informational_element_base import InformationalElementBase
        from .steel_combination_design import SteelCombinationDesign
        from .timber_combination_design import TimberCombinationDesign

        fields: dict[str, Callable[[Any], None]] = {
            "compositeDesign": lambda n : setattr(self, 'composite_design', n.get_object_value(CompositeCombinationDesign)),
            "concreteDesign": lambda n : setattr(self, 'concrete_design', n.get_object_value(ConcreteCombinationDesign)),
            "designCalculations": lambda n : setattr(self, 'design_calculations', n.get_collection_of_enum_values(ECombinationDesignCalculation)),
            "eCombinationType": lambda n : setattr(self, 'e_combination_type', n.get_enum_value(ECombinationType)),
            "idComb": lambda n : setattr(self, 'id_comb', n.get_int_value()),
            "listCasesCoeffs": lambda n : setattr(self, 'list_cases_coeffs', n.get_collection_of_object_values(EIDDoublePair)),
            "steelDesign": lambda n : setattr(self, 'steel_design', n.get_object_value(SteelCombinationDesign)),
            "timberDesign": lambda n : setattr(self, 'timber_design', n.get_object_value(TimberCombinationDesign)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("compositeDesign", self.composite_design)
        writer.write_object_value("concreteDesign", self.concrete_design)
        writer.write_collection_of_enum_values("designCalculations", self.design_calculations)
        writer.write_enum_value("eCombinationType", self.e_combination_type)
        writer.write_collection_of_object_values("listCasesCoeffs", self.list_cases_coeffs)
        writer.write_object_value("steelDesign", self.steel_design)
        writer.write_object_value("timberDesign", self.timber_design)
        writer.write_additional_data_value(self.additional_data)
    

