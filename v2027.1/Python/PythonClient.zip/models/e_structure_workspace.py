from enum import Enum

class EStructureWorkspace(str, Enum):
    PlaneWorkspace = "planeWorkspace",
    GridWorkspace = "gridWorkspace",
    SpaceWorkspace = "spaceWorkspace",

