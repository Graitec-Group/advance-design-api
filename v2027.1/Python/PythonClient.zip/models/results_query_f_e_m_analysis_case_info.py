from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case_analysis_buckling import LoadCaseAnalysisBuckling
    from .load_case_info import LoadCaseInfo

@dataclass
class ResultsQueryFEM_analysisCaseInfo(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes LoadCaseAnalysisBuckling, LoadCaseInfo
    """
    # Composed type representation for type LoadCaseAnalysisBuckling
    load_case_analysis_buckling: Optional[LoadCaseAnalysisBuckling] = None
    # Composed type representation for type LoadCaseInfo
    load_case_info: Optional[LoadCaseInfo] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResultsQueryFEM_analysisCaseInfo:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResultsQueryFEM_analysisCaseInfo
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = ResultsQueryFEM_analysisCaseInfo()
        if mapping_value and mapping_value.casefold() == "LoadCaseAnalysisBuckling".casefold():
            from .load_case_analysis_buckling import LoadCaseAnalysisBuckling

            result.load_case_analysis_buckling = LoadCaseAnalysisBuckling()
        elif mapping_value and mapping_value.casefold() == "LoadCaseInfo".casefold():
            from .load_case_info import LoadCaseInfo

            result.load_case_info = LoadCaseInfo()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case_analysis_buckling import LoadCaseAnalysisBuckling
        from .load_case_info import LoadCaseInfo

        if self.load_case_analysis_buckling:
            return self.load_case_analysis_buckling.get_field_deserializers()
        if self.load_case_info:
            return self.load_case_info.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.load_case_analysis_buckling:
            writer.write_object_value(None, self.load_case_analysis_buckling)
        elif self.load_case_info:
            writer.write_object_value(None, self.load_case_info)
    

