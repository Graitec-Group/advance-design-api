from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .detailed_mesh_on_segment import DetailedMeshOnSegment

@dataclass
class PolyLineMeshProperties(Parsable):
    """
    Mesh properties of a AD.API.ElementPolyLine (the "Mesh" category of the Advance Designproperty list).A poly line has no surface to mesh, so - unlike AD.API.PlanarElementMeshProperties -there is no mesh type and no density mode: only the on/off flag and, when it is on, one meshdefinition per segment.
    """
    # Mesh definition of each segment of the poly line, one entry per segment, in segment order:`DetailedMeshStylePerEdge[i]` is the segment going from `GeomPtsList[i]` to`GeomPtsList[i+1]`, so a poly line of N points has N-1 entries.Only used when AD.API.PolyLineMeshProperties.MeshActive is true.- On Get: the complete segment list of the element.- On Create / Update: optional. Entries beyond the number of segments are ignored, and the  segments the list does not cover keep their current values - so a shorter list sets only  the first segments. A warning is logged when the count does not match. A null entry is  skipped the same way: that segment keeps its current values.- When an Update changes AD.API.ElementPolyLine.GeomPtsList, the vector is resized to  the new number of segments FIRST (new segments get the Advance Design defaults, extra ones  are dropped), then the list sent in the SAME update is applied on top of it.Default value: null (the segment mesh definitions are left untouched)
    detailed_mesh_style_per_edge: Optional[list[DetailedMeshOnSegment]] = None
    # Whether the poly line is taken into account by the mesh generator. When true, the mesherforces FE nodes along the poly line, following AD.API.PolyLineMeshProperties.DetailedMeshStylePerEdge; whenfalse the poly line is pure reference geometry and is ignored by the analysis model.Nullable, and left unset on purpose: a non-nullable `bool` would reach the server as`false` whenever the client omits it. Omitting the property means "keep the AdvanceDesign default" on Create and "leave the current value untouched" on Update.Unit: no unitDefault value : false
    mesh_active: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PolyLineMeshProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PolyLineMeshProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PolyLineMeshProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .detailed_mesh_on_segment import DetailedMeshOnSegment

        from .detailed_mesh_on_segment import DetailedMeshOnSegment

        fields: dict[str, Callable[[Any], None]] = {
            "detailedMeshStylePerEdge": lambda n : setattr(self, 'detailed_mesh_style_per_edge', n.get_collection_of_object_values(DetailedMeshOnSegment)),
            "meshActive": lambda n : setattr(self, 'mesh_active', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("detailedMeshStylePerEdge", self.detailed_mesh_style_per_edge)
        writer.write_bool_value("meshActive", self.mesh_active)
    

