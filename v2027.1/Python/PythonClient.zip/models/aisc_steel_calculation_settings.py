from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .aisc_steel_verification_settings import AiscSteelVerificationSettings
    from .model_settings_base import ModelSettingsBase
    from .steel_angle_verification_settings import SteelAngleVerificationSettings
    from .steel_buckling_settings import SteelBucklingSettings
    from .steel_calculation_sequence_settings import SteelCalculationSequenceSettings
    from .steel_design_code import SteelDesignCode
    from .steel_optimization_settings import SteelOptimizationSettings
    from .steel_profile_sorting_settings import SteelProfileSortingSettings

from .model_settings_base import ModelSettingsBase

@dataclass
class AiscSteelCalculationSettings(ModelSettingsBase, AdditionalDataHolder, Parsable):
    """
    The general settings of the Expert STEEL design calculation of a model designed to aNORTH-AMERICAN code - the same Calculation Settings dialog of the desktop application, asthat code family sees it.SIX CODES, ONE SHAPE. AISC 360, AISC 360-16 and the four CAN/CSA S16 editions (2009, 2014,2019, 2024) share it. That is not a simplification: every place the dialog branches listsexactly those six together and treats them identically - the same hidden controls on theVerification page, the same single buckling method, the same six tabs. ReadAD.API.AiscSteelCalculationSettings.DesignCode to know which of the six the model actually carries.ONE GROUP OF MODEL SETTINGS. This class is the `SteelAiscCalculation` group ofAD.API.ModelSettingsBase: read with`GetModelSettings(eModelSettingsCategory.SteelAiscCalculation)`, written with`SetModelSettings`, which takes the group from this object's own type, and put back towhat a new model of this code carries with`ResetModelSettings(eModelSettingsCategory.SteelAiscCalculation)`.HOW IT DIFFERS FROM AD.API.Ec3SteelCalculationSettings, tab by tab:NO Partial safety factors page. `CGrMetalHypothesesCalculSheet` adds it inside a switchthat lists the four Eurocode codes only - a North-American verification works with theresistance factor phi (LRFD) or the safety factor Omega (ASD) taken from the code itself,not with a user-editable gamma_M. The gamma fields still exist on the model and are leftuntouched by this group.A Verification page of three properties instead of thirteen - seeAD.API.AiscSteelVerificationSettings.A Buckling page whose only accepted method is `eMethodBucklingGa_Gb` - seeAD.API.SteelBucklingSettings.Method.Optimisation, Sort profiles, Angle verification and Calculation sequence are IDENTICAL, andare literally the same four DTO classes the Eurocode group uses.NOT HERE: THE Kt / Kz FACTORS. `CGrMetalExpertLTBSettingsPage` holds this family's ownlateral-torsional-buckling inputs (KtOption, KtFactor, KzOption, KzFactor) and the modelstores them, but the page is never added to the Calculation Settings sheet for any steelcode and its own per-code switch is commented out - no user can reach those four values.Exposing them here would let this API produce a model state the desktop application cannot,which is the half of the parity rule that is easy to forget. They are round-trippeduntouched. Add the page to the sheet first, then expose them.DESIGN TEMPLATES ARE A SEPARATE AXIS, and they are NOT covered yet: `som.Role` carriesan `AISCSteelLinearExpertProperties` slot beside the Eurocode one, but`CreateDesignTemplate` still refuses anything outside the Eurocode family. Thesesettings apply to the whole model and are read by the design engine whether or not anyelement carries a template.WHEN TO CALL IT. Before `LaunchAnalysis`, for the reasonAD.API.SteelCalculationSettings gives: these values are written to the descriptivemodel, and the analysis model copies them while it is built.All the page sub-objects are optional: a null one leaves that whole page as the model hasit, and inside one a null property leaves that single setting alone.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The Angle verification page. Left untouched when null.
    angle_verification: Optional[SteelAngleVerificationSettings] = None
    # The Buckling page. Left untouched when null.
    buckling: Optional[SteelBucklingSettings] = None
    # The Calculation sequence page. Left untouched when null.
    calculation_sequence: Optional[SteelCalculationSequenceSettings] = None
    # The steel design code the model is configured with - one of `aisc`,`aisc_2016`, `can_csa_s16_2009`, `can_csa_s16_2014`,`can_csa_s16_2019` or `can_csa_s16_2024`. READ ONLY HERE: a value sent in a`SetModelSettings` request is ignored. It is chosen once, for the session, with`Environments.DesignCodes.Steel` - which takes five of the six, `can_csa_s16_2024`being the exception - and comes from the localization when that is left null.It changes nothing in this object - all six behave identically here - but it is whattells a caller which edition the model was actually created for.
    design_code: Optional[SteelDesignCode] = None
    # The Optimisation page. Left untouched when null.
    optimization: Optional[SteelOptimizationSettings] = None
    # The Sort profiles page. Left untouched when null.
    profile_sorting: Optional[SteelProfileSortingSettings] = None
    # The Verification page. Left untouched when null.
    verification: Optional[AiscSteelVerificationSettings] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AiscSteelCalculationSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AiscSteelCalculationSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AiscSteelCalculationSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .aisc_steel_verification_settings import AiscSteelVerificationSettings
        from .model_settings_base import ModelSettingsBase
        from .steel_angle_verification_settings import SteelAngleVerificationSettings
        from .steel_buckling_settings import SteelBucklingSettings
        from .steel_calculation_sequence_settings import SteelCalculationSequenceSettings
        from .steel_design_code import SteelDesignCode
        from .steel_optimization_settings import SteelOptimizationSettings
        from .steel_profile_sorting_settings import SteelProfileSortingSettings

        from .aisc_steel_verification_settings import AiscSteelVerificationSettings
        from .model_settings_base import ModelSettingsBase
        from .steel_angle_verification_settings import SteelAngleVerificationSettings
        from .steel_buckling_settings import SteelBucklingSettings
        from .steel_calculation_sequence_settings import SteelCalculationSequenceSettings
        from .steel_design_code import SteelDesignCode
        from .steel_optimization_settings import SteelOptimizationSettings
        from .steel_profile_sorting_settings import SteelProfileSortingSettings

        fields: dict[str, Callable[[Any], None]] = {
            "angleVerification": lambda n : setattr(self, 'angle_verification', n.get_object_value(SteelAngleVerificationSettings)),
            "buckling": lambda n : setattr(self, 'buckling', n.get_object_value(SteelBucklingSettings)),
            "calculationSequence": lambda n : setattr(self, 'calculation_sequence', n.get_object_value(SteelCalculationSequenceSettings)),
            "designCode": lambda n : setattr(self, 'design_code', n.get_enum_value(SteelDesignCode)),
            "optimization": lambda n : setattr(self, 'optimization', n.get_object_value(SteelOptimizationSettings)),
            "profileSorting": lambda n : setattr(self, 'profile_sorting', n.get_object_value(SteelProfileSortingSettings)),
            "verification": lambda n : setattr(self, 'verification', n.get_object_value(AiscSteelVerificationSettings)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("angleVerification", self.angle_verification)
        writer.write_object_value("buckling", self.buckling)
        writer.write_object_value("calculationSequence", self.calculation_sequence)
        writer.write_enum_value("designCode", self.design_code)
        writer.write_object_value("optimization", self.optimization)
        writer.write_object_value("profileSorting", self.profile_sorting)
        writer.write_object_value("verification", self.verification)
        writer.write_additional_data_value(self.additional_data)
    

