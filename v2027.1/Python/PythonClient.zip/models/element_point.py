from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_base import ElementBase
    from .e_i_d import EID
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class ElementPoint(ElementBase, AdditionalDataHolder, Parsable):
    """
    Geometric point element - the "Point" object of Advance Design (`som.EFFacadePoint`).A point has no stiffness and carries no load: it is a positioned model object used to drivethe mesh (it forces an FE node at its location), to snap other elements onto it, and - underEurocode - to act as the pivot of a steel imperfection force direction. Points are created, read, updated, queried and deleted through the same generic elementendpoints as every other element; query them with`ElementTypeEnum.ElementPoint`.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Local mesh density imposed around the point: the target size of the finite elements in itsneighbourhood. 0 means "no local density", i.e. the global mesh settings apply.Only used when AD.API.ElementPoint.MeshActive is true.Unit: m Default value : 0.0
    density: Optional[float] = None
    # Position of the point in the global coordinate system.Unit: m Default value : (0, 0, 0)
    geom_pt: Optional[Pt3D] = None
    # Marks the point as a pivot for the direction of the steel imperfection forces. It is read bythe steel design when the element's design template sets`ForceDirectionPivotOnSuperElement` to `use_points`. Stored and returned for every model, but only meaningful under Eurocode and 2nd generationEurocode; the desktop hides the property for the other design codes.Unit: no unit Default value : false
    imperfection_force_direction_pivot: Optional[bool] = None
    # Enables magnetism on the point: other elements whose end lies withinAD.API.ElementPoint.MagnetismTolerance of this point are snapped onto it.Unit: no unit Default value : false
    magnetism_status: Optional[bool] = None
    # Radius within which magnetism attracts other elements. Only used whenAD.API.ElementPoint.MagnetismStatus is true.Nullable, and left unset on purpose: a non-nullable `double` would reach the server as`0` whenever the client omits it. Omitting the property means "keep the Advance Designdefault" on Create and "leave the current value untouched" on Update.Unit: m Default value : 0.001
    magnetism_tolerance: Optional[float] = None
    # Whether the point is taken into account by the mesh generator. When true, the mesher forcesan FE node at the point's position; when false the point is ignored by the analysis model.Nullable, and left unset on purpose: a non-nullable `bool` would reach the server as`false` whenever the client omits it. Omitting the property means "keep the AdvanceDesign default" on Create and "leave the current value untouched" on Update.Unit: no unit Default value : true
    mesh_active: Optional[bool] = None
    # Internal ids (AD.API.EID) of the systems (`som.System`) this element belongs to.An element can belong to several systems. - On Get: populated with the element's current systems. - On Create: the element is created in the first listed system and added to the rest; when  empty, it is placed in the model's default root system ("Structure 0"); a listed id that is not an existing system makes the creation fail. - On Update: when non-empty, the element's membership is set to exactly these systems (added  to the new ones, removed from the others); when empty, the membership is left unchanged.  Invalid system ids are rejected (the update fails without changing any membership). - The element always belongs to at least one system: it can never be left with none. If it  would be (its systems were deleted, or the requested membership could not be applied), it is  put back in the root system "Structure 0" and a warning is logged.
    system_i_ds: Optional[list[EID]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementPoint:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementPoint
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementPoint()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_base import ElementBase
        from .e_i_d import EID
        from .pt3_d import Pt3D

        from .element_base import ElementBase
        from .e_i_d import EID
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "density": lambda n : setattr(self, 'density', n.get_float_value()),
            "geomPt": lambda n : setattr(self, 'geom_pt', n.get_object_value(Pt3D)),
            "imperfectionForceDirectionPivot": lambda n : setattr(self, 'imperfection_force_direction_pivot', n.get_bool_value()),
            "magnetismStatus": lambda n : setattr(self, 'magnetism_status', n.get_bool_value()),
            "magnetismTolerance": lambda n : setattr(self, 'magnetism_tolerance', n.get_float_value()),
            "meshActive": lambda n : setattr(self, 'mesh_active', n.get_bool_value()),
            "systemIDs": lambda n : setattr(self, 'system_i_ds', n.get_collection_of_object_values(EID)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("density", self.density)
        writer.write_object_value("geomPt", self.geom_pt)
        writer.write_bool_value("imperfectionForceDirectionPivot", self.imperfection_force_direction_pivot)
        writer.write_bool_value("magnetismStatus", self.magnetism_status)
        writer.write_float_value("magnetismTolerance", self.magnetism_tolerance)
        writer.write_bool_value("meshActive", self.mesh_active)
        writer.write_collection_of_object_values("systemIDs", self.system_i_ds)
        writer.write_additional_data_value(self.additional_data)
    

