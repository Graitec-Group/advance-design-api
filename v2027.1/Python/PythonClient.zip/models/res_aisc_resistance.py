from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .aisc_design_method import AiscDesignMethod
    from .res_aisc_axial_compression_detail import ResAiscAxialCompressionDetail
    from .res_aisc_combined_forces_detail import ResAiscCombinedForcesDetail
    from .res_aisc_flexural_detail import ResAiscFlexuralDetail
    from .res_aisc_resistance_check import ResAiscResistanceCheck
    from .res_aisc_shear_detail import ResAiscShearDetail
    from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

@dataclass
class ResAiscResistance(ResNorthAmericaSteelLinearDesignData, AdditionalDataHolder, Parsable):
    """
    Cross-section resistance checks under a North American code. Native: aisc_Resistance.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Buckling quantities behind the axial check. Meaningful only whenAD.API.ResAiscResistance.IsCompression is true.
    axial_detail: Optional[ResAiscAxialCompressionDetail] = None
    # Quantities behind the bending-about-y-y check, including its lateral-torsional buckling terms.
    bending_y_y_detail: Optional[ResAiscFlexuralDetail] = None
    # Quantities behind the bending-about-z-z check. Its five per-limit-state strengths are ALWAYSnull: the native struct records that breakdown for the major axis only, having no df_Mnz_*counterpart to its five df_Mny_* fields.
    bending_z_z_detail: Optional[ResAiscFlexuralDetail] = None
    # The seven checks, one per member of AD.API.AiscResistanceCheckId. Checks the engine didnot perform are present with AD.API.ResAiscResistanceCheck.IsCalculated false, so that"not checked" stays distinguishable from "checked, utilisation nil".
    checks: Optional[list[ResAiscResistanceCheck]] = None
    # Required and available strengths of every component of the combined-forces interaction.
    combined_forces_detail: Optional[ResAiscCombinedForcesDetail] = None
    # Whether the strengths reported below are LRFD design values or ASD allowable values, under anAISC 360 code. Native: iMethod. See AD.API.AiscDesignMethod - it changes whatAD.API.ResAiscResistanceCheck.Strength means, so read it before comparing a strengthagainst anything.NULL UNDER EVERY CSA S16 CODE, because the question does not apply there and the native fieldcannot be trusted to say so. CSA S16 is limit-states design only - it has no allowable-strengthformat - but iMethod is filled from the model-wide AISC method setting(`DefaultValues::GetAISCMethod()`, ASD by default) whatever code the model runs, so aCanadian result would otherwise claim "ASD". That would be wrong twice over: the S16 routinesforce LRFD for the duration of the computation and then RESTORE the setting(FTEngineAISC S16_Flexure.cpp:1173 and S16_Torsion.cpp:54), so not even the computation used thevalue that ends up in the struct. Reported as null for the same reason`ResAiscFlexuralDetail.Mn_Yielding` and the CSA side of the formula pairing are: a field theengine leaves meaningless must not be handed to a caller as if it meant something.
    design_method: Optional[AiscDesignMethod] = None
    # True when the governing axial force was compression, so the axial check is chapter E / clause13.3 and AD.API.ResAiscResistance.AxialDetail is meaningful. False when it was tension - chapter D / clause13.2, which has no buckling term. Native: bIsCompression.
    is_compression: Optional[bool] = None
    # Quantities behind the shear-along-y check.
    shear_y_detail: Optional[ResAiscShearDetail] = None
    # Quantities behind the shear-along-z check.
    shear_z_detail: Optional[ResAiscShearDetail] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscResistance:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscResistance
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscResistance()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .aisc_design_method import AiscDesignMethod
        from .res_aisc_axial_compression_detail import ResAiscAxialCompressionDetail
        from .res_aisc_combined_forces_detail import ResAiscCombinedForcesDetail
        from .res_aisc_flexural_detail import ResAiscFlexuralDetail
        from .res_aisc_resistance_check import ResAiscResistanceCheck
        from .res_aisc_shear_detail import ResAiscShearDetail
        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

        from .aisc_design_method import AiscDesignMethod
        from .res_aisc_axial_compression_detail import ResAiscAxialCompressionDetail
        from .res_aisc_combined_forces_detail import ResAiscCombinedForcesDetail
        from .res_aisc_flexural_detail import ResAiscFlexuralDetail
        from .res_aisc_resistance_check import ResAiscResistanceCheck
        from .res_aisc_shear_detail import ResAiscShearDetail
        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

        fields: dict[str, Callable[[Any], None]] = {
            "axialDetail": lambda n : setattr(self, 'axial_detail', n.get_object_value(ResAiscAxialCompressionDetail)),
            "bendingYYDetail": lambda n : setattr(self, 'bending_y_y_detail', n.get_object_value(ResAiscFlexuralDetail)),
            "bendingZZDetail": lambda n : setattr(self, 'bending_z_z_detail', n.get_object_value(ResAiscFlexuralDetail)),
            "checks": lambda n : setattr(self, 'checks', n.get_collection_of_object_values(ResAiscResistanceCheck)),
            "combinedForcesDetail": lambda n : setattr(self, 'combined_forces_detail', n.get_object_value(ResAiscCombinedForcesDetail)),
            "designMethod": lambda n : setattr(self, 'design_method', n.get_enum_value(AiscDesignMethod)),
            "isCompression": lambda n : setattr(self, 'is_compression', n.get_bool_value()),
            "shearYDetail": lambda n : setattr(self, 'shear_y_detail', n.get_object_value(ResAiscShearDetail)),
            "shearZDetail": lambda n : setattr(self, 'shear_z_detail', n.get_object_value(ResAiscShearDetail)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("axialDetail", self.axial_detail)
        writer.write_object_value("bendingYYDetail", self.bending_y_y_detail)
        writer.write_object_value("bendingZZDetail", self.bending_z_z_detail)
        writer.write_collection_of_object_values("checks", self.checks)
        writer.write_object_value("combinedForcesDetail", self.combined_forces_detail)
        writer.write_enum_value("designMethod", self.design_method)
        writer.write_bool_value("isCompression", self.is_compression)
        writer.write_object_value("shearYDetail", self.shear_y_detail)
        writer.write_object_value("shearZDetail", self.shear_z_detail)
        writer.write_additional_data_value(self.additional_data)
    

