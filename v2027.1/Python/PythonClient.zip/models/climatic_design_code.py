from enum import Enum

class ClimaticDesignCode(str, Enum):
    France = "france",
    Romania = "romania",
    Eurocode = "eurocode",
    Ntc2008 = "ntc2008",
    Cbnsw2010 = "cbnsw2010",
    Cbnsw2015 = "cbnsw2015",
    Ibc2015 = "ibc2015",
    Ntc2018 = "ntc2018",
    Pr_en13031_1 = "pr_en13031_1",
    Ibc2018 = "ibc2018",
    Cbnsw2020 = "cbnsw2020",
    Asce_7_22 = "asce_7_22",

