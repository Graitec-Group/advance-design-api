from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .informational_element_base import InformationalElementBase
    from .linear_release_nonlinearity_type import LinearReleaseNonlinearityType
    from .linear_release_type import LinearReleaseType

from .informational_element_base import InformationalElementBase

@dataclass
class LinearReleaseTemplate(InformationalElementBase, AdditionalDataHolder, Parsable):
    """
    Linear release template (maps to the AD model object `som.LinearRelease`). Templates live in a single model-level pool and describe how an edge of a planar element isconnected to the rest of the structure. They are defined once and then referenced by theedges of any number of planar elements through AD.API.ElementPlanar.LinearReleases andAD.API.ElementPlanar.SelectedReleaseName - editing a template therefore changes everyedge that uses it. Every model always contains three built-in templates, in this order : - "Free"   : all four degrees of freedom released, - "Pinned" : Tx, Ty, Tz fixed and Rx released, - "Fixed"  : all four degrees of freedom fixed (the default for a new planar element). Their names are localized, so list the templates (query`InformationalElementTypeEnum.LinearReleaseTemplate`) instead of hard-coding a name.The three built-ins cannot be modified nor deleted through the API. The template name is AD.API.LinearReleaseTemplate.LinearReleaseName and it must be unique in the model; thebase-class member AD.API.InformationalElementBase.UserName is not used. Available for the descriptive model only.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .linear_release_type import LinearReleaseType

    # Whether this is one of the three built-in templates or a user-defined one(maps to "LinearReleaseType"). Output only : a template created through the API is alwaysAD.API.LinearReleaseType.user_defined_release. Default value : LinearReleaseType.user_defined_release
    linear_release_type: Optional[LinearReleaseType] = LinearReleaseType("user_defined_release")
    from .linear_release_nonlinearity_type import LinearReleaseNonlinearityType

    # Non-linear behaviour of the Rx release (maps to "RxNonlinearityType"). Default value : LinearReleaseNonlinearityType.none
    rx_nonlinearity_type: Optional[LinearReleaseNonlinearityType] = LinearReleaseNonlinearityType("none")
    from .linear_release_nonlinearity_type import LinearReleaseNonlinearityType

    # Non-linear behaviour of the Tx release (maps to "TxNonlinearityType"). Default value : LinearReleaseNonlinearityType.none
    tx_nonlinearity_type: Optional[LinearReleaseNonlinearityType] = LinearReleaseNonlinearityType("none")
    from .linear_release_nonlinearity_type import LinearReleaseNonlinearityType

    # Non-linear behaviour of the Ty release (maps to "TyNonlinearityType"). Default value : LinearReleaseNonlinearityType.none
    ty_nonlinearity_type: Optional[LinearReleaseNonlinearityType] = LinearReleaseNonlinearityType("none")
    from .linear_release_nonlinearity_type import LinearReleaseNonlinearityType

    # Non-linear behaviour of the Tz release (maps to "TzNonlinearityType"). Default value : LinearReleaseNonlinearityType.none
    tz_nonlinearity_type: Optional[LinearReleaseNonlinearityType] = LinearReleaseNonlinearityType("none")
    # Name of the template (maps to "LinearReleaseName"), unique in the model and limited to 50characters. It is the value referenced by AD.API.ElementPlanar.SelectedReleaseName. Mandatory on Create and Update: an empty name, or one longer than 50 characters, is refused withan error in the response diagnostics. Renaming a template on Update also updates theAD.API.ElementPlanar.SelectedReleaseName of every planar element that used the old name.
    linear_release_name: Optional[str] = None
    # Release of the rotation about the edge axis (maps to "Rx"). true = released (free), false = fixed. This is the only rotational release of a linearrelease : there is no Ry nor Rz. Default value : false
    rx: Optional[bool] = None
    # Elastic stiffness of the Rx release, used when AD.API.LinearReleaseTemplate.Rx is true (maps to "StiffnessRx");0 means a perfectly free release. Unit : kNm/rad/m Default value : 0.0
    stiffness_rx: Optional[float] = None
    # Elastic stiffness of the Tx release, used when AD.API.LinearReleaseTemplate.Tx is true (maps to "StiffnessTx");0 means a perfectly free release. Unit : kN/m/m Default value : 0.0
    stiffness_tx: Optional[float] = None
    # Elastic stiffness of the Ty release, used when AD.API.LinearReleaseTemplate.Ty is true (maps to "StiffnessTy");0 means a perfectly free release. Unit : kN/m/m Default value : 0.0
    stiffness_ty: Optional[float] = None
    # Elastic stiffness of the Tz release, used when AD.API.LinearReleaseTemplate.Tz is true (maps to "StiffnessTz");0 means a perfectly free release. Unit : kN/m/m Default value : 0.0
    stiffness_tz: Optional[float] = None
    # Release of the translation along the local x axis of the edge (maps to "Tx"). true = released (free), false = fixed. Default value : false
    tx: Optional[bool] = None
    # Release of the translation along the local y axis of the edge (maps to "Ty"). true = released (free), false = fixed. Default value : false
    ty: Optional[bool] = None
    # Release of the translation along the local z axis of the edge (maps to "Tz"). true = released (free), false = fixed. Default value : false
    tz: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LinearReleaseTemplate:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LinearReleaseTemplate
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LinearReleaseTemplate()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .informational_element_base import InformationalElementBase
        from .linear_release_nonlinearity_type import LinearReleaseNonlinearityType
        from .linear_release_type import LinearReleaseType

        from .informational_element_base import InformationalElementBase
        from .linear_release_nonlinearity_type import LinearReleaseNonlinearityType
        from .linear_release_type import LinearReleaseType

        fields: dict[str, Callable[[Any], None]] = {
            "linearReleaseName": lambda n : setattr(self, 'linear_release_name', n.get_str_value()),
            "linearReleaseType": lambda n : setattr(self, 'linear_release_type', n.get_enum_value(LinearReleaseType)),
            "rx": lambda n : setattr(self, 'rx', n.get_bool_value()),
            "rxNonlinearityType": lambda n : setattr(self, 'rx_nonlinearity_type', n.get_enum_value(LinearReleaseNonlinearityType)),
            "stiffnessRx": lambda n : setattr(self, 'stiffness_rx', n.get_float_value()),
            "stiffnessTx": lambda n : setattr(self, 'stiffness_tx', n.get_float_value()),
            "stiffnessTy": lambda n : setattr(self, 'stiffness_ty', n.get_float_value()),
            "stiffnessTz": lambda n : setattr(self, 'stiffness_tz', n.get_float_value()),
            "tx": lambda n : setattr(self, 'tx', n.get_bool_value()),
            "txNonlinearityType": lambda n : setattr(self, 'tx_nonlinearity_type', n.get_enum_value(LinearReleaseNonlinearityType)),
            "ty": lambda n : setattr(self, 'ty', n.get_bool_value()),
            "tyNonlinearityType": lambda n : setattr(self, 'ty_nonlinearity_type', n.get_enum_value(LinearReleaseNonlinearityType)),
            "tz": lambda n : setattr(self, 'tz', n.get_bool_value()),
            "tzNonlinearityType": lambda n : setattr(self, 'tz_nonlinearity_type', n.get_enum_value(LinearReleaseNonlinearityType)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_str_value("linearReleaseName", self.linear_release_name)
        writer.write_enum_value("linearReleaseType", self.linear_release_type)
        writer.write_bool_value("rx", self.rx)
        writer.write_enum_value("rxNonlinearityType", self.rx_nonlinearity_type)
        writer.write_float_value("stiffnessRx", self.stiffness_rx)
        writer.write_float_value("stiffnessTx", self.stiffness_tx)
        writer.write_float_value("stiffnessTy", self.stiffness_ty)
        writer.write_float_value("stiffnessTz", self.stiffness_tz)
        writer.write_bool_value("tx", self.tx)
        writer.write_enum_value("txNonlinearityType", self.tx_nonlinearity_type)
        writer.write_bool_value("ty", self.ty)
        writer.write_enum_value("tyNonlinearityType", self.ty_nonlinearity_type)
        writer.write_bool_value("tz", self.tz)
        writer.write_enum_value("tzNonlinearityType", self.tz_nonlinearity_type)
        writer.write_additional_data_value(self.additional_data)
    

