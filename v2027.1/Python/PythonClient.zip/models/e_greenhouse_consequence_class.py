from enum import Enum

class EGreenhouseConsequenceClass(str, Enum):
    C0 = "C0",
    C1 = "C1",
    C2 = "C2",
    Other = "Other",

