from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResAiscAxialCompressionDetail(Parsable):
    """
    The quantities behind the axial COMPRESSION strength of AISC 360 chapter E / CSA S16 clause 13.3.Native: the df_KLr / df_Fe / df_Fcr / df_Pn fields of aisc_Resistance.
    """
    # Critical stress Fcr, in N/m^2 - Fe reduced for inelastic buckling by equation (E3-2) or (E3-3).Native: df_Fcr.NULL UNDER EVERY CSA S16 CODE, this one because the quantity does not exist there: clause 13.3.1goes from the non-dimensional slenderness straight to the factored resistance Cr, with nointermediate critical stress, so the CSA branch leaves the field at zero. A reported 0.0 Pa wouldread as a real, and alarming, answer.
    fcr: Optional[float] = None
    # Elastic (Euler) critical buckling stress Fe, in N/m^2. AISC 360 equation (E3-4).Native: df_Fe.NULL UNDER EVERY CSA S16 CODE, and the reason is a unit defect in the writer rather than amissing quantity. The engine DOES compute it on the CSA branch - verified as exactlypi^2 E / (KL/r)^2 with E = 200 GPa, to all reported digits, on two different members - but theCSA branch stores it WITHOUT the conversion its AISC sibling applies: the AISC path writes`KSI_TO_PA(df_Fe)` and the CSA path writes `df_Fe` unchanged(`GrMetalSolverManagerAISC.cpp:8219` against `:8225`). The struct therefore holdsMEGApascals in a field this property declares as pascals - 3308.4 where 3.3084e9 is meant, afactor of a million.Reported as null rather than converted here on purpose, and FIXING THE WRITER WOULD NOT BY ITSELFmake it safe to report. The value is persisted into the result file, so after such a fix a modelcalculated before it still holds MPa and one calculated after holds Pa, with nothing in the fileto tell the two apart - a reader would have to guess, and guessing wrong is a factor of a million.Re-enabling this property therefore needs the writer corrected AND something that distinguishesthe two vintages, such as a result-file version. Rescaling in the mapper instead would be worsestill: it would be silently wrong for every model calculated after the writer is fixed.Note that only this API reads the field under CSA - Advance Design's own Canadian shape sheetnever prints Fe (GrTableExpertMetalProfileInfoCA.cpp does not reference it), which is why thedefect went unnoticed. So nothing in the application depends on the current MPa value either.
    fe: Optional[float] = None
    # Governing slenderness ratio KL/r, dimensionless - the larger of the two axes'.Native: df_KLr.
    k_lr: Optional[float] = None
    # NOMINAL compressive strength Pn = Fcr * Ag, in N. Note this is the nominal value, NOT reduced byphi or Omega - the reduced one is AD.API.ResAiscResistanceCheck.Strength of the axialcheck. Native: df_Pn.
    pn: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscAxialCompressionDetail:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscAxialCompressionDetail
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscAxialCompressionDetail()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "fcr": lambda n : setattr(self, 'fcr', n.get_float_value()),
            "fe": lambda n : setattr(self, 'fe', n.get_float_value()),
            "kLr": lambda n : setattr(self, 'k_lr', n.get_float_value()),
            "pn": lambda n : setattr(self, 'pn', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("fcr", self.fcr)
        writer.write_float_value("fe", self.fe)
        writer.write_float_value("kLr", self.k_lr)
        writer.write_float_value("pn", self.pn)
    

