from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_design_verification_state import EDesignVerificationState

@dataclass
class CombinationConnectionVerification(Parsable):
    """
    Coefficients of the steel connections verification for one combination (maps to the AD modelobject `som.MetalConnectionFields`). Every property is optional: a property left null is filled with the value the Advance Designcombinations dialog would apply, taken from the design settings of the model.
    """
    # Partial safety factor applied to the connection resistance (maps to"CoeficientSecurity"). Default value : null (the model property "ConnectionsSecurityCoeff")
    safety_factor: Optional[float] = None
    # Whether the verification is really evaluated for this combination (maps to "Type"). Default value : null (Active)
    state: Optional[EDesignVerificationState] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CombinationConnectionVerification:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CombinationConnectionVerification
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CombinationConnectionVerification()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_design_verification_state import EDesignVerificationState

        from .e_design_verification_state import EDesignVerificationState

        fields: dict[str, Callable[[Any], None]] = {
            "safetyFactor": lambda n : setattr(self, 'safety_factor', n.get_float_value()),
            "state": lambda n : setattr(self, 'state', n.get_enum_value(EDesignVerificationState)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("safetyFactor", self.safety_factor)
        writer.write_enum_value("state", self.state)
    

