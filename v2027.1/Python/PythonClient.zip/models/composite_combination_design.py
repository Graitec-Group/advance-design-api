from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .combination_deflection_verification import CombinationDeflectionVerification
    from .combination_profile_verification import CombinationProfileVerification

@dataclass
class CompositeCombinationDesign(Parsable):
    """
    Properties applied by the composite beam design engine to one combination. A composite beam is verified twice: at the construction stage, when the steel section acts alone("pre-composite"), and at the final stage, when the composite section acts ("post-composite").Each stage has its own strength and deflection group. Each group matches one design calculation and is relevant only when the combination lists it:AD.API.eCombinationDesignCalculation.PreCompositeProfiles,AD.API.eCombinationDesignCalculation.PostCompositeProfiles,AD.API.eCombinationDesignCalculation.PreCompositeDeflections andAD.API.eCombinationDesignCalculation.PostCompositeDeflections.
    """
    # Final-stage deflection verification, composite section (maps to"ExpertPostCompositeDeflection"). Default value : null
    post_composite_deflections: Optional[CombinationDeflectionVerification] = None
    # Final-stage strength verification, composite section (maps to"ExpertPostCompositeProfile"). Default value : null
    post_composite_profiles: Optional[CombinationProfileVerification] = None
    # Construction-stage deflection verification, steel section alone (maps to"ExpertPreCompositeDeflection"). Default value : null
    pre_composite_deflections: Optional[CombinationDeflectionVerification] = None
    # Construction-stage strength verification, steel section alone (maps to"ExpertPreCompositeProfile"). Default value : null
    pre_composite_profiles: Optional[CombinationProfileVerification] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CompositeCombinationDesign:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CompositeCombinationDesign
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CompositeCombinationDesign()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .combination_deflection_verification import CombinationDeflectionVerification
        from .combination_profile_verification import CombinationProfileVerification

        from .combination_deflection_verification import CombinationDeflectionVerification
        from .combination_profile_verification import CombinationProfileVerification

        fields: dict[str, Callable[[Any], None]] = {
            "postCompositeDeflections": lambda n : setattr(self, 'post_composite_deflections', n.get_object_value(CombinationDeflectionVerification)),
            "postCompositeProfiles": lambda n : setattr(self, 'post_composite_profiles', n.get_object_value(CombinationProfileVerification)),
            "preCompositeDeflections": lambda n : setattr(self, 'pre_composite_deflections', n.get_object_value(CombinationDeflectionVerification)),
            "preCompositeProfiles": lambda n : setattr(self, 'pre_composite_profiles', n.get_object_value(CombinationProfileVerification)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("postCompositeDeflections", self.post_composite_deflections)
        writer.write_object_value("postCompositeProfiles", self.post_composite_profiles)
        writer.write_object_value("preCompositeDeflections", self.pre_composite_deflections)
        writer.write_object_value("preCompositeProfiles", self.pre_composite_profiles)
    

