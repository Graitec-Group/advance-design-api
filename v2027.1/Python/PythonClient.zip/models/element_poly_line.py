from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_base import ElementBase
    from .e_i_d import EID
    from .poly_line_mesh_properties import PolyLineMeshProperties
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class ElementPolyLine(ElementBase, AdditionalDataHolder, Parsable):
    """
    Geometric poly line element - the "Polyline" object of Advance Design (`som.EFFacadeCurve`),listed as "Line" in the model tree.A poly line has no stiffness, no material, no section and carries no load: it is a chain ofstraight segments used as reference geometry - to drive the mesh (it forces FE nodes along itssegments when AD.API.PolyLineMeshProperties.MeshActive is set) and to snap or constructother elements onto it.Its geometry is given as a point list exactly like AD.API.ElementPlanar, but it is onlythe outline: it is NOT closed, NOT required to be planar, and may intersect itself. SeeAD.API.ElementPolyLine.GeomPtsList.Poly lines are created, read, updated, queried and deleted through the same generic elementendpoints as every other element; query them with`ElementTypeEnum.ElementPolyLine`.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Geometry defined by a 3D point list in the global axis system, in drawing order: the poly lineis the chain of straight segments `GeomPtsList[0] -> GeomPtsList[1] -> ... `, so Npoints give N-1 segments.The rules are exactly the ones of the interactive Polyline command, and nothing more:- <b>At least 2 points.</b> A shorter list is refused: the element is not created, and on Update  nothing at all is modified (the element keeps its previous geometry).- <b>A point coincident with the one before it is DROPPED</b>, not refused - Advance Design skips  the zero-length segment the same way. The dropped points are reported as a warning, and both the  read-back geometry and AD.API.PolyLineMeshProperties.DetailedMeshStylePerEdge are indexed  on the segments that remain. A list where nothing survives (every point coincident with the  previous one, so no segment at all) is refused.Everything else is accepted, exactly like in Advance Design:- <b>Aligned points are fine</b> - any number of them. They simply make collinear segments;  alignment is only used internally to pick a non-degenerate local frame.- The poly line is <b>not required to be planar</b> and <b>may cross itself</b>.- There is <b>no maximum</b> number of points.Unlike the contour of a planar element, a poly line is NOT implicitly closed. To close it, repeatthe first point as the last one; a closed poly line reads back the same way, with the closingpoint repeated, so `GeomPtsList.Count - 1` is always the number of segments.Unit: m
    geom_pts_list: Optional[list[Pt3D]] = None
    # Mesh propertiesDefault value : optional nullable object
    mesh_properties: Optional[PolyLineMeshProperties] = None
    # Internal ids (AD.API.EID) of the systems (`som.System`) this element belongs to.An element can belong to several systems. - On Get: populated with the element's current systems. - On Create: the element is created in the first listed system and added to the rest; when  empty, it is placed in the model's default root system ("Structure 0"); a listed id that is not an existing system makes the creation fail. - On Update: when non-empty, the element's membership is set to exactly these systems (added  to the new ones, removed from the others); when empty, the membership is left unchanged.  Invalid system ids are rejected (the update fails without changing any membership). - The element always belongs to at least one system: it can never be left with none. If it  would be (its systems were deleted, or the requested membership could not be applied), it is  put back in the root system "Structure 0" and a warning is logged.
    system_i_ds: Optional[list[EID]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementPolyLine:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementPolyLine
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementPolyLine()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_base import ElementBase
        from .e_i_d import EID
        from .poly_line_mesh_properties import PolyLineMeshProperties
        from .pt3_d import Pt3D

        from .element_base import ElementBase
        from .e_i_d import EID
        from .poly_line_mesh_properties import PolyLineMeshProperties
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "geomPtsList": lambda n : setattr(self, 'geom_pts_list', n.get_collection_of_object_values(Pt3D)),
            "meshProperties": lambda n : setattr(self, 'mesh_properties', n.get_object_value(PolyLineMeshProperties)),
            "systemIDs": lambda n : setattr(self, 'system_i_ds', n.get_collection_of_object_values(EID)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_collection_of_object_values("geomPtsList", self.geom_pts_list)
        writer.write_object_value("meshProperties", self.mesh_properties)
        writer.write_collection_of_object_values("systemIDs", self.system_i_ds)
        writer.write_additional_data_value(self.additional_data)
    

