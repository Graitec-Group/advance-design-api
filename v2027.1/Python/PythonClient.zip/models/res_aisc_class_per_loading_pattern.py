from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .aisc_class_loading_pattern import AiscClassLoadingPattern
    from .aisc_cross_section_class import AiscCrossSectionClass
    from .csa_cross_section_class import CsaCrossSectionClass
    from .res_aisc_section_part import ResAiscSectionPart

@dataclass
class ResAiscClassPerLoadingPattern(Parsable):
    """
    The classification of the cross-section against one stress pattern.
    """
    # Class of the cross-section as a whole under this pattern, AISC 360. Set only under an AISCedition. Native: iClass_* holding an AISC_CROSS_SECTION_CLASS. The native default is -1, meaningthe pattern was not classified, which is reported as AD.API.AiscCrossSectionClass.Unknown.
    aisc_section_class: Optional[AiscCrossSectionClass] = None
    # Class of the cross-section as a whole under this pattern, CSA S16. Set only under a CSA edition.Native: the same iClass_* field, holding a CSA_CROSS_SECTION_CLASS.
    csa_section_class: Optional[CsaCrossSectionClass] = None
    # Which stress pattern this classification was performed against.
    loading_pattern: Optional[AiscClassLoadingPattern] = None
    # Per-plate classification under this pattern, as many entries as the section has parts.Native: iPartType_* and iPartClass*.
    parts: Optional[list[ResAiscSectionPart]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscClassPerLoadingPattern:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscClassPerLoadingPattern
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscClassPerLoadingPattern()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .aisc_class_loading_pattern import AiscClassLoadingPattern
        from .aisc_cross_section_class import AiscCrossSectionClass
        from .csa_cross_section_class import CsaCrossSectionClass
        from .res_aisc_section_part import ResAiscSectionPart

        from .aisc_class_loading_pattern import AiscClassLoadingPattern
        from .aisc_cross_section_class import AiscCrossSectionClass
        from .csa_cross_section_class import CsaCrossSectionClass
        from .res_aisc_section_part import ResAiscSectionPart

        fields: dict[str, Callable[[Any], None]] = {
            "aiscSectionClass": lambda n : setattr(self, 'aisc_section_class', n.get_enum_value(AiscCrossSectionClass)),
            "csaSectionClass": lambda n : setattr(self, 'csa_section_class', n.get_enum_value(CsaCrossSectionClass)),
            "loadingPattern": lambda n : setattr(self, 'loading_pattern', n.get_enum_value(AiscClassLoadingPattern)),
            "parts": lambda n : setattr(self, 'parts', n.get_collection_of_object_values(ResAiscSectionPart)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("aiscSectionClass", self.aisc_section_class)
        writer.write_enum_value("csaSectionClass", self.csa_section_class)
        writer.write_enum_value("loadingPattern", self.loading_pattern)
        writer.write_collection_of_object_values("parts", self.parts)
    

