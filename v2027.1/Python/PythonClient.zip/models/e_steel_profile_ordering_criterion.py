from enum import Enum

class ESteelProfileOrderingCriterion(str, Enum):
    EProfileOptimizationOrderedByHeight = "eProfileOptimizationOrderedByHeight",
    EProfileOptimizationOrderedByWidth = "eProfileOptimizationOrderedByWidth",
    EProfileOptimizationOrderedByIyInertia = "eProfileOptimizationOrderedByIyInertia",
    EProfileOptimizationOrderedByIzInertia = "eProfileOptimizationOrderedByIzInertia",
    EProfileOptimizationOrderedByWeight = "eProfileOptimizationOrderedByWeight",

