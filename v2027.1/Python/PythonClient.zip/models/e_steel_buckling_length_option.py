from enum import Enum

class ESteelBucklingLengthOption(str, Enum):
    ElementLength = "elementLength",
    Imposed = "imposed",
    Neglected = "neglected",

