from enum import Enum

class ETimberDeflectionCriterion(str, Enum):
    FirstCriterion = "FirstCriterion",
    SecondCriterion = "SecondCriterion",
    None_ = "None",

