from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_concrete_combination_type import EConcreteCombinationType
    from .e_concrete_load_duration import EConcreteLoadDuration

@dataclass
class ConcreteCombinationDesign(Parsable):
    """
    Properties applied by the reinforced concrete design engine to one combination (maps to the ADmodel object `som.BetonFields`, attached to the combination as "ExpertFieldBA"). Relevant when the combination listsAD.API.eCombinationDesignCalculation.ConcreteDesign.
    """
    # Duration of the loading, which drives creep, crack width and long-term deflection (maps to"Duration"). Default value : null (derived from the project situation of the combination: ShortTerm for anaccidental combination, LongTerm otherwise)
    duration: Optional[EConcreteLoadDuration] = None
    # Limit state under which the combination is checked (maps to "Type"). Default value : null (derived from the project situation of the combination: ULS for an ULScombination, SLS for an SLS one, UlsAccidental for an accidental one)
    type: Optional[EConcreteCombinationType] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConcreteCombinationDesign:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConcreteCombinationDesign
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConcreteCombinationDesign()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_concrete_combination_type import EConcreteCombinationType
        from .e_concrete_load_duration import EConcreteLoadDuration

        from .e_concrete_combination_type import EConcreteCombinationType
        from .e_concrete_load_duration import EConcreteLoadDuration

        fields: dict[str, Callable[[Any], None]] = {
            "duration": lambda n : setattr(self, 'duration', n.get_enum_value(EConcreteLoadDuration)),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(EConcreteCombinationType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("duration", self.duration)
        writer.write_enum_value("type", self.type)
    

