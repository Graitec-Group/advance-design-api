from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class EC3SteelColdFormedDesign(Parsable):
    """
    "Cold formed design options" group of an EC3 steel design template (maps to the AD model object`som.EC3RoleColdFormedDesign`). Options specific to the EN 1993-1-3 verification ofcold-formed members.
    """
    # Legacy buckling-resistance flag (maps to "BucklingResistance"). The AD model schema marks this field as unused, but that comment is stale: the conversion tothe analysis model still reads it, and when it is true it forces the buckling verification on(it writes "BucklingChecking" = true on the element's buckling group). Setting it therefore hasan effect, but an indirect one - preferAD.API.SteelLinearBuckling.ElementVerification to turn the buckling check on. Default value : false
    buckling_resistance: Optional[bool] = None
    # Whether the design is carried out in the principal u-v axes (maps to"DesignInMainAxesuuvv"). READ-ONLY IN PRACTICE - true is REFUSED. Advance Design withdrew this row from the designtemplate and from the linear element alike (it is hidden unconditionally in both propertylists), so a template can only ever hold false, which is what the engine stamps when it createsone. It is exposed here so that a GET reports the stored value and a GET-then-PUT round tripkeeps working, not so that it can be changed. The reason a non-default value is refused rather than accepted: the option survives as theslave of the linear element's own "Product of inertia Iyz = 0" row, and assigning a templatecopies it onto the element AND overwrites that row with its inverse. Writing true here wouldtherefore silently clear "Product of inertia Iyz = 0" on every element using the template - astate no dialog can display or undo. Set the element property instead - it is the same optioninverted, exposed as `LinearElementInnertia.ProductOfInertiaIyz0` on the linearelement. Default value : false
    design_in_main_axes_uu_vv: Optional[bool] = None
    # Whether the effective Class 4 characteristics are computed exactly rather than through thesimplified approach (maps to "ExactClass4Calculation"). Default value : false
    exact_class4_calculation: Optional[bool] = None
    # Whether the fy·Mz interaction term is ignored (maps to "IgnoreFyMz"). Default value : false
    ignore_fy_mz: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelColdFormedDesign:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelColdFormedDesign
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelColdFormedDesign()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "bucklingResistance": lambda n : setattr(self, 'buckling_resistance', n.get_bool_value()),
            "designInMainAxesUuVv": lambda n : setattr(self, 'design_in_main_axes_uu_vv', n.get_bool_value()),
            "exactClass4Calculation": lambda n : setattr(self, 'exact_class4_calculation', n.get_bool_value()),
            "ignoreFyMz": lambda n : setattr(self, 'ignore_fy_mz', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("bucklingResistance", self.buckling_resistance)
        writer.write_bool_value("designInMainAxesUuVv", self.design_in_main_axes_uu_vv)
        writer.write_bool_value("exactClass4Calculation", self.exact_class4_calculation)
        writer.write_bool_value("ignoreFyMz", self.ignore_fy_mz)
    

