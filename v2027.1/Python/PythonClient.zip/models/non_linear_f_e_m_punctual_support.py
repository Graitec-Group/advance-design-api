from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus
    from .steel_non_linear_f_e_m_dof_type import SteelNonLinearFEMDofType
    from .steel_non_linear_f_e_m_offset_position import SteelNonLinearFEMOffsetPosition

@dataclass
class NonLinearFEMPunctualSupport(Parsable):
    """
    One punctual lateral support of the non-linear (2nd order) analysis (maps to the AD model object`som.PunctualSupportNLFem`). The seven degrees of freedom (Tx, Ty, Tz, Rx, Ry, Rz and the warping Rw) are only readindividually when AD.API.NonLinearFEMPunctualSupport.DofType is AD.API.SteelNonLinearFEMDofType.custom;otherwise the DOF type acts as a preset. Each individual value is a stiffness, used only when thematching status is AD.API.SteelNonLinearFEMDofStatus.elastic.
    """
    from .steel_non_linear_f_e_m_dof_type import SteelNonLinearFEMDofType

    # Preset applied to the seven degrees of freedom (maps to "DofType"). Default value : SteelNonLinearFEMDofType.fully_rigid
    dof_type: Optional[SteelNonLinearFEMDofType] = SteelNonLinearFEMDofType("fully_rigid")
    from .steel_non_linear_f_e_m_offset_position import SteelNonLinearFEMOffsetPosition

    # Position of the support over the height of the cross-section (maps to"OffsetPosition"). Default value : SteelNonLinearFEMOffsetPosition.neutral_fiber
    offset_position: Optional[SteelNonLinearFEMOffsetPosition] = SteelNonLinearFEMOffsetPosition("neutral_fiber")
    from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus

    # Status of the WARPING degree of freedom Rw (maps to "RwStatus"). Default value : SteelNonLinearFEMDofStatus.auto_status
    rw_status: Optional[SteelNonLinearFEMDofStatus] = SteelNonLinearFEMDofStatus("auto_status")
    from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus

    # Status of the torsional rotation Rx (maps to "RxStatus"). Default value : SteelNonLinearFEMDofStatus.auto_status
    rx_status: Optional[SteelNonLinearFEMDofStatus] = SteelNonLinearFEMDofStatus("auto_status")
    from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus

    # Status of the rotation Ry (maps to "RyStatus"). Default value : SteelNonLinearFEMDofStatus.auto_status
    ry_status: Optional[SteelNonLinearFEMDofStatus] = SteelNonLinearFEMDofStatus("auto_status")
    from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus

    # Status of the rotation Rz (maps to "RzStatus"). Default value : SteelNonLinearFEMDofStatus.auto_status
    rz_status: Optional[SteelNonLinearFEMDofStatus] = SteelNonLinearFEMDofStatus("auto_status")
    from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus

    # Status of the axial translation Tx (maps to "TxStatus"). Default value : SteelNonLinearFEMDofStatus.auto_status
    tx_status: Optional[SteelNonLinearFEMDofStatus] = SteelNonLinearFEMDofStatus("auto_status")
    from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus

    # Status of the lateral translation Ty (maps to "TyStatus"). Default value : SteelNonLinearFEMDofStatus.auto_status
    ty_status: Optional[SteelNonLinearFEMDofStatus] = SteelNonLinearFEMDofStatus("auto_status")
    from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus

    # Status of the vertical translation Tz (maps to "TzStatus"). Default value : SteelNonLinearFEMDofStatus.auto_status
    tz_status: Optional[SteelNonLinearFEMDofStatus] = SteelNonLinearFEMDofStatus("auto_status")
    # Position of the support along the element (maps to "Abscissa"). Unit : m Default value : 0.0
    abscissa: Optional[float] = None
    # Imposed offset over the height of the cross-section (maps to "OffsetValue"). Used only whenAD.API.NonLinearFEMPunctualSupport.OffsetPosition isAD.API.SteelNonLinearFEMOffsetPosition.imposed_value. Unit : m Default value : 0.0
    offset_value: Optional[float] = None
    # Elastic stiffness of the warping degree of freedom Rw (maps to "RwValue"). Default value : 0.0
    rw_value: Optional[float] = None
    # Elastic stiffness of Rx (maps to "RxValue"). Unit : kNm/rad Default value : 0.0
    rx_value: Optional[float] = None
    # Elastic stiffness of Ry (maps to "RyValue"). Unit : kNm/rad Default value : 0.0
    ry_value: Optional[float] = None
    # Elastic stiffness of Rz (maps to "RzValue"). Unit : kNm/rad Default value : 0.0
    rz_value: Optional[float] = None
    # Elastic stiffness of Tx (maps to "TxValue"). Unit : kN/m Default value : 0.0
    tx_value: Optional[float] = None
    # Elastic stiffness of Ty (maps to "TyValue"). Unit : kN/m Default value : 0.0
    ty_value: Optional[float] = None
    # Elastic stiffness of Tz (maps to "TzValue"). Unit : kN/m Default value : 0.0
    tz_value: Optional[float] = None
    # Whether this support was placed by the user rather than auto-detected (maps to"UserDefined"). false = auto-detected by Advance Design, true = imposed by the user. Default value : false
    user_defined: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NonLinearFEMPunctualSupport:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NonLinearFEMPunctualSupport
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NonLinearFEMPunctualSupport()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus
        from .steel_non_linear_f_e_m_dof_type import SteelNonLinearFEMDofType
        from .steel_non_linear_f_e_m_offset_position import SteelNonLinearFEMOffsetPosition

        from .steel_non_linear_f_e_m_dof_status import SteelNonLinearFEMDofStatus
        from .steel_non_linear_f_e_m_dof_type import SteelNonLinearFEMDofType
        from .steel_non_linear_f_e_m_offset_position import SteelNonLinearFEMOffsetPosition

        fields: dict[str, Callable[[Any], None]] = {
            "abscissa": lambda n : setattr(self, 'abscissa', n.get_float_value()),
            "dofType": lambda n : setattr(self, 'dof_type', n.get_enum_value(SteelNonLinearFEMDofType)),
            "offsetPosition": lambda n : setattr(self, 'offset_position', n.get_enum_value(SteelNonLinearFEMOffsetPosition)),
            "offsetValue": lambda n : setattr(self, 'offset_value', n.get_float_value()),
            "rwStatus": lambda n : setattr(self, 'rw_status', n.get_enum_value(SteelNonLinearFEMDofStatus)),
            "rwValue": lambda n : setattr(self, 'rw_value', n.get_float_value()),
            "rxStatus": lambda n : setattr(self, 'rx_status', n.get_enum_value(SteelNonLinearFEMDofStatus)),
            "rxValue": lambda n : setattr(self, 'rx_value', n.get_float_value()),
            "ryStatus": lambda n : setattr(self, 'ry_status', n.get_enum_value(SteelNonLinearFEMDofStatus)),
            "ryValue": lambda n : setattr(self, 'ry_value', n.get_float_value()),
            "rzStatus": lambda n : setattr(self, 'rz_status', n.get_enum_value(SteelNonLinearFEMDofStatus)),
            "rzValue": lambda n : setattr(self, 'rz_value', n.get_float_value()),
            "txStatus": lambda n : setattr(self, 'tx_status', n.get_enum_value(SteelNonLinearFEMDofStatus)),
            "txValue": lambda n : setattr(self, 'tx_value', n.get_float_value()),
            "tyStatus": lambda n : setattr(self, 'ty_status', n.get_enum_value(SteelNonLinearFEMDofStatus)),
            "tyValue": lambda n : setattr(self, 'ty_value', n.get_float_value()),
            "tzStatus": lambda n : setattr(self, 'tz_status', n.get_enum_value(SteelNonLinearFEMDofStatus)),
            "tzValue": lambda n : setattr(self, 'tz_value', n.get_float_value()),
            "userDefined": lambda n : setattr(self, 'user_defined', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("abscissa", self.abscissa)
        writer.write_enum_value("dofType", self.dof_type)
        writer.write_enum_value("offsetPosition", self.offset_position)
        writer.write_float_value("offsetValue", self.offset_value)
        writer.write_enum_value("rwStatus", self.rw_status)
        writer.write_float_value("rwValue", self.rw_value)
        writer.write_enum_value("rxStatus", self.rx_status)
        writer.write_float_value("rxValue", self.rx_value)
        writer.write_enum_value("ryStatus", self.ry_status)
        writer.write_float_value("ryValue", self.ry_value)
        writer.write_enum_value("rzStatus", self.rz_status)
        writer.write_float_value("rzValue", self.rz_value)
        writer.write_enum_value("txStatus", self.tx_status)
        writer.write_float_value("txValue", self.tx_value)
        writer.write_enum_value("tyStatus", self.ty_status)
        writer.write_float_value("tyValue", self.ty_value)
        writer.write_enum_value("tzStatus", self.tz_status)
        writer.write_float_value("tzValue", self.tz_value)
        writer.write_bool_value("userDefined", self.user_defined)
    

