from enum import Enum

class EThermalLoadCategory(str, Enum):
    Standard = "Standard",
    UserDefined = "UserDefined",

