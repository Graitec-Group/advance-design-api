from enum import Enum

class ConcreteEurocodeAnnex(str, Enum):
    France = "france",
    Uk = "uk",
    Germany = "germany",
    Romania = "romania",
    General = "general",
    Czech = "czech",
    Italy = "italy",
    Poland = "poland",
    Slovakia = "slovakia",
    Spain = "spain",
    Portugal = "portugal",

