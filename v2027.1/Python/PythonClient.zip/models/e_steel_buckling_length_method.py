from enum import Enum

class ESteelBucklingLengthMethod(str, Enum):
    EMethodBucklingRoA_RoB = "eMethodBucklingRoA_RoB",
    EMethodBucklingKa_Kb = "eMethodBucklingKa_Kb",
    EMethodBucklingN1_N2 = "eMethodBucklingN1_N2",
    EMethodBucklingGa_Gb = "eMethodBucklingGa_Gb",
    EMethodBucklingGu_Gl = "eMethodBucklingGu_Gl",
    EMethodBucklingNone = "eMethodBucklingNone",

