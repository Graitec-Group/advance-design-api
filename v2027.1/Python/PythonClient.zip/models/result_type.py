from enum import Enum

class ResultType(str, Enum):
    Displacement = "displacement",
    Forces = "forces",
    Stresses = "stresses",
    Resultantforces = "resultantforces",
    GeneralizedBucklingRes = "generalizedBucklingRes",

