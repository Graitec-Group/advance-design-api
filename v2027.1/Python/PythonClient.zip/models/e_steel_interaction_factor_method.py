from enum import Enum

class ESteelInteractionFactorMethod(str, Enum):
    EInteractionFactor_kij_Method_EN1993 = "eInteractionFactor_kij_Method_EN1993",
    EInteractionFactor_kij_Method_CEN_TS_1993 = "eInteractionFactor_kij_Method_CEN_TS_1993",

