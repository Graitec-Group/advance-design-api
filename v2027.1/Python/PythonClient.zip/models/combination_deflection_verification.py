from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_deflection_criterion import EDeflectionCriterion

@dataclass
class CombinationDeflectionVerification(Parsable):
    """
    Coefficients of a serviceability deflection verification for one combination (maps to the ADmodel object `som.MetalDeflectionFields`). Shared by the steel verification (AD.API.SteelCombinationDesign.Deflections) and by thetwo composite ones (AD.API.CompositeCombinationDesign.PreCompositeDeflections andAD.API.CompositeCombinationDesign.PostCompositeDeflections), because AD stores all threein the same object class. Every property is optional: a property left null is filled with the value the Advance Designcombinations dialog would apply, taken from the design settings of the model.
    """
    # Deflection criterion checked for this combination (maps to "Type"). The available members depend on the design code configured on the model - seeAD.API.eDeflectionCriterion. Default value : null (FirstCriterion)
    criterion: Optional[EDeflectionCriterion] = None
    # Safety factor applied to the deflection (maps to "Coeficient"). Default value : null (the model property "DeflectionsSecurityCoeff" for steel, gammaM2 of thecomposite design settings for composite)
    safety_factor: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CombinationDeflectionVerification:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CombinationDeflectionVerification
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CombinationDeflectionVerification()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_deflection_criterion import EDeflectionCriterion

        from .e_deflection_criterion import EDeflectionCriterion

        fields: dict[str, Callable[[Any], None]] = {
            "criterion": lambda n : setattr(self, 'criterion', n.get_enum_value(EDeflectionCriterion)),
            "safetyFactor": lambda n : setattr(self, 'safety_factor', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("criterion", self.criterion)
        writer.write_float_value("safetyFactor", self.safety_factor)
    

