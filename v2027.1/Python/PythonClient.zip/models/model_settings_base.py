from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .aisc_steel_calculation_settings import AiscSteelCalculationSettings
    from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings
    from .combinations_generation_settings import CombinationsGenerationSettings
    from .ec3_steel_calculation_settings import Ec3SteelCalculationSettings
    from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings
    from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings
    from .e_model_settings_category import EModelSettingsCategory
    from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings
    from .steel_calculation_settings import SteelCalculationSettings
    from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

@dataclass
class ModelSettingsBase(Parsable):
    """
    Base class of the GENERAL SETTINGS of a model: the options that apply to the model as awhole rather than to any one object of it, and that in the AD model live on`som.ModelProperties`.These are NOT properties of an element, a load case or a combination. They are what thedesktop application edits in its option dialogs - which project situations the combinationgeneration produces, which coefficients it applies, and, as they are added, the generaloptions of the Expert design calculations. They are read, written and reset through THREEgeneric functions, whatever the group:- `GetModelSettings(category)` returns the settings of one group,- `SetModelSettings(settings)` writes them, and- `ResetModelSettings(category)` puts back what the model's standard prescribes.THE OBJECT DECIDES WHAT IS WRITTEN. `SetModelSettings` takes this base class, so it isthe runtime type of the object - its `$type` - that says which group of model settingsthe call writes, exactly as `CreateInformationalElement` takesAD.API.InformationalElementBase and the object decides what is created. There is nofunction per group of settings, and adding a group adds no function.TWO LEVELS OF DERIVATION. Under this base, one class per group of settings(AD.API.CombinationsGenerationSettings, AD.API.SteelCalculationSettings andAD.API.AiscSteelCalculationSettings today) - and under that class, as many classes asthe group has shapes. The combination generation has five, one per combination standard,because the standards share no field; each of the two steel groups has one, because thecodes inside a family share every page of the dialog. So the class hierarchy reads: whatsettings (level 2), in which variant (level 3).TWO STEEL GROUPS, NOT ONE GROUP WITH TWO SHAPES. The Eurocode and the North-Americanfamilies do not answer the same question - the second has no Partial safety factors page atall and a Verification page of three controls instead of thirteen - so they are separatecategories with separate group classes. The five pages they do share are the same DTOclasses, held by both group classes.PARTIAL BY DESIGN. In every group, the properties are optional and what a request does notcarry keeps the value the model has, so a single switch can be changed without restatingthe rest. What each group refuses, what it recomputes rather than stores, and what itreports as a warning instead of an error is documented on that group's own class.
    """
    # Which group of model settings this object carries.READ ONLY: it is filled by `GetModelSettings` and ignored in a`SetModelSettings` request, where the group follows from the object's own type.It is here so that a returned object says what it is without its `$type` having tobe parsed.Named `SettingsCategory` and not `Category` on purpose: a group's own shapescarry categories of their own - the live load, snow, wind and temperature`Category` of the combination settings - and two properties called the same at twolevels of one request body is how a caller ends up sending the wrong one.
    settings_category: Optional[EModelSettingsCategory] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ModelSettingsBase:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ModelSettingsBase
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "AiscSteelCalculationSettings".casefold():
            from .aisc_steel_calculation_settings import AiscSteelCalculationSettings

            return AiscSteelCalculationSettings()
        if mapping_value and mapping_value.casefold() == "CanadaCombinationsGenerationSettings".casefold():
            from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings

            return CanadaCombinationsGenerationSettings()
        if mapping_value and mapping_value.casefold() == "CombinationsGenerationSettings".casefold():
            from .combinations_generation_settings import CombinationsGenerationSettings

            return CombinationsGenerationSettings()
        if mapping_value and mapping_value.casefold() == "Ec3SteelCalculationSettings".casefold():
            from .ec3_steel_calculation_settings import Ec3SteelCalculationSettings

            return Ec3SteelCalculationSettings()
        if mapping_value and mapping_value.casefold() == "Eurocode2ndGenCombinationsGenerationSettings".casefold():
            from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings

            return Eurocode2ndGenCombinationsGenerationSettings()
        if mapping_value and mapping_value.casefold() == "EurocodeCombinationsGenerationSettings".casefold():
            from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings

            return EurocodeCombinationsGenerationSettings()
        if mapping_value and mapping_value.casefold() == "GreenhouseCombinationsGenerationSettings".casefold():
            from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings

            return GreenhouseCombinationsGenerationSettings()
        if mapping_value and mapping_value.casefold() == "SteelCalculationSettings".casefold():
            from .steel_calculation_settings import SteelCalculationSettings

            return SteelCalculationSettings()
        if mapping_value and mapping_value.casefold() == "USCombinationsGenerationSettings".casefold():
            from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

            return USCombinationsGenerationSettings()
        return ModelSettingsBase()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .aisc_steel_calculation_settings import AiscSteelCalculationSettings
        from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings
        from .combinations_generation_settings import CombinationsGenerationSettings
        from .ec3_steel_calculation_settings import Ec3SteelCalculationSettings
        from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings
        from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings
        from .e_model_settings_category import EModelSettingsCategory
        from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings
        from .steel_calculation_settings import SteelCalculationSettings
        from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

        from .aisc_steel_calculation_settings import AiscSteelCalculationSettings
        from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings
        from .combinations_generation_settings import CombinationsGenerationSettings
        from .ec3_steel_calculation_settings import Ec3SteelCalculationSettings
        from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings
        from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings
        from .e_model_settings_category import EModelSettingsCategory
        from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings
        from .steel_calculation_settings import SteelCalculationSettings
        from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

        fields: dict[str, Callable[[Any], None]] = {
            "settingsCategory": lambda n : setattr(self, 'settings_category', n.get_enum_value(EModelSettingsCategory)),
            "$type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("settingsCategory", self.settings_category)
        writer.write_str_value("$type", self.type)
    

