from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .design_calculation_licence import DesignCalculationLicence
    from .licence_protection_type import LicenceProtectionType

@dataclass
class LicenceStatus(Parsable):
    """
    The licence section of `GetStatus`: whether this server holds the licence it needs torun, and what that licence allows.A SNAPSHOT, NOT A LIVE READ. The licence is read when the server starts, and again now andthen when the server is idle; AD.API.LicenceStatus.CheckedAt says when this one was taken. Reading itnever waits behind a running model operation.AD.API.LicenceStatus.IsAvailable is the one value that decides whether the server can work. Everythingelse describes the licence it holds, and is at its default when it holds none - including oncethe licence has been RELEASED because the server is shutting down: then onlyAD.API.LicenceStatus.CheckedAt and AD.API.LicenceStatus.ErrorMessage are set, and nothing of the releasedlicence is reported any more.
    """
    from .licence_protection_type import LicenceProtectionType

    # The kind of licence the server runs under.Default value: LicenceProtectionType.NoLicence<p>Possible values:</p><ul><li><b>0 - NoLicence</b>: No licence.</li><li><b>1 - Demo</b>: Demonstration licence.</li><li><b>2 - Evaluation</b>: Evaluation (trial) licence.</li><li><b>3 - Education</b>: Education licence.</li><li><b>4 - Commercial</b>: Commercial licence.</li><li><b>5 - Reseller</b>: Reseller licence.</li><li><b>6 - Internal</b>: Graitec internal licence.</li><li><b>7 - HomeUse</b>: Home-use licence.</li><li><b>-1 - Unknown</b>: The licence component reported a kind this server does not know.</li></ul>
    protection_type: Optional[LicenceProtectionType] = LicenceProtectionType("NoLicence")
    # When the licence was read for this snapshot.Default value: 0001-01-01T00:00:00+00:00
    checked_at: Optional[datetime.datetime] = None
    # Days left before the base module's licence expires, counted when the snapshot was taken.`null` when the licence is permanent, when none is held, or when the licence componentcould not tell.Default value: null
    days_to_expiry: Optional[int] = None
    # Whether each design family's licence is available. The server always fills in every`DesignCalculationType` it knows, in the order of that enumeration.Default value: empty (the server fills it)
    design_calculations: Optional[list[DesignCalculationLicence]] = None
    # Why the mandatory licence is not held, in words a user can act on: the licence component'sown message without its technical lines (licence server names, licence file paths, raw errorcodes - those go to the server log only), or, when nothing is left of it, a description ofwhat failed. Also set when the licence was released because the server is shutting down,and - with AD.API.LicenceStatus.IsAvailable true - when the licence is held but its details couldnot be read. `null` when there is nothing to report.Default value: null
    error_message: Optional[str] = None
    # True when the server holds its MANDATORY licence - the base module and the user seat,checked out together when the server started. Without it no model operation can be reliedupon, and AD.API.LicenceStatus.ErrorMessage says why.The mandatory licence is checked out once, at startup, and never checked out againafterwards: a network licence whose lease is lost later is NOT detected here.Default value: false
    is_available: Optional[bool] = None
    # True when the base module's licence never expires. AD.API.LicenceStatus.DaysToExpiry is null then.Default value: false
    is_permanent: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LicenceStatus:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LicenceStatus
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LicenceStatus()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .design_calculation_licence import DesignCalculationLicence
        from .licence_protection_type import LicenceProtectionType

        from .design_calculation_licence import DesignCalculationLicence
        from .licence_protection_type import LicenceProtectionType

        fields: dict[str, Callable[[Any], None]] = {
            "checkedAt": lambda n : setattr(self, 'checked_at', n.get_datetime_value()),
            "daysToExpiry": lambda n : setattr(self, 'days_to_expiry', n.get_int_value()),
            "designCalculations": lambda n : setattr(self, 'design_calculations', n.get_collection_of_object_values(DesignCalculationLicence)),
            "errorMessage": lambda n : setattr(self, 'error_message', n.get_str_value()),
            "isAvailable": lambda n : setattr(self, 'is_available', n.get_bool_value()),
            "isPermanent": lambda n : setattr(self, 'is_permanent', n.get_bool_value()),
            "protectionType": lambda n : setattr(self, 'protection_type', n.get_enum_value(LicenceProtectionType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("checkedAt", self.checked_at)
        writer.write_int_value("daysToExpiry", self.days_to_expiry)
        writer.write_collection_of_object_values("designCalculations", self.design_calculations)
        writer.write_str_value("errorMessage", self.error_message)
        writer.write_bool_value("isAvailable", self.is_available)
        writer.write_bool_value("isPermanent", self.is_permanent)
        writer.write_enum_value("protectionType", self.protection_type)
    

