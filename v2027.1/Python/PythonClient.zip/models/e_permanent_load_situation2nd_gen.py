from enum import Enum

class EPermanentLoadSituation2ndGen(str, Enum):
    Unfavorable = "Unfavorable",
    Favorable = "Favorable",
    FavorableAndUnfavorable = "FavorableAndUnfavorable",
    FavorableUnfavorableStabilizingVC2 = "FavorableUnfavorableStabilizingVC2",
    FavorableStabilizingVC2 = "FavorableStabilizingVC2",
    UserDefined = "UserDefined",

