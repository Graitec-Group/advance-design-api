from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .steel_buckling_length_mode import SteelBucklingLengthMode
    from .steel_ltb_end_restraint import SteelLtbEndRestraint
    from .steel_ltb_factor_cb_mode import SteelLtbFactorCbMode

@dataclass
class NorthAmericanSteelLateralTorsionalBucklingParameters(Parsable):
    """
    Lateral-torsional buckling parameters of one flange of a North-American steel design template(maps to the AD model object `som.CM66RoleSDLateralTorsionBucklingParameters`). The same class is used twice, once per flange. It gathers the lateral restraints at the two endsof the flange, the unbraced length, and the Cb moment modification factor. FOUR FIELDS OF THE UNDERLYING OBJECT ARE NOT EXPOSED. <c>som.CM66RoleSDLateralTorsionBucklingParameters</c> is shared with the French CM66 code and carries its B, C, D and PointDeChargecoefficients as well. The AISC / CAN/CSA lateral-torsional-buckling dialog(`CGrAmericaRoleMetalDeversementSheet`) writes none of them and the North-American designengine reads none of them, so exposing them would only offer a caller a way to store values thatnothing consumes. The one field of that CM66 set the North-American codes DO reuse is thekD pair, under the meaning Cb - see AD.API.NorthAmericanSteelLateralTorsionalBucklingParameters.CbMode.
    """
    from .steel_ltb_factor_cb_mode import SteelLtbFactorCbMode

    # How the Cb moment modification factor is obtained (maps to "KD"). Cb accounts for the shape of the moment diagram over the unbraced length - AISC 360 clause F1,CAN/CSA S16 clause 13.6 calls the same quantity omega2. The stored field is the CM66 "kD"slot, reused by the North-American codes. Default value : SteelLtbFactorCbMode.auto_cb
    cb_mode: Optional[SteelLtbFactorCbMode] = SteelLtbFactorCbMode("auto_cb")
    from .steel_ltb_end_restraint import SteelLtbEndRestraint

    # Lateral restraint at the END end of the flange (maps to "MaintienJ"). Default value : SteelLtbEndRestraint.no_restraint
    end_restraint: Optional[SteelLtbEndRestraint] = SteelLtbEndRestraint("no_restraint")
    from .steel_buckling_length_mode import SteelBucklingLengthMode

    # How the unbraced length of this flange is obtained (maps to "Longueur"). Default value : SteelBucklingLengthMode.auto_length
    length_mode: Optional[SteelBucklingLengthMode] = SteelBucklingLengthMode("auto_length")
    from .steel_ltb_end_restraint import SteelLtbEndRestraint

    # Lateral restraint at the START end of the flange (maps to "MaintienI"). Default value : SteelLtbEndRestraint.no_restraint
    start_restraint: Optional[SteelLtbEndRestraint] = SteelLtbEndRestraint("no_restraint")
    # Imposed value of the Cb moment modification factor (maps to "KDValue"). Used only when AD.API.NorthAmericanSteelLateralTorsionalBucklingParameters.CbMode isAD.API.SteelLtbFactorCbMode.imposed_cb. Unit : adimensional Default value : 0.0
    cb_value: Optional[float] = None
    # Whether the element is a catalogue profile (maps to "IsProfile"). Default value : true
    is_profile: Optional[bool] = None
    # Unbraced length, or the coefficient applied to the computed one (maps to"LongueurValue"). It is a LENGTH in metres when AD.API.NorthAmericanSteelLateralTorsionalBucklingParameters.LengthMode isAD.API.SteelBucklingLengthMode.imposed, and a dimensionless coefficient when the modederives the length from the element, the mesh size or the super-element. The dialog refuses an imposed value that is not strictly greater than 0, and so does theAPI. Unit : m or adimensional, see above Default value : 1.0
    length_value: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NorthAmericanSteelLateralTorsionalBucklingParameters:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NorthAmericanSteelLateralTorsionalBucklingParameters
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NorthAmericanSteelLateralTorsionalBucklingParameters()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .steel_buckling_length_mode import SteelBucklingLengthMode
        from .steel_ltb_end_restraint import SteelLtbEndRestraint
        from .steel_ltb_factor_cb_mode import SteelLtbFactorCbMode

        from .steel_buckling_length_mode import SteelBucklingLengthMode
        from .steel_ltb_end_restraint import SteelLtbEndRestraint
        from .steel_ltb_factor_cb_mode import SteelLtbFactorCbMode

        fields: dict[str, Callable[[Any], None]] = {
            "cbMode": lambda n : setattr(self, 'cb_mode', n.get_enum_value(SteelLtbFactorCbMode)),
            "cbValue": lambda n : setattr(self, 'cb_value', n.get_float_value()),
            "endRestraint": lambda n : setattr(self, 'end_restraint', n.get_enum_value(SteelLtbEndRestraint)),
            "isProfile": lambda n : setattr(self, 'is_profile', n.get_bool_value()),
            "lengthMode": lambda n : setattr(self, 'length_mode', n.get_enum_value(SteelBucklingLengthMode)),
            "lengthValue": lambda n : setattr(self, 'length_value', n.get_float_value()),
            "startRestraint": lambda n : setattr(self, 'start_restraint', n.get_enum_value(SteelLtbEndRestraint)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("cbMode", self.cb_mode)
        writer.write_float_value("cbValue", self.cb_value)
        writer.write_enum_value("endRestraint", self.end_restraint)
        writer.write_bool_value("isProfile", self.is_profile)
        writer.write_enum_value("lengthMode", self.length_mode)
        writer.write_float_value("lengthValue", self.length_value)
        writer.write_enum_value("startRestraint", self.start_restraint)
    

