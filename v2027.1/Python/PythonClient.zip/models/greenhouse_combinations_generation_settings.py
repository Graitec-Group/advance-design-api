from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .combinations_generation_settings import CombinationsGenerationSettings
    from .e_greenhouse_consequence_class import EGreenhouseConsequenceClass

from .combinations_generation_settings import CombinationsGenerationSettings

@dataclass
class GreenhouseCombinationsGenerationSettings(CombinationsGenerationSettings, AdditionalDataHolder, Parsable):
    """
    Settings of PR EN 13031-1, the greenhouses standard.Note that no session localization selects this standard: it can be written and readback on any model, but only a server installation configured for greenhouses willactually generate with it.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Consequence factor K of the accidental combinations. Writable only when`ConsequenceClass` is `Other`.
    accidental_consequence_factor_k: Optional[float] = None
    # Consequence class of the greenhouse. Anything other than `Other` makes the twofactors below read only and recomputed from it: C0 gives 0.80 / 0.60, C1 gives0.90 / 0.80, C2 gives 1.00 / 1.00.
    consequence_class: Optional[EGreenhouseConsequenceClass] = None
    # Consequence factor K, applied to the permanent, variable and accidental actions ofthe ULS combinations (seismic excepted). Writable only when`ConsequenceClass` is `Other`.
    consequence_factor_k: Optional[float] = None
    # Generate the SLS combinations. On by default.
    generate_sls: Optional[bool] = None
    # Generate the ULS combinations. On by default.
    generate_uls: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> GreenhouseCombinationsGenerationSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: GreenhouseCombinationsGenerationSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return GreenhouseCombinationsGenerationSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .combinations_generation_settings import CombinationsGenerationSettings
        from .e_greenhouse_consequence_class import EGreenhouseConsequenceClass

        from .combinations_generation_settings import CombinationsGenerationSettings
        from .e_greenhouse_consequence_class import EGreenhouseConsequenceClass

        fields: dict[str, Callable[[Any], None]] = {
            "accidentalConsequenceFactorK": lambda n : setattr(self, 'accidental_consequence_factor_k', n.get_float_value()),
            "consequenceClass": lambda n : setattr(self, 'consequence_class', n.get_enum_value(EGreenhouseConsequenceClass)),
            "consequenceFactorK": lambda n : setattr(self, 'consequence_factor_k', n.get_float_value()),
            "generateSls": lambda n : setattr(self, 'generate_sls', n.get_bool_value()),
            "generateUls": lambda n : setattr(self, 'generate_uls', n.get_bool_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("accidentalConsequenceFactorK", self.accidental_consequence_factor_k)
        writer.write_enum_value("consequenceClass", self.consequence_class)
        writer.write_float_value("consequenceFactorK", self.consequence_factor_k)
        writer.write_bool_value("generateSls", self.generate_sls)
        writer.write_bool_value("generateUls", self.generate_uls)
        writer.write_additional_data_value(self.additional_data)
    

