from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .climatic_design_code import ClimaticDesignCode
    from .climatic_eurocode_annex import ClimaticEurocodeAnnex
    from .composite_design_code import CompositeDesignCode
    from .composite_eurocode_annex import CompositeEurocodeAnnex
    from .concrete_design_code import ConcreteDesignCode
    from .concrete_eurocode_annex import ConcreteEurocodeAnnex
    from .e_aisc_design_method import EAiscDesignMethod
    from .e_combinations_eurocode_annex import ECombinationsEurocodeAnnex
    from .e_combinations_standard import ECombinationsStandard
    from .masonry_design_code import MasonryDesignCode
    from .masonry_eurocode_annex import MasonryEurocodeAnnex
    from .seismic_design_code import SeismicDesignCode
    from .seismic_eurocode_annex import SeismicEurocodeAnnex
    from .steel_design_code import SteelDesignCode
    from .steel_eurocode_annex import SteelEurocodeAnnex
    from .timber_design_code import TimberDesignCode
    from .timber_eurocode_annex import TimberEurocodeAnnex

@dataclass
class DesignCodes(Parsable):
    """
    The design standards and national annexes of the session - the eight rows of theLocalization configuration dialog of the desktop application, one standard each and the"NAD used for Eurocodes" combo beside it.EVERY PROPERTY IS NULLABLE, AND NULL IS NOT "UNSET BY MISTAKE" - IT IS THE DEFAULT.`SetEnvironment` first resolves all eight standards and all eight annexes fromAD.API.Environments.Localization, exactly as the desktop application resolves themfrom its installation, and only then overwrites the ones named here. So a null propertyleaves that standard at the localization's own default, and an object with every propertynull changes nothing at all. There is no "no standard" state to fall into.WHEN IT IS APPLIED, AND WHEN IT IS NOT. Together with the rest ofAD.API.Environments, on the `NewProject` or `OpenProject` call that OPENSthe session, before the model is created or read. It then lasts exactly as long as thatproject: a further `NewProject` or `OpenProject` sent while the project is stillopen is REFUSED, because the standards were already read while the open model was built andwill be read again by the combination generation and by the design Experts. Call`CloseProject` first; the next project takes a new environment. Read back what is inforce with `GetEnvironment`.AN ANNEX IS NOT ALWAYS APPLICABLE. The desktop dialog hides the annex combo whenever thestandard is not a Eurocode one, and then writes no annex at all. This API refuses an annexsent for such a standard instead of dropping it, so that a request never half-applies -sending AD.API.DesignCodes.Concrete = `aci` together with anyAD.API.DesignCodes.ConcreteAnnex fails the whole call and the project is not created. Eachproperty below says which standards accept it.THE 2nd GENERATION EUROCODES ARE NOT AVAILABLE THROUGH THIS API, AND ARE NOT VISIBLE IN IT.They are not released, so no enumeration of this contract carries a member for one - notthe ones written for this class, and not AD.API.SteelDesignCode orAD.API.eCombinationsStandard, which are shared with the read-only settings. Sendingone is therefore impossible by name and refused by number. A model that already carries onecannot be described either: `GetEnvironment` reports that one property as null with awarning naming it, and on any installation that does not have the 2nd generation enabled theoperations that would have to work under it - the combination and steel settings groups,design templates, `GenerateCombinations`, `LaunchDesignCalculation` and`GetDesignResults` - refuse the model rather than answer it under the previousgeneration of the standard. The same is true of the standards the desktop application nolonger offers - CM66, STAS 10107, BS 8110, CSA O86-24, CSA S16-19 composite.SEND ENUMERATORS BY NAME, NEVER BY NUMBER. The numbers in the generated "Possible values"documentation are Advance Design's own storage values, and three of these enumerations aredeliberately not contiguous because the unavailable standards were left out of them. Thegenerated clients renumber their copy from 0, so a number copied out of the documentationand cast into a client enumeration lands on a DIFFERENT standard. A number that is not amember at all is refused with an error rather than accepted.TWO THINGS ARE ONLY EVER SAID AS WARNINGS: a property reported as null because the sessioncarries a standard this API cannot name, and a steelwork / composite pair the desktopapplication could not have produced. Both are dropped from the response at`LogVerbosity` = `Errors`, which is what makes them look like they never happened.Use `ErrorsAndWarnings` if either matters.
    """
    # The AISC 360 design method - ASD (allowable strength) or LRFD (load and resistancefactor) - the "AISC Method" combo of the desktop configuration dialog. Accepted when afamily that reads it is in force: AD.API.DesignCodes.Combinations = `US` or`US2018` (the dialog shows the combo for those two only, and the US generationbuilds ASD or LRFD combinations from it), OR AD.API.DesignCodes.Steel = `aisc` or`aisc_2016` (what the AISC 360 Experts calculate with). With neither - Eurocode orCanadian combinations together with a Eurocode or CSA S16 steel standard - nothing readsit, and it fails the whole call like an annex sent for a standard that has none.Reported by `GetEnvironment` under exactly the same condition.Null keeps what the session already holds: `AllowableStrengthDesign` wheneverAD.API.Environments.Localization is sent - a localization resolves it to ASD, asthe desktop dialog does - and otherwise the value this MACHINE is configured with.WHAT READS IT. The AISC steel and composite design Experts, the NDS timber Expert andtheir reports read it from the session. The US combination generation reads the copy theproject carries, and `GenerateCombinations` rewrites that copy with the session'smethod first - as the desktop's combination dialog does before every generation - so aproject opened under a different method than it was saved with gets combinations for themethod of the session. This is also the value`USCombinationsGenerationSettings.AiscDesignMethod` reports, and the only way tochange it.
    aisc_method: Optional[EAiscDesignMethod] = None
    # The snow and wind standard - the "Climatic" row.
    climatic: Optional[ClimaticDesignCode] = None
    # National annex of Eurocode 1. Accepted with AD.API.DesignCodes.Climatic = `eurocode` (anyvalue), `pr_en13031_1` (`general` or `france`) and `romania`(`romania` only - that standard points at the Romanian annex and the snow and windaccessors read it).
    climatic_annex: Optional[ClimaticEurocodeAnnex] = None
    # The combination standard - the "Combinations" row (EN 1990 and its relatives).`Greenhouse_EN13031_1` is accepted only on an installation carrying the greenhouselicence switch, which is the same condition under which the desktop dialog offers it.This is the same value `CombinationsGenerationSettings.Standard` reports, and itdecides the shape of that settings group - so set it here, then read the settings back tosee which shape the model has.
    combinations: Optional[ECombinationsStandard] = None
    # National annex of the combination standard. Accepted only withAD.API.DesignCodes.Combinations = `Eurocode`: `EurocodeItalia` and `NTC2018`differ from Eurocode by standard rather than by annex, and the US and Canadian standardshave no annex at all.
    combinations_annex: Optional[ECombinationsEurocodeAnnex] = None
    # The composite standard - the "Composite" row.The desktop dialog keeps this row and the steelwork row in step - picking a steelstandard there also picks the composite one. This API writes the two independently, andreports a WARNING (not an error) when the resulting pair is one the dialog could not haveproduced, for instance AD.API.DesignCodes.Steel = `aisc_2016` withAD.API.DesignCodes.Composite = `eurocode`.
    composite: Optional[CompositeDesignCode] = None
    # National annex of Eurocode 4. Accepted only with AD.API.DesignCodes.Composite =`eurocode`.
    composite_annex: Optional[CompositeEurocodeAnnex] = None
    # The reinforced concrete standard - the "Reinforced Concrete" row.
    concrete: Optional[ConcreteDesignCode] = None
    # National annex of Eurocode 2. Accepted with AD.API.DesignCodes.Concrete = `eurocode` (anyvalue except `italy`) and with `ntc2008` / `ntc2018` (`italy` only,which those two standards pin anyway).
    concrete_annex: Optional[ConcreteEurocodeAnnex] = None
    # The masonry standard - the "Masonry" row.
    masonry: Optional[MasonryDesignCode] = None
    # National annex of Eurocode 6. Accepted only with AD.API.DesignCodes.Masonry = `eurocode`.
    masonry_annex: Optional[MasonryEurocodeAnnex] = None
    # The seismic standard - the "Seismic" row.
    seismic: Optional[SeismicDesignCode] = None
    # National annex of Eurocode 8. Accepted only with AD.API.DesignCodes.Seismic = `en1998_1`.
    seismic_annex: Optional[SeismicEurocodeAnnex] = None
    # The steelwork standard - the "Steelwork" row.`can_csa_s16_2024` is refused: the enumeration is shared with the read-only`SteelCalculationSettings.DesignCode`, so it lists one value this API will not takeas an input - S16-24 was removed from the desktop dialog and calculates exactly as`can_csa_s16_2019`. CM66 and the 2nd generation Eurocode are not in the enumerationat all.Which steel settings group the model gets follows from this value: the Eurocode familygives `SteelEc3Calculation`, the North-American one `SteelAiscCalculation`.
    steel: Optional[SteelDesignCode] = None
    # National annex of Eurocode 3. Accepted only with AD.API.DesignCodes.Steel = `eurocode`,and never with the value `italy` - Italy is a steel standard here, not an annex.
    steel_annex: Optional[SteelEurocodeAnnex] = None
    # The timber standard - the "Timber" row.
    timber: Optional[TimberDesignCode] = None
    # National annex of Eurocode 5. Accepted only with AD.API.DesignCodes.Timber = `eurocode`,and never with the value `italy`.
    timber_annex: Optional[TimberEurocodeAnnex] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DesignCodes:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DesignCodes
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DesignCodes()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .climatic_design_code import ClimaticDesignCode
        from .climatic_eurocode_annex import ClimaticEurocodeAnnex
        from .composite_design_code import CompositeDesignCode
        from .composite_eurocode_annex import CompositeEurocodeAnnex
        from .concrete_design_code import ConcreteDesignCode
        from .concrete_eurocode_annex import ConcreteEurocodeAnnex
        from .e_aisc_design_method import EAiscDesignMethod
        from .e_combinations_eurocode_annex import ECombinationsEurocodeAnnex
        from .e_combinations_standard import ECombinationsStandard
        from .masonry_design_code import MasonryDesignCode
        from .masonry_eurocode_annex import MasonryEurocodeAnnex
        from .seismic_design_code import SeismicDesignCode
        from .seismic_eurocode_annex import SeismicEurocodeAnnex
        from .steel_design_code import SteelDesignCode
        from .steel_eurocode_annex import SteelEurocodeAnnex
        from .timber_design_code import TimberDesignCode
        from .timber_eurocode_annex import TimberEurocodeAnnex

        from .climatic_design_code import ClimaticDesignCode
        from .climatic_eurocode_annex import ClimaticEurocodeAnnex
        from .composite_design_code import CompositeDesignCode
        from .composite_eurocode_annex import CompositeEurocodeAnnex
        from .concrete_design_code import ConcreteDesignCode
        from .concrete_eurocode_annex import ConcreteEurocodeAnnex
        from .e_aisc_design_method import EAiscDesignMethod
        from .e_combinations_eurocode_annex import ECombinationsEurocodeAnnex
        from .e_combinations_standard import ECombinationsStandard
        from .masonry_design_code import MasonryDesignCode
        from .masonry_eurocode_annex import MasonryEurocodeAnnex
        from .seismic_design_code import SeismicDesignCode
        from .seismic_eurocode_annex import SeismicEurocodeAnnex
        from .steel_design_code import SteelDesignCode
        from .steel_eurocode_annex import SteelEurocodeAnnex
        from .timber_design_code import TimberDesignCode
        from .timber_eurocode_annex import TimberEurocodeAnnex

        fields: dict[str, Callable[[Any], None]] = {
            "aiscMethod": lambda n : setattr(self, 'aisc_method', n.get_enum_value(EAiscDesignMethod)),
            "climatic": lambda n : setattr(self, 'climatic', n.get_enum_value(ClimaticDesignCode)),
            "climaticAnnex": lambda n : setattr(self, 'climatic_annex', n.get_enum_value(ClimaticEurocodeAnnex)),
            "combinations": lambda n : setattr(self, 'combinations', n.get_enum_value(ECombinationsStandard)),
            "combinationsAnnex": lambda n : setattr(self, 'combinations_annex', n.get_enum_value(ECombinationsEurocodeAnnex)),
            "composite": lambda n : setattr(self, 'composite', n.get_enum_value(CompositeDesignCode)),
            "compositeAnnex": lambda n : setattr(self, 'composite_annex', n.get_enum_value(CompositeEurocodeAnnex)),
            "concrete": lambda n : setattr(self, 'concrete', n.get_enum_value(ConcreteDesignCode)),
            "concreteAnnex": lambda n : setattr(self, 'concrete_annex', n.get_enum_value(ConcreteEurocodeAnnex)),
            "masonry": lambda n : setattr(self, 'masonry', n.get_enum_value(MasonryDesignCode)),
            "masonryAnnex": lambda n : setattr(self, 'masonry_annex', n.get_enum_value(MasonryEurocodeAnnex)),
            "seismic": lambda n : setattr(self, 'seismic', n.get_enum_value(SeismicDesignCode)),
            "seismicAnnex": lambda n : setattr(self, 'seismic_annex', n.get_enum_value(SeismicEurocodeAnnex)),
            "steel": lambda n : setattr(self, 'steel', n.get_enum_value(SteelDesignCode)),
            "steelAnnex": lambda n : setattr(self, 'steel_annex', n.get_enum_value(SteelEurocodeAnnex)),
            "timber": lambda n : setattr(self, 'timber', n.get_enum_value(TimberDesignCode)),
            "timberAnnex": lambda n : setattr(self, 'timber_annex', n.get_enum_value(TimberEurocodeAnnex)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("aiscMethod", self.aisc_method)
        writer.write_enum_value("climatic", self.climatic)
        writer.write_enum_value("climaticAnnex", self.climatic_annex)
        writer.write_enum_value("combinations", self.combinations)
        writer.write_enum_value("combinationsAnnex", self.combinations_annex)
        writer.write_enum_value("composite", self.composite)
        writer.write_enum_value("compositeAnnex", self.composite_annex)
        writer.write_enum_value("concrete", self.concrete)
        writer.write_enum_value("concreteAnnex", self.concrete_annex)
        writer.write_enum_value("masonry", self.masonry)
        writer.write_enum_value("masonryAnnex", self.masonry_annex)
        writer.write_enum_value("seismic", self.seismic)
        writer.write_enum_value("seismicAnnex", self.seismic_annex)
        writer.write_enum_value("steel", self.steel)
        writer.write_enum_value("steelAnnex", self.steel_annex)
        writer.write_enum_value("timber", self.timber)
        writer.write_enum_value("timberAnnex", self.timber_annex)
    

