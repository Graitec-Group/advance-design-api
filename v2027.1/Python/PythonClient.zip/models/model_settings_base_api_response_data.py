from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .aisc_steel_calculation_settings import AiscSteelCalculationSettings
    from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings
    from .combinations_generation_settings import CombinationsGenerationSettings
    from .ec3_steel_calculation_settings import Ec3SteelCalculationSettings
    from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings
    from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings
    from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings
    from .model_settings_base import ModelSettingsBase
    from .steel_calculation_settings import SteelCalculationSettings
    from .structure_settings import StructureSettings
    from .tolerance_settings import ToleranceSettings
    from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

@dataclass
class ModelSettingsBaseApiResponse_data(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes AiscSteelCalculationSettings, CanadaCombinationsGenerationSettings, CombinationsGenerationSettings, Ec3SteelCalculationSettings, Eurocode2ndGenCombinationsGenerationSettings, EurocodeCombinationsGenerationSettings, GreenhouseCombinationsGenerationSettings, ModelSettingsBase, SteelCalculationSettings, StructureSettings, ToleranceSettings, USCombinationsGenerationSettings
    """
    # Composed type representation for type AiscSteelCalculationSettings
    aisc_steel_calculation_settings: Optional[AiscSteelCalculationSettings] = None
    # Composed type representation for type CanadaCombinationsGenerationSettings
    canada_combinations_generation_settings: Optional[CanadaCombinationsGenerationSettings] = None
    # Composed type representation for type CombinationsGenerationSettings
    combinations_generation_settings: Optional[CombinationsGenerationSettings] = None
    # Composed type representation for type Ec3SteelCalculationSettings
    ec3_steel_calculation_settings: Optional[Ec3SteelCalculationSettings] = None
    # Composed type representation for type EurocodeCombinationsGenerationSettings
    eurocode_combinations_generation_settings: Optional[EurocodeCombinationsGenerationSettings] = None
    # Composed type representation for type Eurocode2ndGenCombinationsGenerationSettings
    eurocode2nd_gen_combinations_generation_settings: Optional[Eurocode2ndGenCombinationsGenerationSettings] = None
    # Composed type representation for type GreenhouseCombinationsGenerationSettings
    greenhouse_combinations_generation_settings: Optional[GreenhouseCombinationsGenerationSettings] = None
    # Composed type representation for type ModelSettingsBase
    model_settings_base: Optional[ModelSettingsBase] = None
    # Composed type representation for type SteelCalculationSettings
    steel_calculation_settings: Optional[SteelCalculationSettings] = None
    # Composed type representation for type StructureSettings
    structure_settings: Optional[StructureSettings] = None
    # Composed type representation for type ToleranceSettings
    tolerance_settings: Optional[ToleranceSettings] = None
    # Composed type representation for type USCombinationsGenerationSettings
    u_s_combinations_generation_settings: Optional[USCombinationsGenerationSettings] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ModelSettingsBaseApiResponse_data:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ModelSettingsBaseApiResponse_data
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = ModelSettingsBaseApiResponse_data()
        if mapping_value and mapping_value.casefold() == "AiscSteelCalculationSettings".casefold():
            from .aisc_steel_calculation_settings import AiscSteelCalculationSettings

            result.aisc_steel_calculation_settings = AiscSteelCalculationSettings()
        elif mapping_value and mapping_value.casefold() == "CanadaCombinationsGenerationSettings".casefold():
            from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings

            result.canada_combinations_generation_settings = CanadaCombinationsGenerationSettings()
        elif mapping_value and mapping_value.casefold() == "CombinationsGenerationSettings".casefold():
            from .combinations_generation_settings import CombinationsGenerationSettings

            result.combinations_generation_settings = CombinationsGenerationSettings()
        elif mapping_value and mapping_value.casefold() == "Ec3SteelCalculationSettings".casefold():
            from .ec3_steel_calculation_settings import Ec3SteelCalculationSettings

            result.ec3_steel_calculation_settings = Ec3SteelCalculationSettings()
        elif mapping_value and mapping_value.casefold() == "EurocodeCombinationsGenerationSettings".casefold():
            from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings

            result.eurocode_combinations_generation_settings = EurocodeCombinationsGenerationSettings()
        elif mapping_value and mapping_value.casefold() == "Eurocode2ndGenCombinationsGenerationSettings".casefold():
            from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings

            result.eurocode2nd_gen_combinations_generation_settings = Eurocode2ndGenCombinationsGenerationSettings()
        elif mapping_value and mapping_value.casefold() == "GreenhouseCombinationsGenerationSettings".casefold():
            from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings

            result.greenhouse_combinations_generation_settings = GreenhouseCombinationsGenerationSettings()
        elif mapping_value and mapping_value.casefold() == "ModelSettingsBase".casefold():
            from .model_settings_base import ModelSettingsBase

            result.model_settings_base = ModelSettingsBase()
        elif mapping_value and mapping_value.casefold() == "SteelCalculationSettings".casefold():
            from .steel_calculation_settings import SteelCalculationSettings

            result.steel_calculation_settings = SteelCalculationSettings()
        elif mapping_value and mapping_value.casefold() == "StructureSettings".casefold():
            from .structure_settings import StructureSettings

            result.structure_settings = StructureSettings()
        elif mapping_value and mapping_value.casefold() == "ToleranceSettings".casefold():
            from .tolerance_settings import ToleranceSettings

            result.tolerance_settings = ToleranceSettings()
        elif mapping_value and mapping_value.casefold() == "USCombinationsGenerationSettings".casefold():
            from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

            result.u_s_combinations_generation_settings = USCombinationsGenerationSettings()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .aisc_steel_calculation_settings import AiscSteelCalculationSettings
        from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings
        from .combinations_generation_settings import CombinationsGenerationSettings
        from .ec3_steel_calculation_settings import Ec3SteelCalculationSettings
        from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings
        from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings
        from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings
        from .model_settings_base import ModelSettingsBase
        from .steel_calculation_settings import SteelCalculationSettings
        from .structure_settings import StructureSettings
        from .tolerance_settings import ToleranceSettings
        from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

        if self.aisc_steel_calculation_settings:
            return self.aisc_steel_calculation_settings.get_field_deserializers()
        if self.canada_combinations_generation_settings:
            return self.canada_combinations_generation_settings.get_field_deserializers()
        if self.combinations_generation_settings:
            return self.combinations_generation_settings.get_field_deserializers()
        if self.ec3_steel_calculation_settings:
            return self.ec3_steel_calculation_settings.get_field_deserializers()
        if self.eurocode_combinations_generation_settings:
            return self.eurocode_combinations_generation_settings.get_field_deserializers()
        if self.eurocode2nd_gen_combinations_generation_settings:
            return self.eurocode2nd_gen_combinations_generation_settings.get_field_deserializers()
        if self.greenhouse_combinations_generation_settings:
            return self.greenhouse_combinations_generation_settings.get_field_deserializers()
        if self.model_settings_base:
            return self.model_settings_base.get_field_deserializers()
        if self.steel_calculation_settings:
            return self.steel_calculation_settings.get_field_deserializers()
        if self.structure_settings:
            return self.structure_settings.get_field_deserializers()
        if self.tolerance_settings:
            return self.tolerance_settings.get_field_deserializers()
        if self.u_s_combinations_generation_settings:
            return self.u_s_combinations_generation_settings.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.aisc_steel_calculation_settings:
            writer.write_object_value(None, self.aisc_steel_calculation_settings)
        elif self.canada_combinations_generation_settings:
            writer.write_object_value(None, self.canada_combinations_generation_settings)
        elif self.combinations_generation_settings:
            writer.write_object_value(None, self.combinations_generation_settings)
        elif self.ec3_steel_calculation_settings:
            writer.write_object_value(None, self.ec3_steel_calculation_settings)
        elif self.eurocode_combinations_generation_settings:
            writer.write_object_value(None, self.eurocode_combinations_generation_settings)
        elif self.eurocode2nd_gen_combinations_generation_settings:
            writer.write_object_value(None, self.eurocode2nd_gen_combinations_generation_settings)
        elif self.greenhouse_combinations_generation_settings:
            writer.write_object_value(None, self.greenhouse_combinations_generation_settings)
        elif self.model_settings_base:
            writer.write_object_value(None, self.model_settings_base)
        elif self.steel_calculation_settings:
            writer.write_object_value(None, self.steel_calculation_settings)
        elif self.structure_settings:
            writer.write_object_value(None, self.structure_settings)
        elif self.tolerance_settings:
            writer.write_object_value(None, self.tolerance_settings)
        elif self.u_s_combinations_generation_settings:
            writer.write_object_value(None, self.u_s_combinations_generation_settings)
    

