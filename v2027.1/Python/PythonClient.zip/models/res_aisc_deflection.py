from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_aisc_deflection_location_result import ResAiscDeflectionLocationResult
    from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData
    from .steel_deflection_location import SteelDeflectionLocation

from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

@dataclass
class ResAiscDeflection(ResNorthAmericaSteelLinearDesignData, AdditionalDataHolder, Parsable):
    """
    Deflections of one element against one allowable-deflection criterion, at every location the enginemeasured. Native: aisc_Deflection.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Allowable deflection of an ELEMENT, as the denominator of L/x - the design template's L/360 isreported as 360. Native: df_All_Coeff.
    allowable_coefficient: Optional[float] = None
    # Allowable deflection of a SUPER ELEMENT, as the denominator of L/x.Native: df_All_Coeff_SuperElem.
    allowable_coefficient_super_element: Optional[float] = None
    # Where the ELEMENT-level deflection was required to be verified, as set on the design template.Native: iLocation_EL.
    element_verification_location: Optional[SteelDeflectionLocation] = None
    # The governing location, whichever of the above the verification settings selected.Native: the *_Envelope fields.
    envelope: Optional[ResAiscDeflectionLocationResult] = None
    # Reference length the envelope location was divided by, in m. Native: df_Length_Envelope.
    envelope_length: Optional[float] = None
    # Deflection at the end of one segment, relative to that segment's start.Native: the *_TronEnd fields.
    segment_end: Optional[ResAiscDeflectionLocationResult] = None
    # Reference length the segment locations were divided by, in m. Native: df_Length_Tron.
    segment_length: Optional[float] = None
    # Deflection in the span of one segment, relative to the line joining that segment's ends.Native: the *_TronSpan fields.
    segment_span: Optional[ResAiscDeflectionLocationResult] = None
    # Deflection at the extremity of the super element - the absolute displacement of its ends.Native: the *_SEExtremity fields.
    super_element_end: Optional[ResAiscDeflectionLocationResult] = None
    # Reference length the super-element locations were divided by, in m. Native: df_Length_SE.
    super_element_length: Optional[float] = None
    # Deflection in the span of the super element, relative to the line joining its ends.Native: the *_SESpan fields.
    super_element_span: Optional[ResAiscDeflectionLocationResult] = None
    # Where the SUPER-ELEMENT-level deflection was required to be verified, as set on the designtemplate. Native: iLocation_SE.
    super_element_verification_location: Optional[SteelDeflectionLocation] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscDeflection:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscDeflection
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscDeflection()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_aisc_deflection_location_result import ResAiscDeflectionLocationResult
        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData
        from .steel_deflection_location import SteelDeflectionLocation

        from .res_aisc_deflection_location_result import ResAiscDeflectionLocationResult
        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData
        from .steel_deflection_location import SteelDeflectionLocation

        fields: dict[str, Callable[[Any], None]] = {
            "allowableCoefficient": lambda n : setattr(self, 'allowable_coefficient', n.get_float_value()),
            "allowableCoefficientSuperElement": lambda n : setattr(self, 'allowable_coefficient_super_element', n.get_float_value()),
            "elementVerificationLocation": lambda n : setattr(self, 'element_verification_location', n.get_enum_value(SteelDeflectionLocation)),
            "envelope": lambda n : setattr(self, 'envelope', n.get_object_value(ResAiscDeflectionLocationResult)),
            "envelopeLength": lambda n : setattr(self, 'envelope_length', n.get_float_value()),
            "segmentEnd": lambda n : setattr(self, 'segment_end', n.get_object_value(ResAiscDeflectionLocationResult)),
            "segmentLength": lambda n : setattr(self, 'segment_length', n.get_float_value()),
            "segmentSpan": lambda n : setattr(self, 'segment_span', n.get_object_value(ResAiscDeflectionLocationResult)),
            "superElementEnd": lambda n : setattr(self, 'super_element_end', n.get_object_value(ResAiscDeflectionLocationResult)),
            "superElementLength": lambda n : setattr(self, 'super_element_length', n.get_float_value()),
            "superElementSpan": lambda n : setattr(self, 'super_element_span', n.get_object_value(ResAiscDeflectionLocationResult)),
            "superElementVerificationLocation": lambda n : setattr(self, 'super_element_verification_location', n.get_enum_value(SteelDeflectionLocation)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("allowableCoefficient", self.allowable_coefficient)
        writer.write_float_value("allowableCoefficientSuperElement", self.allowable_coefficient_super_element)
        writer.write_enum_value("elementVerificationLocation", self.element_verification_location)
        writer.write_object_value("envelope", self.envelope)
        writer.write_float_value("envelopeLength", self.envelope_length)
        writer.write_object_value("segmentEnd", self.segment_end)
        writer.write_float_value("segmentLength", self.segment_length)
        writer.write_object_value("segmentSpan", self.segment_span)
        writer.write_object_value("superElementEnd", self.super_element_end)
        writer.write_float_value("superElementLength", self.super_element_length)
        writer.write_object_value("superElementSpan", self.super_element_span)
        writer.write_enum_value("superElementVerificationLocation", self.super_element_verification_location)
        writer.write_additional_data_value(self.additional_data)
    

