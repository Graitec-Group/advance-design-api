from enum import Enum

class ECombinationsGenerationMode(str, Enum):
    Simplified = "Simplified",
    DetailedMatrix = "DetailedMatrix",

