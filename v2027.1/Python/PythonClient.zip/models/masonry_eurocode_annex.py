from enum import Enum

class MasonryEurocodeAnnex(str, Enum):
    General = "general",
    Czech = "czech",
    France = "france",
    Poland = "poland",
    Romania = "romania",
    Slovakia = "slovakia",
    Uk = "uk",
    Germany = "germany",
    Portugal = "portugal",
    Spain = "spain",

