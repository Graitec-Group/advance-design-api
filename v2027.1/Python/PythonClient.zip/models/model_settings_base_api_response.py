from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .api_response_details import ApiResponseDetails
    from .model_settings_base_api_response_data import ModelSettingsBaseApiResponse_data

@dataclass
class ModelSettingsBaseApiResponse(Parsable):
    """
    Standard envelope returned by every API operation.Wraps the actual result together with structured diagnostics(errors, warnings, informational messages) so that callers –including AI agents – can programmatically inspect the outcome.
    """
    # The result payload of the operation.May be `null` or default when AD.API.Srv.Models.ApiResponseDetails.Success is `false`.
    data: Optional[ModelSettingsBaseApiResponse_data] = None
    # response details for API operations, including the actual result data and structured diagnostics.
    details: Optional[ApiResponseDetails] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ModelSettingsBaseApiResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ModelSettingsBaseApiResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ModelSettingsBaseApiResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .api_response_details import ApiResponseDetails
        from .model_settings_base_api_response_data import ModelSettingsBaseApiResponse_data

        from .api_response_details import ApiResponseDetails
        from .model_settings_base_api_response_data import ModelSettingsBaseApiResponse_data

        fields: dict[str, Callable[[Any], None]] = {
            "data": lambda n : setattr(self, 'data', n.get_object_value(ModelSettingsBaseApiResponse_data)),
            "details": lambda n : setattr(self, 'details', n.get_object_value(ApiResponseDetails)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("data", self.data)
        writer.write_object_value("details", self.details)
    

