from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResAiscCombinedForcesDetail(Parsable):
    """
    The quantities behind the combined-forces interaction, AISC 360 chapter H / CSA S16 clauses 13.8and 13.9. Native: the df_Pr ... df_McLTB fields of aisc_Resistance.
    """
    # The interaction exponent beta, dimensionless - CSA S16 clause 13.8's beta, and the equivalentexponent AISC 360 uses for HSS and box sections. Native: df_beta.
    beta: Optional[float] = None
    # Available lateral-torsional strength for strong-axis flexure, in N*m. The companion ofAD.API.ResAiscCombinedForcesDetail.Pcy in AISC 360 equation (H1-2). Native: df_McLTB.
    mc_l_t_b: Optional[float] = None
    # Available flexural strength about y-y, Mcy, in N*m. Native: df_Mcy.
    mcy: Optional[float] = None
    # Available flexural strength about z-z, Mcz, in N*m. Native: df_Mcz.
    mcz: Optional[float] = None
    # Required flexural strength about y-y, Mry, in N*m. Native: df_Mry.
    mry: Optional[float] = None
    # Required flexural strength about z-z, Mrz, in N*m. Native: df_Mrz.
    mrz: Optional[float] = None
    # Available axial strength Pc, in N. Native: df_Pc.
    pc: Optional[float] = None
    # Available compressive strength OUT OF THE PLANE OF BENDING, Pcy, in N. Used by the alternativeinteraction of AISC 360 equation (H1-2), so it is only meaningful whenAD.API.ResAiscResistanceCheck.AppliedAiscFormula is AD.API.AiscFormula.H1_2.Native: df_Pcy.
    pcy: Optional[float] = None
    # Required axial strength Pr, in N. Native: df_Pr.
    pr: Optional[float] = None
    # Available torsional strength Tc, in N*m. Native: df_Tc.
    tc: Optional[float] = None
    # Required torsional strength Tr, in N*m. Native: df_Tr.
    tr: Optional[float] = None
    # Second-order amplification factor U1 for bending about y-y, dimensionless - CSA S16 clause 13.8.Native: df_U1y, fed from the engine's U1x.
    u1y: Optional[float] = None
    # Second-order amplification factor U1 for bending about z-z, dimensionless.Native: df_U1z, fed from the engine's U1y.
    u1z: Optional[float] = None
    # Available shear strength along y, Vcy, in N. Native: df_Vcy.
    vcy: Optional[float] = None
    # Available shear strength along z, Vcz, in N. Native: df_Vcz.
    vcz: Optional[float] = None
    # Required shear strength along y, Vry, in N. Native: df_Vry.
    vry: Optional[float] = None
    # Required shear strength along z, Vrz, in N. Native: df_Vrz.
    vrz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscCombinedForcesDetail:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscCombinedForcesDetail
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscCombinedForcesDetail()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "beta": lambda n : setattr(self, 'beta', n.get_float_value()),
            "mcLTB": lambda n : setattr(self, 'mc_l_t_b', n.get_float_value()),
            "mcy": lambda n : setattr(self, 'mcy', n.get_float_value()),
            "mcz": lambda n : setattr(self, 'mcz', n.get_float_value()),
            "mry": lambda n : setattr(self, 'mry', n.get_float_value()),
            "mrz": lambda n : setattr(self, 'mrz', n.get_float_value()),
            "pc": lambda n : setattr(self, 'pc', n.get_float_value()),
            "pcy": lambda n : setattr(self, 'pcy', n.get_float_value()),
            "pr": lambda n : setattr(self, 'pr', n.get_float_value()),
            "tc": lambda n : setattr(self, 'tc', n.get_float_value()),
            "tr": lambda n : setattr(self, 'tr', n.get_float_value()),
            "u1y": lambda n : setattr(self, 'u1y', n.get_float_value()),
            "u1z": lambda n : setattr(self, 'u1z', n.get_float_value()),
            "vcy": lambda n : setattr(self, 'vcy', n.get_float_value()),
            "vcz": lambda n : setattr(self, 'vcz', n.get_float_value()),
            "vry": lambda n : setattr(self, 'vry', n.get_float_value()),
            "vrz": lambda n : setattr(self, 'vrz', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("beta", self.beta)
        writer.write_float_value("mcLTB", self.mc_l_t_b)
        writer.write_float_value("mcy", self.mcy)
        writer.write_float_value("mcz", self.mcz)
        writer.write_float_value("mry", self.mry)
        writer.write_float_value("mrz", self.mrz)
        writer.write_float_value("pc", self.pc)
        writer.write_float_value("pcy", self.pcy)
        writer.write_float_value("pr", self.pr)
        writer.write_float_value("tc", self.tc)
        writer.write_float_value("tr", self.tr)
        writer.write_float_value("u1y", self.u1y)
        writer.write_float_value("u1z", self.u1z)
        writer.write_float_value("vcy", self.vcy)
        writer.write_float_value("vcz", self.vcz)
        writer.write_float_value("vry", self.vry)
        writer.write_float_value("vrz", self.vrz)
    

