from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_base import ElementBase
    from .e_i_d import EID
    from .planar_element_mesh_properties import PlanarElementMeshProperties
    from .planar_element_type import PlanarElementType
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class ElementPlanar(ElementBase, AdditionalDataHolder, Parsable):
    """
    The planar element class (i.e. slab , shell, etc.)
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .planar_element_type import PlanarElementType

    # element typeDefault value : PlanarElementType.shell
    element_type: Optional[PlanarElementType] = PlanarElementType("shell")
    # eccentricity of element;Unit: mDefault value : 0.0
    eccentricity: Optional[float] = None
    # Decide whether or not the offset is taken into account in the FEM calculation.Default value : false
    eccentricity_c_onsidered_also_for_f_e_m: Optional[bool] = None
    # geometry defined by 3D point list defined in global axis system, can't be empty, the object will not be createdThe contour must be a valid planar polygon, checked with the same rule as the interactive model: atleast 3 points, no coincident (duplicated) points, no three consecutive COLLINEAR points (they wouldcreate a degenerate zero-length edge), all the points in the same plane, and no self-intersection.A contour that breaks any of these is refused: the element is not created, and on Update nothing atall is modified (the element keeps its previous geometry).
    geom_pts_list: Optional[list[Pt3D]] = None
    # Internal ids (AD.API.EID) of the AD.API.LinearReleaseTemplate applied to each edgeof the element, one entry per edge, in edge order: `LinearReleases[i]` is the edge going from`GeomPtsList[i]` to `GeomPtsList[i+1]`, the last one closing back on `GeomPtsList[0]`.This is the per-side definition of the AD "Releases / Definition" dialog.- On Get: the complete edge list of the element (null only when the element has no releases at all).- On Create / Update: optional. When supplied, the number of entries must equal the number of  edges of the element and every id must be an existing template, otherwise the whole list is  rejected, an error is logged and no edge is changed - never a partial assignment.- Ignored when AD.API.ElementPlanar.SelectedReleaseName is also set.- On Update, an element whose releases were never initialized (created by an API build older than  this feature) is initialized with the default template first, so the per-edge assignment applies.- When an Update changes AD.API.ElementPlanar.GeomPtsList in a way that changes the NUMBER of edges, the  indices no longer designate the same physical sides, so every edge is RESET to the built-in "Fixed"  template and a warning is logged. A contour change that keeps the same number of edges leaves the  releases in place (they stay attached to the same edge index), like the interactive model does.  To keep or apply a specific assignment across an edge-count change, send it - this property or  AD.API.ElementPlanar.SelectedReleaseName - in the SAME update; an explicit request always wins over the reset.Use the templates already defined in the model: list them with a query on`InformationalElementTypeEnum.LinearReleaseTemplate`, or create your own with`CreateInformationalElement`.Default value: null
    linear_releases: Optional[list[EID]] = None
    # EID of the material already created, if it is 0 the object is not created
    material: Optional[EID] = None
    # Mesh propertiesDefault value : optional nullable object
    mesh_properties: Optional[PlanarElementMeshProperties] = None
    # Name of the AD.API.LinearReleaseTemplate applied to every edge of the element.This is the "Releases / Side" property of the AD user interface.- On Get: the value stored on the element - the name of a template when all the edges share  the same one, a localized "Other" when they differ, and empty for an element whose releases  were never initialized. AD.API.ElementPlanar.LinearReleases always holds the authoritative per-edge state.- On Create: when omitted, the built-in "Fixed" template is applied to every edge, exactly like  for an element created in AD. A value that names no existing template falls back to "Fixed"  and a warning is logged - the element is still created.- On Update: null or an empty string leaves the current assignment unchanged; a non-empty value  must name a template that exists in the model, otherwise it is ignored and a warning is logged.- Setting it applies that template to ALL the edges and therefore takes precedence over  AD.API.ElementPlanar.LinearReleases when both are provided, on Create as well as on Update; sending  both logs a warning. Send AD.API.ElementPlanar.LinearReleases alone to define a per-edge assignment.Because the names of the three built-in templates are localized, the invariant keywords "free","pinned" and "fixed" are also accepted (case-insensitive) and resolved to the correspondingbuilt-in template.Default value: null
    selected_release_name: Optional[str] = None
    # Definition of variable thickness by slope (tangent of the angle of inclination) in local x axis directionUnit: no unitDefault value : 0.0
    slope_x: Optional[float] = None
    # Definition of variable thickness by slope (tangent of the angle of inclination) in local y axis directionUnit: no unitDefault value : 0.0
    slope_y: Optional[float] = None
    # Act as Supporting element for load areasDefault value : true
    supporting_element: Optional[bool] = None
    # Internal ids (AD.API.EID) of the systems (`som.System`) this element belongs to.An element can belong to several systems. - On Get: populated with the element's current systems. - On Create: the element is created in the first listed system and added to the rest; when  empty, it is placed in the model's default root system ("Structure 0"); a listed id that is not an existing system makes the creation fail. - On Update: when non-empty, the element's membership is set to exactly these systems (added  to the new ones, removed from the others); when empty, the membership is left unchanged.  Invalid system ids are rejected (the update fails without changing any membership). - The element always belongs to at least one system: it can never be left with none. If it  would be (its systems were deleted, or the requested membership could not be applied), it is  put back in the root system "Structure 0" and a warning is logged.
    system_i_ds: Optional[list[EID]] = None
    # Thickness in 1st vertex;Unit: mDefault value : 0.2
    thickness_in1st_vertex: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementPlanar:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementPlanar
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementPlanar()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_base import ElementBase
        from .e_i_d import EID
        from .planar_element_mesh_properties import PlanarElementMeshProperties
        from .planar_element_type import PlanarElementType
        from .pt3_d import Pt3D

        from .element_base import ElementBase
        from .e_i_d import EID
        from .planar_element_mesh_properties import PlanarElementMeshProperties
        from .planar_element_type import PlanarElementType
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "eccentricity": lambda n : setattr(self, 'eccentricity', n.get_float_value()),
            "eccentricityCOnsideredAlsoForFEM": lambda n : setattr(self, 'eccentricity_c_onsidered_also_for_f_e_m', n.get_bool_value()),
            "elementType": lambda n : setattr(self, 'element_type', n.get_enum_value(PlanarElementType)),
            "geomPtsList": lambda n : setattr(self, 'geom_pts_list', n.get_collection_of_object_values(Pt3D)),
            "linearReleases": lambda n : setattr(self, 'linear_releases', n.get_collection_of_object_values(EID)),
            "material": lambda n : setattr(self, 'material', n.get_object_value(EID)),
            "meshProperties": lambda n : setattr(self, 'mesh_properties', n.get_object_value(PlanarElementMeshProperties)),
            "selectedReleaseName": lambda n : setattr(self, 'selected_release_name', n.get_str_value()),
            "slopeX": lambda n : setattr(self, 'slope_x', n.get_float_value()),
            "slopeY": lambda n : setattr(self, 'slope_y', n.get_float_value()),
            "supportingElement": lambda n : setattr(self, 'supporting_element', n.get_bool_value()),
            "systemIDs": lambda n : setattr(self, 'system_i_ds', n.get_collection_of_object_values(EID)),
            "thicknessIn1stVertex": lambda n : setattr(self, 'thickness_in1st_vertex', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("eccentricity", self.eccentricity)
        writer.write_bool_value("eccentricityCOnsideredAlsoForFEM", self.eccentricity_c_onsidered_also_for_f_e_m)
        writer.write_enum_value("elementType", self.element_type)
        writer.write_collection_of_object_values("geomPtsList", self.geom_pts_list)
        writer.write_collection_of_object_values("linearReleases", self.linear_releases)
        writer.write_object_value("material", self.material)
        writer.write_object_value("meshProperties", self.mesh_properties)
        writer.write_str_value("selectedReleaseName", self.selected_release_name)
        writer.write_float_value("slopeX", self.slope_x)
        writer.write_float_value("slopeY", self.slope_y)
        writer.write_bool_value("supportingElement", self.supporting_element)
        writer.write_collection_of_object_values("systemIDs", self.system_i_ds)
        writer.write_float_value("thicknessIn1stVertex", self.thickness_in1st_vertex)
        writer.write_additional_data_value(self.additional_data)
    

