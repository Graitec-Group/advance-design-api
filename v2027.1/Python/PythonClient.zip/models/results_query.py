from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .results_query_design import ResultsQueryDesign
    from .results_query_design_steel_linear import ResultsQueryDesignSteelLinear
    from .results_query_f_e_m import ResultsQueryFEM

@dataclass
class ResultsQuery(Parsable):
    """
    Base type for results queries. Derived types carry the actual query parametersand are selected through the "$type" discriminator.
    """
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResultsQuery:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResultsQuery
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "ResultsQueryDesign".casefold():
            from .results_query_design import ResultsQueryDesign

            return ResultsQueryDesign()
        if mapping_value and mapping_value.casefold() == "ResultsQueryDesignSteelLinear".casefold():
            from .results_query_design_steel_linear import ResultsQueryDesignSteelLinear

            return ResultsQueryDesignSteelLinear()
        if mapping_value and mapping_value.casefold() == "ResultsQueryFEM".casefold():
            from .results_query_f_e_m import ResultsQueryFEM

            return ResultsQueryFEM()
        return ResultsQuery()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .results_query_design import ResultsQueryDesign
        from .results_query_design_steel_linear import ResultsQueryDesignSteelLinear
        from .results_query_f_e_m import ResultsQueryFEM

        from .results_query_design import ResultsQueryDesign
        from .results_query_design_steel_linear import ResultsQueryDesignSteelLinear
        from .results_query_f_e_m import ResultsQueryFEM

        fields: dict[str, Callable[[Any], None]] = {
            "$type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("$type", self.type)
    

