from enum import Enum

class AiscResistanceError(str, Enum):
    None_ = "None",
    NotDone = "NotDone",
    Class_ = "Class",
    Segments = "Segments",

