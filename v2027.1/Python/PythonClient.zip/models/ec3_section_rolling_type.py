from enum import Enum

class Ec3SectionRollingType(str, Enum):
    Unknown = "Unknown",
    Rolled = "Rolled",
    HotRolled = "HotRolled",
    ColdRolled = "ColdRolled",
    Welded = "Welded",
    ThickWelded = "ThickWelded",
    ColdFormedRolled = "ColdFormedRolled",
    ColdFormedBend = "ColdFormedBend",

