from enum import Enum

class ESteelOptimizationSearchRange(str, Enum):
    EProfileOptimizationSearchRangeAuto = "eProfileOptimizationSearchRangeAuto",
    EProfileOptimizationSearchRangeAutoWithMaxLimit = "eProfileOptimizationSearchRangeAutoWithMaxLimit",

