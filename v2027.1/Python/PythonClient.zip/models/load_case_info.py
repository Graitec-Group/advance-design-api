from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID
    from .load_case_analysis_buckling import LoadCaseAnalysisBuckling

@dataclass
class LoadCaseInfo(Parsable):
    """
    Identifies the load case / analysis for which results are requested.The base carries only the EID; specialized analyses (buckling, non-linear)add their own indices through derived types selected by the "$type" discriminator.
    """
    # EID of LoadCase/Analysis.
    id: Optional[EID] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseInfo:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseInfo
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "LoadCaseAnalysisBuckling".casefold():
            from .load_case_analysis_buckling import LoadCaseAnalysisBuckling

            return LoadCaseAnalysisBuckling()
        return LoadCaseInfo()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID
        from .load_case_analysis_buckling import LoadCaseAnalysisBuckling

        from .e_i_d import EID
        from .load_case_analysis_buckling import LoadCaseAnalysisBuckling

        fields: dict[str, Callable[[Any], None]] = {
            "id": lambda n : setattr(self, 'id', n.get_object_value(EID)),
            "$type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("id", self.id)
        writer.write_str_value("$type", self.type)
    

