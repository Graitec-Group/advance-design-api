from enum import Enum

class ESteelProfileSortCriterion(str, Enum):
    ETriCriteriaDeflections = "eTriCriteriaDeflections",
    ETriCriteriaWorkRatio = "eTriCriteriaWorkRatio",
    ETriCriteriaEnveloppe = "eTriCriteriaEnveloppe",

