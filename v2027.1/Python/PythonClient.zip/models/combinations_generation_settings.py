from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings
    from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings
    from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings
    from .e_combinations_eurocode_annex import ECombinationsEurocodeAnnex
    from .e_combinations_standard import ECombinationsStandard
    from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings
    from .model_settings_base import ModelSettingsBase
    from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

from .model_settings_base import ModelSettingsBase

@dataclass
class CombinationsGenerationSettings(ModelSettingsBase, AdditionalDataHolder, Parsable):
    """
    The settings of the automatic ("simplified") combination generation, as they are storedon the model - the same ones the Combinations options dialog of the desktop applicationedits.These are NOT properties of any combination: they are general options that apply to thewhole model and are read by the generation, so they are set once, before calling`GenerateCombinations`. What each load case contributes on its own (its gamma, itspsi, its duration) lives on the load case instead, as`LoadCase.CombinationsCoefficients`.ONE GROUP OF MODEL SETTINGS. This class is the `CombinationsGeneration` group ofAD.API.ModelSettingsBase - the general settings of the model - so it is read with`GetModelSettings(eModelSettingsCategory.CombinationsGeneration)`, written with`SetModelSettings`, which takes the base class and takes the group from thisobject's own type, and put back to what the active standard prescribes with`ResetModelSettings(eModelSettingsCategory.CombinationsGeneration)`.FIVE SHAPES, FOUR OF THEM REACHABLE. Eurocode, the 2nd generation Eurocode, US, Canada andEN 13031-1 (greenhouses) share nothing: each has its own set of fields on the model andits own dialog page. The derived type therefore says which standard the settings belongto, and AD.API.CombinationsGenerationSettings.Standard says which one the model actually generates for. The 2ndgeneration shape is NOT reachable: EN 1990:2023 is not exposed by this API, soAD.API.eCombinationsStandard has no member for it and a model that carries it isrefused by the read, the write and the reset alike.HOW THE STANDARD IS CHOSEN. Not here - it is a property of the SESSION, fixed on the`NewProject` / `OpenProject` call and unchangeable afterwards. By default it isresolved from the localization passed to `SetEnvironment`: `LOCALIZATION_US` and`LOCALIZATION_ASIA` give a US standard, `LOCALIZATION_CANADA` a Canadian one,`LOCALIZATION_ITALIA` gives NTC 2018, and every other localization gives Eurocodewith that country's national annex. WHICH edition of the US and Canadian standards isthe installation's own business - read AD.API.CombinationsGenerationSettings.Standard rather than assuming one.To choose it instead of inheriting it, set `Environments.DesignCodes.Combinations` onthat same call. EN 13031-1 is reachable only on an installation configured for greenhouses,whichever way you ask for it: elsewhere its settings can be written and read back, but ageneration will not use them and naming it in `DesignCodes` is refused.DERIVED COEFFICIENTS. Wherever the standard tabulates a coefficient against a category,the category decides and the coefficient is read only, exactly as the cell is read onlyin the dialog's grid. Sending a value anyway is not an error: it is ignored and reportedas a warning in the response diagnostics. Each category has one "user defined" memberwhich unlocks its coefficients; that is the only way to impose your own.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # National annex of the Eurocode standard. READ ONLY HERE on the same terms asAD.API.CombinationsGenerationSettings.Standard - chosen with `Environments.DesignCodes.CombinationsAnnex` -and null for the standards that have no annex (US, Canada, and the Italian standards,which differ from Eurocode by standard rather than by annex).Worth reading before writing live load or snow settings: the annex decides how manycategories exist and what each index means.
    annex: Optional[ECombinationsEurocodeAnnex] = None
    # The combination standard the model generates for. READ ONLY HERE - a value sent in a`SetModelSettings` request is ignored. What decides which settings a requestwrites is its `$type`, not this.It is chosen once, for the session, with `Environments.DesignCodes.Combinations`on `NewProject` / `OpenProject`, and comes from the localization when that isleft null.
    standard: Optional[ECombinationsStandard] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CombinationsGenerationSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CombinationsGenerationSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "CanadaCombinationsGenerationSettings".casefold():
            from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings

            return CanadaCombinationsGenerationSettings()
        if mapping_value and mapping_value.casefold() == "Eurocode2ndGenCombinationsGenerationSettings".casefold():
            from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings

            return Eurocode2ndGenCombinationsGenerationSettings()
        if mapping_value and mapping_value.casefold() == "EurocodeCombinationsGenerationSettings".casefold():
            from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings

            return EurocodeCombinationsGenerationSettings()
        if mapping_value and mapping_value.casefold() == "GreenhouseCombinationsGenerationSettings".casefold():
            from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings

            return GreenhouseCombinationsGenerationSettings()
        if mapping_value and mapping_value.casefold() == "USCombinationsGenerationSettings".casefold():
            from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

            return USCombinationsGenerationSettings()
        return CombinationsGenerationSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings
        from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings
        from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings
        from .e_combinations_eurocode_annex import ECombinationsEurocodeAnnex
        from .e_combinations_standard import ECombinationsStandard
        from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings
        from .model_settings_base import ModelSettingsBase
        from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

        from .canada_combinations_generation_settings import CanadaCombinationsGenerationSettings
        from .eurocode2nd_gen_combinations_generation_settings import Eurocode2ndGenCombinationsGenerationSettings
        from .eurocode_combinations_generation_settings import EurocodeCombinationsGenerationSettings
        from .e_combinations_eurocode_annex import ECombinationsEurocodeAnnex
        from .e_combinations_standard import ECombinationsStandard
        from .greenhouse_combinations_generation_settings import GreenhouseCombinationsGenerationSettings
        from .model_settings_base import ModelSettingsBase
        from .u_s_combinations_generation_settings import USCombinationsGenerationSettings

        fields: dict[str, Callable[[Any], None]] = {
            "annex": lambda n : setattr(self, 'annex', n.get_enum_value(ECombinationsEurocodeAnnex)),
            "standard": lambda n : setattr(self, 'standard', n.get_enum_value(ECombinationsStandard)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("annex", self.annex)
        writer.write_enum_value("standard", self.standard)
        writer.write_additional_data_value(self.additional_data)
    

