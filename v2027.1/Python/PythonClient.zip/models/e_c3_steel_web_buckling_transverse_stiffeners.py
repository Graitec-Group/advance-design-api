from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .steel_web_buckling_stiffener_location import SteelWebBucklingStiffenerLocation
    from .steel_web_stiffeners_sides import SteelWebStiffenersSides

@dataclass
class EC3SteelWebBucklingTransverseStiffeners(Parsable):
    """
    Transverse stiffeners of the web (maps to the AD model object`som.EC3RoleSDWebBucklingTransverseStiffeners`).
    """
    from .steel_web_stiffeners_sides import SteelWebStiffenersSides

    # On which sides of the web the transverse stiffeners are welded (maps to"TransverseStiffenersSides"). Advance Design does not currently display this property, but it is stored and propagated. Default value : SteelWebStiffenersSides.both_sides_of_web
    transverse_stiffeners_sides: Optional[SteelWebStiffenersSides] = SteelWebStiffenersSides("both_sides_of_web")
    # Whether the transverse stiffeners are taken into account (maps to"TransverseStiffenersChecking"). Default value : true
    transverse_stiffeners_checking: Optional[bool] = None
    # Positions of the transverse stiffeners along the element (maps to"TransverseStiffenersLocation"). A new template is created with TWO entries, one at each end of the element: (abscissa 0,relative 0) and (abscissa 1, relative 1). On Update the list REPLACES the stored one in full - the model vector is cleared and rebuilt -so send every stiffener you want to keep, not just the new ones. Send null to leave the storedlist untouched. Default value : null
    transverse_stiffeners_location: Optional[list[SteelWebBucklingStiffenerLocation]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EC3SteelWebBucklingTransverseStiffeners:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EC3SteelWebBucklingTransverseStiffeners
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EC3SteelWebBucklingTransverseStiffeners()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .steel_web_buckling_stiffener_location import SteelWebBucklingStiffenerLocation
        from .steel_web_stiffeners_sides import SteelWebStiffenersSides

        from .steel_web_buckling_stiffener_location import SteelWebBucklingStiffenerLocation
        from .steel_web_stiffeners_sides import SteelWebStiffenersSides

        fields: dict[str, Callable[[Any], None]] = {
            "transverseStiffenersChecking": lambda n : setattr(self, 'transverse_stiffeners_checking', n.get_bool_value()),
            "transverseStiffenersLocation": lambda n : setattr(self, 'transverse_stiffeners_location', n.get_collection_of_object_values(SteelWebBucklingStiffenerLocation)),
            "transverseStiffenersSides": lambda n : setattr(self, 'transverse_stiffeners_sides', n.get_enum_value(SteelWebStiffenersSides)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("transverseStiffenersChecking", self.transverse_stiffeners_checking)
        writer.write_collection_of_object_values("transverseStiffenersLocation", self.transverse_stiffeners_location)
        writer.write_enum_value("transverseStiffenersSides", self.transverse_stiffeners_sides)
    

