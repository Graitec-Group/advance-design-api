from enum import Enum

class DesignTemplateElementType(str, Enum):
    Linear = "linear",
    Planar = "planar",
    Undefined_element = "undefined_element",

