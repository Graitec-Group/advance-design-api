from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_steel_interaction_factor_method import ESteelInteractionFactorMethod

@dataclass
class Ec3G2VerificationOptions(Parsable):
    """
    The three values EN 1993-1-1:2023 adds to the Verification page. Sent on a model that isnot configured with the 2nd generation Eurocode, this whole object is ignored and reportedas a warning - the desktop dialog hides the same controls there.
    """
    # Which expression the interaction factors k_ij come from.
    interaction_factor_method: Optional[ESteelInteractionFactorMethod] = None
    # Allow the elasto-plastic modulus for class 3 (semi-compact) cross-sections. On bydefault.
    use_elasto_plastic_modulus_for_class3: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Ec3G2VerificationOptions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Ec3G2VerificationOptions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Ec3G2VerificationOptions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_steel_interaction_factor_method import ESteelInteractionFactorMethod

        from .e_steel_interaction_factor_method import ESteelInteractionFactorMethod

        fields: dict[str, Callable[[Any], None]] = {
            "interactionFactorMethod": lambda n : setattr(self, 'interaction_factor_method', n.get_enum_value(ESteelInteractionFactorMethod)),
            "useElastoPlasticModulusForClass3": lambda n : setattr(self, 'use_elasto_plastic_modulus_for_class3', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("interactionFactorMethod", self.interaction_factor_method)
        writer.write_bool_value("useElastoPlasticModulusForClass3", self.use_elasto_plastic_modulus_for_class3)
    

