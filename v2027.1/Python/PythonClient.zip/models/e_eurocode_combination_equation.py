from enum import Enum

class EEurocodeCombinationEquation(str, Enum):
    Equation_6_10 = "Equation_6_10",
    Equation_6_10a_6_10b = "Equation_6_10a_6_10b",

