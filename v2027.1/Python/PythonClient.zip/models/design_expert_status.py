from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .design_calculation_type import DesignCalculationType

@dataclass
class DesignExpertStatus(Parsable):
    """
    State of the Expert design calculation of ONE material family, as part ofAD.API.AnalysisModelStatus. One entry per `DesignCalculationType` is alwaysreturned, including for families the model contains no element of - a family with nothing tocalculate simply reports `IsCalculated = false`.The family is named by the SAME enumeration `LaunchDesignCalculation` takes, so reading astate and launching a calculation use one vocabulary: whatever appears here can be launched,and whatever can be launched appears here.
    """
    from .design_calculation_type import DesignCalculationType

    # Which material family this entry describes.Default value: DesignCalculationType.Concrete
    family: Optional[DesignCalculationType] = DesignCalculationType("Concrete")
    # True when the design engine of this family has produced design results on the model.This is the engine's OWN flag on `som.ModelProperties` - the same one`LaunchDesignCalculation` returns as its verdict and the same one the Advance Designuser interface reads to decide whether design results exist:`CalculationReinforcementDone`, `CalculationSteelDone`,`CalculationTimberDone`, `CalculationCompositeDone`. The API and the applicationtherefore agree on what "calculated" means.IT IS NOT A PROOF THAT DESIGN RESULTS ARE ON DISK. The flag is a boolean the model stores,and the desktop application writes it on one path that never calculated anything: closingthe Advanced stability dialog of a linear element re-writes `CalculationSteelDone` as"nothing relevant changed", so a project saved from the user interface can report thesteel family calculated without a single steel result. That path does not exist in an APIsession, so a model calculated entirely through this API is not affected - but a modelopened from a project file may be. When it has to be certain, read the results(`GetDesignResults`) rather than this flag.Default value: false
    is_calculated: Optional[bool] = None
    # True when the CALCULATION SETTINGS of this family were changed after the design was lastcalculated, so the results no longer match the settings that would be used now. The modelflags `IsHypothesesDeCalculMetalModified`, `IsHypothesesDeCalculTimberModified`and `IsHypothesesDeCalculCompositeModified`.`null` means the model does not track this for the family: it is ALWAYS null for`DesignCalculationType.Concrete`, which has no such flag in the model schema (concretehas `VerificationModelBA` and `ErrorsOnCalculBA` instead, and neither means "thesettings changed since the calculation"). Nothing is missing from this API - theinformation does not exist.ONLY THE DESKTOP APPLICATION MAINTAINS THESE FLAGS. They are raised by the CalculationSettings dialog when it detects a changed control, and cleared by the design engines.`SetModelSettings` does NOT raise them, so in an API-only session this stays`false` even right after the steel calculation settings were rewritten. Treat`true` as reliable and `false` as "nothing was reported", not as "nothingchanged".Default value: null
    settings_changed_since_calculation: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DesignExpertStatus:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DesignExpertStatus
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DesignExpertStatus()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .design_calculation_type import DesignCalculationType

        from .design_calculation_type import DesignCalculationType

        fields: dict[str, Callable[[Any], None]] = {
            "family": lambda n : setattr(self, 'family', n.get_enum_value(DesignCalculationType)),
            "isCalculated": lambda n : setattr(self, 'is_calculated', n.get_bool_value()),
            "settingsChangedSinceCalculation": lambda n : setattr(self, 'settings_changed_since_calculation', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("family", self.family)
        writer.write_bool_value("isCalculated", self.is_calculated)
        writer.write_bool_value("settingsChangedSinceCalculation", self.settings_changed_since_calculation)
    

