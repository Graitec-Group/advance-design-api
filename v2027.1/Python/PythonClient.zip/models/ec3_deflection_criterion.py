from enum import Enum

class Ec3DeflectionCriterion(str, Enum):
    Criterion1 = "Criterion1",
    Criterion2 = "Criterion2",

