from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .non_linear_f_e_m_initial_deformation_segment import NonLinearFEMInitialDeformationSegment
    from .steel_initial_deformation_shape import SteelInitialDeformationShape

@dataclass
class NonLinearFEMInitialDeformation(Parsable):
    """
    Initial deformation of the element in the non-linear (2nd order) analysis (maps to the AD modelobject `som.InitialDeformation`).
    """
    from .steel_initial_deformation_shape import SteelInitialDeformationShape

    # Shape of the initial deformation (maps to "InitialDeformationShape"). The AD.API.NonLinearFEMInitialDeformation.Segments list is only used withAD.API.SteelInitialDeformationShape.parabolic_variation. Default value : SteelInitialDeformationShape.dominant_eigen_shape
    initial_deformation_shape: Optional[SteelInitialDeformationShape] = SteelInitialDeformationShape("dominant_eigen_shape")
    # Whether this element is included in the initial deformation (maps to"IncludedInInitialDeformation"). Default value : false
    included_in_initial_deformation: Optional[bool] = None
    # Scale factor applied to the initial deformation (maps to "ScaleFactor"). Unit : adimensional Default value : 900.0
    scale_factor: Optional[float] = None
    # Segment-by-segment description of a parabolic initial deformation (maps to"Segments"). On Update the list REPLACES the stored one in full. Send null to leave it untouched. Default value : null
    segments: Optional[list[NonLinearFEMInitialDeformationSegment]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NonLinearFEMInitialDeformation:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NonLinearFEMInitialDeformation
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NonLinearFEMInitialDeformation()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .non_linear_f_e_m_initial_deformation_segment import NonLinearFEMInitialDeformationSegment
        from .steel_initial_deformation_shape import SteelInitialDeformationShape

        from .non_linear_f_e_m_initial_deformation_segment import NonLinearFEMInitialDeformationSegment
        from .steel_initial_deformation_shape import SteelInitialDeformationShape

        fields: dict[str, Callable[[Any], None]] = {
            "includedInInitialDeformation": lambda n : setattr(self, 'included_in_initial_deformation', n.get_bool_value()),
            "initialDeformationShape": lambda n : setattr(self, 'initial_deformation_shape', n.get_enum_value(SteelInitialDeformationShape)),
            "scaleFactor": lambda n : setattr(self, 'scale_factor', n.get_float_value()),
            "segments": lambda n : setattr(self, 'segments', n.get_collection_of_object_values(NonLinearFEMInitialDeformationSegment)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("includedInInitialDeformation", self.included_in_initial_deformation)
        writer.write_enum_value("initialDeformationShape", self.initial_deformation_shape)
        writer.write_float_value("scaleFactor", self.scale_factor)
        writer.write_collection_of_object_values("segments", self.segments)
    

