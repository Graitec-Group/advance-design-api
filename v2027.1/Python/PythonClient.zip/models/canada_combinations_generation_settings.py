from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .combinations_generation_settings import CombinationsGenerationSettings
    from .e_canada_importance_category import ECanadaImportanceCategory

from .combinations_generation_settings import CombinationsGenerationSettings

@dataclass
class CanadaCombinationsGenerationSettings(CombinationsGenerationSettings, AdditionalDataHolder, Parsable):
    """
    Settings of the Canadian family (NBC / CNB load combinations, verified with CSA).
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Generate the additional short-term deflection combinations for steel. On bydefault.
    generate_steel_short_term_deflections: Optional[bool] = None
    # Importance category of the structure, which fixes the snow and wind importancefactors Is and Iw the generated combinations carry.
    importance_category: Optional[ECanadaImportanceCategory] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CanadaCombinationsGenerationSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CanadaCombinationsGenerationSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CanadaCombinationsGenerationSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .combinations_generation_settings import CombinationsGenerationSettings
        from .e_canada_importance_category import ECanadaImportanceCategory

        from .combinations_generation_settings import CombinationsGenerationSettings
        from .e_canada_importance_category import ECanadaImportanceCategory

        fields: dict[str, Callable[[Any], None]] = {
            "generateSteelShortTermDeflections": lambda n : setattr(self, 'generate_steel_short_term_deflections', n.get_bool_value()),
            "importanceCategory": lambda n : setattr(self, 'importance_category', n.get_enum_value(ECanadaImportanceCategory)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_bool_value("generateSteelShortTermDeflections", self.generate_steel_short_term_deflections)
        writer.write_enum_value("importanceCategory", self.importance_category)
        writer.write_additional_data_value(self.additional_data)
    

