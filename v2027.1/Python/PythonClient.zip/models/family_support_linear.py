from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_advanced_linear_support import ElementAdvancedLinearSupport
    from .element_base import ElementBase
    from .element_elastic_linear_support import ElementElasticLinearSupport
    from .element_rigid_linear_support import ElementRigidLinearSupport
    from .element_t_c_linear_support import ElementTCLinearSupport
    from .e_i_d import EID
    from .footing_dimensions_linear import FootingDimensionsLinear
    from .pt3_d import Pt3D
    from .supporting_element_dimensions_linear import SupportingElementDimensionsLinear

from .element_base import ElementBase

@dataclass
class FamilySupportLinear(ElementBase, AdditionalDataHolder, Parsable):
    """
    Linear support
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Indicates whether the element is active in the analysis.Unit: no unit Default value : true
    element_active: Optional[bool] = None
    # Footing dimensions for the support.Default value : optional nullable object
    footing: Optional[FootingDimensionsLinear] = None
    # End point in 3D space expressed in global axes.Unit: m Default value : (0, 0, 0)
    geom_pt_end: Optional[Pt3D] = None
    # Start oint in 3D space expressed in global axes.Unit: m Default value : (0, 0, 0)
    geom_pt_start: Optional[Pt3D] = None
    # EID of the material already created
    material: Optional[EID] = None
    # Supporting element information.Default value : optional nullable object
    supp_element: Optional[SupportingElementDimensionsLinear] = None
    # Internal ids (AD.API.EID) of the systems (`som.System`) this element belongs to.An element can belong to several systems. - On Get: populated with the element's current systems. - On Create: the element is created in the first listed system and added to the rest; when  empty, it is placed in the model's default root system ("Structure 0"); a listed id that is not an existing system makes the creation fail. - On Update: when non-empty, the element's membership is set to exactly these systems (added  to the new ones, removed from the others); when empty, the membership is left unchanged.  Invalid system ids are rejected (the update fails without changing any membership). - The support always belongs to at least one system: it can never be left with none. If it  would be (its systems were deleted, or the requested membership could not be applied), it is  put back in the root system "Structure 0" and a warning is logged.
    system_i_ds: Optional[list[EID]] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FamilySupportLinear:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FamilySupportLinear
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "ElementAdvancedLinearSupport".casefold():
            from .element_advanced_linear_support import ElementAdvancedLinearSupport

            return ElementAdvancedLinearSupport()
        if mapping_value and mapping_value.casefold() == "ElementElasticLinearSupport".casefold():
            from .element_elastic_linear_support import ElementElasticLinearSupport

            return ElementElasticLinearSupport()
        if mapping_value and mapping_value.casefold() == "ElementRigidLinearSupport".casefold():
            from .element_rigid_linear_support import ElementRigidLinearSupport

            return ElementRigidLinearSupport()
        if mapping_value and mapping_value.casefold() == "ElementTCLinearSupport".casefold():
            from .element_t_c_linear_support import ElementTCLinearSupport

            return ElementTCLinearSupport()
        return FamilySupportLinear()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_advanced_linear_support import ElementAdvancedLinearSupport
        from .element_base import ElementBase
        from .element_elastic_linear_support import ElementElasticLinearSupport
        from .element_rigid_linear_support import ElementRigidLinearSupport
        from .element_t_c_linear_support import ElementTCLinearSupport
        from .e_i_d import EID
        from .footing_dimensions_linear import FootingDimensionsLinear
        from .pt3_d import Pt3D
        from .supporting_element_dimensions_linear import SupportingElementDimensionsLinear

        from .element_advanced_linear_support import ElementAdvancedLinearSupport
        from .element_base import ElementBase
        from .element_elastic_linear_support import ElementElasticLinearSupport
        from .element_rigid_linear_support import ElementRigidLinearSupport
        from .element_t_c_linear_support import ElementTCLinearSupport
        from .e_i_d import EID
        from .footing_dimensions_linear import FootingDimensionsLinear
        from .pt3_d import Pt3D
        from .supporting_element_dimensions_linear import SupportingElementDimensionsLinear

        fields: dict[str, Callable[[Any], None]] = {
            "elementActive": lambda n : setattr(self, 'element_active', n.get_bool_value()),
            "footing": lambda n : setattr(self, 'footing', n.get_object_value(FootingDimensionsLinear)),
            "geomPtEnd": lambda n : setattr(self, 'geom_pt_end', n.get_object_value(Pt3D)),
            "geomPtStart": lambda n : setattr(self, 'geom_pt_start', n.get_object_value(Pt3D)),
            "material": lambda n : setattr(self, 'material', n.get_object_value(EID)),
            "suppElement": lambda n : setattr(self, 'supp_element', n.get_object_value(SupportingElementDimensionsLinear)),
            "systemIDs": lambda n : setattr(self, 'system_i_ds', n.get_collection_of_object_values(EID)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_bool_value("elementActive", self.element_active)
        writer.write_object_value("footing", self.footing)
        writer.write_object_value("geomPtEnd", self.geom_pt_end)
        writer.write_object_value("geomPtStart", self.geom_pt_start)
        writer.write_object_value("material", self.material)
        writer.write_object_value("suppElement", self.supp_element)
        writer.write_collection_of_object_values("systemIDs", self.system_i_ds)
        writer.write_additional_data_value(self.additional_data)
    

