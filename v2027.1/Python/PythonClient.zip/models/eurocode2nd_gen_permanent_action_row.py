from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_combinations_action_family import ECombinationsActionFamily
    from .e_permanent_load_situation2nd_gen import EPermanentLoadSituation2ndGen

@dataclass
class Eurocode2ndGenPermanentActionRow(Parsable):
    """
    One permanent action row of the 2nd generation settings, identified by its family.The 2nd generation settings are a LIST of rows rather than a single set of fields:each permanent family carries its own partial factors. A request matches rows byAD.API.Eurocode2ndGenPermanentActionRow.Family and leaves the ones it does not name alone; a family the modelhas no row for is refused, because the underlying model vector cannot grow.
    """
    # Which permanent family this row is - `PermanentLoad` or`PermanentLoadWater`.REQUIRED, and nullable so that leaving it out is an error rather than a silentchoice: it is what identifies the row, and a default would quietly point everyunnamed row at the same family.
    family: Optional[ECombinationsActionFamily] = None
    # gamma for VC1, favorable.
    gamma_v_c1_favorable: Optional[float] = None
    # gamma for VC1, unfavorable.
    gamma_v_c1_unfavorable: Optional[float] = None
    # gamma for VC2a.
    gamma_v_c2a: Optional[float] = None
    # gamma for VC2b.NOTE - this one is written but NOT read back: the model reader has never read theGammaVC2b column of a permanent row, so a `Get` reports the struct default(1.0) rather than what the model holds. Pre-existing, shared with the desktopoptions dialog, and left alone on purpose while the 2nd generation standard isunder development.
    gamma_v_c2b: Optional[float] = None
    # gamma for VC3.
    gamma_v_c3: Optional[float] = None
    # The reduction factor xi applied to the permanent action.
    reduction_factor_xi: Optional[float] = None
    # How this family enters the combinations.
    situation: Optional[EPermanentLoadSituation2ndGen] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Eurocode2ndGenPermanentActionRow:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Eurocode2ndGenPermanentActionRow
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Eurocode2ndGenPermanentActionRow()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_combinations_action_family import ECombinationsActionFamily
        from .e_permanent_load_situation2nd_gen import EPermanentLoadSituation2ndGen

        from .e_combinations_action_family import ECombinationsActionFamily
        from .e_permanent_load_situation2nd_gen import EPermanentLoadSituation2ndGen

        fields: dict[str, Callable[[Any], None]] = {
            "family": lambda n : setattr(self, 'family', n.get_enum_value(ECombinationsActionFamily)),
            "gammaVC1Favorable": lambda n : setattr(self, 'gamma_v_c1_favorable', n.get_float_value()),
            "gammaVC1Unfavorable": lambda n : setattr(self, 'gamma_v_c1_unfavorable', n.get_float_value()),
            "gammaVC2a": lambda n : setattr(self, 'gamma_v_c2a', n.get_float_value()),
            "gammaVC2b": lambda n : setattr(self, 'gamma_v_c2b', n.get_float_value()),
            "gammaVC3": lambda n : setattr(self, 'gamma_v_c3', n.get_float_value()),
            "reductionFactorXi": lambda n : setattr(self, 'reduction_factor_xi', n.get_float_value()),
            "situation": lambda n : setattr(self, 'situation', n.get_enum_value(EPermanentLoadSituation2ndGen)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("family", self.family)
        writer.write_float_value("gammaVC1Favorable", self.gamma_v_c1_favorable)
        writer.write_float_value("gammaVC1Unfavorable", self.gamma_v_c1_unfavorable)
        writer.write_float_value("gammaVC2a", self.gamma_v_c2a)
        writer.write_float_value("gammaVC2b", self.gamma_v_c2b)
        writer.write_float_value("gammaVC3", self.gamma_v_c3)
        writer.write_float_value("reductionFactorXi", self.reduction_factor_xi)
        writer.write_enum_value("situation", self.situation)
    

