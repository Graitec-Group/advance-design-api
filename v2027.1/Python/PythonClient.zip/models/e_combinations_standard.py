from enum import Enum

class ECombinationsStandard(str, Enum):
    Eurocode = "Eurocode",
    US = "US",
    Canada = "Canada",
    EurocodeItalia = "EurocodeItalia",
    CanadaNBC2015 = "CanadaNBC2015",
    NTC2018 = "NTC2018",
    Greenhouse_EN13031_1 = "Greenhouse_EN13031_1",
    US2018 = "US2018",
    CanadaCNB2020 = "CanadaCNB2020",

