from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .design_calculation_type import DesignCalculationType

@dataclass
class DesignCalculationLicence(Parsable):
    """
    Whether the licence of ONE design family is available, as part of AD.API.LicenceStatus.The server returns one entry for every `DesignCalculationType` it knows.The answer comes from the SAME licence mapping `LaunchDesignCalculation` refuses on, so afamily reported available here was not refused for licence reasons at the time ofAD.API.LicenceStatus.CheckedAt. It is no promise about a later call:`LaunchDesignCalculation` does its own full checkout, and other gates (for example the2nd-generation EC3 gate) can still refuse it.
    """
    from .design_calculation_type import DesignCalculationType

    # Which design family this entry describes - the same enumeration`LaunchDesignCalculation` takes.Default value: DesignCalculationType.Concrete
    type: Optional[DesignCalculationType] = DesignCalculationType("Concrete")
    # True when the licence module(s) this family needs could be checked out when the licence waslast read (AD.API.LicenceStatus.CheckedAt). `Composite` needs both the concreteand the steelwork modules.Always false when the mandatory licence of the server is not held(AD.API.LicenceStatus.IsAvailable false): nothing was asked of the licence component then.Default value: false
    is_available: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DesignCalculationLicence:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DesignCalculationLicence
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DesignCalculationLicence()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .design_calculation_type import DesignCalculationType

        from .design_calculation_type import DesignCalculationType

        fields: dict[str, Callable[[Any], None]] = {
            "isAvailable": lambda n : setattr(self, 'is_available', n.get_bool_value()),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(DesignCalculationType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("isAvailable", self.is_available)
        writer.write_enum_value("type", self.type)
    

