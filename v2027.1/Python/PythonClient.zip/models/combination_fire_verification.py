from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_design_verification_state import EDesignVerificationState

@dataclass
class CombinationFireVerification(Parsable):
    """
    Coefficients of the steel fire resistance verification for one combination (maps to the ADmodel object `som.MetalFireFields`). Every property is optional: a property left null is filled with the value the Advance Designcombinations dialog would apply, taken from the design settings of the model.
    """
    # Loading level of the fire situation (maps to "Niveau"). Default value : null (1.0)
    load_level: Optional[float] = None
    # Partial safety factor applied in the fire situation, gammaMfi (maps to "Coeficient"). Default value : null (the model property "FireSecurityCoeff")
    safety_factor: Optional[float] = None
    # Whether the verification is really evaluated for this combination (maps to "Type"). Default value : null (Active)
    state: Optional[EDesignVerificationState] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CombinationFireVerification:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CombinationFireVerification
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CombinationFireVerification()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_design_verification_state import EDesignVerificationState

        from .e_design_verification_state import EDesignVerificationState

        fields: dict[str, Callable[[Any], None]] = {
            "loadLevel": lambda n : setattr(self, 'load_level', n.get_float_value()),
            "safetyFactor": lambda n : setattr(self, 'safety_factor', n.get_float_value()),
            "state": lambda n : setattr(self, 'state', n.get_enum_value(EDesignVerificationState)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("loadLevel", self.load_level)
        writer.write_float_value("safetyFactor", self.safety_factor)
        writer.write_enum_value("state", self.state)
    

