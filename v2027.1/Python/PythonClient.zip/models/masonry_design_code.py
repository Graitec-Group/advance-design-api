from enum import Enum

class MasonryDesignCode(str, Enum):
    Eurocode = "eurocode",
    Ntc2018 = "ntc2018",
    Cr6_2013 = "cr6_2013",

