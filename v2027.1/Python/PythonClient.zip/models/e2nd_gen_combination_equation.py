from enum import Enum

class E2ndGenCombinationEquation(str, Enum):
    Equation_8_12 = "Equation_8_12",
    Equation_8_13 = "Equation_8_13",
    Equation_8_14 = "Equation_8_14",

