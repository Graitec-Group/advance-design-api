from enum import Enum

class ECombinationsActionFamily(str, Enum):
    PermanentLoad = "PermanentLoad",
    PermanentLoadWater = "PermanentLoadWater",
    Exploitation = "Exploitation",
    Snow = "Snow",
    Wind = "Wind",
    Thermal = "Thermal",
    ConstructionActions = "ConstructionActions",
    Icing = "Icing",
    WaterActions = "WaterActions",
    WavesAndCurrents = "WavesAndCurrents",

