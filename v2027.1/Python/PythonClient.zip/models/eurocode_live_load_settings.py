from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .eurocode_variable_action_settings import EurocodeVariableActionSettings
    from .e_exploitation_category import EExploitationCategory

from .eurocode_variable_action_settings import EurocodeVariableActionSettings

@dataclass
class EurocodeLiveLoadSettings(EurocodeVariableActionSettings, AdditionalDataHolder, Parsable):
    """
    The live load (exploitation) row of the variable actions grid.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Live load category of EN 1991-1-1, which fixes psi0 / psi1 / psi2.Usable under every national annex that keeps the general list - General, UK,Germany, Romania, Slovakia, Poland - and, under the two that renumber it, only forthe leading categories that still mean the same thing: A to D under the Frenchannex, A to H under the Czech one. Naming a category past that point is refusedrather than silently written, because there it would mean a different action thanits name says: `UserDefined` is 10, which under the French annex is categoryH and under the Czech one does not exist.Use AD.API.EurocodeLiveLoadSettings.CategoryIndex for those, and for the categories the general listhas no name for at all (French E1, E2a, E2b, E2c, K, K1).
    category: Optional[EExploitationCategory] = None
    # The live load category as the raw index the model stores, for the annexes whoselist AD.API.eExploitationCategory cannot name. Takes precedence over`Category` when both are sent.Valid values run from 0 to AD.API.EurocodeVariableActionSettings.UserDefinedCategory,which `GetModelSettings` reports for the active annex - 13under the French annex (A, B, C, D, E1, E2a, E2b, E2c, F, G, H, K, K1, then 13 =user defined), 8 under the Czech one (A .. H, then 8), 10 everywhere else.Always filled on read, so a `Get` followed by a `Set` round-trips underany annex.
    category_index: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EurocodeLiveLoadSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EurocodeLiveLoadSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EurocodeLiveLoadSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .eurocode_variable_action_settings import EurocodeVariableActionSettings
        from .e_exploitation_category import EExploitationCategory

        from .eurocode_variable_action_settings import EurocodeVariableActionSettings
        from .e_exploitation_category import EExploitationCategory

        fields: dict[str, Callable[[Any], None]] = {
            "category": lambda n : setattr(self, 'category', n.get_enum_value(EExploitationCategory)),
            "categoryIndex": lambda n : setattr(self, 'category_index', n.get_int_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("category", self.category)
        writer.write_int_value("categoryIndex", self.category_index)
        writer.write_additional_data_value(self.additional_data)
    

