from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .steel_c_f_d_flange_condition import SteelCFDFlangeCondition
    from .steel_c_f_d_flange_loading_type import SteelCFDFlangeLoadingType
    from .steel_c_f_d_support_condition import SteelCFDSupportCondition

@dataclass
class NorthAmericanSteelWebCripplingInfo(Parsable):
    """
    Web crippling conditions at one kind of support of a cold-formed member (maps to the AD modelobjects `som.RoleExteriorCFDWebCripplingInfo` and`som.RoleInteriorCFDWebCripplingInfo`, both of them plain`som.CFDWebCripplingInfo`). The same class is used twice, once for the exterior support and once for the interior one. Thethree properties are the three entries of the coefficient table of AISI S100 clause G5.
    """
    from .steel_c_f_d_flange_condition import SteelCFDFlangeCondition

    # Stiffening of the flange at the support (maps to "FlangeCondition"). Default value : SteelCFDFlangeCondition.stiffened_or_partially_stiffened
    flange_condition: Optional[SteelCFDFlangeCondition] = SteelCFDFlangeCondition("stiffened_or_partially_stiffened")
    from .steel_c_f_d_flange_loading_type import SteelCFDFlangeLoadingType

    # How many flanges the concentrated load or reaction acts on (maps to"FlangeLoadingType"). Default value : SteelCFDFlangeLoadingType.one_flange_loading_or_reaction
    flange_loading_type: Optional[SteelCFDFlangeLoadingType] = SteelCFDFlangeLoadingType("one_flange_loading_or_reaction")
    from .steel_c_f_d_support_condition import SteelCFDSupportCondition

    # Whether the member is fastened to the support (maps to "SupportCondition"). Default value : SteelCFDSupportCondition.fastened
    support_condition: Optional[SteelCFDSupportCondition] = SteelCFDSupportCondition("fastened")
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NorthAmericanSteelWebCripplingInfo:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NorthAmericanSteelWebCripplingInfo
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NorthAmericanSteelWebCripplingInfo()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .steel_c_f_d_flange_condition import SteelCFDFlangeCondition
        from .steel_c_f_d_flange_loading_type import SteelCFDFlangeLoadingType
        from .steel_c_f_d_support_condition import SteelCFDSupportCondition

        from .steel_c_f_d_flange_condition import SteelCFDFlangeCondition
        from .steel_c_f_d_flange_loading_type import SteelCFDFlangeLoadingType
        from .steel_c_f_d_support_condition import SteelCFDSupportCondition

        fields: dict[str, Callable[[Any], None]] = {
            "flangeCondition": lambda n : setattr(self, 'flange_condition', n.get_enum_value(SteelCFDFlangeCondition)),
            "flangeLoadingType": lambda n : setattr(self, 'flange_loading_type', n.get_enum_value(SteelCFDFlangeLoadingType)),
            "supportCondition": lambda n : setattr(self, 'support_condition', n.get_enum_value(SteelCFDSupportCondition)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("flangeCondition", self.flange_condition)
        writer.write_enum_value("flangeLoadingType", self.flange_loading_type)
        writer.write_enum_value("supportCondition", self.support_condition)
    

