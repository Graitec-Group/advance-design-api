from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .design_codes import DesignCodes
    from .language_code import Language_Code
    from .localization_code import Localization_Code
    from .log_verbose_level import LogVerboseLevel

@dataclass
class Environments(Parsable):
    """
    Environment settings - the language, the localization, the diagnostics verbosity and thedesign standards a session runs under.IT CONFIGURES THE SESSION, AND A SESSION IS CONFIGURED ONCE. The environment takes effect onthe `NewProject` / `OpenProject` call that opens the session and lasts as long asthat project. A call sent while a project is still open is REFUSED - the whole call, notjust the environment: the localization and design standards were read while that model wasbuilt and are read again by the generation and by the design Experts, so running a secondproject on them would calculate it under standards it was never described with. Close theproject first; the next one takes a new environment.THE LANGUAGE IS NARROWER STILL - fixed for the life of the SERVER PROCESS. The firstenvironment settles it, and the two ways of changing it afterwards are treated differently:* an EXPLICIT AD.API.Environments.Language that disagrees with the one in force is REFUSED, and  the caller is told to restart the server;* a language merely IMPLIED by AD.API.Environments.Localization is HELD BACK with a warning, and  the rest of that localization - its eight design standards, which is what it is really  being asked for - is applied normally. Refusing here instead would tie a whole server to  one localization family, since sixteen of the eighteen localizations imply a language  other than English.The restriction is what the desktop application achieves by restarting itself: reloading theprompt database is not enough, because the catalogues, units and resources already loadedkeep the language they were read in.WHAT IT WRITES. Everything this environment configures lives in the server's memory for thelife of the session; no design standard, annex, localization or language chosen here iswritten back to the machine's Advance Design configuration. One thing is not in thatpromise, and it is not this API's doing: OPENING the in-memory session seeds it by readingthe per-user registry, and Advance Design's own accessors write a default back when theyfind a value missing. So on a machine where Advance Design has never run, the first requestmaterialises the default keys - with the values the read already resolved to, never withanything this request named.
    """
    # The design standards and national annexes to impose on the session, overriding whatAD.API.Environments.Localization resolves to.Null - the default - means "take all eight from the localization", which is what everycaller got before this property existed. Deliberately NOT initialised to an empty object:a request that does not mention design standards must not read as one that mentions themall. Inside it, each property is null on the same terms. SeeAD.API.DesignCodes.A standard or annex combination the desktop application could not produce fails the whole`NewProject` / `OpenProject` call, with the reason in the response diagnostics.
    design_codes: Optional[DesignCodes] = None
    # Language used in environment.FIXED FOR THE LIFE OF THE SERVER PROCESS, not of the session: the first environmentsettles it and a later one naming a different language is refused. Null means "whateverthe server is already running in", which is always accepted. See the remarks onAD.API.Environments.
    language: Optional[Language_Code] = None
    # Localization setting for norms and regulations. It resolves all eight design standards andall eight national annexes in one go, exactly as the installation does for the desktopapplication; AD.API.Environments.DesignCodes then overrides individual ones.SEND IT. Null does NOT mean a neutral default - it means "keep the eight standards thisMACHINE is configured for", read from the per-user Advance Design settings. The samerequest then produces a Eurocode model on one machine and an ACI / AISC model on another,and a AD.API.Environments.DesignCodes object accepted on one can be refused on the other,because the annex rules are checked against whatever standard is in force. It is the oneproperty whose absence makes the result depend on the server's installation.
    localization: Optional[Localization_Code] = None
    # Verbosity level for engine log output in API responses.Level 1: Errors only. Level 2: Errors and Warnings. Level 3: All details.Default is ErrorsAndWarnings (2).<p>Possible values:</p><ul><li><b>1 - Errors</b>: Level 1: Only errors are included in the API response diagnostics.</li><li><b>2 - ErrorsAndWarnings</b>: Level 2: Errors and warnings are included in the API response diagnostics.</li><li><b>3 - AllDetails</b>: Level 3: All details (errors, warnings, and informational messages) are included.</li></ul>
    log_verbosity: Optional[LogVerboseLevel] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Environments:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Environments
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Environments()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .design_codes import DesignCodes
        from .language_code import Language_Code
        from .localization_code import Localization_Code
        from .log_verbose_level import LogVerboseLevel

        from .design_codes import DesignCodes
        from .language_code import Language_Code
        from .localization_code import Localization_Code
        from .log_verbose_level import LogVerboseLevel

        fields: dict[str, Callable[[Any], None]] = {
            "designCodes": lambda n : setattr(self, 'design_codes', n.get_object_value(DesignCodes)),
            "language": lambda n : setattr(self, 'language', n.get_enum_value(Language_Code)),
            "localization": lambda n : setattr(self, 'localization', n.get_enum_value(Localization_Code)),
            "logVerbosity": lambda n : setattr(self, 'log_verbosity', n.get_enum_value(LogVerboseLevel)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("designCodes", self.design_codes)
        writer.write_enum_value("language", self.language)
        writer.write_enum_value("localization", self.localization)
        writer.write_enum_value("logVerbosity", self.log_verbosity)
    

