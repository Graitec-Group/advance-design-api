from enum import Enum

class Ec3DeflectionVerificationId(str, Enum):
    ElementEndY_Criterion1 = "ElementEndY_Criterion1",
    ElementEndY_Criterion2 = "ElementEndY_Criterion2",
    ElementEndZ_Criterion1 = "ElementEndZ_Criterion1",
    ElementEndZ_Criterion2 = "ElementEndZ_Criterion2",
    ElementSpanY_Criterion1 = "ElementSpanY_Criterion1",
    ElementSpanY_Criterion2 = "ElementSpanY_Criterion2",
    ElementSpanZ_Criterion1 = "ElementSpanZ_Criterion1",
    ElementSpanZ_Criterion2 = "ElementSpanZ_Criterion2",
    SuperElementEndY_Criterion1 = "SuperElementEndY_Criterion1",
    SuperElementEndY_Criterion2 = "SuperElementEndY_Criterion2",
    SuperElementEndZ_Criterion1 = "SuperElementEndZ_Criterion1",
    SuperElementEndZ_Criterion2 = "SuperElementEndZ_Criterion2",
    SuperElementSpanY_Criterion1 = "SuperElementSpanY_Criterion1",
    SuperElementSpanY_Criterion2 = "SuperElementSpanY_Criterion2",
    SuperElementSpanZ_Criterion1 = "SuperElementSpanZ_Criterion1",
    SuperElementSpanZ_Criterion2 = "SuperElementSpanZ_Criterion2",

