from enum import Enum

class CompositeEurocodeAnnex(str, Enum):
    General = "general",
    France = "france",
    Uk = "uk",
    Romania = "romania",
    Germany = "germany",
    Czech = "czech",
    Poland = "poland",
    Slovakia = "slovakia",
    Spain = "spain",
    Portugal = "portugal",

