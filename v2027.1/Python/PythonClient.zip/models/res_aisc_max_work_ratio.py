from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData
    from .res_steel_max_work_ratio_entry import ResSteelMaxWorkRatioEntry

from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

@dataclass
class ResAiscMaxWorkRatio(ResNorthAmericaSteelLinearDesignData, AdditionalDataHolder, Parsable):
    """
    The governing work ratio of the element and the per-family maxima behind it, under a North Americancode.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The available maxima, at most one entry per component. Families the accessor cannot answer forare absent from the list rather than reported as zero, so that "not checked" and "checked, ratio0" stay distinguishable.
    work_ratios: Optional[list[ResSteelMaxWorkRatioEntry]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscMaxWorkRatio:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscMaxWorkRatio
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscMaxWorkRatio()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData
        from .res_steel_max_work_ratio_entry import ResSteelMaxWorkRatioEntry

        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData
        from .res_steel_max_work_ratio_entry import ResSteelMaxWorkRatioEntry

        fields: dict[str, Callable[[Any], None]] = {
            "workRatios": lambda n : setattr(self, 'work_ratios', n.get_collection_of_object_values(ResSteelMaxWorkRatioEntry)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_collection_of_object_values("workRatios", self.work_ratios)
        writer.write_additional_data_value(self.additional_data)
    

