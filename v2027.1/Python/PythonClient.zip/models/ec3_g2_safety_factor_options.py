from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class Ec3G2SafetyFactorOptions(Parsable):
    """
    What EN 1993-1-1:2023 adds to the Safety factors page. Ignored, and reported as a warning,on a model that is not configured with the 2nd generation Eurocode.
    """
    # eta_v - the shear utilisation above which the bending resistance is reduced for theshear and bending interaction. EN 1993-1-1:2023, 8.2.8 (3). Dimensionless, between 0and 1; 0.5 by default.
    shear_ratio_limit_for_bending_reduction: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Ec3G2SafetyFactorOptions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Ec3G2SafetyFactorOptions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Ec3G2SafetyFactorOptions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "shearRatioLimitForBendingReduction": lambda n : setattr(self, 'shear_ratio_limit_for_bending_reduction', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("shearRatioLimitForBendingReduction", self.shear_ratio_limit_for_bending_reduction)
    

