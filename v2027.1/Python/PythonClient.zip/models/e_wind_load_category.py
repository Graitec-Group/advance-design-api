from enum import Enum

class EWindLoadCategory(str, Enum):
    Standard = "Standard",
    UserDefined = "UserDefined",

