from enum import Enum

class Ec3FireResistanceCheckId(str, Enum):
    Axial = "Axial",
    BendingYY = "BendingYY",
    BendingZZ = "BendingZZ",
    ObliqueBending1 = "ObliqueBending1",
    ObliqueBending2 = "ObliqueBending2",
    Class4 = "Class4",

