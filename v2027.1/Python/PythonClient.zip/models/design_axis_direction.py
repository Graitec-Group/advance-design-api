from enum import Enum

class DesignAxisDirection(str, Enum):
    Y = "Y",
    Z = "Z",

