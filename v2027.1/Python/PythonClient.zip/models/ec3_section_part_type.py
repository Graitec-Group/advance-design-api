from enum import Enum

class Ec3SectionPartType(str, Enum):
    Web = "Web",
    Internal = "Internal",
    Flange = "Flange",
    None_ = "None",

