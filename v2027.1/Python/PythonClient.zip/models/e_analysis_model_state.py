from enum import Enum

class EAnalysisModelState(str, Enum):
    NotCreated = "NotCreated",
    Created = "Created",
    Meshed = "Meshed",
    Calculated = "Calculated",
    OutOfDate = "OutOfDate",

