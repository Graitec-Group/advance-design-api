from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
    from .steel_section_class_a_i_s_c import SteelSectionClassAISC

from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate

@dataclass
class AISCSteelLinearDesignTemplate(NorthAmericanSteelLinearDesignTemplate, AdditionalDataHolder, Parsable):
    """
    Expert design template for linear STEEL elements verified to AISC 360 (maps to the AD modelobject `som.AISCSteelLinearRole`, held by `som.Role` in its"AISCSteelLinearExpertProperties" slot). It corresponds to the "Design template description" dialog of Advance Design when the materialis Steel, the element type is Linear and the model's steel design code is an AISC one. The template name is the base-class member AD.API.InformationalElementBase.UserName; itmust be unique among the steel/linear templates of the model and is limited to 50characters. USED BY WHICH DESIGN CODES - this property set is the one Advance Design allocates forAD.API.SteelDesignCode.aisc and AD.API.SteelDesignCode.aisc_2016. Both editionsshare ONE class because they share one SOM object: `CRoleManager::AddRole` normalizes themto a single "AISC" expert set, and neither the model nor the property list distinguishes them.Creating this template in a model configured for any other steel code is refused, because theengine would never allocate the AISC property set for it; the response diagnostics then name theactive code. PROPAGATION - assigning the template to a linear element, or editing the template afterwards,copies these properties onto the element's own expert properties through the same mechanism theuser interface uses. Editing a template therefore changes every element that references it. PARTIAL UPDATE - every group of AD.API.NorthAmericanSteelLinearDesignTemplate isnullable. On Update, a group left null keeps its stored value. Available for the descriptive model only.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .steel_section_class_a_i_s_c import SteelSectionClassAISC

    # Cross-section class (maps to "SectionClass"). Displayed as "Cross section class". AISC classifies a section as compact, noncompact or slender-element, so this property is typedwith AD.API.SteelSectionClassAISC and NOT with theAD.API.SteelSectionClass used by the Eurocode and CAN/CSA leaves - the same storedinteger, read against a different list. Unlike the two other codes, AISC has no imposed effective (Class 4) characteristics: there isnothing for the class to enable. Default value : SteelSectionClassAISC.auto_class
    section_class: Optional[SteelSectionClassAISC] = SteelSectionClassAISC("auto_class")
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AISCSteelLinearDesignTemplate:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AISCSteelLinearDesignTemplate
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AISCSteelLinearDesignTemplate()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
        from .steel_section_class_a_i_s_c import SteelSectionClassAISC

        from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
        from .steel_section_class_a_i_s_c import SteelSectionClassAISC

        fields: dict[str, Callable[[Any], None]] = {
            "sectionClass": lambda n : setattr(self, 'section_class', n.get_enum_value(SteelSectionClassAISC)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("sectionClass", self.section_class)
        writer.write_additional_data_value(self.additional_data)
    

