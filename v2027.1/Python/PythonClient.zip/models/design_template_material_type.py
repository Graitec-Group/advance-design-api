from enum import Enum

class DesignTemplateMaterialType(str, Enum):
    Concrete = "concrete",
    Steel = "steel",
    Timber = "timber",
    Composite = "composite",
    Rigid = "rigid",
    Undefined_material = "undefined_material",

