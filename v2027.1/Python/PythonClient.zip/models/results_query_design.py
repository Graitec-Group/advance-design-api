from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .results_query import ResultsQuery
    from .results_query_design_steel_linear import ResultsQueryDesignSteelLinear

from .results_query import ResultsQuery

@dataclass
class ResultsQueryDesign(ResultsQuery, AdditionalDataHolder, Parsable):
    """
    Base query for design-expert results. One endpoint, `GetDesignResults`, serves every designfamily; which family and which element type are being asked for is carried by the concrete querytype, selected through the "$type" discriminator.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # EIDs of the elements the results are requested for. These are descriptive identifiers, the sameones used to create the elements. An empty list returns no results and aDESIGN_RESULTS_EMPTY_INPUT diagnostic.
    list_elements_i_ds: Optional[list[int]] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResultsQueryDesign:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResultsQueryDesign
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "ResultsQueryDesignSteelLinear".casefold():
            from .results_query_design_steel_linear import ResultsQueryDesignSteelLinear

            return ResultsQueryDesignSteelLinear()
        return ResultsQueryDesign()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .results_query import ResultsQuery
        from .results_query_design_steel_linear import ResultsQueryDesignSteelLinear

        from .results_query import ResultsQuery
        from .results_query_design_steel_linear import ResultsQueryDesignSteelLinear

        fields: dict[str, Callable[[Any], None]] = {
            "listElementsIDs": lambda n : setattr(self, 'list_elements_i_ds', n.get_collection_of_primitive_values(int)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_collection_of_primitive_values("listElementsIDs", self.list_elements_i_ds)
        writer.write_additional_data_value(self.additional_data)
    

