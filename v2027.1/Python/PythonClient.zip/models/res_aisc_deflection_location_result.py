from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResAiscDeflectionLocationResult(Parsable):
    """
    The deflection found at one measurement location, for one allowable-deflection criterion.
    """
    # Index of the most unfavourable load combination, as the engine stores it - the raw engine index,not an EID and not a user combination number. Native: iCase_*.
    case_number: Optional[int] = None
    # The deflection itself, in m. Native: df_Defl_Val_*.
    deflection_value: Optional[float] = None
    # The deflection expressed as the denominator of Length/x - a deflection of L/360 is reported as360. Note it moves OPPOSITE to severity: a larger value is a smaller deflection.Native: df_Eff_Coeff_*.
    effective_coefficient: Optional[float] = None
    # True when a deflection was found at this location. When false the numbers below are meaningless -they are the struct's initialisers, not a deflection of zero. Native: bExist_*.
    exists: Optional[bool] = None
    # Node the extreme deflection was found at. Native: iNode_*.
    node_number: Optional[int] = None
    # Work ratio, dimensionless. Above 1 means the allowable deflection is exceeded. Not multiplied by100. Native: df_WR_*.
    work_ratio: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscDeflectionLocationResult:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscDeflectionLocationResult
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscDeflectionLocationResult()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "caseNumber": lambda n : setattr(self, 'case_number', n.get_int_value()),
            "deflectionValue": lambda n : setattr(self, 'deflection_value', n.get_float_value()),
            "effectiveCoefficient": lambda n : setattr(self, 'effective_coefficient', n.get_float_value()),
            "exists": lambda n : setattr(self, 'exists', n.get_bool_value()),
            "nodeNumber": lambda n : setattr(self, 'node_number', n.get_int_value()),
            "workRatio": lambda n : setattr(self, 'work_ratio', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("caseNumber", self.case_number)
        writer.write_float_value("deflectionValue", self.deflection_value)
        writer.write_float_value("effectiveCoefficient", self.effective_coefficient)
        writer.write_bool_value("exists", self.exists)
        writer.write_int_value("nodeNumber", self.node_number)
        writer.write_float_value("workRatio", self.work_ratio)
    

