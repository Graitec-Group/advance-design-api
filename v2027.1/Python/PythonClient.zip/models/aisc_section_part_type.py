from enum import Enum

class AiscSectionPartType(str, Enum):
    Web = "Web",
    Flange = "Flange",
    Round = "Round",

