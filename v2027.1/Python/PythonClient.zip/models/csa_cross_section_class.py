from enum import Enum

class CsaCrossSectionClass(str, Enum):
    Auto = "Auto",
    Class1 = "Class1",
    Class2 = "Class2",
    Class3 = "Class3",
    Class4 = "Class4",
    Unknown = "Unknown",

