from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .ec3_g2_safety_factor_options import Ec3G2SafetyFactorOptions
    from .e_steel_safety_factors_option import ESteelSafetyFactorsOption

@dataclass
class Ec3SteelSafetyFactorSettings(Parsable):
    """
    The Safety factors page: the partial safety factors of EN 1993-1-1.DERIVED UNLESS IMPOSED. While AD.API.Ec3SteelSafetyFactorSettings.Option is `eSafetyFactorsAuto` the four gamma values arewhat the steel code and its national annex dictate, and they are READ ONLY - exactly as thedialog greys the fields out. Sending one anyway is not an error: it is dropped and reportedas a warning in the response diagnostics. Set AD.API.Ec3SteelSafetyFactorSettings.Option to `eSafetyFactorsImposed` towrite your own; that can be done in the same request.The defaults are 1.00 for all of them except gamma_M2, which is 1.25, with two nationalexceptions the engine applies on its own: the German annex raises gamma_M1 to 1.10 andgamma_Mfi to 1.15, and the Italian annex and the NTC standards raise gamma_M0 and gamma_M1to 1.05.
    """
    # gamma_M0 - resistance of cross-sections. Writable only when AD.API.Ec3SteelSafetyFactorSettings.Option is`eSafetyFactorsImposed`.
    gamma_m0: Optional[float] = None
    # gamma_M1 - resistance to instability. Writable only when AD.API.Ec3SteelSafetyFactorSettings.Option is`eSafetyFactorsImposed`.
    gamma_m1: Optional[float] = None
    # gamma_M2 - resistance of the net section at bolt holes, used by the angleverification. Writable only when AD.API.Ec3SteelSafetyFactorSettings.Option is `eSafetyFactorsImposed`.
    gamma_m2: Optional[float] = None
    # gamma_M,fi - the accidental fire situation. Writable only when AD.API.Ec3SteelSafetyFactorSettings.Option is`eSafetyFactorsImposed`.
    gamma_mfi: Optional[float] = None
    # Whether the factors come from the code or from this request. `eSafetyFactorsAuto` by default.
    option: Optional[ESteelSafetyFactorsOption] = None
    # The 2nd generation addition to this page. Left untouched when null, and ignored with awarning when the model is not a 2nd generation one.
    second_generation: Optional[Ec3G2SafetyFactorOptions] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Ec3SteelSafetyFactorSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Ec3SteelSafetyFactorSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Ec3SteelSafetyFactorSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .ec3_g2_safety_factor_options import Ec3G2SafetyFactorOptions
        from .e_steel_safety_factors_option import ESteelSafetyFactorsOption

        from .ec3_g2_safety_factor_options import Ec3G2SafetyFactorOptions
        from .e_steel_safety_factors_option import ESteelSafetyFactorsOption

        fields: dict[str, Callable[[Any], None]] = {
            "gammaM0": lambda n : setattr(self, 'gamma_m0', n.get_float_value()),
            "gammaM1": lambda n : setattr(self, 'gamma_m1', n.get_float_value()),
            "gammaM2": lambda n : setattr(self, 'gamma_m2', n.get_float_value()),
            "gammaMfi": lambda n : setattr(self, 'gamma_mfi', n.get_float_value()),
            "option": lambda n : setattr(self, 'option', n.get_enum_value(ESteelSafetyFactorsOption)),
            "secondGeneration": lambda n : setattr(self, 'second_generation', n.get_object_value(Ec3G2SafetyFactorOptions)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("gammaM0", self.gamma_m0)
        writer.write_float_value("gammaM1", self.gamma_m1)
        writer.write_float_value("gammaM2", self.gamma_m2)
        writer.write_float_value("gammaMfi", self.gamma_mfi)
        writer.write_enum_value("option", self.option)
        writer.write_object_value("secondGeneration", self.second_generation)
    

