from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
    from .steel_section_class import SteelSectionClass

from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate

@dataclass
class CSASteelLinearDesignTemplate(NorthAmericanSteelLinearDesignTemplate, AdditionalDataHolder, Parsable):
    """
    Expert design template for linear STEEL elements verified to CAN/CSA S16 (maps to the AD modelobject `som.CSASteelLinearRole`, held by `som.Role` in its"CSASteelLinearExpertProperties" slot). It corresponds to the "Design template description" dialog of Advance Design when the materialis Steel, the element type is Linear and the model's steel design code is a Canadian one. The template name is the base-class member AD.API.InformationalElementBase.UserName; itmust be unique among the steel/linear templates of the model and is limited to 50characters. USED BY WHICH DESIGN CODES - this property set is the one Advance Design allocates forAD.API.SteelDesignCode.can_csa_s16_2009, AD.API.SteelDesignCode.can_csa_s16_2014,AD.API.SteelDesignCode.can_csa_s16_2019 andAD.API.SteelDesignCode.can_csa_s16_2024. All four editions share ONE class because theyshare one SOM object: `CRoleManager::AddRole` normalizes them to a single "CSA" expert set,and neither the model nor the property list distinguishes them. Creating this template in amodel configured for any other steel code is refused, because the engine would never allocatethe CAN/CSA property set for it; the response diagnostics then name the active code. HOW IT DIFFERS FROM THE AISC LEAF - two things, and only two. The cross-section class keeps theEurocode-like Class 1 to Class 4 list, and the imposed effective (Class 4) characteristics belowexist. Everything else is inherited unchanged fromAD.API.NorthAmericanSteelLinearDesignTemplate. Two rows ofAD.API.NorthAmericanSteelLinearDesignTemplate.SteelSpecificProperties are converselyCAN/CSA-only and are refused on an AD.API.AISCSteelLinearDesignTemplate. PROPAGATION - assigning the template to a linear element, or editing the template afterwards,copies these properties onto the element's own expert properties through the same mechanism theuser interface uses. Editing a template therefore changes every element that references it. PARTIAL UPDATE - every group of AD.API.NorthAmericanSteelLinearDesignTemplate isnullable. On Update, a group left null keeps its stored value. Available for the descriptive model only.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .steel_section_class import SteelSectionClass

    # Cross-section class (maps to "SectionClass"). Displayed as "Cross section class". CAN/CSA S16 keeps the Class 1 to Class 4 list, so thisproperty shares AD.API.SteelSectionClass with the Eurocode leaf. OnlyAD.API.SteelSectionClass.class_4 makes the effective characteristics belowmeaningful. Default value : SteelSectionClass.auto_class
    section_class: Optional[SteelSectionClass] = SteelSectionClass("auto_class")
    # Imposed shift of the centroid of the effective area along the y axis (maps to "eNy"). Unit : m Default value : 0.0
    e_ny: Optional[float] = None
    # Imposed shift of the centroid of the effective area along the z axis (maps to "eNz"). Unit : m Default value : 0.0
    e_nz: Optional[float] = None
    # Whether the effective Class 4 characteristics below are imposed rather than computed (maps to"ImposedValues"). Meaningful only when AD.API.CSASteelLinearDesignTemplate.SectionClass isAD.API.SteelSectionClass.class_4. Default value : false
    imposed_values: Optional[bool] = None
    # Imposed effective area of the cross-section (maps to "Sxeff"). Unit : m2 Default value : 0.0
    sxeff: Optional[float] = None
    # Imposed effective section modulus Weff,1 about the y axis (maps to "Weff1y"). Unit : m3 Default value : 0.0
    weff1y: Optional[float] = None
    # Imposed effective section modulus Weff,1 about the z axis (maps to "Weff1z"). Unit : m3 Default value : 0.0
    weff1z: Optional[float] = None
    # Imposed effective section modulus Weff,2 about the y axis (maps to "Weff2y"). Unit : m3 Default value : 0.0
    weff2y: Optional[float] = None
    # Imposed effective section modulus Weff,2 about the z axis (maps to "Weff2z"). Unit : m3 Default value : 0.0
    weff2z: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CSASteelLinearDesignTemplate:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CSASteelLinearDesignTemplate
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CSASteelLinearDesignTemplate()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
        from .steel_section_class import SteelSectionClass

        from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
        from .steel_section_class import SteelSectionClass

        fields: dict[str, Callable[[Any], None]] = {
            "eNy": lambda n : setattr(self, 'e_ny', n.get_float_value()),
            "eNz": lambda n : setattr(self, 'e_nz', n.get_float_value()),
            "imposedValues": lambda n : setattr(self, 'imposed_values', n.get_bool_value()),
            "sectionClass": lambda n : setattr(self, 'section_class', n.get_enum_value(SteelSectionClass)),
            "sxeff": lambda n : setattr(self, 'sxeff', n.get_float_value()),
            "weff1y": lambda n : setattr(self, 'weff1y', n.get_float_value()),
            "weff1z": lambda n : setattr(self, 'weff1z', n.get_float_value()),
            "weff2y": lambda n : setattr(self, 'weff2y', n.get_float_value()),
            "weff2z": lambda n : setattr(self, 'weff2z', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("eNy", self.e_ny)
        writer.write_float_value("eNz", self.e_nz)
        writer.write_bool_value("imposedValues", self.imposed_values)
        writer.write_enum_value("sectionClass", self.section_class)
        writer.write_float_value("sxeff", self.sxeff)
        writer.write_float_value("weff1y", self.weff1y)
        writer.write_float_value("weff1z", self.weff1z)
        writer.write_float_value("weff2y", self.weff2y)
        writer.write_float_value("weff2z", self.weff2z)
        writer.write_additional_data_value(self.additional_data)
    

