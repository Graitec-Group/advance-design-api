from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .family_support_linear import FamilySupportLinear
    from .seismic_support_damping_ratio import SeismicSupportDampingRatio
    from .support_elastic_stiffness import SupportElasticStiffness
    from .support_vertical_stiffness import SupportVerticalStiffness

from .family_support_linear import FamilySupportLinear

@dataclass
class ElementElasticLinearSupport(FamilySupportLinear, AdditionalDataHolder, Parsable):
    """
    Element Elastic Linear Support
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Damping associated to each degree of freedom.Unit: no unit Default value : optional nullable object
    damping_ratio: Optional[SeismicSupportDampingRatio] = None
    # Stiffness associated with degrees of freedom, PER METRE of support length, in global axes.Unit: N/m² (translational, N/m per m), N·m/rad/m (rotational) Default value : optional nullable object
    stiffness: Optional[SupportElasticStiffness] = None
    # Vertical stiffness soil-structure interaction propertiesUnit: no unit Default value : optional nullable object
    vertical_stiffness: Optional[SupportVerticalStiffness] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementElasticLinearSupport:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementElasticLinearSupport
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementElasticLinearSupport()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .family_support_linear import FamilySupportLinear
        from .seismic_support_damping_ratio import SeismicSupportDampingRatio
        from .support_elastic_stiffness import SupportElasticStiffness
        from .support_vertical_stiffness import SupportVerticalStiffness

        from .family_support_linear import FamilySupportLinear
        from .seismic_support_damping_ratio import SeismicSupportDampingRatio
        from .support_elastic_stiffness import SupportElasticStiffness
        from .support_vertical_stiffness import SupportVerticalStiffness

        fields: dict[str, Callable[[Any], None]] = {
            "dampingRatio": lambda n : setattr(self, 'damping_ratio', n.get_object_value(SeismicSupportDampingRatio)),
            "stiffness": lambda n : setattr(self, 'stiffness', n.get_object_value(SupportElasticStiffness)),
            "verticalStiffness": lambda n : setattr(self, 'vertical_stiffness', n.get_object_value(SupportVerticalStiffness)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("dampingRatio", self.damping_ratio)
        writer.write_object_value("stiffness", self.stiffness)
        writer.write_object_value("verticalStiffness", self.vertical_stiffness)
        writer.write_additional_data_value(self.additional_data)
    

