from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_base import ElementBase
    from .e_i_d import EID
    from .load_area_climatic_properties import LoadAreaClimaticProperties
    from .load_area_load_transfer import LoadAreaLoadTransfer
    from .load_area_mechanical_properties import LoadAreaMechanicalProperties
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class ElementLoadArea(ElementBase, AdditionalDataHolder, Parsable):
    """
    Load area class
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Climatic properties Default value : optional nullable object
    climatic_properties: Optional[LoadAreaClimaticProperties] = None
    # geometry as list of 3D points in global axisUnit: m Default value : null
    geom_pts_list: Optional[list[Pt3D]] = None
    # Mechanical properties - consider as Rigid Diafragm and/or add self weightDefault value : optional nullable object
    load_transfer_properties: Optional[LoadAreaLoadTransfer] = None
    # Mechanical properties - consider as Rigid Diafragm and/or add self weightDefault value : optional nullable object
    mechanical_properties: Optional[LoadAreaMechanicalProperties] = None
    # Internal ids (AD.API.EID) of the systems (`som.System`) this element belongs to.An element can belong to several systems. - On Get: populated with the element's current systems. - On Create: the element is created in the first listed system and added to the rest; when  empty, it is placed in the model's default root system ("Structure 0"); a listed id that is not an existing system makes the creation fail. - On Update: when non-empty, the element's membership is set to exactly these systems (added  to the new ones, removed from the others); when empty, the membership is left unchanged.  Invalid system ids are rejected (the update fails without changing any membership). - The load area always belongs to at least one system: it can never be left with none. If it  would be (its systems were deleted, or the requested membership could not be applied), it is  put back in the root system "Structure 0" and a warning is logged.
    system_i_ds: Optional[list[EID]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementLoadArea:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementLoadArea
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementLoadArea()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_base import ElementBase
        from .e_i_d import EID
        from .load_area_climatic_properties import LoadAreaClimaticProperties
        from .load_area_load_transfer import LoadAreaLoadTransfer
        from .load_area_mechanical_properties import LoadAreaMechanicalProperties
        from .pt3_d import Pt3D

        from .element_base import ElementBase
        from .e_i_d import EID
        from .load_area_climatic_properties import LoadAreaClimaticProperties
        from .load_area_load_transfer import LoadAreaLoadTransfer
        from .load_area_mechanical_properties import LoadAreaMechanicalProperties
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "climaticProperties": lambda n : setattr(self, 'climatic_properties', n.get_object_value(LoadAreaClimaticProperties)),
            "geomPtsList": lambda n : setattr(self, 'geom_pts_list', n.get_collection_of_object_values(Pt3D)),
            "loadTransferProperties": lambda n : setattr(self, 'load_transfer_properties', n.get_object_value(LoadAreaLoadTransfer)),
            "mechanicalProperties": lambda n : setattr(self, 'mechanical_properties', n.get_object_value(LoadAreaMechanicalProperties)),
            "systemIDs": lambda n : setattr(self, 'system_i_ds', n.get_collection_of_object_values(EID)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("climaticProperties", self.climatic_properties)
        writer.write_collection_of_object_values("geomPtsList", self.geom_pts_list)
        writer.write_object_value("loadTransferProperties", self.load_transfer_properties)
        writer.write_object_value("mechanicalProperties", self.mechanical_properties)
        writer.write_collection_of_object_values("systemIDs", self.system_i_ds)
        writer.write_additional_data_value(self.additional_data)
    

