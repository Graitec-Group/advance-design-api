from enum import Enum

class AiscResistanceWarning(str, Enum):
    None_ = "None",
    SlendernessRatioAbove200 = "SlendernessRatioAbove200",

