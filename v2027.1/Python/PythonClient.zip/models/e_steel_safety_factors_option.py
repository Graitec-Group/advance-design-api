from enum import Enum

class ESteelSafetyFactorsOption(str, Enum):
    ESafetyFactorsAuto = "eSafetyFactorsAuto",
    ESafetyFactorsImposed = "eSafetyFactorsImposed",

