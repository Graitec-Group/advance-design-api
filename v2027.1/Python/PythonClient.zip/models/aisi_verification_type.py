from enum import Enum

class AisiVerificationType(str, Enum):
    NoVerifStrength = "noVerifStrength",
    AxialTension_D2 = "AxialTension_D2",
    AxialCompression_E2 = "AxialCompression_E2",
    BendingMoment_F_XX = "BendingMoment_F_XX",
    BendingMoment_F_YY = "BendingMoment_F_YY",
    Shear_G = "Shear_G",
    WebCripgling_G2 = "WebCripgling_G2",
    CombinedMomentAndAxial_H1 = "CombinedMomentAndAxial_H1",
    CombinedMomentAndShear_H2 = "CombinedMomentAndShear_H2",
    CombinedMomentAndWebCrippling_H3 = "CombinedMomentAndWebCrippling_H3",
    CombinedMomentAndTrosion_H4 = "CombinedMomentAndTrosion_H4",

