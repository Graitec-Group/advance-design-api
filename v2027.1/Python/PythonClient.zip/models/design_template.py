from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate
    from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate
    from .design_template_element_type import DesignTemplateElementType
    from .design_template_material_type import DesignTemplateMaterialType
    from .e_c3_steel_linear_design_template import EC3SteelLinearDesignTemplate
    from .informational_element_base import InformationalElementBase
    from .linear_design_template import LinearDesignTemplate
    from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
    from .steel_linear_design_template import SteelLinearDesignTemplate

from .informational_element_base import InformationalElementBase

@dataclass
class DesignTemplate(InformationalElementBase, AdditionalDataHolder, Parsable):
    """
    Base class of every Expert design template (maps to the AD model object `som.Role`, called a"Role" in the code and a "Design template" in the user interface). A design template is a named set of design (Expert) properties that lives in a singlemodel-level pool and is then referenced by any number of structural elements - editing atemplate therefore changes every element that uses it. The properties themselves are NOT on thisclass: they live on the leaf class of the hierarchy, because they depend both on the materialfamily and on the design code configured on the model. The hierarchy is `DesignTemplate` -> per element type -> per material family -> per design code, e.g.AD.API.EC3SteelLinearDesignTemplate. The template name is the base-class member AD.API.InformationalElementBase.UserName, whichfor this entity maps to the "Name" field of the role object (NOT to "FullName" as it does for theother informational elements). It must be unique for a given (material family, element type) pairand is limited to 50 characters. Every model always contains one built-in default template (displayed as "None"). It belongs to nomaterial family nor element type - both AD.API.DesignTemplate.MaterialType and AD.API.DesignTemplate.ElementTyperead back as the "undefined" value - and it can neither be modified nor deleted through the API.Assigning it to an element detaches the element from any real template, and deliberately leavesthe element's own design properties untouched. List the templates of a model by querying`InformationalElementTypeEnum.DesignTemplate`. Available for the descriptive model only.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .design_template_element_type import DesignTemplateElementType

    # Kind of structural element this template applies to (maps to "ElementType"). Output only: it is implied by the concrete type of the template and is set by the engine whenthe template is created. A value sent on Create or Update is ignored. Default value : DesignTemplateElementType.undefined_element
    element_type: Optional[DesignTemplateElementType] = DesignTemplateElementType("undefined_element")
    from .design_template_material_type import DesignTemplateMaterialType

    # Material family this template applies to (maps to "MaterialType"). Output only: it is implied by the concrete type of the template and is set by the engine whenthe template is created. A value sent on Create or Update is ignored. Default value : DesignTemplateMaterialType.undefined_material
    material_type: Optional[DesignTemplateMaterialType] = DesignTemplateMaterialType("undefined_material")
    # Number of structural elements currently referencing this template (maps to"AssignmentNumber"). Output only: the engine maintains this counter when a template is assigned to or removed froman element. A value sent on Create or Update is ignored. A template whose assignment number isgreater than zero can still be deleted; the elements that used it silently fall back to thebuilt-in default template and keep their current design properties. Default value : 0
    assignment_number: Optional[int] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DesignTemplate:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DesignTemplate
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "AISCSteelLinearDesignTemplate".casefold():
            from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate

            return AISCSteelLinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "CSASteelLinearDesignTemplate".casefold():
            from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate

            return CSASteelLinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "EC3SteelLinearDesignTemplate".casefold():
            from .e_c3_steel_linear_design_template import EC3SteelLinearDesignTemplate

            return EC3SteelLinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "LinearDesignTemplate".casefold():
            from .linear_design_template import LinearDesignTemplate

            return LinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "NorthAmericanSteelLinearDesignTemplate".casefold():
            from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate

            return NorthAmericanSteelLinearDesignTemplate()
        if mapping_value and mapping_value.casefold() == "SteelLinearDesignTemplate".casefold():
            from .steel_linear_design_template import SteelLinearDesignTemplate

            return SteelLinearDesignTemplate()
        return DesignTemplate()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate
        from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate
        from .design_template_element_type import DesignTemplateElementType
        from .design_template_material_type import DesignTemplateMaterialType
        from .e_c3_steel_linear_design_template import EC3SteelLinearDesignTemplate
        from .informational_element_base import InformationalElementBase
        from .linear_design_template import LinearDesignTemplate
        from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
        from .steel_linear_design_template import SteelLinearDesignTemplate

        from .a_i_s_c_steel_linear_design_template import AISCSteelLinearDesignTemplate
        from .c_s_a_steel_linear_design_template import CSASteelLinearDesignTemplate
        from .design_template_element_type import DesignTemplateElementType
        from .design_template_material_type import DesignTemplateMaterialType
        from .e_c3_steel_linear_design_template import EC3SteelLinearDesignTemplate
        from .informational_element_base import InformationalElementBase
        from .linear_design_template import LinearDesignTemplate
        from .north_american_steel_linear_design_template import NorthAmericanSteelLinearDesignTemplate
        from .steel_linear_design_template import SteelLinearDesignTemplate

        fields: dict[str, Callable[[Any], None]] = {
            "assignmentNumber": lambda n : setattr(self, 'assignment_number', n.get_int_value()),
            "elementType": lambda n : setattr(self, 'element_type', n.get_enum_value(DesignTemplateElementType)),
            "materialType": lambda n : setattr(self, 'material_type', n.get_enum_value(DesignTemplateMaterialType)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_int_value("assignmentNumber", self.assignment_number)
        writer.write_enum_value("elementType", self.element_type)
        writer.write_enum_value("materialType", self.material_type)
        writer.write_additional_data_value(self.additional_data)
    

