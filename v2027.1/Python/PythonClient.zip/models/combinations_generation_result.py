from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID

@dataclass
class CombinationsGenerationResult(Parsable):
    """
    Outcome of the automatic combination generation.Deliberately narrow. The generation either writes combinations or it does not, andanything else worth knowing about the run - a template that could not be opened, amodel that yields nothing - is reported as a diagnostic in the response details ratherthan as a flag here.
    """
    # Internal identifiers of the combinations that were created, in generation order.Read them back with `GetInformationalElementsObject`. Empty when nothing wasgenerated - the reason is then in the response diagnostics.
    created_combinations: Optional[list[EID]] = None
    # The user visible number ("No.") of the first generated combination, 0 whennothing was generated. The same numbers are on the combinations themselves, as`Combination.IdComb`; this pair is here so that reporting the range does notcost a read of every object.
    first_identifier: Optional[int] = None
    # The user visible number ("No.") of the last generated combination, 0 when nothingwas generated.
    last_identifier: Optional[int] = None
    # True when the generator produced more combinations than the limit configured onthe model (`ModelProperties.MaxNumberMatrixGeneratedCombinations`) and the setwas therefore trimmed to it. AD.API.CombinationsGenerationResult.CreatedCombinations then holds thecombinations that were kept, and the ones beyond the limit do not exist.
    limit_exceeded: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CombinationsGenerationResult:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CombinationsGenerationResult
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CombinationsGenerationResult()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID

        from .e_i_d import EID

        fields: dict[str, Callable[[Any], None]] = {
            "createdCombinations": lambda n : setattr(self, 'created_combinations', n.get_collection_of_object_values(EID)),
            "firstIdentifier": lambda n : setattr(self, 'first_identifier', n.get_int_value()),
            "lastIdentifier": lambda n : setattr(self, 'last_identifier', n.get_int_value()),
            "limitExceeded": lambda n : setattr(self, 'limit_exceeded', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("createdCombinations", self.created_combinations)
        writer.write_int_value("firstIdentifier", self.first_identifier)
        writer.write_int_value("lastIdentifier", self.last_identifier)
        writer.write_bool_value("limitExceeded", self.limit_exceeded)
    

