from enum import Enum

class EConcreteLoadDuration(str, Enum):
    ShortTerm = "ShortTerm",
    MediumTerm = "MediumTerm",
    LongTerm = "LongTerm",
    None_ = "None",

