from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_permanent_load_situation import EPermanentLoadSituation

@dataclass
class EurocodePermanentActionSettings(Parsable):
    """
    The permanent actions row of the options grid: how they enter the combinations and withwhich partial factors.Only the UNFAVOURABLE gamma values are settings. The favourable ones are not stored onthe model at all - the standard's table supplies them - which is why there is no`GammaFavorable` here.
    """
    # gamma_G for the EQU situation. Writable only when `Situation` is `UserDefined`.
    gamma_equ: Optional[float] = None
    # gamma_G for the GEO situation. Writable only when `Situation` is`UserDefined`, and only read by the generation under the Italian standards.
    gamma_geo: Optional[float] = None
    # gamma_G for the STR/GEO situation. Writable only when `Situation` is `UserDefined`.
    gamma_str_geo: Optional[float] = None
    # Favorable, unfavorable, both, or your own values. Anything other than`UserDefined` makes the three gamma properties read only and recomputed fromthe standard's table.
    situation: Optional[EPermanentLoadSituation] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EurocodePermanentActionSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EurocodePermanentActionSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EurocodePermanentActionSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_permanent_load_situation import EPermanentLoadSituation

        from .e_permanent_load_situation import EPermanentLoadSituation

        fields: dict[str, Callable[[Any], None]] = {
            "gammaEqu": lambda n : setattr(self, 'gamma_equ', n.get_float_value()),
            "gammaGeo": lambda n : setattr(self, 'gamma_geo', n.get_float_value()),
            "gammaStrGeo": lambda n : setattr(self, 'gamma_str_geo', n.get_float_value()),
            "situation": lambda n : setattr(self, 'situation', n.get_enum_value(EPermanentLoadSituation)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("gammaEqu", self.gamma_equ)
        writer.write_float_value("gammaGeo", self.gamma_geo)
        writer.write_float_value("gammaStrGeo", self.gamma_str_geo)
        writer.write_enum_value("situation", self.situation)
    

