from enum import Enum

class EAiscDesignMethod(str, Enum):
    AllowableStrengthDesign = "AllowableStrengthDesign",
    LoadAndResistanceFactorDesign = "LoadAndResistanceFactorDesign",

