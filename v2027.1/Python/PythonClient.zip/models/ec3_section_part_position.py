from enum import Enum

class Ec3SectionPartPosition(str, Enum):
    LineAB_A = "LineAB_A",
    LineAB_B = "LineAB_B",
    LineBC_B = "LineBC_B",
    LineBC_C = "LineBC_C",
    LineCD_C = "LineCD_C",
    LineCD_D = "LineCD_D",
    LineDA_D = "LineDA_D",
    LineDA_A = "LineDA_A",
    LineAB_CD = "LineAB_CD",
    LineBC_DA = "LineBC_DA",
    LineAB = "LineAB",
    LineBC = "LineBC",
    LineCD = "LineCD",
    LineDA = "LineDA",
    LineEF_AB = "LineEF_AB",
    LineEF_E = "LineEF_E",
    LineEF_F = "LineEF_F",
    LineGH_CD = "LineGH_CD",
    LineGH_G = "LineGH_G",
    LineGH_H = "LineGH_H",

