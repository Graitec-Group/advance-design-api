from enum import Enum

class ETimberLoadDuration(str, Enum):
    Permanent = "Permanent",
    LongTerm = "LongTerm",
    MediumTerm = "MediumTerm",
    ShortTerm = "ShortTerm",
    Instantaneous = "Instantaneous",

