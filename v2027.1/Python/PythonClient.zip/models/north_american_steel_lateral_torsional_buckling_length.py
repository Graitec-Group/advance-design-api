from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .north_american_steel_lateral_torsional_buckling_parameters import NorthAmericanSteelLateralTorsionalBucklingParameters

@dataclass
class NorthAmericanSteelLateralTorsionalBucklingLength(Parsable):
    """
    Lateral-torsional buckling lengths of a North-American steel design template (maps to the ADmodel object `som.CM66RoleSDLateralTorsionBuckling`). The two flanges are treated independently, because the compressed flange is the one that needsrestraining and which flange is compressed depends on the moment sign: each has its own lengthand its own parameter set. Compared with AD.API.EC3SteelLateralTorsionalBucklingLength there is no buckling curve:`som.CM66RoleSDLateralTorsionBuckling` has no "LateralTorsionBucklingCurve" field, becauseAISC 360 and CAN/CSA S16 derive the resistance from the unbraced length and Cb rather than froma tabulated curve.
    """
    # Lateral-torsional buckling length of the LOWER flange (maps to "Ldi"). Unit : m Default value : 0.0
    lower_flange_length: Optional[float] = None
    # Lateral-torsional buckling parameter set of the LOWER flange (maps to"RoleSDLateralTorsionBucklingInferior"). Send null to leave the whole group unchanged on Update. Default value : null
    lower_flange_parameters: Optional[NorthAmericanSteelLateralTorsionalBucklingParameters] = None
    # Human-readable summary of the lower-flange end restraints (maps to "LowerFlange"). Output only and localized, see AD.API.NorthAmericanSteelLateralTorsionalBucklingLength.UpperFlangeRestraintSummary. Default value : null
    lower_flange_restraint_summary: Optional[str] = None
    # Lateral-torsional buckling length of the UPPER flange (maps to "Lds", from the French"longueur de deversement superieure" - the field name is shared with the French CM66 code,whose object shape the North-American codes reuse). THE SAME PHYSICAL QUANTITY ASAD.API.NorthAmericanSteelLateralTorsionalBucklingParameters.LengthValue ofAD.API.NorthAmericanSteelLateralTorsionalBucklingLength.UpperFlangeParameters - Advance Design stores it twice, and its dialog derivesthis one from the other when it closes. There are therefore two ways to set it, and both work: send this length ALONE and the flange's mode switches to "imposed" with it, exactly as typing itin the property list does; or send the flange's own mode and value and leave this at 0, and itis derived - under the North-American codes it simply follows the flange's value, whatever themode, so it carries the length for the imposed mode and the COEFFICIENT for the computedones. Either way the 0 default is never taken literally, so an update that sends this group withoutAD.API.NorthAmericanSteelLateralTorsionalBucklingLength.UpperFlangeParameters keeps the stored length. Note that SENDING that flangegroup does reset the properties of the flange you leave unset, as every group does. Unit : m Default value : 0.0
    upper_flange_length: Optional[float] = None
    # Lateral-torsional buckling parameter set of the UPPER flange (maps to"RoleSDLateralTorsionBucklingSuperior"). Send null to leave the whole group unchanged on Update. Default value : null
    upper_flange_parameters: Optional[NorthAmericanSteelLateralTorsionalBucklingParameters] = None
    # Human-readable summary of the upper-flange end restraints, e.g. "Pinned / Pinned" (maps to"UpperFlange"). Output only and localized: Advance Design rebuilds this string fromAD.API.NorthAmericanSteelLateralTorsionalBucklingLength.UpperFlangeParameters (its `StartRestraint` and `EndRestraint`), so avalue sent here is overwritten. Do not parse it - read the restraints instead. Default value : null
    upper_flange_restraint_summary: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NorthAmericanSteelLateralTorsionalBucklingLength:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NorthAmericanSteelLateralTorsionalBucklingLength
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NorthAmericanSteelLateralTorsionalBucklingLength()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .north_american_steel_lateral_torsional_buckling_parameters import NorthAmericanSteelLateralTorsionalBucklingParameters

        from .north_american_steel_lateral_torsional_buckling_parameters import NorthAmericanSteelLateralTorsionalBucklingParameters

        fields: dict[str, Callable[[Any], None]] = {
            "lowerFlangeLength": lambda n : setattr(self, 'lower_flange_length', n.get_float_value()),
            "lowerFlangeParameters": lambda n : setattr(self, 'lower_flange_parameters', n.get_object_value(NorthAmericanSteelLateralTorsionalBucklingParameters)),
            "lowerFlangeRestraintSummary": lambda n : setattr(self, 'lower_flange_restraint_summary', n.get_str_value()),
            "upperFlangeLength": lambda n : setattr(self, 'upper_flange_length', n.get_float_value()),
            "upperFlangeParameters": lambda n : setattr(self, 'upper_flange_parameters', n.get_object_value(NorthAmericanSteelLateralTorsionalBucklingParameters)),
            "upperFlangeRestraintSummary": lambda n : setattr(self, 'upper_flange_restraint_summary', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("lowerFlangeLength", self.lower_flange_length)
        writer.write_object_value("lowerFlangeParameters", self.lower_flange_parameters)
        writer.write_str_value("lowerFlangeRestraintSummary", self.lower_flange_restraint_summary)
        writer.write_float_value("upperFlangeLength", self.upper_flange_length)
        writer.write_object_value("upperFlangeParameters", self.upper_flange_parameters)
        writer.write_str_value("upperFlangeRestraintSummary", self.upper_flange_restraint_summary)
    

