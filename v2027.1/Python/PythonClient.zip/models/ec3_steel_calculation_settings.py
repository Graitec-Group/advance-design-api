from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .ec3_steel_safety_factor_settings import Ec3SteelSafetyFactorSettings
    from .ec3_steel_verification_settings import Ec3SteelVerificationSettings
    from .steel_angle_verification_settings import SteelAngleVerificationSettings
    from .steel_buckling_settings import SteelBucklingSettings
    from .steel_calculation_sequence_settings import SteelCalculationSequenceSettings
    from .steel_calculation_settings import SteelCalculationSettings
    from .steel_optimization_settings import SteelOptimizationSettings
    from .steel_profile_sorting_settings import SteelProfileSortingSettings

from .steel_calculation_settings import SteelCalculationSettings

@dataclass
class Ec3SteelCalculationSettings(SteelCalculationSettings, AdditionalDataHolder, Parsable):
    """
    The steel calculation settings of a model designed to Eurocode 3 - either generation, andincluding the Italian NTC standards, which are national applications of it.One sub-object per page of the Calculation Settings dialog. All of them are optional: anull sub-object leaves that whole page as the model has it, and inside a sub-object a nullproperty leaves that one setting alone. So changing a single switch is a request carryingone sub-object with one property in it.PREFER A PARTIAL REQUEST TO A WHOLE-OBJECT ECHO. Posting back everything a`GetModelSettings` returned works and changes nothing, but it will report a handful ofadvisory warnings: several properties are only read while another switch is on - the firetime, the optimisation thresholds, the iteration ceiling, the profile limits, thecomplete-calculation count - and the 2nd-generation sub-objects are not read at all on a1st-generation model. Sending only what you mean to change keeps the diagnostics meaningful.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The Angle verification page. Left untouched when null.
    angle_verification: Optional[SteelAngleVerificationSettings] = None
    # The Buckling page. Left untouched when null.
    buckling: Optional[SteelBucklingSettings] = None
    # The Calculation sequence page. Left untouched when null.
    calculation_sequence: Optional[SteelCalculationSequenceSettings] = None
    # The Optimisation page. Left untouched when null.
    optimization: Optional[SteelOptimizationSettings] = None
    # The Sort profiles page. Left untouched when null.
    profile_sorting: Optional[SteelProfileSortingSettings] = None
    # The Safety factors page. Left untouched when null.
    safety_factors: Optional[Ec3SteelSafetyFactorSettings] = None
    # The Verification page. Left untouched when null.
    verification: Optional[Ec3SteelVerificationSettings] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Ec3SteelCalculationSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Ec3SteelCalculationSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Ec3SteelCalculationSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .ec3_steel_safety_factor_settings import Ec3SteelSafetyFactorSettings
        from .ec3_steel_verification_settings import Ec3SteelVerificationSettings
        from .steel_angle_verification_settings import SteelAngleVerificationSettings
        from .steel_buckling_settings import SteelBucklingSettings
        from .steel_calculation_sequence_settings import SteelCalculationSequenceSettings
        from .steel_calculation_settings import SteelCalculationSettings
        from .steel_optimization_settings import SteelOptimizationSettings
        from .steel_profile_sorting_settings import SteelProfileSortingSettings

        from .ec3_steel_safety_factor_settings import Ec3SteelSafetyFactorSettings
        from .ec3_steel_verification_settings import Ec3SteelVerificationSettings
        from .steel_angle_verification_settings import SteelAngleVerificationSettings
        from .steel_buckling_settings import SteelBucklingSettings
        from .steel_calculation_sequence_settings import SteelCalculationSequenceSettings
        from .steel_calculation_settings import SteelCalculationSettings
        from .steel_optimization_settings import SteelOptimizationSettings
        from .steel_profile_sorting_settings import SteelProfileSortingSettings

        fields: dict[str, Callable[[Any], None]] = {
            "angleVerification": lambda n : setattr(self, 'angle_verification', n.get_object_value(SteelAngleVerificationSettings)),
            "buckling": lambda n : setattr(self, 'buckling', n.get_object_value(SteelBucklingSettings)),
            "calculationSequence": lambda n : setattr(self, 'calculation_sequence', n.get_object_value(SteelCalculationSequenceSettings)),
            "optimization": lambda n : setattr(self, 'optimization', n.get_object_value(SteelOptimizationSettings)),
            "profileSorting": lambda n : setattr(self, 'profile_sorting', n.get_object_value(SteelProfileSortingSettings)),
            "safetyFactors": lambda n : setattr(self, 'safety_factors', n.get_object_value(Ec3SteelSafetyFactorSettings)),
            "verification": lambda n : setattr(self, 'verification', n.get_object_value(Ec3SteelVerificationSettings)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("angleVerification", self.angle_verification)
        writer.write_object_value("buckling", self.buckling)
        writer.write_object_value("calculationSequence", self.calculation_sequence)
        writer.write_object_value("optimization", self.optimization)
        writer.write_object_value("profileSorting", self.profile_sorting)
        writer.write_object_value("safetyFactors", self.safety_factors)
        writer.write_object_value("verification", self.verification)
        writer.write_additional_data_value(self.additional_data)
    

