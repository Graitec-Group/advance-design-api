from enum import Enum

class DesignCalculationType(str, Enum):
    Concrete = "Concrete",
    Steel = "Steel",
    Timber = "Timber",
    Composite = "Composite",

