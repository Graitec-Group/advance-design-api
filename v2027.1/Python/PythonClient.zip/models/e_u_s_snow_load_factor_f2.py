from enum import Enum

class EUSSnowLoadFactorF2(str, Enum):
    RoofNotShedding = "RoofNotShedding",
    RoofOthers = "RoofOthers",

