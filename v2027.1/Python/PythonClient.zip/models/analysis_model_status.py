from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .design_expert_status import DesignExpertStatus
    from .e_analysis_model_state import EAnalysisModelState
    from .e_mesh_state import EMeshState

@dataclass
class AnalysisModelStatus(Parsable):
    """
    A read-only snapshot of where the current model stands in the mesh -> finite element ->design chain: whether an analysis model exists, whether it is meshed, whether it wascalculated, which design experts have run, and how construction stages stand.PURELY A READ. It creates nothing, opens nothing and runs nothing - in particular it doesnot open the analysis model when the session has not opened it, and it does not run the modelverification. It is cheap: every value below is a flag or a counter the model alreadycarries, and no element of the model is visited. Call it as often as you like.FLAT ON PURPOSE. The mesh, finite element and construction stage values are prefixedproperties rather than sub-objects, so that no caller has to null-check a group beforereading a value that is always there - a generated client cannot express a non-nullablesub-object. The design families are the one exception: they are a list because there is oneentry per family.When AD.API.AnalysisModelStatus.HasAnalysisModel is false, nothing below it is meaningful: every value isat its default. In the one further case where nothing more could be read - an analysis modelthe session has not opened, which a status read must not open - the same is true and awarning in the response diagnostics says so.
    """
    from .e_mesh_state import EMeshState

    # State of the finite element mesh: none, complete, or incomplete. A tri-state and not aboolean because Advance Design lets a calculation run on an incomplete mesh - see`eMeshState.mesh_incomplete`.The values are Advance Design's own (`mesh_no` / `mesh_available` /`mesh_incomplete`): `eMeshState` shares its definition with the native meshenumeration the mesher and the analysis model use, so the two cannot drift.Default value: eMeshState.mesh_no
    mesh_state: Optional[EMeshState] = EMeshState("mesh_no")
    from .e_analysis_model_state import EAnalysisModelState

    # The one value most callers need: where the model stands in the work-flow. Derived from theproperties above, which are all on this same object - so nothing is hidden and no secondcall is needed to see why.The rule, first match wins:1. `NotCreated` - AD.API.AnalysisModelStatus.HasAnalysisModel is false.2. `OutOfDate` - AD.API.AnalysisModelStatus.FemIsCalculated and notAD.API.AnalysisModelStatus.FemIsUpToDate.3. `Calculated` - AD.API.AnalysisModelStatus.FemIsCalculated.4. `Meshed` - AD.API.AnalysisModelStatus.MeshState is not `mesh_no`.5. `Created` - otherwise, which also covers an analysis model the session hasnot opened and that a status read must not open (a warning in the diagnostics says so).Note what is NOT in the rule: the design experts. A model can be `Calculated` withevery family uncalculated, and that is the normal state right after `LaunchAnalysis`;AD.API.AnalysisModelStatus.Design is the answer to that question, and no single summary can carry fourindependent booleans.Note also that an INCOMPLETE mesh does not change the summary: rules 2 to 4 only askwhether a mesh exists, because Advance Design allows a calculation on an incomplete one.Read AD.API.AnalysisModelStatus.MeshState when it matters.`OutOfDate` IS NEVER REPORTED IN A HEADLESS API SESSION. The flag rule 2 tests ismaintained by the desktop application only - see AD.API.AnalysisModelStatus.FemIsUpToDate. It appearsfor a project saved stale by Advance Design, or for one converted on open. Do not use thesummary to decide whether YOUR changes have invalidated the results: it cannot know.Default value: eAnalysisModelState.NotCreated
    overall_state: Optional[EAnalysisModelState] = EAnalysisModelState("NotCreated")
    # True when every construction stage has been calculated - the condition the design commandsof Advance Design check before they will run on a staged model.`null` when the question does not apply: when the model defines no stage, or when theanalysis model could not be read. This is not caution - the model itself answers`true` for a model without stages, because "every stage is calculated" is vacuouslytrue of no stages, and reporting that `true` would read as "the staged calculation isdone" on a model that has no stages at all.Default value: null
    all_stages_calculated: Optional[bool] = None
    # One entry per material family that has a design engine - always all four of`DesignCalculationType`, in that order, so a caller can index the list or match onAD.API.DesignExpertStatus.Family without checking for absent entries. Empty onlywhen the analysis model could not be read at all.Default value: four entries, all at their own defaults
    design: Optional[list[DesignExpertStatus]] = None
    # How many analysis cases - load cases, combinations and envelopes - carry finite elementresults. The count of the analyses whose state is "selected, done, OK", which is exactlythe set Advance Design offers in a result table or a report.0 with AD.API.AnalysisModelStatus.FemIsCalculated true is possible and means the solve succeeded but noanalysis kept its results - read the diagnostics of the last `LaunchAnalysis`.Default value: 0
    fem_calculated_cases_count: Optional[int] = None
    # True when the finite element analysis has been run and produced results - the analysismodel's own `IsAnalysisCalculated` flag, and the precondition`LaunchDesignCalculation` refuses to run without.Default value: false
    fem_is_calculated: Optional[bool] = None
    # True when the analysis model still matches the finite element results on disk - the`Updated` property the design engines and the analysis navigator read.THIS IS NOT A FRESHNESS GUARANTEE IN AN API SESSION, and the reason is worth readingbefore it is used as a gate. The flag is set to `true` by a successful solve and setback to `false` only by the user interface listener that reacts to a model change(`InvalidateAnalysisModel`, raised by the Advance Design navigator and snap-ins). AnAPI session installs no such listener, so once `LaunchAnalysis` has succeeded thisstays `true` no matter what is created, updated or deleted afterwards.`false` is therefore trustworthy - something really did invalidate the model, whichin practice means a project saved stale by the desktop application, or a converted one.`true` only means "nothing reported an invalidation". If you changed the modelthrough this API and need results that match it, call `LaunchAnalysis` again; do notask this flag.Default value: false
    fem_is_up_to_date: Optional[bool] = None
    # True when the project holds an analysis model. A model created through this API has noneuntil `LaunchAnalysis` is called; a project opened from a file has one when it wasever calculated.An Advance Design project holds at most ONE analysis model, so this is a plain boolean andthere is nothing to name or select.Default value: false
    has_analysis_model: Optional[bool] = None
    # True when the model defines construction stages. Read from the analysis model when it isavailable, from the descriptive model otherwise - stages are defined on the descriptivemodel, so a staged model that was never calculated still reports `true`.Default value: false
    has_construction_stages: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AnalysisModelStatus:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AnalysisModelStatus
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AnalysisModelStatus()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .design_expert_status import DesignExpertStatus
        from .e_analysis_model_state import EAnalysisModelState
        from .e_mesh_state import EMeshState

        from .design_expert_status import DesignExpertStatus
        from .e_analysis_model_state import EAnalysisModelState
        from .e_mesh_state import EMeshState

        fields: dict[str, Callable[[Any], None]] = {
            "allStagesCalculated": lambda n : setattr(self, 'all_stages_calculated', n.get_bool_value()),
            "design": lambda n : setattr(self, 'design', n.get_collection_of_object_values(DesignExpertStatus)),
            "femCalculatedCasesCount": lambda n : setattr(self, 'fem_calculated_cases_count', n.get_int_value()),
            "femIsCalculated": lambda n : setattr(self, 'fem_is_calculated', n.get_bool_value()),
            "femIsUpToDate": lambda n : setattr(self, 'fem_is_up_to_date', n.get_bool_value()),
            "hasAnalysisModel": lambda n : setattr(self, 'has_analysis_model', n.get_bool_value()),
            "hasConstructionStages": lambda n : setattr(self, 'has_construction_stages', n.get_bool_value()),
            "meshState": lambda n : setattr(self, 'mesh_state', n.get_enum_value(EMeshState)),
            "overallState": lambda n : setattr(self, 'overall_state', n.get_enum_value(EAnalysisModelState)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("allStagesCalculated", self.all_stages_calculated)
        writer.write_collection_of_object_values("design", self.design)
        writer.write_int_value("femCalculatedCasesCount", self.fem_calculated_cases_count)
        writer.write_bool_value("femIsCalculated", self.fem_is_calculated)
        writer.write_bool_value("femIsUpToDate", self.fem_is_up_to_date)
        writer.write_bool_value("hasAnalysisModel", self.has_analysis_model)
        writer.write_bool_value("hasConstructionStages", self.has_construction_stages)
        writer.write_enum_value("meshState", self.mesh_state)
        writer.write_enum_value("overallState", self.overall_state)
    

