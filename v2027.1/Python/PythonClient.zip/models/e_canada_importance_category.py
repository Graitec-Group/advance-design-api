from enum import Enum

class ECanadaImportanceCategory(str, Enum):
    Low = "Low",
    Normal = "Normal",
    High = "High",
    PostDisaster = "PostDisaster",

