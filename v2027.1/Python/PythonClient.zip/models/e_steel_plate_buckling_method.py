from enum import Enum

class ESteelPlateBucklingMethod(str, Enum):
    EMethodWebBucklingEffectiveCrossSections = "eMethodWebBucklingEffectiveCrossSections",
    EMethodWebBucklingReducedStresses = "eMethodWebBucklingReducedStresses",
    EMethodWebBucklingUndefined = "eMethodWebBucklingUndefined",

