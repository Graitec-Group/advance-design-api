from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_aisc_class_per_loading_pattern import ResAiscClassPerLoadingPattern
    from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

@dataclass
class ResAiscCrossSectionClass(ResNorthAmericaSteelLinearDesignData, AdditionalDataHolder, Parsable):
    """
    Cross-section classification under a North American code. Native: aisc_Class.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Classification per stress pattern - four entries, one per member ofAD.API.AiscClassLoadingPattern.
    class_per_loading_pattern: Optional[list[ResAiscClassPerLoadingPattern]] = None
    # True when the user forced the class on the design template instead of letting the engine computeit. Native: bIsImposed.
    is_imposed: Optional[bool] = None
    # Number of plates the cross-section was split into, at most 5. Native: iNbParts. It is the lengthof every pattern's AD.API.ResAiscClassPerLoadingPattern.Parts list, and 0 for an imposedclassification.
    part_count: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAiscCrossSectionClass:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAiscCrossSectionClass
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAiscCrossSectionClass()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_aisc_class_per_loading_pattern import ResAiscClassPerLoadingPattern
        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

        from .res_aisc_class_per_loading_pattern import ResAiscClassPerLoadingPattern
        from .res_north_america_steel_linear_design_data import ResNorthAmericaSteelLinearDesignData

        fields: dict[str, Callable[[Any], None]] = {
            "classPerLoadingPattern": lambda n : setattr(self, 'class_per_loading_pattern', n.get_collection_of_object_values(ResAiscClassPerLoadingPattern)),
            "isImposed": lambda n : setattr(self, 'is_imposed', n.get_bool_value()),
            "partCount": lambda n : setattr(self, 'part_count', n.get_int_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_collection_of_object_values("classPerLoadingPattern", self.class_per_loading_pattern)
        writer.write_bool_value("isImposed", self.is_imposed)
        writer.write_int_value("partCount", self.part_count)
        writer.write_additional_data_value(self.additional_data)
    

