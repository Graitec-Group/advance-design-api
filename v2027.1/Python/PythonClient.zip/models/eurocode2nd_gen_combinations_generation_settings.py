from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .combinations_generation_settings import CombinationsGenerationSettings
    from .eurocode2nd_gen_permanent_action_row import Eurocode2ndGenPermanentActionRow
    from .eurocode2nd_gen_project_situations import Eurocode2ndGenProjectSituations
    from .eurocode2nd_gen_variable_action_row import Eurocode2ndGenVariableActionRow

from .combinations_generation_settings import CombinationsGenerationSettings

@dataclass
class Eurocode2ndGenCombinationsGenerationSettings(CombinationsGenerationSettings, AdditionalDataHolder, Parsable):
    """
    Settings of the 2nd generation Eurocode (EN 1990:2023).EXPOSED BUT NOT YET REACHABLE. The standard is still under development, and no sessionlocalization resolves to it, so `GetModelSettings` will not returnthis type and `SetModelSettings` will refuse it - the activestandard has to match. It is here so that the shape is settled and the same for allfive standards.Two things differ from the 1st generation settings beyond the field names:- The per-family coefficients are LISTS of rows, one per action family, matched by`Family`. Rows the request does not name are left alone; a family the model has norow for is refused, because the model vector cannot grow from here - building thoserows is the model creation path's job.- No coefficient is recomputed from its category. The 2nd generationcategory-to-psi derivation still lives in the desktop options dialog, so what is senthere is what gets stored. That is the one place where this standard is deliberatelyNOT uniform with the other four, and it will change when that derivation is shared.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The permanent action rows to update, matched by family. Left untouched when null;an empty list also changes nothing.
    permanent_actions: Optional[list[Eurocode2ndGenPermanentActionRow]] = None
    # Which verification cases and SLS combinations are generated. Left untouched when null.
    project_situations: Optional[Eurocode2ndGenProjectSituations] = None
    # The variable action rows to update, matched by family. Left untouched when null;an empty list also changes nothing.
    variable_actions: Optional[list[Eurocode2ndGenVariableActionRow]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Eurocode2ndGenCombinationsGenerationSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Eurocode2ndGenCombinationsGenerationSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Eurocode2ndGenCombinationsGenerationSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .combinations_generation_settings import CombinationsGenerationSettings
        from .eurocode2nd_gen_permanent_action_row import Eurocode2ndGenPermanentActionRow
        from .eurocode2nd_gen_project_situations import Eurocode2ndGenProjectSituations
        from .eurocode2nd_gen_variable_action_row import Eurocode2ndGenVariableActionRow

        from .combinations_generation_settings import CombinationsGenerationSettings
        from .eurocode2nd_gen_permanent_action_row import Eurocode2ndGenPermanentActionRow
        from .eurocode2nd_gen_project_situations import Eurocode2ndGenProjectSituations
        from .eurocode2nd_gen_variable_action_row import Eurocode2ndGenVariableActionRow

        fields: dict[str, Callable[[Any], None]] = {
            "permanentActions": lambda n : setattr(self, 'permanent_actions', n.get_collection_of_object_values(Eurocode2ndGenPermanentActionRow)),
            "projectSituations": lambda n : setattr(self, 'project_situations', n.get_object_value(Eurocode2ndGenProjectSituations)),
            "variableActions": lambda n : setattr(self, 'variable_actions', n.get_collection_of_object_values(Eurocode2ndGenVariableActionRow)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_collection_of_object_values("permanentActions", self.permanent_actions)
        writer.write_object_value("projectSituations", self.project_situations)
        writer.write_collection_of_object_values("variableActions", self.variable_actions)
        writer.write_additional_data_value(self.additional_data)
    

