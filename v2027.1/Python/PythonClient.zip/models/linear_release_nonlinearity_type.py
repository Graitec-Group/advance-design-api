from enum import Enum

class LinearReleaseNonlinearityType(str, Enum):
    None_ = "none",
    Compression_only = "compression_only",
    Tension_only = "tension_only",

