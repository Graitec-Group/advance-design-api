from enum import Enum

class AiscResistanceCheckId(str, Enum):
    Axial = "Axial",
    ShearY = "ShearY",
    ShearZ = "ShearZ",
    BendingYY = "BendingYY",
    BendingZZ = "BendingZZ",
    Torsion = "Torsion",
    CombinedForces = "CombinedForces",

