from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class NonLinearFEMInitialDeformationSegment(Parsable):
    """
    One segment of a parabolic initial deformation (maps to the AD model object`som.InitialDeformationSegment`). The deformation is given at three points of the segment - start, middle and end - by a lateraltranslation Ty, a vertical translation Tz and a torsional rotation Rx.
    """
    # End position of the segment along the element (maps to "AbscissaEnd"). Unit : m Default value : 0.0
    abscissa_end: Optional[float] = None
    # Start position of the segment along the element (maps to "AbscissaStart"). Unit : m Default value : 0.0
    abscissa_start: Optional[float] = None
    # Torsional rotation Rx at the end of the segment (maps to "EndPointRx"). Unit : rad Default value : 0.0
    end_point_rx: Optional[float] = None
    # Lateral translation Ty at the end of the segment (maps to "EndPointTy"). Unit : m Default value : 0.0
    end_point_ty: Optional[float] = None
    # Vertical translation Tz at the end of the segment (maps to "EndPointTz"). Unit : m Default value : 0.0
    end_point_tz: Optional[float] = None
    # Torsional rotation Rx at the middle of the segment (maps to "MiddlePointRx"). Unit : rad Default value : 0.0
    middle_point_rx: Optional[float] = None
    # Lateral translation Ty at the middle of the segment (maps to "MiddlePointTy"). Unit : m Default value : 0.0
    middle_point_ty: Optional[float] = None
    # Vertical translation Tz at the middle of the segment (maps to "MiddlePointTz"). Unit : m Default value : 0.0
    middle_point_tz: Optional[float] = None
    # Torsional rotation Rx at the start of the segment (maps to "StartPointRx"). Unit : rad Default value : 0.0
    start_point_rx: Optional[float] = None
    # Lateral translation Ty at the start of the segment (maps to "StartPointTy"). Unit : m Default value : 0.0
    start_point_ty: Optional[float] = None
    # Vertical translation Tz at the start of the segment (maps to "StartPointTz"). Unit : m Default value : 0.0
    start_point_tz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NonLinearFEMInitialDeformationSegment:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NonLinearFEMInitialDeformationSegment
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NonLinearFEMInitialDeformationSegment()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "abscissaEnd": lambda n : setattr(self, 'abscissa_end', n.get_float_value()),
            "abscissaStart": lambda n : setattr(self, 'abscissa_start', n.get_float_value()),
            "endPointRx": lambda n : setattr(self, 'end_point_rx', n.get_float_value()),
            "endPointTy": lambda n : setattr(self, 'end_point_ty', n.get_float_value()),
            "endPointTz": lambda n : setattr(self, 'end_point_tz', n.get_float_value()),
            "middlePointRx": lambda n : setattr(self, 'middle_point_rx', n.get_float_value()),
            "middlePointTy": lambda n : setattr(self, 'middle_point_ty', n.get_float_value()),
            "middlePointTz": lambda n : setattr(self, 'middle_point_tz', n.get_float_value()),
            "startPointRx": lambda n : setattr(self, 'start_point_rx', n.get_float_value()),
            "startPointTy": lambda n : setattr(self, 'start_point_ty', n.get_float_value()),
            "startPointTz": lambda n : setattr(self, 'start_point_tz', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("abscissaEnd", self.abscissa_end)
        writer.write_float_value("abscissaStart", self.abscissa_start)
        writer.write_float_value("endPointRx", self.end_point_rx)
        writer.write_float_value("endPointTy", self.end_point_ty)
        writer.write_float_value("endPointTz", self.end_point_tz)
        writer.write_float_value("middlePointRx", self.middle_point_rx)
        writer.write_float_value("middlePointTy", self.middle_point_ty)
        writer.write_float_value("middlePointTz", self.middle_point_tz)
        writer.write_float_value("startPointRx", self.start_point_rx)
        writer.write_float_value("startPointTy", self.start_point_ty)
        writer.write_float_value("startPointTz", self.start_point_tz)
    

