from enum import Enum

class Ec3ResistanceCheckId(str, Enum):
    Axial = "Axial",
    ShearY = "ShearY",
    ShearZ = "ShearZ",
    BendingYY = "BendingYY",
    BendingZZ = "BendingZZ",
    BendingYYAndAxial = "BendingYYAndAxial",
    BendingZZAndAxial = "BendingZZAndAxial",
    BendingYYAndShearZ = "BendingYYAndShearZ",
    BendingZZAndShearY = "BendingZZAndShearY",
    BiaxialBending = "BiaxialBending",
    Torsion = "Torsion",
    ElasticStress = "ElasticStress",

