from enum import Enum

class CompositeDesignCode(str, Enum):
    Eurocode = "eurocode",
    Aisc_360_16 = "aisc_360_16",

