from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_timber_combination_type import ETimberCombinationType
    from .e_timber_load_duration import ETimberLoadDuration

@dataclass
class CombinationTimberVerification(Parsable):
    """
    Properties of a timber strength or fire verification for one combination (maps to the"TypeProfile"/"DurationProfile" and "TypeFire"/"DurationFire" pairs of the AD model object`som.TimberFields`). Every property is optional: a property left null is filled with its default value.
    """
    # Load-duration class of the combination, which drives kmod and kdef. Default value : null (Permanent)
    duration: Optional[ETimberLoadDuration] = None
    # Limit state under which the combination is checked. Default value : null (Uls)
    type: Optional[ETimberCombinationType] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CombinationTimberVerification:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CombinationTimberVerification
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CombinationTimberVerification()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_timber_combination_type import ETimberCombinationType
        from .e_timber_load_duration import ETimberLoadDuration

        from .e_timber_combination_type import ETimberCombinationType
        from .e_timber_load_duration import ETimberLoadDuration

        fields: dict[str, Callable[[Any], None]] = {
            "duration": lambda n : setattr(self, 'duration', n.get_enum_value(ETimberLoadDuration)),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(ETimberCombinationType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("duration", self.duration)
        writer.write_enum_value("type", self.type)
    

