from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .combinations_generation_settings import CombinationsGenerationSettings
    from .eurocode_live_load_settings import EurocodeLiveLoadSettings
    from .eurocode_permanent_action_settings import EurocodePermanentActionSettings
    from .eurocode_project_situations import EurocodeProjectSituations
    from .eurocode_snow_load_settings import EurocodeSnowLoadSettings
    from .eurocode_temperature_load_settings import EurocodeTemperatureLoadSettings
    from .eurocode_wind_load_settings import EurocodeWindLoadSettings

from .combinations_generation_settings import CombinationsGenerationSettings

@dataclass
class EurocodeCombinationsGenerationSettings(CombinationsGenerationSettings, AdditionalDataHolder, Parsable):
    """
    Settings of the Eurocode family: EN 1990 1st generation with its national annexes,Eurocode Italia, and Italy NTC 2018. They share one set of fields on the model; thestandard changes which coefficient tables the categories resolve against, and whetherthe GEO situation exists at all.Every group is nullable and unset by default, so a request changes only the groups itcarries. Sending the whole object back after a `Get` is also fine: the read onlyproperties are ignored and the derived coefficients simply resolve to the same values.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The live load row of the variable actions. Left untouched when null.
    live_loads: Optional[EurocodeLiveLoadSettings] = None
    # The permanent actions row. Left untouched when null.
    permanent_actions: Optional[EurocodePermanentActionSettings] = None
    # Which project situations are generated. Left untouched when null.
    project_situations: Optional[EurocodeProjectSituations] = None
    # The snow row of the variable actions. Left untouched when null.
    snow_loads: Optional[EurocodeSnowLoadSettings] = None
    # The temperature row of the variable actions. Left untouched when null.
    temperature_loads: Optional[EurocodeTemperatureLoadSettings] = None
    # The wind row of the variable actions. Left untouched when null.
    wind_loads: Optional[EurocodeWindLoadSettings] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EurocodeCombinationsGenerationSettings:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EurocodeCombinationsGenerationSettings
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EurocodeCombinationsGenerationSettings()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .combinations_generation_settings import CombinationsGenerationSettings
        from .eurocode_live_load_settings import EurocodeLiveLoadSettings
        from .eurocode_permanent_action_settings import EurocodePermanentActionSettings
        from .eurocode_project_situations import EurocodeProjectSituations
        from .eurocode_snow_load_settings import EurocodeSnowLoadSettings
        from .eurocode_temperature_load_settings import EurocodeTemperatureLoadSettings
        from .eurocode_wind_load_settings import EurocodeWindLoadSettings

        from .combinations_generation_settings import CombinationsGenerationSettings
        from .eurocode_live_load_settings import EurocodeLiveLoadSettings
        from .eurocode_permanent_action_settings import EurocodePermanentActionSettings
        from .eurocode_project_situations import EurocodeProjectSituations
        from .eurocode_snow_load_settings import EurocodeSnowLoadSettings
        from .eurocode_temperature_load_settings import EurocodeTemperatureLoadSettings
        from .eurocode_wind_load_settings import EurocodeWindLoadSettings

        fields: dict[str, Callable[[Any], None]] = {
            "liveLoads": lambda n : setattr(self, 'live_loads', n.get_object_value(EurocodeLiveLoadSettings)),
            "permanentActions": lambda n : setattr(self, 'permanent_actions', n.get_object_value(EurocodePermanentActionSettings)),
            "projectSituations": lambda n : setattr(self, 'project_situations', n.get_object_value(EurocodeProjectSituations)),
            "snowLoads": lambda n : setattr(self, 'snow_loads', n.get_object_value(EurocodeSnowLoadSettings)),
            "temperatureLoads": lambda n : setattr(self, 'temperature_loads', n.get_object_value(EurocodeTemperatureLoadSettings)),
            "windLoads": lambda n : setattr(self, 'wind_loads', n.get_object_value(EurocodeWindLoadSettings)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("liveLoads", self.live_loads)
        writer.write_object_value("permanentActions", self.permanent_actions)
        writer.write_object_value("projectSituations", self.project_situations)
        writer.write_object_value("snowLoads", self.snow_loads)
        writer.write_object_value("temperatureLoads", self.temperature_loads)
        writer.write_object_value("windLoads", self.wind_loads)
        writer.write_additional_data_value(self.additional_data)
    

